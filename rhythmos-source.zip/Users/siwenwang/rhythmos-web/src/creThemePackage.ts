// creThemePackage.ts

export interface CREThemePackage {
  id: string
  title: string
  description: string
  recommendedTone: string
  taskType: string
  phrases: string[]
}

export const creThemePackages: CREThemePackage[] = [
  {
    id: 'overwhelm_calm',
    title: '🕊️ Calm the Overwhelm',
    description: 'Use gentle, grounding CRE cues to soothe anxious starts.',
    recommendedTone: 'gentle',
    taskType: 'minimal',
    phrases: [
      'You don’t need to be ready. You just need to breathe.',
      'Begin with the smallest step you can see.',
      'Even one pause is a form of progress.',
      'This moment is enough to begin.',
      'Let presence come before pressure.'
    ]
  },
  {
    id: 'energy_direct',
    title: '🔥 Energy & Action',
    description: 'Use directive, bold cues to energize your motion.',
    recommendedTone: 'directive',
    taskType: 'challenge',
    phrases: [
      'Push the block. No delay.',
      'First move wins. You’re in it now.',
      'Act fast. Think later.',
      'Don’t overthink. Start the action.',
      'Move before your doubts grow louder.'
    ]
  }
]