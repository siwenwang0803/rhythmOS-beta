// personaIntentClassifier.ts

export type PersonaId = 'caelum' | 'lucis' | 'aurelia' | 'niveus' | 'rhea'

interface MatchRule {
  keywords: string[]
  persona: PersonaId
}

const matchRules: MatchRule[] = [
  {
    persona: 'caelum',
    keywords: ['confident', 'vision', 'leader', 'strong', 'mature', 'decisive', 'powerful', 'calm']
  },
  {
    persona: 'lucis',
    keywords: ['action', 'decide', 'drive', 'discipline', 'fire', 'motivate', 'push', 'momentum']
  },
  {
    persona: 'niveus',
    keywords: ['clear', 'logic', 'rational', 'analyze', 'objectivity', 'focus', 'calculated']
  },
  {
    persona: 'aurelia',
    keywords: ['empathy', 'gentle', 'soft', 'emotional', 'accept', 'kindness', 'inner peace']
  },
  {
    persona: 'rhea',
    keywords: ['warm', 'supportive', 'relational', 'caring', 'presence', 'friendly', 'human']
  }
]

export function recommendPersonaFromVision(vision: string): PersonaId {
  const lower = vision.toLowerCase()
  const scores: Record<PersonaId, number> = {
    caelum: 0,
    lucis: 0,
    niveus: 0,
    aurelia: 0,
    rhea: 0
  }

  for (const rule of matchRules) {
    for (const keyword of rule.keywords) {
      if (lower.includes(keyword)) {
        scores[rule.persona] += 1
      }
    }
  }

  return Object.entries(scores).sort((a, b) => b[1] - a[1])[0][0]
}