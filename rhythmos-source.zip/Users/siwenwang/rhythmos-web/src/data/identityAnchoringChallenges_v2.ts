

export interface IdentityAnchoringChallenge {
    cue: string;
    paragraph: string;
    action: string;
  }
  
  export const identityAnchoringChallenges: Record<string, IdentityAnchoringChallenge[]> = {
    caelum: [
      {
        cue: "Act before you're ready.",
        paragraph: "Momentum starts not with certainty, but with motion. You don’t have to be sure — you just have to begin.",
        action: "Start a 15-minute task block immediately, no prep."
      },
      {
        cue: "Strong decisions stabilize your identity.",
        paragraph: "Each time you choose and follow through, you reinforce your momentum-based self.",
        action: "Pick one open loop — and close it today, cleanly."
      },
      {
        cue: "Energy grows through execution.",
        paragraph: "Stop waiting for the right time. The right time starts with movement.",
        action: "Send the message / open the file / launch the task now."
      },
      {
        cue: "Leadership doesn’t require permission.",
        paragraph: "Direct your focus — that’s how leaders emerge.",
        action: "Choose the next 30 minutes of your day and claim it fully."
      },
      {
        cue: "You are calm intensity.",
        paragraph: "You don't need to shout. But your energy moves everything when it’s focused.",
        action: "Do one thing decisively — no backtracking, no apologizing."
      },
      {
        cue: "Decisiveness is a muscle — use it daily.",
        paragraph: "Every clear choice builds internal momentum. Action is clarity in motion.",
        action: "Make a quick decision you've been delaying — act on it now."
      },
      {
        cue: "Boldness beats perfection.",
        paragraph: "You're not here to be flawless. You're here to move — cleanly, quickly, courageously.",
        action: "Ship something at 80% today. Done is better than perfect."
      },
      {
        cue: "Speed can be sacred.",
        paragraph: "When you're in rhythm, hesitation is the only friction.",
        action: "Set a 10-minute countdown. Complete a micro-task without pause."
      },
      {
        cue: "Clarity comes through movement.",
        paragraph: "Don't wait to feel ready — movement reveals what matters.",
        action: "Start your workday with the hardest task — for just 10 minutes."
      },
      {
        cue: "You are the starter, not the spectator.",
        paragraph: "Progress is personal. You don't need permission — only momentum.",
        action: "Take the first bold step in something you've been planning too long."
      }
      
    ],
    rhea: [
      {
        cue: "Softness is your superpower.",
        paragraph: "In a world that pushes hard, you move gently — and that's rare strength.",
        action: "Pause for 1 minute, breathe deeply, and affirm what you need."
      },
      {
        cue: "You deserve kindness first — from you.",
        paragraph: "You do not have to earn rest. You do not have to push to belong.",
        action: "Write a note to yourself like you'd write to a struggling friend."
      },
      {
        cue: "You are unfolding, not behind.",
        paragraph: "Growth is not a race. It’s a return to your own pace.",
        action: "List 3 things that make you feel calm — and do one today."
      },
      {
        cue: "Compassion changes your rhythm.",
        paragraph: "Not every step needs to be strong. Some just need to be soft.",
        action: "Do one thing slowly, on purpose — without pressure."
      },
      {
        cue: "You grow through gentleness.",
        paragraph: "You don’t need fire to move — sometimes water carries you further.",
        action: "Choose one thing to release control over — breathe it out."
      },

      {
        cue: "Your calm is contagious.",
        paragraph: "When you soften, the world around you breathes easier too.",
        action: "Send a kind message to someone — no reason, just resonance."
      },
      {
        cue: "You don’t need to prove your peace.",
        paragraph: "Your worth is not in effort. It’s in your being.",
        action: "Let yourself rest for 10 minutes — without guilt, without goal."
      },
      {
        cue: "Tension isn’t always strength.",
        paragraph: "Sometimes, the bravest thing is to loosen your grip.",
        action: "Notice one thing you're clinging to. Choose to release it today."
      },
      {
        cue: "Softness doesn’t mean weakness.",
        paragraph: "It means you’re strong enough to stay open.",
        action: "Write a gentle affirmation you need to hear — and repeat it aloud."
      },
      {
        cue: "Stillness can be sacred.",
        paragraph: "You don’t always have to move to be moving forward.",
        action: "Take a 2-minute pause mid-task to breathe and reset."
      }
      
    ],
    aurelia: [
      {
        cue: "Clarity is calming.",
        paragraph: "You don’t need more options — you need fewer distractions.",
        action: "Pick the most important task. Say no to the rest — just for now."
      },
      {
        cue: "Structure gives space.",
        paragraph: "When you define your frame, you free your mind.",
        action: "Write a 3-bullet plan for your next task. Execute only that."
      },
      {
        cue: "Your logic holds emotion — not rejects it.",
        paragraph: "You think clearly, because you feel deeply but choose wisely.",
        action: "Reframe one emotional reaction logically, and move on."
      },
      {
        cue: "Simplification is liberation.",
        paragraph: "You reduce noise by choosing what to ignore.",
        action: "List 3 friction points. Remove or bypass one today."
      },
      {
        cue: "Rationality is not cold — it’s kind.",
        paragraph: "Because it leads you toward what works, not what only feels safe.",
        action: "Make one small decision today — purely based on clarity."
      },
      {
        cue: "Your structure is strength.",
        paragraph: "Boundaries aren’t limitations — they’re clarity in motion.",
        action: "Define your next hour in 3 bullet points. Follow only that."
      },
      {
        cue: "Minimalism sharpens momentum.",
        paragraph: "Clarity comes when you subtract noise — not when you add effort.",
        action: "Eliminate one unnecessary tab, tool, or task today."
      },
      {
        cue: "Emotions are data — not distractions.",
        paragraph: "Let your feelings inform your logic, not override it.",
        action: "Name one feeling you had today, and ask: what is it telling me?"
      },
      {
        cue: "Systems save energy.",
        paragraph: "Repeatable workflows aren't boring — they're brilliant.",
        action: "Templatize one routine task you often redo manually."
      },
      {
        cue: "Clear choices create calm.",
        paragraph: "When you reduce ambiguity, you recover attention.",
        action: "Clarify one open task — write the next 3 steps and do the first."
      }
      
    ],
    lucis: [
      {
        cue: "Stability is a gift you give yourself daily.",
        paragraph: "You are the constant in a world of variables.",
        action: "Repeat one small task today with full awareness."
      },
      {
        cue: "Stillness is not stagnation.",
        paragraph: "Being grounded doesn't mean you're not moving. It means you're centered.",
        action: "Spend 5 minutes doing nothing — intentionally."
      },
      {
        cue: "Consistency compounds.",
        paragraph: "Tiny repetitions become rhythm. Rhythm becomes transformation.",
        action: "List 3 things you did yesterday. Repeat one today with care."
      },
      {
        cue: "Rituals are scaffolding for growth.",
        paragraph: "They don’t limit you — they hold you up.",
        action: "Reclaim one small ritual you’ve let slide."
      },
      {
        cue: "You’re not slow — you’re steady.",
        paragraph: "And steady gets you further than force ever could.",
        action: "Choose one action to do calmly — without urgency."
      },
      {
        cue: "You grow by holding steady.",
        paragraph: "What you repeat becomes who you are.",
        action: "Do one small thing today at the exact same time as yesterday."
      },
      {
        cue: "Patience is quiet power.",
        paragraph: "You're not falling behind — you're building forward with rhythm.",
        action: "Journal 3 things you did well this week — however small."
      },
      {
        cue: "You move in quiet increments.",
        paragraph: "You don’t need acceleration — just continuation.",
        action: "Choose a habit you've started. Repeat it with full presence today."
      },
      {
        cue: "Anchor in the ordinary.",
        paragraph: "Your rituals don’t limit you — they shape you.",
        action: "Make one daily routine feel sacred today — do it with intention."
      },
      {
        cue: "You're building a rhythm, not chasing a result.",
        paragraph: "What matters is not the milestone — it's the movement.",
        action: "Track one action today you want to repeat all week."
      }
      
    ],
    niveus: [
      {
        cue: "Precision is your power.",
        paragraph: "You don’t waste motion. You don’t chase noise. You execute, cleanly.",
        action: "Pick one task. Do it with 100% focus for 15 minutes."
      },
      {
        cue: "Decide once, then execute.",
        paragraph: "You conserve energy by reducing overthinking.",
        action: "Write your top decision today. Commit — no renegotiation."
      },
      {
        cue: "Structure clears chaos.",
        paragraph: "Where others spin, you slice. Where others stall, you systemize.",
        action: "Organize one area of your workflow right now — small, fast, clean."
      },
      {
        cue: "Sharp focus beats broad motion.",
        paragraph: "You’re not fast by chance — you’re sharp by structure.",
        action: "Name your top 3 priorities. Eliminate one that doesn’t fit."
      },
      {
        cue: "You move with intent, not impulse.",
        paragraph: "That’s what makes your rhythm efficient — and rare.",
        action: "Time-block your next hour. Move precisely inside it."
      },
      {
        cue: "Execution is your clarity.",
        paragraph: "You don’t debate. You define and deploy.",
        action: "Write a 3-step checklist — then complete it without deviation."
      },
      {
        cue: "Efficiency is elegant.",
        paragraph: "You do not rush. You refine.",
        action: "Audit your last task — find one way to tighten the flow."
      },
      {
        cue: "Simplicity is velocity.",
        paragraph: "Each removed step increases your speed.",
        action: "Choose one process to simplify today — cut 1 step from it."
      },
      {
        cue: "Intentionality > intensity.",
        paragraph: "It's not about how much. It's about how precise.",
        action: "Set a clear 25-minute block. Guard it like a deadline."
      },
      {
        cue: "Order supports power.",
        paragraph: "Systems aren’t constraints — they’re catalysts.",
        action: "Sort one small digital space today (e.g. files, tabs, notes)."
      }
      
    ]
  }
  