/*
  RhythmOS Persona × RhythmTrend Mapping (v1.2)
  Created by user + system memory sync

  - Niveus represents stability, not spark. He consolidates rhythm.
  - Lucis triggers motion when energy is there. He is a catalytic force.
  - Aurelia and Rhea represent different layers of emotional buffering.
  - Caelum appears when purpose overrides urgency.
*/
