// /utils/hintMap.ts

const hintMap: Record<string, Record<string, string>> = {
    rational: {
      rising: "You've been sharp and structured — now let clarity lead the next big step.",
      stable: "You're moving with logic and rhythm — but don't forget to rest.",
      wavy: "You've stayed clear-headed through fluctuations — now tighten your system.",
      collapsed: "You’re holding onto structure — maybe it's time to let go a little."
    },
    visionary: {
      rising: "You’re shaping more than actions — you’re rewriting a mindset.",
      stable: "You’re steady in vision — just be sure you’re still moving.",
      wavy: "The future is pulling you — anchor in one thing today.",
      collapsed: "Your vision matters — even when it feels blurry. Reclaim one piece of it."
    },
    gentle: {
      rising: "Softness doesn’t mean slow — you’re blooming steadily.",
      stable: "You’re holding your rhythm with care — let that be enough.",
      wavy: "You’ve been moving gently — now give yourself a pause.",
      collapsed: "You’ve been kind to others. Be kind to yourself too."
    },
    motivated: {
      rising: "You’re building real energy — don’t lose your direction.",
      stable: "Momentum is on your side — keep it clean, not chaotic.",
      wavy: "Energy is cycling — today is your chance to recenter it.",
      collapsed: "Even in low energy, a spark is enough. Restart with one act."
    },
    directive: {
      rising: "You’re executing like a machine — just make sure you’re steering.",
      stable: "You’re pushing well — don’t forget to check the goal.",
      wavy: "You’re fighting through dips — now refine your target.",
      collapsed: "Force won’t help here. Start by anchoring in one task that matters."
    }
  };
  
  export function getDigestHint(
    tone: string,
    trend: string,
    tags?: string[]
  ): string {
    return (
      hintMap[tone as keyof typeof hintMap]?.[trend as keyof typeof hintMap[tone]] ??
      "You're doing something meaningful — even if you can’t see it yet."
    );
  }
  