// /data/microtaskInsightToneMap.ts

export const microtaskInsightToneMap: Record<string, string> = {
    // Collapsed
    'collapsed_gentle': 'In softness, your effort is still movement.',
    'collapsed_rational': 'Choosing action while collapsed shows resilience.',
    'collapsed_directive': 'Even in low rhythm, you chose direction.',
    'collapsed_balanced': 'You brought structure to a scattered moment.',
    'collapsed_visionary': 'You acted while unclear — that’s visionary in disguise.',
  
    // Wavy
    'wavy_gentle': 'You flowed with your energy rather than resisted it.',
    'wavy_rational': 'You grounded the waves with reason.',
    'wavy_directive': 'You gave direction to a changing current.',
    'wavy_balanced': 'You balanced your mood with motion.',
    'wavy_visionary': 'In emotional tides, you still honored the future.',
  
    // Stable
    'stable_gentle': 'Gentle momentum creates sustainable growth.',
    'stable_rational': 'You showed calm precision — the mark of maturity.',
    'stable_directive': 'You stabilized with purpose. That’s clarity.',
    'stable_balanced': 'Consistency is your quiet superpower.',
    'stable_visionary': 'Your stable rhythm quietly feeds your greater vision.',
  
    // Rising
    'rising_gentle': 'You rise without harshness — graceful momentum.',
    'rising_rational': 'You’re translating energy into clarity.',
    'rising_directive': 'Focused power. You’re shaping your day.',
    'rising_balanced': 'This rise is fueled by harmony, not hustle.',
    'rising_visionary': 'You’re becoming the person your future needs.'
  };
  