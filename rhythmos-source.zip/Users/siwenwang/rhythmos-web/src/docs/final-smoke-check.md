# ✅ RhythmOS Final Developer Test Checklist (v0.9.1-beta)

## 🛫 Onboarding Flow (First Use Only)
- [ ] Welcome Page shows beta intro and step guide
- [ ] Step 1: Rhythm trend selected → `lastTrend` saved
- [ ] Step 2: Preferred tone selected → `preferredTone` saved
- [ ] Step 3: MBTI → correct persona recommended
- [ ] Step 4: Identity anchoring sets `initPersona`
- [ ] `creStyleOverride` reflects selected target persona
- [ ] Fallback suggestion based on MBTI appears correctly

## 🔁 Daily Flow (Post-Onboarding)
- [ ] Daily rhythm starts at `/rhythm` check-in page
- [ ] Check-in trend sets `lastTrend` and triggers CRE cue
- [ ] Generated CRE matches `preferredTone` × trend stage only
- [ ] Cue refresh generates new block and re-renders
- [ ] User text input accepted and logs passive tone
- [ ] Identity challenges rendered correctly from persona pool
- [ ] Daily challenges persist across refresh
- [ ] Feedback selection (Aligned / Okay / Not me) is stored and replayable
- [ ] Score only finalized when `End My Day` button clicked
- [ ] New day automatically triggered at midnight (00:00)

## 🎯 Goal & Subtask Flow
- [ ] Goal creation, title, and notes save properly
- [ ] Subtasks generate per goal and show correct difficulty
- [ ] Subtask status updates UI and logs score correctly
- [ ] Radar chart logs accepted subtask types

## 📊 Insight & Visualization
- [ ] Daily rhythm score line graph works (0–10)
- [ ] CRE feedback logs update Signature Map correctly
- [ ] Tone heatmap accurately reflects score
- [ ] Challenge history correctly counts ✅ / 😐 / ❌
- [ ] CRE + challenge feedback shown in replay section

## 🧪 Dev Tools
- [ ] Reset local data clears rhythm logs, tone, cue history
- [ ] Simulate New Day injects new `dailySummaryLog` and removes current day context
- [ ] Goals / Challenges can be cleared individually

## 📘 Guide Page
- [ ] Glossary tooltips appear via `<RhythmTooltip />`
- [ ] “What is Rhythm?” section is first block
- [ ] Definitions for cue, tone, trend, persona, signature map included

## 📦 Beta Summary Page
- [ ] Build date + version rendered
- [ ] Module coverage summary included
- [ ] Tester feedback button redirects to Google Form
- [ ] Flow chart correctly reflects onboarding vs daily structure

