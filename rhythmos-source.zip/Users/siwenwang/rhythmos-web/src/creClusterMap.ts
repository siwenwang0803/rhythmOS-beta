// creClusterMap.ts

import { creTemplates, CRETemplate } from './creTemplateRegistry'

export interface CRECluster {
  key: string
  tone: string
  taskType: string
  count: number
  examples: CRETemplate[]
}

export function getCREClusterMap(): CRECluster[] {
  const clusters: Record<string, CRECluster> = {}

  for (const t of creTemplates) {
    const key = `${t.tone}__${t.taskType}`
    if (!clusters[key]) {
      clusters[key] = {
        key,
        tone: t.tone,
        taskType: t.taskType,
        count: 0,
        examples: []
      }
    }
    clusters[key].count += 1
    clusters[key].examples.push(t)
  }

  return Object.values(clusters).sort((a, b) => b.count - a.count)
}