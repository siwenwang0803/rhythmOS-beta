// feedbackRecord.ts（增强版）– 支持预测 persona 自动写入
import { getDefaultPersonaFromTrend } from './utils/getDefaultPersonaFromTrend';
export interface CREFeedbackEntry {
  taskType: string
  variant: string
  tone: string
  persona: string
  score: number
  source: 'system' | 'studio' | 'replay'
  timestamp: number
}

// 可选：引入 signature map 预测最可能 persona
import { getBestPersonaForTrend } from './signatureAnalyzer'

export function addFeedbackRecord(entry: Partial<CREFeedbackEntry> & { tone: string, taskType: string, variant: string, score: number }) {
  const raw = localStorage.getItem('creFeedbackLog')
  const log = raw ? JSON.parse(raw) : []

  const signature = JSON.parse(localStorage.getItem('rhythmSignature') || '{}')
  const trend = localStorage.getItem('lastTrend') || 'stable'
  const persona = entry.persona || getBestPersonaForTrend(trend, signature)?.persona || 'auto'

  log.push({
    ...entry,
    persona,
    source: entry.source || 'studio',
    timestamp: Date.now()
  })

  localStorage.setItem('creFeedbackLog', JSON.stringify(log))
}
export function recordFeedback(cue: string, score: number, trend: string) {
  const override = localStorage.getItem('creStyleOverride') || 'auto';
  const persona = override !== 'auto' ? override : getDefaultPersonaFromTrend(trend);

  const entry = {
    cue,
    score,
    trend,
    persona, // ✅ 写入 persona
    timestamp: Date.now(),
    feedbackType: 'complete'
  };

  const raw = localStorage.getItem('rhythmSignatureLog');
  const existing = raw ? JSON.parse(raw) : [];
  const updated = [...existing, entry];
  localStorage.setItem('rhythmSignatureLog', JSON.stringify(updated));
}