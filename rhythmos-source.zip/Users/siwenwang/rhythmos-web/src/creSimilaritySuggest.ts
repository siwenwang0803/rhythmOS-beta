// creSimilaritySuggest.ts

import { CRETemplate, creTemplates } from './creTemplateRegistry'

export function getSimilarCREVariants(base: CRETemplate, limit = 5): CRETemplate[] {
  return creTemplates
    .filter((t) =>
      t.tone === base.tone &&
      t.taskType === base.taskType &&
      t.variant === base.variant &&
      t.text !== base.text
    )
    .slice(0, limit)
}