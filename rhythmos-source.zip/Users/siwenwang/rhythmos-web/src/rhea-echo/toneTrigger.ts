// rhea-echo/toneTrigger.ts
// RheaEcho | Passive Tone Trigger Engine v1.0 (English version)
// Created by Steven & RhythmOS Engine
// Purpose: Detect emotional tone from user input based on English emotional keywords

export type EmotionCategory = "sadness" | "anger" | "joy" | "anxiety" | "neutral" | null;

const toneTriggers: Record<EmotionCategory, string[]> = {
  sadness: ["ugh", "sigh", "tired", "drained", "whatever", "don't care", "disappointed", "not worth it"],
  anger: ["damn", "annoyed", "pissed", "mad", "seriously?", "so done", "fuck", "fuck this"],
  joy: ["yay", "finally", "haha", "lol", "so good", "excited", "happy", "love it", "amazing"],
  anxiety: ["what now", "help", "overwhelmed", "can't breathe", "nervous", "anxious", "i'm scared", "not ready"],
  neutral: [],
  null: []
};

/**
 * Detect dominant emotion category from input string (English only).
 * @param input - user input string
 * @returns EmotionCategory or null if no match
 */
export function detectToneTrigger(input: string): EmotionCategory {
  const normalized = input.toLowerCase();

  for (const [emotion, triggers] of Object.entries(toneTriggers)) {
    if (
      triggers.some((word) => normalized.includes(word))
    ) {
      return emotion as EmotionCategory;
    }
  }

  return null;
}

/**
 * Wrapper function for usePassiveToneTracker and others
 */
export function triggerToneFromText(input: string): EmotionCategory {
  return detectToneTrigger(input);
}

