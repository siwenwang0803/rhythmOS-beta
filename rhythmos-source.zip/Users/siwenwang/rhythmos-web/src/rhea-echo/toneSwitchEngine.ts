// rhea-echo/toneSwitchEngine.ts

export const mapEmotionToTone = (emotion: string | null | undefined): string => {
    if (!emotion || typeof emotion !== 'string') return 'gentle'  // 防止 null 崩溃
    switch (emotion.toLowerCase()) {
      case 'sadness':
      case 'tired':
      case 'lonely':
        return 'gentle'
      case 'anger':
      case 'resentment':
      case 'frustration':
        return 'directive'
      case 'hope':
      case 'inspired':
      case 'joy':
        return 'motivated'
      case 'curiosity':
      case 'confused':
      case 'searching':
        return 'balanced'
      case 'visionary':
      case 'ambitious':
        return 'visionary'
      default:
        return 'gentle'
    }
  }
