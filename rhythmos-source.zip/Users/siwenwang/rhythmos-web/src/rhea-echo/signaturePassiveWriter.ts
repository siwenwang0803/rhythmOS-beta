// rhea-echo/signaturePassiveWriter.ts
// RheaEcho | Signature Passive Layer Writer v1.0
// Created by Steven & RhythmOS Engine
// Purpose: Log passive tone suggestions into SignatureMap for future trend analysis

import type { ToneStyle } from './toneSwitchEngine'

export type PassiveToneLog = {
  tone: ToneStyle
  emotionSignal: string | null
  timestamp: number
}

let passiveSignatureMap: PassiveToneLog[] = []

/**
 * Save a passive tone detection into the user's passive SignatureMap layer
 * @param entry - full log entry with tone + emotion + timestamp
 */
export function writePassiveToneLog(entry: PassiveToneLog) {
  const existing = JSON.parse(localStorage.getItem('passiveToneLog') || '[]')
  const updated = [...existing, entry]
  localStorage.setItem('passiveToneLog', JSON.stringify(updated))

  // Keep in memory for fast access (optional)
  passiveSignatureMap.push(entry)
}

/**
 * Get recent passive tone history (e.g., last N records)
 * @param count - number of latest records to return
 */
export function getRecentPassiveTones(count = 5): PassiveToneLog[] {
  return passiveSignatureMap.slice(-count)
}

/**
 * Update rhythmScore passively based on tone signal
 * This is a shallow adjustment, does not overwrite trend
 */
export function updatePassiveTrendScore(tone: ToneStyle) {
  writePassiveToneLog({ tone, emotionSignal: null, timestamp: Date.now() })

  const base = parseFloat(localStorage.getItem('rhythmScore') || '5')
  let adjusted = base

  if (tone === 'gentle') adjusted -= 0.5
  if (tone === 'directive') adjusted += 0.5
  if (tone === 'motivated') adjusted += 0.3
  if (tone === 'visionary') adjusted += 0.2
  if (tone === 'rational') adjusted -= 0.2

  adjusted = Math.max(1, Math.min(10, adjusted))
  localStorage.setItem('rhythmScore', adjusted.toFixed(1))
}
export function writeSignatureFeedback(entry: {
    cue: string
    paragraph: string
    tone: string
    persona: string
    feedback: 'not-me' | 'okay' | 'aligned'
    timestamp: number
  }) {
    const existing = JSON.parse(localStorage.getItem('signatureFeedbackLog') || '[]')
    const updated = [...existing, entry]
    localStorage.setItem('signatureFeedbackLog', JSON.stringify(updated))
  }
  