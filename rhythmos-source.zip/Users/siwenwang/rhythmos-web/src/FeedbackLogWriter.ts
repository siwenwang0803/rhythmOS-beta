// FeedbackLogWriter.ts
import { getSignatureMap, ToneEntry, CueEntry, TrendEntry, ChallengeEntry } from './SignatureMap';

export const logToneFeedback = (entry: ToneEntry) => {
  console.log('🚀 logToneFeedback called with:', entry);
  
  // Use getSignatureMap to ensure we're accessing the unique instance
  const signatureMap = getSignatureMap();
  
  console.log('🔍 SignatureMap instance:', signatureMap);
  console.log('🔍 Current toneLog:', signatureMap.toneLog);
  console.log('🔍 Is toneLog an array?', Array.isArray(signatureMap.toneLog));
  
  // Ensure toneLog is initialized
  if (!signatureMap.toneLog) {
    console.log('📝 Initializing toneLog');
    signatureMap.toneLog = [];
  }
  
  // Add entry to toneLog
  signatureMap.toneLog.push(entry);
  
  console.log('✅ Entry pushed. New toneLog length:', signatureMap.toneLog.length);
  console.log('✅ Last entry:', signatureMap.toneLog[signatureMap.toneLog.length - 1]);
  
  // Update meta timestamp
  signatureMap.meta.lastUpdated = new Date().toISOString();
  
  // Trigger update event
  const event = new CustomEvent('signatureMapUpdated', { detail: { type: 'toneLog' } });
  window.dispatchEvent(event);
};

export const logCueFeedback = (entry: CueEntry) => {
  const signatureMap = getSignatureMap();
  
  if (!signatureMap.cueFeedbackLog) {
    signatureMap.cueFeedbackLog = [];
  }
  signatureMap.cueFeedbackLog.push(entry);
  signatureMap.meta.lastUpdated = new Date().toISOString();
};

export const logTrend = (entry: TrendEntry) => {
  const signatureMap = getSignatureMap();
  
  if (!signatureMap.trendHistory) {
    signatureMap.trendHistory = [];
  }
  signatureMap.trendHistory.push(entry);
  signatureMap.meta.lastUpdated = new Date().toISOString();
};

export const logChallenge = (entry: ChallengeEntry) => {
  const signatureMap = getSignatureMap();
  
  if (!signatureMap.challengeLog) {
    signatureMap.challengeLog = [];
  }
  signatureMap.challengeLog.push(entry);
  signatureMap.meta.lastUpdated = new Date().toISOString();
};
