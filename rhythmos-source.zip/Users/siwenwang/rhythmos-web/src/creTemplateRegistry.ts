// creTemplateRegistry.ts（清理版本，使用 JSON 模板为唯一数据源）

import templates from './data/cre_templates.json'

export type CREVariant = 'base' | 'metaphorical' | 'concise' | 'expansive'

export interface CRETemplate {
  tone: string
  stage: string
  taskType: string
  variant: CREVariant
  text: string
}

export const creTemplates: CRETemplate[] = templates

// ❗以下为开发期原始数组，仅供编辑器调用（如需使用可重命名）
// export const creTemplatesDraft: CRETemplate[] = [ ... ]