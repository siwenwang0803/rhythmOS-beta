// clusterGapSuggest.ts

import { creTemplates } from './creTemplateRegistry'

export interface ClusterGap {
  tone: string
  taskType: string
  count: number
}

export function getClusterGaps(minThreshold = 2): ClusterGap[] {
  const tones = ['gentle', 'directive', 'motivated', 'visionary']
  const taskTypes = ['minimal', 'light', 'normal', 'challenge']

  const counts: Record<string, number> = {}

  for (const t of creTemplates) {
    const key = `${t.tone}__${t.taskType}`
    counts[key] = (counts[key] || 0) + 1
  }

  const gaps: ClusterGap[] = []

  for (const tone of tones) {
    for (const task of taskTypes) {
      const key = `${tone}__${task}`
      const count = counts[key] || 0
      if (count < minThreshold) {
        gaps.push({ tone, taskType: task, count })
      }
    }
  }

  return gaps.sort((a, b) => a.count - b.count)
}