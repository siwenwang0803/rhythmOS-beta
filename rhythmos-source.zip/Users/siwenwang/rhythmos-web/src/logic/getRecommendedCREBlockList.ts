// logic/getRecommendedCREBlockList.ts

import { creBlocks } from '../cre/creBlockLibrary'

export function getRecommendedCREBlockList(limit = 3) {
  const log = JSON.parse(localStorage.getItem('signatureFeedbackLog') || '[]')

  const alignedCombos: Record<string, boolean> = {}
  const seenCues = new Set<string>()

  log.forEach((entry: any) => {
    const combo = `${entry.persona}_${entry.tone}`
    if (entry.feedback === 'aligned') alignedCombos[combo] = true
    seenCues.add(entry.cue)
  })

  // Step 1: 优先推荐未展示过的 CREBlock（用户喜爱的 tone × persona）
  const unseenPreferred = creBlocks.filter(
    (b) => alignedCombos[`${b.persona}_${b.tone}`] && !seenCues.has(b.cue)
  )

  // Step 2: 备选推荐（喜爱过的但已展示过）
  const seenPreferred = creBlocks.filter(
    (b) => alignedCombos[`${b.persona}_${b.tone}`] && seenCues.has(b.cue)
  )

  const all = [...unseenPreferred, ...seenPreferred]
  return all.slice(0, limit)
}
