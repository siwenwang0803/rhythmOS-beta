import { getSignatureMap } from '../SignatureMap';

export function getCREContext(): {
  days: number;
  completed: number;
  total: number;
} {
  const signatureMap = getSignatureMap();

  const toneLog = signatureMap.toneLog || [];
  const microtaskLog = signatureMap.microtaskLog || [];

  const now = Date.now();
  const collapsedDays = toneLog.filter(entry =>
    entry.trendAtFeedback === 'collapsed' &&
    now - new Date(entry.timestamp).getTime() < 7 * 86400 * 1000
  ).length;

  return {
    days: collapsedDays,
    completed: microtaskLog.length,
    total: 30 // TODO: 未来可计算为目标设定下的总任务数
  };
}
