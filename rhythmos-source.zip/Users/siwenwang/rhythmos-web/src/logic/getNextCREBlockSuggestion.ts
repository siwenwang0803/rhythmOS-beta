// logic/getNextCREBlockSuggestion.ts

import { creBlocks } from '../cre/creBlockLibrary'

export function getNextCREBlockSuggestion() {
  const raw = localStorage.getItem('signatureFeedbackLog')
  const log = raw ? JSON.parse(raw) : []

  const personaToneScores: Record<string, number> = {}

  log.forEach((entry: any) => {
    const key = `${entry.persona}_${entry.tone}`
    const weight = entry.feedback === 'aligned' ? 3 : entry.feedback === 'okay' ? 1 : -1
    personaToneScores[key] = (personaToneScores[key] || 0) + weight
  })

  // Find the best scoring tone + persona pair
  const topCombo = Object.entries(personaToneScores).sort((a, b) => b[1] - a[1])[0]?.[0]

  if (!topCombo) return null

  const [topPersona, topTone] = topCombo.split('_')

  // Find a CREBlock that matches this persona + tone
  const candidates = creBlocks.filter(
    (b) => b.persona === topPersona && b.tone === topTone
  )

  if (candidates.length === 0) return null

  return candidates[Math.floor(Math.random() * candidates.length)]
}
