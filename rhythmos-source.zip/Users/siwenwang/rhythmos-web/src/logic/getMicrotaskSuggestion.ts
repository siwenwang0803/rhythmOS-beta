export function getMicrotaskSuggestion(trend: string): string {
  const suggestions: Record<string, string> = {
    frozen: "Just organize your desk for 1 minute.",
    collapsed: "Write one sentence. That’s enough.",
    wavy: "Pick one tab to close. Then pause.",
    stable: "Sketch a short outline for what you want to do.",
    rising: "Choose one task and give it 5 focused minutes."
  }

  return suggestions[trend] || "Do something light and rhythmic."
}
