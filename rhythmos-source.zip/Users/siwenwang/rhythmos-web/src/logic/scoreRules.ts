// src/logic/scoreRules.ts

export const scoreRules = {
    maxDailyTotalScore: 6.0, // 每日总得分封顶
    minDailyTotalScore: -2.0, // 最低保护
    goalSubtaskCombinedMax: 4.0, // Goal+Subtask得分合计上限
  
    behaviorLimits: {
      'subtask': { maxPerDay: 4, pointsPer: 0.5 },
      'goal-complete': { maxPerDay: 2, pointsPer: 2 },
      'microtask': { maxPerDay: 2, pointsPer: 1 },
      'challenge': { maxPerDay: 2, pointsPer: 2 },
      'daily-checkin': { maxPerDay: 1, pointsPer: 2 },
      'cre-feedback': { maxPerDay: null, pointsPer: 0 } // 只影响 signature, 不打 rhythmScore
    }
  };
  
  