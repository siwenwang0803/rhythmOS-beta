export type RhythmTrend = 'frozen' | 'collapsed' | 'wavy' | 'stable' | 'rising'
export type Persona = 'Aurelia' | 'Rhea' | 'Lucis' | 'Caelum'

export interface RhythmStrategy {
  trend: RhythmTrend
  persona: Persona
  tone: string
  taskType: 'minimal' | 'light' | 'normal' | 'challenge'
  suggestion: string
}

export const rhythmStrategyMap: Record<RhythmTrend, RhythmStrategy> = {
  frozen: {
    trend: 'frozen',
    persona: 'Aurelia',
    tone: 'gentle',
    taskType: 'minimal',
    suggestion: "You’ve been quiet for a while. Just one step is enough today."
  },
  collapsed: {
    trend: 'collapsed',
    persona: 'Aurelia',
    tone: 'gentle',
    taskType: 'minimal',
    suggestion: "Let’s take one breath and see if we can start from there."
  },
  wavy: {
    trend: 'wavy',
    persona: 'Rhea',
    tone: 'gentle',
    taskType: 'light',
    suggestion: "Let’s try something light. No pressure, just presence."
  },
  stable: {
    trend: 'stable',
    persona: 'Lucis',
    tone: 'motivated',
    taskType: 'normal',
    suggestion: "Keep the rhythm steady. You’re doing well here."
  },
  rising: {
    trend: 'rising',
    persona: 'Caelum',
    tone: 'directive',
    taskType: 'challenge',
    suggestion: "Let’s ride this wave — you’re ready for more."
  }
}
