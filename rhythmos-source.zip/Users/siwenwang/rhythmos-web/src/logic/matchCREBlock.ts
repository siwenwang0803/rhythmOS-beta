import { renderCRETemplate } from '../logic/renderCRETemplate';
import { getCREContext } from '../logic/getCREContext';
import { creBlocks } from '../cre/creBlockLibrary';

const trendStageMapping: Record<string, 'initial' | 'middle' | 'final'> = {
  collapsed: 'initial',
  wavy: 'middle',
  stable: 'middle',
  rising: 'final'
};
export function matchCREBlock(
  text: string,
  trend?: string,
  preferredTone?: string
): CREBlock & { rhythm: string } {
  const stage = trend ? trendStageMapping[trend] : 'middle';
  const resolvedTone = preferredTone && personaToTone[preferredTone]
    ? personaToTone[preferredTone]
    : preferredTone;

  const context = getCREContext(); // ✅ 获取上下文
  const candidates = creBlocks.filter(block =>
    block.tone === resolvedTone && block.stage === stage
  );

  if (candidates.length > 0) {
    const picked = candidates[Math.floor(Math.random() * candidates.length)];
    return {
      ...picked,
      cue: renderCRETemplate(picked.cue, context),
      paragraph: renderCRETemplate(picked.paragraph, context),
      rhythm: trend || 'wavy'
    };
  }

  // fallback
  const fallback = creBlocks.find(block => block.tone === 'gentle') || creBlocks[0];
  return {
    ...fallback,
    cue: renderCRETemplate(fallback.cue, context),
    paragraph: renderCRETemplate(fallback.paragraph, context),
    rhythm: trend || 'wavy'
  };
}









  
  