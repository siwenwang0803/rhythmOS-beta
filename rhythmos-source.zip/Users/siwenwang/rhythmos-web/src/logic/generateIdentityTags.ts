export function generateIdentityTags(): string[] {
  try {
    const raw = localStorage.getItem('signatureFeedbackLog');
    const log = raw && raw !== 'undefined' ? JSON.parse(raw) : [];
    const mbti = (localStorage.getItem('mbtiType') || '').toUpperCase();

    const comboScores: Record<string, number> = {};
    log.forEach((entry: any) => {
      if (!entry.persona || !entry.tone) return;
      const key = `${entry.persona}_${entry.tone}`;
      const weight = entry.feedback === 'aligned' ? 3 : entry.feedback === 'okay' ? 1 : -1;
      comboScores[key] = (comboScores[key] || 0) + weight;
    });

    const sortedCombos = Object.entries(comboScores).sort((a, b) => b[1] - a[1]);
    const topCombos = sortedCombos.slice(0, 2).map(([key]) => key);

    const tagMap: Record<string, string> = {
      'rhea_gentle': 'Compassionate Empath',
      'caelum_directive': 'Decisive Strategist',
      'lucis_visionary': 'Visionary Planner',
      'aurelia_rational': 'Logical Thinker',
      'niveus_directive': 'Execution-Oriented Leader',
      'lucis_balanced': 'Grounded Architect',
      'rhea_reflective': 'Emotional Navigator',
      'caelum_motivated': 'Focused Achiever'
    };

    const mbtiOverlay: Record<string, string> = {
      ISTJ: 'Structured Executor',
      ISFJ: 'Supportive Guardian',
      INFJ: 'Introspective Mentor',
      INTJ: 'Strategic Visionary',
      ISTP: 'Practical Solver',
      ISFP: 'Gentle Creator',
      INFP: 'Empathetic Idealist',
      INTP: 'Analytical Observer',
      ESTP: 'Energetic Realist',
      ESFP: 'Expressive Motivator',
      ENFP: 'Creative Connector',
      ENTP: 'Innovative Challenger',
      ESTJ: 'Efficient Organizer',
      ESFJ: 'Harmonizing Coordinator',
      ENFJ: 'Expressive Guide',
      ENTJ: 'Decisive Visionary'
    };

    const tags: string[] = [];

    for (const combo of topCombos) {
      if (tagMap[combo]) tags.push(tagMap[combo]);
    }

    if (mbti && mbtiOverlay[mbti]) tags.push(mbtiOverlay[mbti]);

    return tags;
  } catch (e) {
    console.error('❌ Failed to generate identity tags:', e);
    return [];
  }
}

  