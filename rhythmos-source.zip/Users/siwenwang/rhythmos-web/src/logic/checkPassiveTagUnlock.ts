// checkPassiveTagUnlock.ts (expanded with timestamped tagLog)

import { getSignatureMap } from '../SignatureMap';

export function checkPassiveTagUnlock(): string[] {
  const signatureMap = getSignatureMap();
  const newlyUnlocked: string[] = [];

  signatureMap.tagLog = signatureMap.tagLog || [];
  signatureMap.microtaskLog = signatureMap.microtaskLog || [];
  signatureMap.toneLog = signatureMap.toneLog || [];

  const today = new Date().toISOString();

  const hasTag = (id: string) =>
    signatureMap.tagLog.some(
      (t: any) => (typeof t === 'string' ? t === id : t.tagId === id)
    );

  const unlock = (id: string) => {
    if (!hasTag(id)) {
      signatureMap.tagLog.push({ tagId: id, timestamp: today });
      newlyUnlocked.push(id);
    }
  };

  // 🧘 1. Gentle Builder
  if ((signatureMap.microtaskCount || 0) >= 10) unlock('gentle_builder');

  // 🌊 2. Resilient Resetter
  if ((signatureMap.microtaskCount || 0) >= 25) unlock('resilient_resetter');

  // 📈 3. Directive Climber
  const directiveAligned = signatureMap.toneLog.filter(
    (e) => e.tone === 'directive' && e.feedback === 'aligned'
  ).length;
  if (directiveAligned >= 10) unlock('directive_climber');

  // 🎭 4. Multi Voice
  const uniqueTones = new Set(signatureMap.toneLog.map((e) => e.tone));
  if (uniqueTones.size >= 5) unlock('multi_voice_explorer');

  // ⚖️ 5. Balanced Reflector
  const okays = signatureMap.toneLog.filter((e) => e.feedback === 'okay').length;
  const aligned = signatureMap.toneLog.filter((e) => e.feedback === 'aligned').length;
  if (okays >= 3 && aligned >= 3) unlock('balanced_reflector');

  // 🧭 6. Identity Consistent
  const last3 = signatureMap.toneLog.slice(-3);
  const samePersona = last3.length === 3 && new Set(last3.map((e) => e.persona)).size === 1;
  if (samePersona) unlock('identity_consistent');

  return newlyUnlocked;
}

