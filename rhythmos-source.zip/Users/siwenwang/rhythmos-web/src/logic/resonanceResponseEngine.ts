// src/logic/resonanceResponseEngine.ts

import { creBlocks } from '../cre/creBlockLibrary'
import { CREBlock } from '../cre/creBlockLibrary'

/**
 * Emotion keyword to CREBlock tone mapping
 */
const keywordToneMap: Record<string, keyof typeof creBlocks[number]['tone']> = {
  tired: 'gentle',
  exhausted: 'gentle',
  stuck: 'rational',
  overwhelmed: 'rational',
  angry: 'directive',
  behind: 'motivated',
  frustrated: 'directive',
  hopeful: 'visionary',
  inspired: 'visionary',
  lost: 'rational',
  confused: 'rational',
  ready: 'motivated',
  calm: 'gentle',
}

export function matchCREBlockFromInput(input: string): CREBlock | null {
  const lower = input.toLowerCase()

  // Try to find the first matching tone based on keyword presence
  for (const keyword in keywordToneMap) {
    if (lower.includes(keyword)) {
      const tone = keywordToneMap[keyword]
      const candidates = creBlocks.filter((b) => b.tone === tone)
      if (candidates.length > 0) {
        return candidates[Math.floor(Math.random() * candidates.length)]
      }
    }
  }

  // fallback
  const fallback = creBlocks.filter((b) => b.tone === 'gentle')
  return fallback.length > 0 ? fallback[0] : null
}

