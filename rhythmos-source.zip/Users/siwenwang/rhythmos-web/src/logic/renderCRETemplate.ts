export function renderCRETemplate(template: string, context: Record<string, string | number>): string {
    return template.replace(/{(.*?)}/g, (_, key) =>
      String(context[key] ?? `{${key}}`)
    );
  }
  