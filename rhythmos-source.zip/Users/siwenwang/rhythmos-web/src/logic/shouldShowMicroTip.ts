/**
 * Decide whether a microtip should be shown for a cueId and feedback type.
 * NotMe → immediate show (once per day)
 * Okay → after one okay + one notMe OR two okays (counts reset daily)
 * Uses localStorage to persist temporary session memory
 */

export function shouldShowMicroTip(cueId: string, feedback: string): boolean {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const key = `microtip_shown_${cueId}_${today}`;
    
    // 检查是否在今天已经显示过
    if (localStorage.getItem(key)) return false;
  
    // NotMe 反馈立即显示
    if (feedback === 'notMe') {
      localStorage.setItem(key, '1');
      return true;
    }
  
    if (feedback === 'okay') {
      const countKey = `okay_count_${cueId}_${today}`;
      const notMeKey = `notme_received_${cueId}_${today}`;
      
      // 更新 okay 计数
      const count = parseInt(localStorage.getItem(countKey) || '0', 10) + 1;
      localStorage.setItem(countKey, count.toString());
      
      // 检查是否已有 notMe 反馈
      const hasNotMe = localStorage.getItem(notMeKey) === '1';
      
      // 条件1: 两次 okay
      // 条件2: 一次 okay + 一次 notMe
      if (count >= 2 || (count >= 1 && hasNotMe)) {
        localStorage.setItem(key, '1');
        return true;
      }
    }
    
    // 如果是 notMe，记录已收到 notMe 反馈
    // 这段放在外面，用于记录收到过 notMe，即使当前已经显示了提示
    if (feedback === 'notMe') {
      const notMeKey = `notme_received_${cueId}_${today}`;
      localStorage.setItem(notMeKey, '1');
    }
  
    return false;
  }