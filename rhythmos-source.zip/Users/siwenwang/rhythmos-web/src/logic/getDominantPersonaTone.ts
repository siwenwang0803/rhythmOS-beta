// logic/getDominantPersonaTone.ts

export function getDominantPersonaTone() {
  const raw = localStorage.getItem('signatureFeedbackLog');
  const log = raw && raw !== 'undefined' ? JSON.parse(raw) : [];
  
  
    const scoreMap: Record<string, number> = {}
  
    log.forEach((entry: any) => {
      if (!entry.persona || !entry.tone) return
      const key = `${entry.persona}_${entry.tone}`
      const weight = entry.feedback === 'aligned' ? 3 : entry.feedback === 'okay' ? 1 : -1
      scoreMap[key] = (scoreMap[key] || 0) + weight
    })
  
    const sorted = Object.entries(scoreMap).sort((a, b) => b[1] - a[1])
    const top = sorted[0]?.[0]
  
    if (!top) return null
  
    const [persona, tone] = top.split('_')
    const alignedCount = log.filter((e: any) => e.persona === persona && e.tone === tone && e.feedback === 'aligned').length
  
    return {
      persona,
      tone,
      aligned: alignedCount
    }
  }
  