
import { getToneScoreMapByDays } from '../utils/writeToneLog';

export function checkToneFatigueSuggestion(days = 14): { dominant: string; suggested: string } | null {
  const scoreMap = getToneScoreMapByDays(days);
  const entries = Object.entries(scoreMap);
  if (entries.length === 0) return null;

  const sorted = entries.sort((a, b) => b[1] - a[1]);
  const [topTone, topScore] = sorted[0];

  const totalScore = sorted.reduce((sum, [, v]) => sum + v, 0);
  const ratio = topScore / totalScore;

  const fatigueThreshold = totalScore > 15 ? 0.5 : 0.6;

  if (ratio >= fatigueThreshold) {
    const altTone = sorted.find(([tone]) => tone !== topTone)?.[0] || 'directive';
    return { dominant: topTone, suggested: altTone };
  }

  return null;
}