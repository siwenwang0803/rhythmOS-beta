// /src/logic/gpt/GPTCueEngine.ts

import { getSignaturePromptMemory } from '../signature/getSignaturePromptMemory';
import { openaiComplete } from '../openai/openaiComplete'; // 确保你已有该文件
import { validateCue } from '../CueValidationLayer';
import { addSignatureCueReplayEntry } from '../signature/SignatureCueReplayLog';
import { generateCRECue } from '../generateCRECue';
import { stageFromTrend } from '../generate/stageFromTrend';

interface GPTCueOptions {
  trend: string;
  preferredTone: string;
  initPersona: string;
}

export async function generateCRECueAsync(options: GPTCueOptions) {
  const { trend, preferredTone, initPersona } = options;
  const stage = stageFromTrend(trend);
  const memory = getSignaturePromptMemory();

  const systemPrompt = `You are RhythmOS, an emotionally intelligent identity coach. Your role is to generate daily identity-aligned guidance cues.`;
  const userPrompt = `
${memory}

User trend: ${trend}
Stage: ${stage}
Preferred tone: ${preferredTone}
Initial persona: ${initPersona}

Please generate a CRE cue object like:
{
  "cue": "...",
  "paragraph": "...",
  "tone": "...",
  "persona": "...",
  "stage": "...",
  "taskType": "light",
  "voiceStyle": "gentle"
}
`;

  try {
    const result = await openaiComplete({ system: systemPrompt, user: userPrompt });
    const gptCue = JSON.parse(result.content);

    const validation = validateCue(gptCue);

    if (!validation.isValid) {
      console.warn('[GPTCueEngine] ⚠️ Invalid cue, fallback to static:', validation.reasons);
      return generateCRECue({ trend, preferredTone, initPersona, currentCueId: '' });
    }

    addSignatureCueReplayEntry({
      timestamp: new Date().toISOString(),
      type: 'identityCue',
      prompt: userPrompt,
      gptResponse: result.content
    });

    return { ...gptCue, rhythm: trend, source: 'gpt' };
  } catch (err) {
    console.warn('[GPTCueEngine] ❌ GPT call failed, fallback used:', err);
    return generateCRECue({ trend, preferredTone, initPersona, currentCueId: '' });
  }
}
