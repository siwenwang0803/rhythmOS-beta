// /src/logic/gpt/SignaturePromptEngine.ts
// 只需要添加一行导入，其他保持不变

import { getSignaturePromptMemory } from '../signature/getSignaturePromptMemory';
import { addSignatureCueReplayEntry } from '../signature/SignatureCueReplayLog';
import { getDailySignatureContext } from '../../utils/openaiComplete';  // 👈 添加这行

export interface GeneratedCRECue {
  cue: string;
  paragraph: string;
  tone: string;
  persona: string;
  source?: 'static' | 'gpt' | 'exploratory';
}

// 防止递归的标志
let isGenerating = false;

export async function generateCRECueFromSignaturePrompt(
  options?: {
    tone?: string;
    trend?: string;
    microEmotion?: string;
    userContext?: string;
  }
): Promise<GeneratedCRECue | null> {
  // 防止递归调用
  if (isGenerating) {
    console.warn('[CRE Generation] Prevented recursive call');
    return null;
  }
  
  isGenerating = true;
  
  try {
    console.log('[CRE Generation] Starting with options:', options);
    
    // 👇 修改这部分：使用简洁的每日上下文
    // 原来：const signatureMemory = getSignaturePromptMemory();
    const signatureMemory = getDailySignatureContext();  // 使用新的简洁版本
    console.log('[CRE Generation] Daily context loaded:', signatureMemory);
    
    // 检查是否有 openaiComplete 的 generateCREWithOpenAI
    const openaiModule = await import('../../utils/openaiComplete');
    
    if (!openaiModule.generateCREWithOpenAI) {
      console.error('[CRE Generation] generateCREWithOpenAI not found in openaiComplete');
      throw new Error('generateCREWithOpenAI function not found');
    }
    
    // 调用 OpenAI 生成
    const result = await openaiModule.generateCREWithOpenAI({
      tone: options?.tone || 'gentle',
      trend: options?.trend || 'stable',
      microEmotion: options?.microEmotion,
      userContext: options?.userContext,
      signatureMemory,
    });

    const cre: GeneratedCRECue = {
      cue: result.cue,
      paragraph: result.paragraph,
      tone: result.tone,
      persona: result.persona,
      source: 'gpt',
    };

    // 记录到重放日志 - 只有在成功时才记录
    try {
      addSignatureCueReplayEntry({
        timestamp: new Date().toISOString(),
        type: 'identityCue',
        prompt: JSON.stringify(options),
        gptResponse: JSON.stringify(cre),
        tone: cre.tone,
        persona: cre.persona,
        cue: cre.cue
      });
    } catch (logError) {
      console.warn('[CRE Generation] Failed to log entry:', logError);
      // 不阻止返回结果
    }

    console.log('[CRE Generation] Success:', cre.cue);
    return cre;

  } catch (error) {
    console.error('[CRE Generation] Error:', error);
    return null;
  } finally {
    // 重置标志
    isGenerating = false;
  }
}

// 用于测试的简化版本
export async function testCREGeneration(): Promise<void> {
  console.log('[CRE Test] Starting test...');
  
  const result = await generateCRECueFromSignaturePrompt({
    tone: 'gentle',
    trend: 'wavy',
    userContext: 'Test context'
  });
  
  console.log('[CRE Test] Result:', result);
}