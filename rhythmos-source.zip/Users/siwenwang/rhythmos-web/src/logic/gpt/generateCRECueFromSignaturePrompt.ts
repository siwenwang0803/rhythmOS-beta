// /src/logic/generateCRECueFromSignaturePrompt.ts
// 修复导入和实现

import { getSignaturePromptMemory } from '../signature/getSignaturePromptMemory';
import { generateCREWithOpenAI, getDailySignatureContext } from '../../utils/openaiComplete';
import { addSignatureCueReplayEntry } from '../signature/SignatureCueReplayLog';
import { useCueAsPrompt } from '../../utils/cuePromptBuilder';

// 返回结构定义
export interface GeneratedCRECue {
  cue: string;
  paragraph: string;
  tone: string;
  persona: string;
  trend?: string;
  source?: string;
}

/**
 * generateCRECueFromSignaturePrompt
 * 从当前 SignaturePromptMemory + 高分 cue 样本，生成个性化 CRE cue + paragraph
 */
export async function generateCRECueFromSignaturePrompt(): Promise<GeneratedCRECue | null> {
  try {
    console.log('[generateCRECueFromSignaturePrompt] Starting generation...');
    
    // 获取用户上下文
    const dailyContext = getDailySignatureContext();
    const cuePrompt = useCueAsPrompt(); // 🧠 高分 cue 风格参考
    
    // 获取当前趋势
    const lastTrend = localStorage.getItem('lastTrend') || 'stable';
    const preferredTone = localStorage.getItem('preferredTone') || 'gentle';
    
    // 构建用户上下文
    let userContext = '';
    if (cuePrompt) {
      userContext = `Style reference: "${cuePrompt}"`;
    }

    // 使用新的 generateCREWithOpenAI 函数
    const result = await generateCREWithOpenAI({
      tone: preferredTone,
      trend: lastTrend,
      userContext: userContext,
      signatureMemory: dailyContext
    });

    const generatedCue: GeneratedCRECue = {
      cue: result.cue,
      paragraph: result.paragraph,
      tone: result.tone,
      persona: result.persona,
      trend: lastTrend,
      source: 'gpt'
    };

    // 记录生成日志
    try {
      addSignatureCueReplayEntry({
        timestamp: new Date().toISOString(),
        type: 'identityCue',
        prompt: JSON.stringify({
          tone: preferredTone,
          trend: lastTrend,
          context: dailyContext
        }),
        gptResponse: JSON.stringify(generatedCue),
        tone: generatedCue.tone,
        persona: generatedCue.persona,
        cue: generatedCue.cue
      });
    } catch (logError) {
      console.warn('[generateCRECueFromSignaturePrompt] Failed to log:', logError);
    }

    console.log('[generateCRECueFromSignaturePrompt] Generated:', generatedCue.cue);
    return generatedCue;

  } catch (err) {
    console.error('[generateCRECueFromSignaturePrompt] Error:', err);
    return null;
  }
}

