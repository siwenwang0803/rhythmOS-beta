// logic/getWeeklyHighlight.ts

import { format, subDays } from 'date-fns';

interface CueEntry {
  cueId: string;
  cueText: string;
  tone: string;
  trend: 'collapsed' | 'wavy' | 'stable' | 'rising';
  feedback: 'aligned' | 'okay' | 'notMe';
  timestamp: string;
}

export const getWeeklyHighlight = () => {
  try {
    const raw = localStorage.getItem('cueFeedbackLog');
    if (!raw) return null;

    const log: CueEntry[] = JSON.parse(raw);
    const today = new Date();
    const sevenDaysAgo = subDays(today, 7);

    // 过滤本周内 aligned + collapsed/wavy 的反馈
    const highlights = log.filter(entry => {
      const time = new Date(entry.timestamp);
      return (
        time >= sevenDaysAgo &&
        entry.feedback === 'aligned' &&
        (entry.trend === 'collapsed' || entry.trend === 'wavy')
      );
    });

    if (!highlights.length) return null;

    // 返回最早一次记录
    const first = highlights.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())[0];

    return {
      dateLabel: format(new Date(first.timestamp), 'EEEE'), // e.g. Wednesday
      trend: first.trend,
      cueText: first.cueText
    };
  } catch (e) {
    console.warn('[getWeeklyHighlight] Failed:', e);
    return null;
  }
};
