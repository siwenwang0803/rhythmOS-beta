// /src/logic/CueValidationLayer.ts

import { CRECue } from '../types/creTypes';

export interface CueValidationResult {
  isValid: boolean;
  reasons: string[];
}

/**
 * 校验当前 cue 是否符合 tone、persona、stage 等上下文要求
 */
export function validateCue(cue: CRECue): CueValidationResult {
  const reasons: string[] = [];

  // ✅ 基本字段存在性校验
  if (!cue.cue || !cue.paragraph) {
    reasons.push('Cue text or paragraph is missing');
  }

  // ✅ tone 和 persona 合法性（可以联动词典）
  const allowedTones = ['gentle', 'directive', 'rational', 'motivated', 'visionary', 'balanced'];
  if (!allowedTones.includes(cue.tone)) {
    reasons.push(`Invalid tone: ${cue.tone}`);
  }

  const allowedPersonas = ['rhea', 'caelum', 'aurelia', 'lucis', 'niveus'];
  if (!allowedPersonas.includes(cue.persona)) {
    reasons.push(`Invalid persona: ${cue.persona}`);
  }

  // ✅ cue 内容是否过短
  if (cue.cue.length < 6) {
    reasons.push('Cue text is too short');
  }

  // ✅ optional: 检查 stage 和 trend 是否逻辑匹配（后续可加强）

  const isValid = reasons.length === 0;
  return { isValid, reasons };
}
