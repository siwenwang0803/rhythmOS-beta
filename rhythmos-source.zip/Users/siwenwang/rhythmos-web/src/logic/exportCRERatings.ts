// logic/exportCRERatings.ts

export function downloadCRERatings(): void {
    const ratings = JSON.parse(localStorage.getItem('creSampleRatings') || '[]')
  
    const data = {
      exportedAt: new Date().toISOString(),
      total: ratings.length,
      samples: ratings
    }
  
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'cre-variant-feedback.json'
    link.click()
    URL.revokeObjectURL(url)
  }
  