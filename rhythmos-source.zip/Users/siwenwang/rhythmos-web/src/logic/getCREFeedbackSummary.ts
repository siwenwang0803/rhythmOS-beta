export function getCREFeedbackSummary(): string | null {
  const raw = localStorage.getItem('creSampleRatings')
  if (!raw) return null

  const ratings = JSON.parse(raw)

  const toneStats: Record<string, number[]> = {}

  ratings.forEach((entry: any) => {
    if (!toneStats[entry.tone]) toneStats[entry.tone] = []
    toneStats[entry.tone].push(entry.score)
  })

  const averages = Object.entries(toneStats)
    .filter(([_, scores]) => scores.length >= 3)
    .map(([tone, scores]) => {
      const avg = scores.reduce((a, b) => a + b, 0) / scores.length
      return { tone, avg: parseFloat(avg.toFixed(2)) }
    })

  if (averages.length === 0) return null

  averages.sort((a, b) => b.avg - a.avg)
  const best = averages[0]

  return `You seem to respond best to the "${best.tone}" tone (avg score: ${best.avg}). We’ll use it more.`
}
