// /src/logic/signature/getSignaturePromptMemory.ts
// 修复版本 - 使用正确的 localStorage key

/**
 * getSignaturePromptMemory - 返回格式化的 GPT 可读记忆段
 * 用于构建 CRE 生成 Prompt，不应触发 CRE 生成
 */
export function getSignaturePromptMemory(): string {
  // 修复：使用正确的 key 'signatureCueReplayLog'
  const raw = localStorage.getItem('signatureCueReplayLog') || '[]';

  try {
    const log = JSON.parse(raw);
    if (!Array.isArray(log) || log.length === 0) {
      // 提供更有帮助的默认记忆
      return 'The user is beginning their emotional rhythm journey.';
    }

    // 获取最近的条目
    const recentEntries = log.slice(0, 5); // 注意：log 是 latest first
    
    const summary = recentEntries.map((entry: any, i: number) => {
      // 尝试解析 gptResponse
      let cueText = '';
      try {
        const response = typeof entry.gptResponse === 'string' 
          ? JSON.parse(entry.gptResponse) 
          : entry.gptResponse;
        cueText = response.cue || 'Unknown cue';
      } catch {
        cueText = entry.gptResponse?.slice(0, 80) || 'Unknown cue';
      }
      
      return `${i + 1}. "${cueText}"`;
    }).join('\n');

    return `The user has recently resonated with identity cues such as:\n${summary}`;
  } catch (err) {
    console.error('[Memory] Failed to parse signatureCueReplayLog', err);
    return 'Memory data temporarily unavailable.';
  }
}

