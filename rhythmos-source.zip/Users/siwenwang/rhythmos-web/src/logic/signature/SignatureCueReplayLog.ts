// /src/logic/signature/SignatureCueReplayLog.ts

/**
 * SignatureCueReplayLog.ts
 * 记录系统使用结构化 cue prompt 生成的历史记录
 */

const LOCAL_STORAGE_KEY = 'signatureCueReplayLog';

export interface SignatureCueReplayEntry {
  timestamp: string;
  type: 'identityCue' | 'growthRecommendation';
  prompt: string;
  gptResponse: string;
}

export function getSignatureCueReplayLog(): SignatureCueReplayEntry[] {
  const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function addSignatureCueReplayEntry(entry: SignatureCueReplayEntry): void {
  const log = getSignatureCueReplayLog();
  log.unshift(entry); // latest first
  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(log.slice(0, 30)));
}
