// /src/logic/signature/getSignaturePromptMemory.ts

import { generateCRECueFromSignaturePrompt } from '../gpt/SignaturePromptEngine';

/**
 * getSignaturePromptMemory - 返回格式化的 GPT 可读记忆段
 * 可用于系统性 prompt 注入，例如：
 *  "As of this week, the user's resonance signature is..."
 */
export function getSignaturePromptMemory(): string {
    const summary = generateCRECueFromSignaturePrompt();

  if (!summary || typeof summary !== 'string' || summary.trim() === '') {
    return 'User behavior preference data is currently unavailable.';
  }

  return `User resonance signature:
${summary}`;
}
