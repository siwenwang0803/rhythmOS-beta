// /src/logic/signature/SignatureCueGenerator.ts

import { getSignaturePromptMemory } from './getSignaturePromptMemory';

/**
 * generateSystemCuePrompt - 构建带有记忆注入的 cue 生成系统提示
 * 可用于调用 OpenAI / Anthropic / Mistral 等 LLM 接口
 */
export function generateSystemCuePrompt(taskType: 'identityCue' | 'growthRecommendation' = 'identityCue'): string {
  const memory = getSignaturePromptMemory();

  const instructions = {
    identityCue: `You are an identity cue designer. Your goal is to generate a short but emotionally resonant prompt that helps the user align with their ideal rhythm and identity.

Use evocative, clear, and gentle language. Speak in a tone that reflects the user's current signature.`,

    growthRecommendation: `You are a rhythm growth advisor. Based on the user's current resonance signature, recommend one next action, habit, or psychological focus.

Keep the output actionable and supportive, grounded in behavioral psychology.`
  };

  const prefix = instructions[taskType] || instructions.identityCue;

  return `${prefix}

${memory}`;
}
