// SignaturePromptMemory.ts
// This module stores and retrieves recent CRE feedback memory entries

export interface PromptMemoryEntry {
    cueId: string;
    tone: string;
    persona: string;
    trend: string;
    feedbackScore: number;
    timestamp: string;
  }
  
  const MAX_MEMORY_ENTRIES = 40;
  
  export function getPromptMemory(): PromptMemoryEntry[] {
    const raw = localStorage.getItem('signaturePromptMemory');
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch (e) {
      console.warn('[PromptMemory] Failed to parse:', e);
      return [];
    }
  }
  
  export function savePromptMemory(entries: PromptMemoryEntry[]) {
    const trimmed = entries.slice(-MAX_MEMORY_ENTRIES); // Keep most recent 40
    localStorage.setItem('signaturePromptMemory', JSON.stringify(trimmed));
  }
  
  export function addPromptMemory(entry: PromptMemoryEntry) {
    const current = getPromptMemory();
    current.push(entry);
    savePromptMemory(current);
  }
  
  export function clearPromptMemory() {
    localStorage.removeItem('signaturePromptMemory');
  }
  