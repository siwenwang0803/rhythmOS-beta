// /src/logic/validation/validateCue.ts

import { stageFromTrend } from '../stageFromTrend';
import { CRECue } from '../creTypes';
import { getSignatureMap } from '../../SignatureMap';

export interface CueValidationResult {
  passed: boolean;
  reasons?: string[];
}

export function validateCue(cue: CRECue): CueValidationResult {
  const reasons: string[] = [];

  if (!cue || typeof cue !== 'object') {
    return { passed: false, reasons: ['Cue object is invalid or undefined.'] };
  }

  if (!cue.cue || cue.cue.length < 5) {
    reasons.push('Cue text is missing or too short.');
  }

  if (!cue.paragraph || cue.paragraph.length < 10) {
    reasons.push('Cue paragraph is missing or too short.');
  }

  if (!cue.persona) {
    reasons.push('Persona is missing.');
  }

  if (!cue.tone) {
    reasons.push('Tone is missing.');
  }

  const map = getSignatureMap();
  const currentPersona = map.personaAnchor || 'rhea';
  const trend = map.trendHistory?.[map.trendHistory.length - 1]?.trend || 'wavy';
  const expectedStage = stageFromTrend(trend);

  // Persona match
  if (cue.persona !== currentPersona) {
    reasons.push(`Persona mismatch: expected ${currentPersona}, got ${cue.persona}`);
  }

  // Stage match
  if (cue.stage && cue.stage !== expectedStage) {
    reasons.push(`Stage mismatch: expected ${expectedStage}, got ${cue.stage}`);
  }

  // Optional: tone validation (if trend → tone mapping logic defined)

  const passed = reasons.length === 0;
  return { passed, reasons: passed ? undefined : reasons };
}
