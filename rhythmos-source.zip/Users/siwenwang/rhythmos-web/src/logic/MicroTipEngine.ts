// MicroTipEngine.ts

/**
 * MicroTipEngine: generates a small suggestion based on user's current rhythm + feedback.
 * Used after NotMe feedback or in PassiveMode.
 */

export function getMicroTip(trend: string, feedback: string = 'notMe'): string {
    const fallback = 'Try one small thing to shift your rhythm.';
  
    if (feedback === 'notMe') {
      switch (trend) {
        case 'collapsed':
          return 'Take one deep breath, then write down one thing you can let go of.';
        case 'wavy':
          return 'Note one pattern that threw you off — just name it.';
        case 'stable':
          return 'Add one tiny surprise to your routine today.';
        case 'rising':
          return 'Channel that surge: pick one goal and do 5 minutes now.';
        default:
          return fallback;
      }
    }
  
    if (feedback === 'okay') {
      switch (trend) {
        case 'collapsed':
          return 'That’s okay. Try softening your schedule today — then check back.';
        case 'stable':
          return 'Okay means partial resonance. Try rewording the cue in your own terms.';
        default:
          return fallback;
      }
    }
  
    return fallback;
  }
  