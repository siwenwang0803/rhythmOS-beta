// /logic/identity/generateIdentityChallengeFromPersona.ts

import { openaiComplete } from '../../utils/openaiComplete';
import { identityAnchoringChallenges } from '../../data/identityAnchoringChallenges_v2';
import { personaMap } from '../../utils/personaMap';

export interface IdentityAnchoringChallenge {
  cue: string;
  paragraph: string;
  action: string;
}

// GPT 控制开关
const usePersonaGPT = false;

// ⏰ 根据当前时间判断早/午/晚
function getTimeOfDay(): 'morning' | 'afternoon' | 'evening' {
  const hour = new Date().getHours();
  if (hour < 12) return 'morning';
  if (hour < 18) return 'afternoon';
  return 'evening';
}

export async function generateIdentityChallengeFromPersona(
  persona: string,
  trend: string
): Promise<IdentityAnchoringChallenge> {
  const staticList = identityAnchoringChallenges[persona] || identityAnchoringChallenges['lucis'];

  if (!usePersonaGPT) {
    return staticList[Math.floor(Math.random() * staticList.length)];
  }

  const config = personaMap[persona] || personaMap['lucis'];
  const tone = config.tone;
  const traits = config.traits.join(', ');
  const desc = config.description;
  const timeOfDay = getTimeOfDay(); // 'morning' | 'afternoon' | 'evening'

  const prompt = `
You are an identity transformation coach.

Generate one high-impact behavioral challenge for today, helping a user act more like this persona:

Persona: ${persona.toUpperCase()}
Tone: ${tone}
Traits: ${traits}
Description: ${desc}
User state: ${trend}
Time of day: ${timeOfDay}

Output format (exactly 3 fields):
cue: [short belief statement]
paragraph: [1–2 sentence reflection]
action: [specific task they can perform today]
`;

  try {
    const result = await openaiComplete(prompt, {
      temperature: 0.8,
      max_tokens: 300
    });

    const lines = result.trim().split('\n');
    const cue = lines.find(l => l.startsWith('cue:'))?.replace('cue:', '').trim() || '';
    const paragraph = lines.find(l => l.startsWith('paragraph:'))?.replace('paragraph:', '').trim() || '';
    const action = lines.find(l => l.startsWith('action:'))?.replace('action:', '').trim() || '';

    if (!cue || !action) throw new Error('Incomplete GPT result');

    return { cue, paragraph, action };
  } catch (e) {
    console.warn('[IdentityChallenge] GPT fallback triggered:', e);
    return staticList[Math.floor(Math.random() * staticList.length)];
  }
}


