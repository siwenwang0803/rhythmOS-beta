import { classifyGoalIntent } from './goalIntentClassifier';
import { subtaskTemplateMap } from './subtaskTemplateMap';
import { generateCREVariants } from './generateCREVariants';

export interface SuggestedSubtask {
  text: string;
  cue: string;
  tone: string;
  taskType: string;
}

export function generateSubtaskSuggestions(goal: string, trend: string): SuggestedSubtask[] {
  const intent = classifyGoalIntent(goal);
  const template = subtaskTemplateMap.find(t => t.intent === intent);

  if (!template) {
    if (goal.toLowerCase().includes('read')) {
      return fallbackReadingSubtasks(trend);
    }
    return fallbackGenericSubtasks(trend);
  }

  return generateSuggestionsFromSteps(template.steps, trend);
}

// --------------------------
// 🔁 Helper Generators
// --------------------------

function generateSuggestionsFromSteps(steps: string[], trend: string): SuggestedSubtask[] {
  return steps.map((step, i) => {
    const tone = trend === 'collapsed' ? 'gentle' :
                 trend === 'wavy' ? 'motivated' :
                 trend === 'rising' ? 'directive' : 'gentle';

    let cue = '';
    try {
      const variants = generateCREVariants({ tone, taskType: 'light' });
      cue = variants[i % variants.length]?.text || 'Take one grounded step forward.';
    } catch {
      const fallbackCues = [
        'Even one step moves the rhythm forward.',
        'Clarity comes from gentle doing.',
        'You are building, breath by breath.',
        'Soft rhythm, strong foundation.',
        'Today’s effort defines tomorrow’s ease.'
      ];
      cue = fallbackCues[i % fallbackCues.length];
    }

    return {
      text: step,
      cue,
      tone,
      taskType: 'light'
    };
  });
}

function fallbackGenericSubtasks(trend: string): SuggestedSubtask[] {
  const steps = [
    'Define what success looks like for this goal.',
    'Identify the first small step to take.',
    'Schedule time on your calendar to work on this.',
    'Find resources or people who can help you.',
    'Create a way to track your progress.'
  ];
  return generateSuggestionsFromSteps(steps, trend);
}

function fallbackReadingSubtasks(trend: string): SuggestedSubtask[] {
  const steps = [
    'Choose which book to read first.',
    'Schedule dedicated reading time in your calendar.',
    'Read the first chapter and take notes.',
    'Share one insight from your reading with someone.',
    'Reflect on how the book relates to your life.'
  ];
  return generateSuggestionsFromSteps(steps, trend);
}
