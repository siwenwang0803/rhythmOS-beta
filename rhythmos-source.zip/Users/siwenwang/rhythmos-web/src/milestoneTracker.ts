// milestoneTracker.ts

export interface MilestoneEntry {
  type: string
  message: string
  timestamp: number
}

export function getMilestoneLog(): MilestoneEntry[] {
  const raw = localStorage.getItem('milestoneLog')
  return raw ? JSON.parse(raw) : []
}

export function addMilestone(type: string, message: string) {
  const raw = localStorage.getItem('milestoneLog')
  const log: MilestoneEntry[] = raw ? JSON.parse(raw) : []

  const exists = log.some(m => m.type === type)
  if (exists) return // don't duplicate same milestone

  log.push({ type, message, timestamp: Date.now() })
  localStorage.setItem('milestoneLog', JSON.stringify(log.slice(-50)))
}