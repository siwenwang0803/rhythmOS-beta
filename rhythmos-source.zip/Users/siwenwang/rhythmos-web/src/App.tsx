// App.tsx - 修复后的版本

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop';
import DevMenu from './components/DevMenu'; // 如果你创建了这个组件

// 页面导入
import ExportLogPage from './components/ExportLogPage';
import ViewLogPage from './log/ViewLogPage';
import GoalDetailPage from './pages/GoalDetailPage';
import GoalOverviewPage from './pages/GoalOverviewPage';
import CREStyleProfilePage from './pages/CREStyleProfilePage';
import CREBatchGenerator from './pages/CREBatchGenerator';
import GoalInputPage from './pages/GoalInputPage';
import GrowthMapPage from './pages/GrowthMapPage';
import OnboardingFlow from './pages/OnboardingFlow';
import LaunchPrepPage from './pages/LaunchPrepPage';
import SettingsPage from './pages/SettingsPage';
import SystemExportPage from './pages/SystemExportPage';
import SystemSummaryPage from './pages/SystemSummaryPage';
import TestGuide from './pages/TestGuide';
import RhythmCheckinPage from './pages/RhythmCheckinPage';
import ExperienceMapPage from './pages/ExperienceMapPage';
import PersonaReportPage from './pages/PersonaReportPage';
import JournalLogPage from './pages/JournalLogPage';
import PersonaArchivePage from './pages/PersonaArchivePage';
import CRELibraryPage from './pages/CRELibraryPage';
import CREExportPage from './pages/CREExportPage';
import CREImportPage from './pages/CREImportPage';
import CRETrainingReplayPage from './pages/CRETrainingReplayPage';
import JourneyPage from './pages/JourneyPage';
import SharePage from './pages/SharePage';
import SignatureLogPage from './pages/SignatureLogPage';
import CRECreator from './pages/CRECreator';
import IdentityStartPage from './pages/IdentityStartPage';
import IdentityTrainPage from './pages/IdentityTrainPage';
import MBTISelectorPage from './pages/MBTISelectPage';
import OnboardingStep1 from './pages/OnboardingStep1';
import OnboardingStep2 from './pages/OnboardingStep2';
import MBTISelectPage from './pages/MBTISelectPage';
import GuidePage from './pages/GuidePage';
import GlossaryPage from './pages/GlossaryPage';
import IdentityInsightPage from './pages/IdentityInsightPage';
import FeedbackLogDebugPage from './pages/FeedbackLogDebugPage';
import RhythmOSBetaWelcome from './pages/RhythmOSBetaWelcome';
import DevResetPage from './pages/DevResetPage';
import OnboardingFlowPreview from './pages/OnboardingFlowPreview';
import RhythmStateDebug from './pages/DebugRhythmState';
import BetaSummaryPage from './pages/BetaSummaryPage';
import DigestPage from './pages/DigestPage';
import IdentityGrowthPage from './pages/IdentityGrowthPage';
import CRETrainStudioPage from './pages/CRETrainStudioPage';
import TestOpenAI from './pages/TestOpenAI';

function App() {
  return (
    <Router>
      <div className="relative min-h-screen">
        <ScrollToTop />
        <Routes>
          {/* 主页 */}
          <Route path="/" element={<RhythmOSBetaWelcome />} />
          
          {/* 核心功能页面 */}
          <Route path="/rhythm" element={<RhythmCheckinPage />} />
          <Route path="/identity/start" element={<IdentityStartPage />} />
          <Route path="/identity/train" element={<IdentityTrainPage />} />
          <Route path="/identity/insight" element={<IdentityInsightPage />} />
          <Route path="/identity/growth" element={<IdentityGrowthPage />} />
          <Route path="/identity/mbti" element={<MBTISelectPage />} />
          
          {/* Onboarding 流程 */}
          <Route path="/onboarding" element={<OnboardingFlow />} />
          <Route path="/onboarding/step1" element={<OnboardingStep1 />} />
          <Route path="/onboarding/step2" element={<OnboardingStep2 />} />
          <Route path="/onboarding/flow-preview" element={<OnboardingFlowPreview />} />
          
          {/* 目标管理 */}
          <Route path="/goals" element={<GoalOverviewPage />} />
          <Route path="/goal-input" element={<GoalInputPage />} />
          <Route path="/goals/:id" element={<GoalDetailPage />} />
          
          {/* CRE 相关 */}
          <Route path="/cre-studio" element={<CRETrainStudioPage />} />
          <Route path="/cre-batch" element={<CREBatchGenerator />} />
          <Route path="/cre-library" element={<CRELibraryPage />} />
          <Route path="/cre-export" element={<CREExportPage />} />
          <Route path="/cre-import" element={<CREImportPage />} />
          <Route path="/cre-train-replay" element={<CRETrainingReplayPage />} />
          <Route path="/cre-creator" element={<CRECreator />} />
          
          {/* 个人档案和报告 */}
          <Route path="/profile" element={<CREStyleProfilePage />} />
          <Route path="/persona" element={<PersonaReportPage />} />
          <Route path="/archive" element={<PersonaArchivePage />} />
          
          {/* 日志和历史 */}
          <Route path="/view-log" element={<ViewLogPage />} />
          <Route path="/journal-log" element={<JournalLogPage />} />
          <Route path="/log-history" element={<SignatureLogPage />} />
          
          {/* 地图和可视化 */}
          <Route path="/map" element={<ExperienceMapPage />} />
          <Route path="/growth-map" element={<GrowthMapPage />} />
          <Route path="/journey" element={<JourneyPage />} />
          
          {/* 系统功能 */}
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/export" element={<SystemExportPage />} />
          <Route path="/summary" element={<SystemSummaryPage />} />
          <Route path="/share" element={<SharePage />} />
          <Route path="/digest" element={<DigestPage />} />
          <Route path="/beta/summary" element={<BetaSummaryPage />} />
          
          {/* 帮助和指南 */}
          <Route path="/guide" element={<GuidePage />} />
          <Route path="/glossary" element={<GlossaryPage />} />
          
          {/* 开发和调试 */}
          <Route path="/test-openai" element={<TestOpenAI />} />
          <Route path="/dev/feedback-log" element={<FeedbackLogDebugPage />} />
          <Route path="/debug/reset" element={<DevResetPage />} />
          <Route path="/debug/rhythm-state" element={<RhythmStateDebug />} />
        </Routes>
        
        {/* 开发工具菜单 - 在 Routes 外部 */}
        {import.meta.env.DEV && <DevMenu />}
      </div>
    </Router>
  );
}

export default App;

