// CREPersonaBiasMap.ts

import { creTemplates } from './creTemplateRegistry'
import { CREFeedbackEntry } from './components/feedbackRecord'

export function getPersonaBiasSummary(): {
  personaUsage: Record<string, number>
  topPersona: string | null
} {
  const raw = localStorage.getItem('creFeedbackLog')
  const feedback: CREFeedbackEntry[] = raw ? JSON.parse(raw) : []

  const usage: Record<string, number> = {}
  for (const entry of feedback) {
    if (!entry.persona) continue
    usage[entry.persona] = (usage[entry.persona] || 0) + 1
  }

  const sorted = Object.entries(usage).sort((a, b) => b[1] - a[1])
  const topPersona = sorted.length > 0 ? sorted[0][0] : null

  return {
    personaUsage: usage,
    topPersona
  }
}