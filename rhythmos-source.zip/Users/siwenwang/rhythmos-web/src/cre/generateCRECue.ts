// /src/logic/generateCRECue.ts
// 更新后的 generateCRECue，集成 GPT 功能和版本切换

import { creBlocks } from '../cre/creBlockLibrary';
import { stageFromTrend } from './stageFromTrend';
import { generateCRECueFromSignaturePrompt } from '../logic/gpt/SignaturePromptEngine';

export type CRECue = {
  id?: string;
  cue: string;
  paragraph: string;
  persona: string;
  tone: string;
  stage: string;
  taskType?: string;
  voiceStyle?: string;
  rhythm?: string;
  source?: 'static' | 'gpt' | 'exploratory';
};

interface GenerateCRECueOptions {
  preferredTone: string;
  initPersona: string;
  trend: string;
  context?: string;
  currentCueId?: string;
  excludeCueId?: string;
  microEmotion?: string;
  userContext?: string;
}

// ✅ 配置选项 - 添加版本切换逻辑
const USE_GPT_CRE = localStorage.getItem('useGptCRE') !== 'false'; // 默认为 true，除非明确设置为 false
const useMockInDev = false;   // 关闭模拟模式，使用真实 API

// 导出设置函数，供其他组件使用
export function setUseGptCRE(value: boolean) {
  localStorage.setItem('useGptCRE', value.toString());
  // 可选：触发页面刷新或状态更新
  window.location.reload();
}

export function getUseGptCRE(): boolean {
  return localStorage.getItem('useGptCRE') !== 'false';
}

function normalize(value: string): string {
  return value?.toLowerCase().trim();
}

function shuffle<T>(arr: T[]): T[] {
  return [...arr].sort(() => Math.random() - 0.5);
}

function pickCueFromList(cues: CRECue[], excludeId?: string): CRECue | null {
  if (!cues || cues.length === 0) return null;
  const filtered = excludeId ? cues.filter(c => c.id !== excludeId && c.cue !== excludeId) : cues;
  const pool = filtered.length > 0 ? filtered : cues;
  return shuffle(pool)[0] || null;
}

// 模拟 GPT 生成的 CRE
function generateMockCRE(options: GenerateCRECueOptions): CRECue {
  const { tone, trend, microEmotion, userContext } = options;
  
  // 根据不同的 tone 和 trend 组合返回不同的模拟数据
  const mockCREs: Record<string, Record<string, CRECue>> = {
    gentle: {
      collapsed: {
        cue: "Rest is not giving up",
        paragraph: "When exhaustion takes over, the kindest thing you can do is honor your need for restoration. Tomorrow's strength comes from today's rest.",
        tone: "gentle",
        persona: "rhea",
        stage: "awareness"
      },
      wavy: {
        cue: "Ride the waves, don't fight them",
        paragraph: "Emotional fluctuations are natural rhythms. Like ocean waves, they rise and fall. Your task is to surf, not to stop the tide.",
        tone: "gentle",
        persona: "rhea",
        stage: "awareness"
      },
      stable: {
        cue: "Steady progress is still progress",
        paragraph: "In this calm moment, appreciate how far you've come. Stability is the foundation for sustainable growth.",
        tone: "gentle",
        persona: "rhea",
        stage: "integration"
      },
      rising: {
        cue: "Channel this energy wisely",
        paragraph: "Your momentum is building beautifully. Remember to pace yourself - sustainable speed beats burnout every time.",
        tone: "gentle",
        persona: "rhea",
        stage: "breakthrough"
      }
    },
    directive: {
      wavy: {
        cue: "Choose your focus for the next hour",
        paragraph: "When emotions fluctuate, structure becomes your friend. Pick one meaningful task and commit to it fully.",
        tone: "directive",
        persona: "caelum",
        stage: "awareness"
      }
    },
    rational: {
      wavy: {
        cue: "Map your emotional patterns",
        paragraph: "Understanding your rhythms gives you power. Notice what triggers shifts and what helps you find balance.",
        tone: "rational",
        persona: "aurelia",
        stage: "awareness"
      }
    }
  };
  
  // 获取对应的模拟 CRE
  const toneGroup = mockCREs[tone] || mockCREs.gentle;
  const mockCRE = toneGroup[trend] || toneGroup.wavy || mockCREs.gentle.wavy;
  
  console.log('[CRE] 🎭 Using mock CRE:', mockCRE.cue);
  
  return {
    ...mockCRE,
    rhythm: trend,
    source: 'gpt', // 标记为 GPT 以测试流程
    stage: stageFromTrend(trend)
  };
}

// 验证 CRE 的函数
function validateCue(cue: any): { isValid: boolean; reasons: string[] } {
  const reasons: string[] = [];
  
  if (!cue) {
    reasons.push('Cue is null or undefined');
    return { isValid: false, reasons };
  }
  
  if (!cue.cue || cue.cue.trim().length === 0) {
    reasons.push('Cue text is empty');
  }
  
  if (!cue.paragraph || cue.paragraph.trim().length === 0) {
    reasons.push('Paragraph is empty');
  }
  
  if (!cue.tone || cue.tone.trim().length === 0) {
    reasons.push('Tone is empty');
  }
  
  if (!cue.persona || cue.persona.trim().length === 0) {
    reasons.push('Persona is empty');
  }
  
  // 检查 cue 长度（应该少于12个词）
  if (cue.cue && cue.cue.split(' ').length > 12) {
    reasons.push('Cue is too long (should be under 12 words)');
  }
  
  return { isValid: reasons.length === 0, reasons };
}

export async function generateCRECueAsync(options: GenerateCRECueOptions): Promise<CRECue> {
  const { preferredTone, initPersona, trend, context, currentCueId, microEmotion, userContext } = options;
  
  // 检查版本切换开关
  const useGPT = getUseGptCRE();
  console.log('[CRE] 📋 Version mode:', useGPT ? 'GPT' : 'Static');

  // 如果关闭了 GPT，直接使用静态版本
  if (!useGPT) {
    console.log('[CRE] 📚 Using static CRE (GPT disabled by user)');
    return generateCRECue({ 
      preferredTone, 
      initPersona, 
      trend, 
      context, 
      currentCueId,
      microEmotion,
      userContext 
    });
  }

  // 在开发环境下使用模拟数据
  if (import.meta.env.DEV && useMockInDev) {
    console.log('[CRE] 🎭 Dev mode: Using mock CRE generation');
    return generateMockCRE(options);
  }

  // 尝试使用 GPT 生成
  try {
    console.log('[CRE] 🤖 Attempting GPT generation...');
    
    const gptCue = await generateCRECueFromSignaturePrompt({
      tone: preferredTone,
      trend: trend,
      microEmotion: microEmotion,
      userContext: userContext || context,
    });

    if (gptCue) {
      const { isValid, reasons } = validateCue(gptCue);
      if (isValid) {
        console.log('[CRE] ✅ GPT generation successful:', gptCue.cue);
        return {
          ...gptCue,
          rhythm: trend,
          source: 'gpt',
          stage: stageFromTrend(trend)
        };
      } else {
        console.warn('[CRE] ❌ GPT validation failed:', reasons);
      }
    }
  } catch (e) {
    console.warn('[CRE] ❌ GPT generation error:', e);
  }

  // Fallback to local static cue
  console.log('[CRE] 📚 Falling back to static CRE...');
  return generateCRECue({ 
    preferredTone, 
    initPersona, 
    trend, 
    context, 
    currentCueId,
    microEmotion,
    userContext 
  });
}

export function generateCRECue({
  preferredTone,
  initPersona,
  trend,
  context,
  currentCueId,
  microEmotion,
  userContext
}: GenerateCRECueOptions): CRECue {
  const stage = stageFromTrend(trend);
  const tone = normalize(preferredTone);
  const persona = normalize(initPersona);
  const stageKey = normalize(stage);

  console.log('[CRE] Generating static cue →', { 
    tone, 
    persona, 
    stage: stageKey, 
    trend, 
    context,
    microEmotion 
  });

  // 严格匹配：tone + persona + stage
  const strictMatches = creBlocks.filter(
    block =>
      normalize(block.tone) === tone &&
      normalize(block.persona) === persona &&
      normalize(block.stage) === stageKey
  );
  if (strictMatches.length > 0) {
    const picked = pickCueFromList(strictMatches, currentCueId);
    console.log('[CRE] ✅ Strict match picked:', picked?.cue);
    return { ...picked, rhythm: trend, source: 'static' };
  }

  // 次优匹配：tone + stage
  const toneStageMatches = creBlocks.filter(
    block => normalize(block.tone) === tone && normalize(block.stage) === stageKey
  );
  if (toneStageMatches.length > 0) {
    const picked = pickCueFromList(toneStageMatches, currentCueId);
    console.log('[CRE] ✅ Tone + Stage match picked:', picked?.cue);
    return { ...picked, rhythm: trend, source: 'static' };
  }

  // 仅匹配 tone
  const toneMatches = creBlocks.filter(block => normalize(block.tone) === tone);
  if (toneMatches.length > 0) {
    const picked = pickCueFromList(toneMatches, currentCueId);
    console.log('[CRE] ✅ Tone-only match picked:', picked?.cue);
    return { ...picked, rhythm: trend, source: 'static' };
  }

  // 最终 fallback
  const fallback = creBlocks.find(block => block.tone === 'gentle') || creBlocks[0];
  console.log('[CRE] ⚠️ Fallback to gentle:', fallback?.cue);
  return { ...fallback, rhythm: trend, source: 'static' };
}

