// /src/cre/generateCRECueAsync.ts

import { generateCRECueFromSignaturePrompt } from '../logic/gpt/SignaturePromptEngine';
import { matchCREBlock } from '../logic/matchCREBlock';

export async function generateCRECueAsync(inputText: string, trend: string) {
  const useSignatureGPT = true;

  if (useSignatureGPT) {
    const result = await generateCRECueFromSignaturePrompt();
    if (result) {
      return {
        ...result,
        rhythm: trend
      };
    }
  }

  // fallback
  const block = matchCREBlock(inputText, trend);
  return {
    cue: block?.cue || 'Let’s begin from where you are.',
    paragraph: block?.paragraph || 'Even one small shift in rhythm is a beginning.',
    tone: block?.tone || 'gentle',
    persona: block?.persona || 'rhea',
    rhythm: trend,
  };
}
