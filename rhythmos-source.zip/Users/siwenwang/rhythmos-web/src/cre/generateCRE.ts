import { RhythmSignatureMap } from '../rhythmSignature'
import { getCREStylePreference } from '../creStylePreference'
import { generateCREVariant } from './generateCREVariant'
import { CRETone, CREStage, CRETaskType, creVariants } from './creVariantRegistry'
import { isToneLocked } from '../logic/rhythmTrendGuard'

export function generateCRE({
  trend,
  stage,
  taskType,
  signature,
  override
}: {
  trend: string
  stage: CREStage
  taskType: CRETaskType
  signature: RhythmSignatureMap
  override?: string
}): string {
  const tone: CRETone =
    (isToneLocked(trend) as CRETone) ||
    (override as CRETone) ||
    getCREStylePreference(signature).tone ||
    'gentle'

  // fallback to creVariants
  const cuePool = creVariants?.[tone]?.[stage]?.[taskType]
  if (cuePool && cuePool.length > 0) {
    const cue = cuePool[Math.floor(Math.random() * cuePool.length)]
    return cue
  }

  // fallback to sample generator
  const cue = generateCREVariant({ tone, stage, taskType })
  return cue || 'Let rhythm guide you.'
}

