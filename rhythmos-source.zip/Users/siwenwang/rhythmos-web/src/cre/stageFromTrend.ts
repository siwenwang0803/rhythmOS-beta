// /cre/stageFromTrend.ts

import { CREStage } from './creVariantRegistry'

export function stageFromTrend(trend: string): CREStage {
  switch (trend) {
    case 'collapsed':
      return 'initial'
    case 'wavy':
      return 'middle'
    case 'stable':
      return 'middle'
    case 'rising':
      return 'final'
    default:
      return 'middle'
  }
}
