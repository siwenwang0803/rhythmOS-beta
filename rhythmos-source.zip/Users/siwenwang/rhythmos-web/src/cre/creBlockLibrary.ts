// cre/creBlockLibrary.ts

export interface CREBlock {
    cue: string
    paragraph: string
    tone: 'gentle' | 'directive' | 'motivated' | 'visionary' | 'rational'
    persona: string
    stage: 'initial' | 'middle' | 'final'
    taskType: 'minimal' | 'light' | 'normal' | 'challenge'
    voiceStyle?: 'default' | 'family' | 'coach' | 'innerDialogue'
  }
  
  export const creBlocks: CREBlock[] = [

  {
    cue: "[Rhea says:] You’re allowed to begin softly. One breath is enough.",
    paragraph: "You've had a few slow days lately, and that's okay. What if starting today simply means breathing with awareness? Try this: take one calm breath, and write one word for how it felt.",
    tone: "gentle",
    persona: "rhea",
    stage: "initial",
    taskType: "minimal",
    voiceStyle: "family"
  },
  {
    cue: "[Rhea says:] Just pause. That alone counts.",
    paragraph: "Even in stillness, your rhythm continues. When was the last time you gave yourself permission to not act? Try sitting still for 30 seconds, and note what sensations arise.",
    tone: "gentle",
    persona: "rhea",
    stage: "initial",
    taskType: "minimal",
    voiceStyle: "family"
  },
  {
    cue: "[Rhea says:] Let the rhythm begin with ease.",
    paragraph: "You've been holding tension—it's okay to soften. What would a gentle beginning look like right now? Try closing your eyes and noticing the light in the room for one minute.",
    tone: "gentle",
    persona: "rhea",
    stage: "initial",
    taskType: "minimal",
    voiceStyle: "family"
  },
  {
    cue: "[Rhea says:] Breathe once. That is movement already.",
    paragraph: "Your rhythm doesn’t need to be loud to be real. What happens when you treat breath as progress? Try this: inhale deeply, then write where in your body the breath moved.",
    tone: "gentle",
    persona: "rhea",
    stage: "initial",
    taskType: "minimal",
    voiceStyle: "family"
  },
  {
    cue: "[Rhea says:] Start with noticing, not forcing.",
    paragraph: "You've been under pressure — let’s not add more. What can you notice around you without needing to change it? Try describing one nearby sound or scent in a sentence.",
    tone: "gentle",
    persona: "rhea",
    stage: "initial",
    taskType: "minimal",
    voiceStyle: "family"
  },
  {
    cue: "[Rhea says:] Gently meet yourself where you are.",
    paragraph: "Today’s energy may be low — and that’s completely allowed. What would it mean to just accept that? Try this: write one sentence beginning with 'Right now, I am…'",
    tone: "gentle",
    persona: "rhea",
    stage: "initial",
    taskType: "minimal",
    voiceStyle: "family"
  },
  {
    cue: "[Rhea says:] Let this moment be enough to start.",
    paragraph: "You might feel behind — but you’re not. What if this very moment is your first step? Try placing your hand on your chest, then write how that small act feels.",
    tone: "gentle",
    persona: "rhea",
    stage: "initial",
    taskType: "minimal",
    voiceStyle: "family"
  },
  {
    cue: "[Rhea says:] Whisper, not shout. Begin softly.",
    paragraph: "Not every beginning needs to be big. How can you approach today like a whisper instead of a shout? Try naming one small thing you can do with tenderness.",
    tone: "gentle",
    persona: "rhea",
    stage: "initial",
    taskType: "minimal",
    voiceStyle: "family"
  },
  {
    cue: "[Rhea says:] A quiet step counts.",
    paragraph: "Sometimes the softest steps are the most important. What’s the smallest shift that still honors your rhythm? Try taking a sip of water, then write how it grounded you.",
    tone: "gentle",
    persona: "rhea",
    stage: "initial",
    taskType: "minimal",
    voiceStyle: "family"
  },
  {
    cue: "[Lucis says:] Let your vision interrupt the pattern.",
    paragraph: "You’ve felt the old rhythm loop too many times — but this moment can rewrite the script. What’s one frame you can break today, even if gently? Try this: describe one pattern you’re done repeating.",
    tone: "visionary",
    persona: "lucis",
    stage: "middle",
    taskType: "normal",
    voiceStyle: "family"
  },
  {
    cue: "[Lucis says:] What you’re doing isn’t just execution — it’s authorship.",
    paragraph: "Lately, you’ve been tasking without meaning — but that doesn’t have to stay true. What future are you quietly writing with your actions today? Try this: write one line that begins with ‘I am shaping a day where…’",
    tone: "visionary",
    persona: "lucis",
    stage: "middle",
    taskType: "normal",
    voiceStyle: "innerDialogue"
  },
  
  {
    cue: "[Lucis says:] Realignment is momentum, not delay.",
    paragraph: "You might feel behind — but pausing to adjust isn’t weakness, it’s intelligence. What would it mean to change direction without shame? Try this: name one adjustment you’re making today, and own it.",
    tone: "visionary",
    persona: "lucis",
    stage: "middle",
    taskType: "normal",
    voiceStyle: "family"
  },
    
  {
    cue: "[Rhea says:] That small step? It matters.",
    paragraph: "You don’t need to do it all — you just need to not freeze. One step keeps things moving. What’s a tiny thing you can do in the next 5 minutes? Go do it. It counts.",
    tone: "gentle",
    persona: "rhea",
    stage: "initial",
    taskType: "minimal",
    voiceStyle: "family"
  },

    {
      cue: "[Caelum says:] You’ve already built some flow — don’t stop to doubt it.",
      paragraph: "You’ve started. That matters. You don’t need to overthink the next step — just take it. Try this: keep the momentum going by tackling one thing without checking your phone first.",
      tone: "motivated",
      persona: "caelum",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "family"
    }
    
,
{
  cue: "[Caelum says:] The work you’ve already done is adding up — stay with it.",
  paragraph: "You don’t need to create magic. You just need to not quit right now. What’s one thing today that can add to your momentum? Try writing it down and starting it without stalling.",
  tone: "motivated",
  persona: "caelum",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "family"
}
,
{
  cue: "[Caelum says:] You’ve already started — now let’s push it a little further.",
  paragraph: "The hardest part’s done. Now it’s just about choosing not to drop the thread. What’s something you can finish today that proves you’re in it? Try picking one item you can close out in the next 30 minutes.",
  tone: "motivated",
  persona: "caelum",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "family"
}
,
{
  cue: "[Caelum says:] You’re already moving — don’t overthink it.",
  paragraph: "Momentum’s on your side, even if it doesn’t feel dramatic. What’s one thing you can do right now without needing a perfect plan? Just pick it, and go.",
  tone: "motivated",
  persona: "caelum",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "family"
},
{
  cue: "[Caelum says:] The tough part? That’s the signal — not the stop sign.",
  paragraph: "If this feels uncomfortable, that might mean it’s working. What’s one thing you’ve been holding back on? Try leaning into it for just 10 focused minutes.",
  tone: "motivated",
  persona: "caelum",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "family"
},
{
  cue: "[Caelum says:] You’ve built this rhythm — keep shaping it.",
  paragraph: "It’s not luck. It’s habit. And every choice you make now is part of it. What’s one repeatable thing you can do today to feel more solid? Try writing it down and checking it off when done.",
  tone: "motivated",
  persona: "caelum",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "family"
},
{
  cue: "[Lucis says:] This start might look small — but it echoes.",
  paragraph: "You might not feel ready, but you showed up — and that shapes who you’re becoming. What’s one small action that matches the person you want to be? Try this: write one sentence beginning with 'Today, I choose to…'",
  tone: "visionary",
  persona: "lucis",
  stage: "initial",
  taskType: "light",
  voiceStyle: "family"
},
{
  cue: "[Lucis says:] This isn’t just a start — it’s a message to yourself.",
  paragraph: "You’re not proving anything to anyone today. But you *are* showing your future self what kind of day this will be. What would it mean to begin like it matters? Try this: write down one word that describes how you want to feel later — and let it guide the first thing you do.",
  tone: "visionary",
  persona: "lucis",
  stage: "initial",
  taskType: "light",
  voiceStyle: "family"
},
{
  cue: "[Caelum says:] Strong doesn’t have to mean burnt out.",
  paragraph: "You’ve carried enough. Now finish like someone who chose this — not someone who barely survived it. What’s one small thing you can close with clarity? Try naming it now, then give it your last clean effort.",
  tone: "motivated",
  persona: "caelum",
  stage: "final",
  taskType: "normal",
  voiceStyle: "family"
},
{
  cue: "[Caelum says:] Finish with pride — not hurry.",
  paragraph: "You’re not running out the clock — you’re wrapping it right. What would it mean to end the day knowing you chose *how* to finish? Try this: before you shut it down, list one win from today — no matter how small.",
  tone: "motivated",
  persona: "caelum",
  stage: "final",
  taskType: "normal",
  voiceStyle: "family"
},
{
  cue: "[Lucis says:] You’re not just checking off a task — you’re shaping direction.",
  paragraph: "Even this tiny step sets a tone. What are you building toward, without even realizing? Try writing one sentence starting with 'The kind of person I’m practicing being is…'",
  tone: "visionary",
  persona: "lucis",
  stage: "initial",
  taskType: "light",
  voiceStyle: "family"
}
,
{
  cue: "[Lucis says:] Stillness isn’t nothing — it’s a decision.",
  paragraph: "Even your pauses today carry weight. What’s one quiet move that could signal momentum without loud effort? Try sitting still for 30 seconds, then write down one word you felt during that pause.",
  tone: "visionary",
  persona: "lucis",
  stage: "initial",
  taskType: "light",
  voiceStyle: "family"
},
{
  cue: "[Lucis says:] Before the action — breathe in the reason.",
  paragraph: "No need to rush in. Let this next breath be the point where the day turns. What are you stepping into — and why? Try this: close your eyes for 5 seconds, then write what matters right now.",
  tone: "visionary",
  persona: "lucis",
  stage: "initial",
  taskType: "light",
  voiceStyle: "family"
},
{
  cue: "[Lucis says:] Just because it looks familiar, doesn’t mean it’s the same.",
  paragraph: "You’ve been here before — but this version of you hasn’t. What’s one small way today can say something different? Try writing a sentence that starts: 'This time, I will…'",
  tone: "visionary",
  persona: "lucis",
  stage: "initial",
  taskType: "light",
  voiceStyle: "family"
}
,

{
  cue: "[Lucis says:] Before anything grows tall, it anchors deep.",
  paragraph: "You don’t need to go fast right now — you need to be steady. What’s one quiet step that still means something? Try this: write one intention, and hold it for the next 10 minutes.",
  tone: "visionary",
  persona: "lucis",
  stage: "initial",
  taskType: "light",
  voiceStyle: "family"
}
,
{
  cue: "[Lucis says:] Don’t skip the opening scene — this one sets the tone.",
  paragraph: "The way you start today will echo longer than you think. What’s one move that makes you feel like you’re building something that matters? Try this: name one small task as if it were your headline for the day.",
  tone: "visionary",
  persona: "lucis",
  stage: "initial",
  taskType: "light",
  voiceStyle: "innerDialogue"
}
,
{
  cue: "[Lucis says:] You’re not here to prove anything — just to try something that feels true.",
  paragraph: "Today doesn’t have to be a conclusion. It can be an experiment. What’s one thing you can test without pressure? Try writing one small question you’d like today to help you answer.",
  tone: "visionary",
  persona: "lucis",
  stage: "initial",
  taskType: "light",
  voiceStyle: "family"
}
,
{
  cue: "[Lucis says:] Every move you make today has a ripple.",
  paragraph: "The decisions you make right now may feel small — but they add up. What kind of tomorrow are you quietly leaning toward? Try writing one thing today that will make future-you feel grounded.",
  tone: "visionary",
  persona: "lucis",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "family"
}
,
    
{
  cue: "[Niveus says:] 25 minutes. One block. No excuses.",
  paragraph: "You said you wanted to change — this is what it looks like. Block the noise. Start the timer. Finish one real thing before noon. You don’t need motivation — you need a decision.",
  tone: "directive",
  persona: "niveus",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "coach"
}
,
{
  cue: "[Niveus says:] Set the timer. Start the block. Nothing else matters.",
  paragraph: "You don’t need a mood. You need a move. Choose one clear task, press start, and go full focus for 25 minutes. Don’t wait to feel ready — act, and rhythm will follow.",
  tone: "directive",
  persona: "niveus",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "coach"
},
{
  cue: "[Niveus says:] Skip the scroll. Get to the next thing.",
  paragraph: "Distraction feels safer, but it's killing your rhythm. What’s the one thing that actually moves the needle right now? Do it — before your brain finds another excuse.",
  tone: "directive",
  persona: "niveus",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "coach"
},
{
  cue: "[Niveus says:] Lock in. You owe yourself this finish.",
  paragraph: "It’s not about mood — it’s about the decision to complete. You’ve done half the work already. Now see it through. Start the timer. No tabs. No toggling.",
  tone: "directive",
  persona: "niveus",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "coach"
},

{
  cue: "[Aurelia says:] Pause. Think clearly — then move.",
  paragraph: "You don’t need to push harder. You need to remove the noise. What’s the frame that makes this action obvious? Try writing the 'why' behind what you're about to do.",
  tone: "rational",
  persona: "aurelia",
  stage: "initial",
  taskType: "light",
  voiceStyle: "default"
}
,
{
  cue: "[Aurelia says:] You don’t need force. You need a plan.",
  paragraph: "When clarity fades, systems hold you. What’s one small structure you can put in place right now? Try listing the exact three things you know you’ll touch today.",
  tone: "rational",
  persona: "aurelia",
  stage: "initial",
  taskType: "light",
  voiceStyle: "innerDialogue"
}
,
{
  cue: "[Aurelia says:] Don’t push the feeling away — organize it.",
  paragraph: "Overwhelm often hides in the unsorted. What’s one thing you’re feeling? Label it. Map it. Reduce the blur. Try creating a three-word mindmap for what’s in your head right now.",
  tone: "rational",
  persona: "aurelia",
  stage: "initial",
  taskType: "light",
  voiceStyle: "default"
}
,
    
{
  cue: "[Niveus says:] You don’t need perfect — you need movement.",
  paragraph: "Perfection is the enemy of now. Pick a direction, act, and refine later. Try this: choose one unfinished task and move it forward by 10%. That’s progress.",
  tone: "directive",
  persona: "niveus",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "coach"
}
,
{
  cue: "[Niveus says:] Stop debating with yourself. Decide, then execute.",
  paragraph: "Momentum hates indecision. What’s your next move? Pick it, and act without explaining it to yourself again. Do it first — understand it later.",
  tone: "directive",
  persona: "niveus",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "coach"
}
,
{
  cue: "[Niveus says:] Don’t master the day — master the next 25 minutes.",
  paragraph: "Trying to win the whole day is overwhelming. Win the block. One focus. Full presence. Set your timer now and give it clean execution — nothing scattered.",
  tone: "directive",
  persona: "niveus",
  stage: "middle",
  taskType: "normal",
  voiceStyle: "coach"
}
,
    
    {
      cue: "[Aurelia says:] You don’t need to solve everything. Just the next step.",
      paragraph: "Your brain sees the whole mountain — no wonder you froze. But progress lives in the next ledge. What’s one chunk you *already understand*? Start there.",
      tone: "rational",
      persona: "aurelia",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "default"
    }
    ,
    {
      cue: "[Aurelia says:] Clarity isn’t found — it’s designed.",
      paragraph: "Feeling scattered doesn’t mean you’re lost — just unstructured. What’s one small system that would reduce confusion right now? Try writing a three-bullet checklist for just this hour.",
      tone: "rational",
      persona: "aurelia",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "default"
    }
    ,
    {
      cue: "[Aurelia says:] Don’t start from scratch — start from what’s stable.",
      paragraph: "You already have things that are functioning. Use them. What’s one workflow or habit that felt solid this week? Try replicating it now before you fix what’s broken.",
      tone: "rational",
      persona: "aurelia",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "default"
    },
    {
      cue: "[Aurelia says:] Emotion clouds — structure clears.",
      paragraph: "If everything feels messy, start with one question: what’s next? Build the answer like a step-by-step instruction. Try sketching the next 3 moves as if writing them for someone else to follow.",
      tone: "rational",
      persona: "aurelia",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "default"
    }
    ,
    {
      cue: "[Aurelia says:] Energy fades. Structure remains.",
      paragraph: "Don’t rely on hype. Build rhythms you can repeat. What’s one repeatable step you can do again tomorrow? Try simplifying a task until it fits into a template.",
      tone: "rational",
      persona: "aurelia",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "default"
    }
    ,
    {
      cue: "[Aurelia says:] Speed without order burns out fast.",
      paragraph: "You’ve been moving — but is it stable? Take a minute to check your structure. Try reorganizing your task list into ‘now’, ‘next’, and ‘later’.",
      tone: "rational",
      persona: "aurelia",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "default"
    }
    ,
    {
      cue: "[Rhea says:] Stay soft — but steady.",
      paragraph: "You don’t have to rush. You just need to not disappear. What would a small but steady act look like right now? Try this: set a timer for 10 minutes and just begin, gently.",
      tone: "gentle",
      persona: "rhea",
      stage: "middle",
      taskType: "light",
      voiceStyle: "family"
    },
    {
      cue: "[Rhea says:] Each step counts — even the quiet ones.",
      paragraph: "You’re building something real. Even when it feels small. What’s one gentle action you can do without stress? Try naming it now — and giving it five calm minutes.",
      tone: "gentle",
      persona: "rhea",
      stage: "middle",
      taskType: "light",
      voiceStyle: "family"
    },
    {
      cue: "[Rhea says:] You can go slow — and still be strong.",
      paragraph: "Today doesn’t have to be fast. It just has to be honest. What’s one thing you can do at your own pace? Try choosing it, and letting that choice be enough.",
      tone: "gentle",
      persona: "rhea",
      stage: "middle",
      taskType: "light",
      voiceStyle: "family"
    },
    {
      cue: "[Rhea says:] Gentleness isn’t weakness. It’s wisdom.",
      paragraph: "There’s power in not pushing too hard. What can you approach with care, not force? Try softening your posture while you work on one small task.",
      tone: "gentle",
      persona: "rhea",
      stage: "middle",
      taskType: "light",
      voiceStyle: "family"
    },
    {
      cue: "[Rhea says:] Growth doesn’t always roar.",
      paragraph: "Sometimes the most lasting progress is the quiet kind. What’s one thing you’ve done repeatedly — even gently — that proves you’re growing? Try writing it down.",
      tone: "gentle",
      persona: "rhea",
      stage: "middle",
      taskType: "light",
      voiceStyle: "family"
    },
    {
      cue: "[Rhea says:] You don’t need to fight. Just keep going.",
      paragraph: "There’s enough resistance out there — you don’t need to add more. What’s a small next step you can take without bracing yourself? Try breathing once, then beginning.",
      tone: "gentle",
      persona: "rhea",
      stage: "middle",
      taskType: "light",
      voiceStyle: "family"
    },
    
    {
      cue: "[Aurelia says:] Strip it down until you can’t *not* do it.",
      paragraph: "Overcomplexity is resistance in disguise. What would this task look like if it were 30% easier? Try rewriting it in one sentence that even tired-you would start.",
      tone: "rational",
      persona: "aurelia",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "default"
    }
    ,
    {
      cue: "[Niveus says:] Don’t ease up — finish like you mean it.",
      paragraph: "The final stretch is where momentum locks in. You’ve come this far — now seal it. Try setting a 20-minute block with no breaks. Just close it clean.",
      tone: "directive",
      persona: "niveus",
      stage: "final",
      taskType: "challenge",
      voiceStyle: "coach"
    },
    {
      cue: "[Niveus says:] No drag. Just drive.",
      paragraph: "Endings shape the rhythm you carry into tomorrow. What would it look like to close today with power? Try naming your final task — then execute it now.",
      tone: "directive",
      persona: "niveus",
      stage: "final",
      taskType: "challenge",
      voiceStyle: "coach"
    },
    {
      cue: "[Niveus says:] This is the last sprint. Go all in.",
      paragraph: "You’ve already built momentum — now finish with focus. Set a countdown, close the loops, and feel the shift when you push clean through.",
      tone: "directive",
      persona: "niveus",
      stage: "final",
      taskType: "challenge",
      voiceStyle: "coach"
    },
    {
      cue: "[Niveus says:] Don’t trail off — lock it down.",
      paragraph: "You started strong. End stronger. What’s the last open block you can close cleanly? Try finishing it without switching tabs.",
      tone: "directive",
      persona: "niveus",
      stage: "final",
      taskType: "challenge",
      voiceStyle: "coach"
    },
    {
      cue: "[Niveus says:] Past the finish — not just to it.",
      paragraph: "You don’t stop at the line. You break it. Give your last task the same intent you started with — maybe even more. One move. No hesitation.",
      tone: "directive",
      persona: "niveus",
      stage: "final",
      taskType: "challenge",
      voiceStyle: "coach"
    },
    {
      cue: "[Niveus says:] You started strong. End louder.",
      paragraph: "Don’t walk across the finish — drive through it. What’s the last task that needs full-force closure? Set a 20-minute block and give it your sharpest execution today.",
      tone: "directive",
      persona: "niveus",
      stage: "final",
      taskType: "challenge",
      voiceStyle: "coach"
    },
    {
      cue: "[Caelum says:] Close this day like it matters.",
      paragraph: "You’ve already built enough rhythm — now land it. What would feel like a clean, proud end? Try this: choose one small thing to finish with intention, not hurry.",
      tone: "motivated",
      persona: "caelum",
      stage: "final",
      taskType: "normal",
      voiceStyle: "family"
    },
    {
      cue: "[Caelum says:] You’ve carried it — now complete it.",
      paragraph: "This wasn’t for show. You’ve done real work. Let your final move today reflect how far you’ve come. Try writing down one thing you *will* close today.",
      tone: "motivated",
      persona: "caelum",
      stage: "final",
      taskType: "normal",
      voiceStyle: "family"
    },
    {
      cue: "[Caelum says:] The finish makes it real.",
      paragraph: "Ideas are great. Action is better. But finishing? That’s what turns this into progress. Pick one thing — and seal it now.",
      tone: "motivated",
      persona: "caelum",
      stage: "final",
      taskType: "normal",
      voiceStyle: "family"
    },
    {
      cue: "[Caelum says:] End with energy — not emptiness.",
      paragraph: "You don’t need to burn out. You just need one last focused move. What would feel powerful but light to close today with? Try it now — no dragging.",
      tone: "motivated",
      persona: "caelum",
      stage: "final",
      taskType: "normal",
      voiceStyle: "family"
    },
    {
      cue: "[Caelum says:] Cross the line with purpose.",
      paragraph: "Endings are underrated. They hold your next beginning. What’s one thing you can wrap that leaves you lighter? Do it now, not later.",
      tone: "motivated",
      persona: "caelum",
      stage: "final",
      taskType: "normal",
      voiceStyle: "family"
    },
    {
      cue: "[Caelum says:] End this chapter like a pro.",
      paragraph: "You’re not escaping the day. You’re completing it. What would make this feel finished and grounded? Try checking off your smallest task with full presence.",
      tone: "motivated",
      persona: "caelum",
      stage: "final",
      taskType: "normal",
      voiceStyle: "family"
    },
        
    {
      cue: "[Caelum says:] You’ve started. Now let’s keep it moving.",
      paragraph: "You’ve already stepped in — now give it a little more. What can you push forward just one notch? Try picking one task to finish in the next 15 minutes. I’ll be here when you’re done.",
      tone: "motivated",
      persona: "caelum",
      stage: "middle",
      taskType: "light",
      voiceStyle: "family"
    }
    ,
    {
      cue: "[Aurelia says:] Endings deserve as much structure as beginnings.",
      paragraph: "Don’t collapse the moment just because it’s late. What’s your exit system? Try organizing what’s left into 2 buckets: close now / defer cleanly.",
      tone: "rational",
      persona: "aurelia",
      stage: "final",
      taskType: "light",
      voiceStyle: "default"
    },
    
    {
      cue: "[Aurelia says:] The way you finish reveals how you moved.",
      paragraph: "If today felt messy — end it with clarity. What structure can you leave behind for your future self? Try writing the final 3 actions you took today as a clean log.",
      tone: "rational",
      persona: "aurelia",
      stage: "final",
      taskType: "light",
      voiceStyle: "default"
    },
    {
      cue: "[Aurelia says:] A clear ending creates a cleaner start.",
      paragraph: "Don’t just drop things — close them. What would make tomorrow’s start easier? Try summarizing what’s still open, so it’s ready for next time.",
      tone: "rational",
      persona: "aurelia",
      stage: "final",
      taskType: "light",
      voiceStyle: "default"
    },
    {
      cue: "[Aurelia says:] Capture the rhythm before it fades.",
      paragraph: "You’ve built something today — name it while it’s warm. Try writing one sentence that describes the rhythm you found. Let that be your carryover.",
      tone: "rational",
      persona: "aurelia",
      stage: "final",
      taskType: "light",
      voiceStyle: "default"
    },
    {
      cue: "[Aurelia says:] Shape the ending like you shaped the effort.",
      paragraph: "You didn’t stumble through today — don’t stumble out of it. How would someone with clarity end this block? Try doing that.",
      tone: "rational",
      persona: "aurelia",
      stage: "final",
      taskType: "light",
      voiceStyle: "default"
    },
    {
      cue: "[Rhea says:] You’ve done enough. Let that be true.",
      paragraph: "You’re not behind. You’ve arrived — exactly where you need to be. Try sitting quietly for a moment and writing one thing you’re grateful to yourself for.",
      tone: "gentle",
      persona: "rhea",
      stage: "final",
      taskType: "minimal",
      voiceStyle: "family"
    },
    {
      cue: "[Rhea says:] This ending is yours — not rushed, not forced.",
      paragraph: "You can close softly. What would it feel like to not push into the finish? Try breathing slowly, then write one gentle thing you want to carry forward.",
      tone: "gentle",
      persona: "rhea",
      stage: "final",
      taskType: "minimal",
      voiceStyle: "family"
    },
    {
      cue: "[Rhea says:] Let the day settle — that’s still movement.",
      paragraph: "Stillness isn’t stopping. It’s assimilation. What’s one feeling from today you haven’t named yet? Write it now — even if just one word.",
      tone: "gentle",
      persona: "rhea",
      stage: "final",
      taskType: "minimal",
      voiceStyle: "family"
    },
    {
      cue: "[Rhea says:] Land softly. You don’t need to make noise.",
      paragraph: "There’s no need for a dramatic close. Let yourself descend, not crash. Try this: close your laptop gently — and say 'done' out loud.",
      tone: "gentle",
      persona: "rhea",
      stage: "final",
      taskType: "minimal",
      voiceStyle: "family"
    },
    {
      cue: "[Rhea says:] Let the ending be a thank-you.",
      paragraph: "Not every day is loud — but each one carries you. What can you say thank you to? Try writing a line that begins with 'Today, I’m glad I…'",
      tone: "gentle",
      persona: "rhea",
      stage: "final",
      taskType: "minimal",
      voiceStyle: "family"
    },
    {
      cue: "[Rhea says:] Close the day like closing a book — no rush.",
      paragraph: "You don’t need to flip into the next thing. Let this ending be its own moment. Try looking at your hands and saying, 'We did enough today.'",
      tone: "gentle",
      persona: "rhea",
      stage: "final",
      taskType: "minimal",
      voiceStyle: "family"
    },
    
    {
      cue: "[Aurelia says:] Shape your ending with as much clarity as your beginning.",
      paragraph: "The start gave you momentum — but the close defines your discipline. What would a well-structured closure feel like today? Try this: write the final 3 things you want to log, release, or prepare before stepping away.",
      tone: "rational",
      persona: "aurelia",
      stage: "final",
      taskType: "light",
      voiceStyle: "default"
    },







    {
      cue: "[Lucis says:] Start with something that reflects the person you want to become.",
      paragraph: "This isn’t just about checking boxes — it’s about casting a signal. What would it look like to start today from a future you believe in? Try writing one sentence that begins: 'Today, I choose to…'",
      tone: "visionary",
      persona: "lucis",
      stage: "initial",
      taskType: "light",
      voiceStyle: "family"
    },
    {
      cue: "[Lucis says:] Let the first thing you do carry meaning — not momentum.",
      paragraph: "You don’t have to rush forward. You can move with shape. What if the way you start is the way you want to continue? Try this: pick one small action that deserves intention — and do it slowly.",
      tone: "visionary",
      persona: "lucis",
      stage: "initial",
      taskType: "light",
      voiceStyle: "family"
    },
    {
      cue: "[Lucis says:] Every beginning is a new agreement with yourself.",
      paragraph: "You’re not repeating yesterday. You’re choosing again — and that’s power. What kind of person are you signing up to be today? Try answering with one simple line: 'Today, I commit to…'",
      tone: "visionary",
      persona: "lucis",
      stage: "initial",
      taskType: "light",
      voiceStyle: "innerDialogue"
    },

    {
      cue: "[Aurelia says:] When the task feels too big, make the question smaller.",
      paragraph: "You’re not confused — the frame is just too wide. What’s the clearest sub-question inside your current block? Try writing it down, and only answer that for now.",
      tone: "rational",
      persona: "aurelia",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "default"
    },
    {
      cue: "[Aurelia says:] When momentum stalls, return to a known process.",
      paragraph: "You don’t need to invent a better way. You just need one reliable method that worked before. What system helped you last week? Try bringing it back for this exact block.",
      tone: "rational",
      persona: "aurelia",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "default"
    },

    {
      cue: "[Aurelia says:] The problem might not be effort — it might be structure drift.",
      paragraph: "You’re trying — but is your method clear enough? What part of your current system feels fuzzy? Try labeling one friction point and writing down what you expected it to do.",
      tone: "rational",
      persona: "aurelia",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "default"
    },
    {
      cue: "[Niveus says:] You don’t need a plan right now. You need traction.",
      paragraph: "You’re stalling — not because you’re confused, but because you haven’t committed to motion. What’s one small thing that doesn’t need more thinking? Do that, now.",
      tone: "directive",
      persona: "niveus",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "coach"
    },  
    
    {
      cue: "[Niveus says:] Start the clock and buy yourself rhythm.",
      paragraph: "You don’t need to finish the whole thing. You just need to get back in motion. Set a timer for 10 minutes. One task. One rule: no switching.",
      tone: "directive",
      persona: "niveus",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "coach"
    },
    {
      cue: "[Niveus says:] Don’t wait for clarity. Build it by doing.",
      paragraph: "Overthinking is a mask for hesitation. What task could give you more clarity *after* it’s touched? Start that one. Let execution bring the answers.",
      tone: "directive",
      persona: "niveus",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "coach"
    },

    {
      cue: "[Rhea says:] Let yourself land — not collapse.",
      paragraph: "Today’s rhythm is winding down. You don’t have to push anymore. What would a soft landing feel like? Try sitting back, placing your hand on your chest, and saying: 'This was enough.'",
      tone: "gentle",
      persona: "rhea",
      stage: "final",
      taskType: "minimal",
      voiceStyle: "family"
    },

    {
      cue: "[Rhea says:] You don’t need a highlight — just a moment that’s yours.",
      paragraph: "Not every day ends with triumph. But that doesn’t mean it didn’t matter. What was one moment today that felt like you? Try writing it down. Let that be what you carry forward.",
      tone: "gentle",
      persona: "rhea",
      stage: "final",
      taskType: "minimal",
      voiceStyle: "family"
    },

    {
      cue: "[Rhea says:] Endings aren’t breaks — they’re rituals.",
      paragraph: "Your mind deserves a closing gesture, not a sudden stop. What’s one small thing you can do to mark the end of your effort? Try this: stretch for 20 seconds while thanking your body for showing up today.",
      tone: "gentle",
      persona: "rhea",
      stage: "final",
      taskType: "minimal",
      voiceStyle: "family"
    },

    {
      cue: "[Lucis says:] The midpoint is where most people coast. You don’t have to.",
      paragraph: "You’re already moving — but are you still choosing? What shift would make the second half of today more intentional? Try naming one rhythm you want to restore right now.",
      tone: "visionary",
      persona: "lucis",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "family"
    },

    {
      cue: "[Aurelia says:] The best days aren’t spontaneous — they’re gently structured.",
      paragraph: "You don’t need to map the whole day. Just give it an outline. What’s one anchor that would make this morning steadier? Try listing your top 3 non-negotiables, without guilt.",
      tone: "rational",
      persona: "aurelia",
      stage: "initial",
      taskType: "light",
      voiceStyle: "default"
    },

    {
      cue: "[Niveus says:] There’s still time to win this block.",
      paragraph: "Midday isn’t for evaluating — it’s for executing. What’s one thing you can close in the next 30 minutes? Start it. No tabs. No toggling. Just move.",
      tone: "directive",
      persona: "niveus",
      stage: "middle",
      taskType: "normal",
      voiceStyle: "coach"
    }
    
    
    
    
    

  ];
  
  