// cre/creVariantRegistry.ts

export type CRETone = 'directive' | 'gentle' | 'motivated' | 'visionary' | 'rational'
export type CREStage = 'initial' | 'middle' | 'final'
export type CRETaskType = 'minimal' | 'light' | 'normal' | 'challenge'

export interface CREVariantSet {
  [tone: string]: {
    [stage in CREStage]?: {
      [type in CRETaskType]?: string[]
    }
  }
}

export const creVariants: CREVariantSet = {
  gentle: {
    initial: {
      minimal: [
        'You’re allowed to begin softly. One breath is enough.',
        'Just pause. That alone counts.',
        'Let the rhythm begin with ease.',
        'Breathe once. That is movement already.',
        'Start with noticing, not forcing.',
        'Gently meet yourself where you are.',
        'Let this moment be enough to start.',
        'Whisper, not shout. Begin softly.',
        "A quiet step counts."
      ],
      light: [
        'A small start is still a start. I’m with you.',
        'Begin gently, no rush.',
        'Let’s ease into it together.'
      ]
    },
    middle: {
      light: [
        'Each step matters. Let’s keep flowing.',
        'Stay soft but steady.',
        'The rhythm doesn’t need to be forced.',
        'You’re allowed to move slowly and still win.',
        'Gentleness can be strength too.',
        'Consistency grows even through softness.',
        'Tender momentum is still momentum.'
      ]
    },
    final: {
      minimal: [
        'You’ve done enough. Let yourself rest now.',
        'This ending is gentle, and it’s yours.',
        'Let it settle. That’s the final rhythm.',
        'Close today with softness.',
        'Breathe gratitude into the ending.',
        'Ease into closure — no sharp edges.',
        "Let yourself land — not collapse.",
        "You don’t need a highlight — just a moment that’s yours.",
        "Endings aren’t breaks — they’re rituals."
      ]
    }
  },

  directive: {
    initial: {
      challenge: [
        'Start now. One breath, then move.',
        'No delay. Begin with intent.',
        'Step in. Go hard. Don’t think.'
      ]
    },
    middle: {
      normal: [
        'Push forward—one timer, one task.',
        'No distractions. Continue.',
        'Finish the block. Stay locked in.',
        'Push forward — one timer, one task.',
        'Cut noise. Execute next.',
        'Stay locked. Finish the block.',
        'Pick pace over perfection.',
        'Anchor the flow. Minimal negotiation.',
        'One block. One focus. Full send.',
        "There’s still time to win this block."
        
        
      ]
    },
    final: {
      challenge: [
        'Close it strong. You’ve got this.',
        'No drag. End with force.',
        'Final push. All in.',
        'Seal the block. No hesitation.',
        'Push past the finish line.',
        'End louder than you started.'
      ]
    }
  },

  motivated: {
    initial: {
      light: [
        'Start light. Let it build.',
        'Warm into the motion. It counts.',
        'Get moving gently—then grow.'
      ],
      minimal: [
        'Even a spark can start a fire.',
        'Let’s begin small—but begin.',
        'This one move can change the day.'
      ]
    },
    middle: {
      normal: [
        'Momentum is here. Ride it.',
        'You’re moving. Don’t stop.',
        'Keep going. You’re becoming stronger.',
        'Ride the momentum — don’t hesitate.',
        'Energy is compounding. Move with it.',
        'You’ve started. Amplify it now.',
        'Stay in motion. Momentum is your advantage.',
        'Push into the curve — not away from it.',
        'This rhythm is yours. Strengthen it with action.'
        
      ],
      light: [
        'You’ve started. Now give it rhythm.',
        'One step creates another.',
        'Stay in the flow—you’re already in it.'
      ]
    },
    final: {
      normal: [
        'Bring this to a satisfying close.',
        'You’ve carried it—now complete it.',
        'The finish makes it real.',
        'End it with energy — not exhaustion.',
        'Cross the line with deliberate pride.',
        'Complete this chapter before chasing the next.'
      ],
      challenge: [
        'Last push. You’re capable.',
        'End strong. You’ll remember this.',
        'You did more than enough—finish it with fire.'
      ]
    }
  },
  visionary: {
    initial: {
      light: [
        'Every beginning echoes into who you become.',
        'This is more than a start—it is a signal.',
        'You are re not just doing—you are shaping.',
        'Even stillness holds movement inside it.',
        'Breathe the intention into being.',
        'Today is not repetition — it is a new line written.',
        "Start with something that reflects the person you want to become.",
        "Let the first thing you do carry meaning — not momentum.",
        "Every beginning is a new agreement with yourself."
      ],
      minimal: [
        'Even stillness is motion in the right frame.',
        'A breath can begin a transformation.',
        'This is not small—it’s precise.'
      ]
    },
    middle: {
      normal: [
        'You’re walking the edge of who you were and who you’re becoming.',
        'Keep choosing the shape of your next self.',
        'The rhythm isn’t external. It’s yours now.',
        "Realignment is momentum, not delay.",
        "What you’re doing isn’t just execution — it’s authorship.",
        "Let your vision interrupt the pattern.",
        "The midpoint is where most people coast. You don’t have to.",
        
  
      ],
      challenge: [
        'The path that stretches you is the one that remakes you.',
        'This difficulty is sculpting you.',
        'You’re not repeating—you’re reshaping.'
      ]
    },
    final: {
      normal: [
        'This finish leaves a trace. Make it yours.',
        'You arrived not by chance, but by rhythm.',
        'Endings are just shaped continuations.'
      ],
      challenge: [
        'You complete more than a task—you finish a self-expression.',
        'This closure is legacy rhythm.',
        'You didn’t just do—you created memory.'
      ]
    }
  },
  rational: {
    initial: {
         light: [
        "The best days aren’t spontaneous — they’re gently structured."

      ],
      minimal: [
        'Break it down step by step. Consistency beats intensity.',
        'Before reacting, clarify the premise.',
        'You don’t need more emotion — you need better structure.',
        "Vision doesn't rush. It roots first.",
        "This is the prologue to a bigger movement.",
        "Let today begin as a gentle hypothesis.",
      ]
    },
    middle: {
      normal: [
        'Clarity isn’t found in chaos. It’s built by logic.',
        'Build on what’s working. Debug what isn’t.',
        'Structure solves what emotion confuses.',
        'Precision outlasts passion.',
        'Organize to stabilize momentum.',
        'Simplify until motion becomes inevitable.'
      ]
    },
    final: {
      light: [
        'Even endings should be structured.',
        'Reflect. Record. Refine.',
        'Endings reveal the architecture of action.',
        'Closing properly creates clearer beginnings.',
        'Capture the rhythm before it fades.',
        'Structure the closure as carefully as the start.',
         "The best days aren’t spontaneous — they’re gently structured."
  
      ]
    }
  }
}