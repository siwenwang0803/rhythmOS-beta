// trendPathTracker.ts

export interface RhythmTrendEntry {
  score: number
  state: string
  timestamp: number
}

export function recordRhythmTrend(score: number, state: string) {
  const raw = localStorage.getItem('rhythmTrendLog')
  const log: RhythmTrendEntry[] = raw ? JSON.parse(raw) : []
  log.push({ score, state, timestamp: Date.now() })
  localStorage.setItem('rhythmTrendLog', JSON.stringify(log.slice(-50)))
}

export function getRhythmTrendLog(): RhythmTrendEntry[] {
  const raw = localStorage.getItem('rhythmTrendLog')
  return raw ? JSON.parse(raw) : []
}