import { classifyGoalIntent } from './goalIntentClassifier';
import { subtaskTemplateMap } from './subtaskTemplateMap';
import { generateCREVariants } from './generateCREVariants';

export interface SuggestedSubtask {
  text: string;
  cue: string;
  tone: string;
  taskType: string;
}

export function generateSubtaskSuggestions(goal: string, trend: string): SuggestedSubtask[] {
  // 日志辅助函数
  const logDebug = (message: string, data?: any) => {
    console.log(`[SubtaskSuggestion] ${message}`, data || '');
  };

  // 识别目标意图
  const intent = classifyGoalIntent(goal);
  logDebug('Classified intent:', intent);
  
  // 查找对应模板
  const template = subtaskTemplateMap.find(t => t.intent === intent);
  
  // 如果找不到模板，使用通用阅读模板（针对 "read books" 类型的目标）
  if (!template) {
    logDebug('No template found for intent:', intent);
    
    // 检查是否是阅读相关的目标
    if (goal.toLowerCase().includes('read') || goal.toLowerCase().includes('book')) {
      logDebug('Using reading template fallback');
      
      // 为阅读类目标提供特定的子任务
      const readingTasks = [
        'Choose which book to read first',
        'Schedule dedicated reading time in your calendar',
        'Read the first chapter and take notes',
        'Share one insight from your reading with someone',
        'Reflect on how the book relates to your life'
      ];
      
      // 生成建议
      return generateSuggestionsFromSteps(readingTasks, trend);
    }
    
    // 通用子任务模板（当没有匹配的模板时使用）
    logDebug('Using generic template fallback');
    const genericTasks = [
      'Define what success looks like for this goal',
      'Identify the first small step to take',
      'Schedule time on your calendar to work on this',
      'Find resources or people who can help you',
      'Create a way to track your progress'
    ];
    
    return generateSuggestionsFromSteps(genericTasks, trend);
  }
  
  // 使用找到的模板生成建议
  logDebug('Using template for intent:', intent);
  return generateSuggestionsFromSteps(template.steps, trend);
}

// 辅助函数：根据步骤和趋势生成建议
function generateSuggestionsFromSteps(steps: string[], trend: string): SuggestedSubtask[] {
  return steps.map((step, i) => {
    // 根据趋势选择语气
    const tone = trend === 'collapsed' ? 'gentle'
              : trend === 'wavy' ? 'motivated'
              : trend === 'rising' ? 'directive'
              : 'gentle';

    // 生成 CRE 变体（如果 generateCREVariants 不可用，使用默认值）
    let cue = '';
    try {
      const variants = generateCREVariants({ tone, taskType: 'light' });
      cue = variants[i % variants.length]?.text || 'Let rhythm begin here.';
    } catch (error) {
      // 如果 generateCREVariants 不可用或出错，使用默认提示
      const defaultCues = [
        'A gentle step forward is still progress.',
        'Each small action builds your momentum.',
        'You are creating positive change with each step.',
        'Trust your pace - you are moving exactly as you should.',
        'Acknowledge even the smallest movement forward.'
      ];
      cue = defaultCues[i % defaultCues.length];
    }

    // 返回建议
    return {
      text: step,
      cue,
      tone,
      taskType: 'light'
    };
  });
}