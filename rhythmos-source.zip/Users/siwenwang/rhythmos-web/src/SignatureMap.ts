// SignatureMap.ts — Core user signature data structure

// Interface definitions
export interface ToneEntry {
    cueId: string;
    tone: 'gentle' | 'neutral' | 'directive';
    feedback: 'aligned' | 'okay' | 'notMe';
    score?: number; // 1–5 optional rating
    trendAtFeedback: 'collapsed' | 'wavy' | 'stable' | 'rising';
    timestamp: string;
  }
  
  export interface CueEntry {
    cueId: string;
    cueText: string;
    tone: 'gentle' | 'neutral' | 'directive';
    trend: 'collapsed' | 'wavy' | 'stable' | 'rising';
    feedback: 'aligned' | 'okay' | 'notMe';
    timestamp: string;
  }
  
  export interface TrendEntry {
    date: string; // YYYY-MM-DD
    trend: 'collapsed' | 'wavy' | 'stable' | 'rising';
  }
  
  export interface ChallengeEntry {
    challengeId: string;
    persona: string;
    text: string;
    completed: boolean;
    skipped?: boolean;
    trend: 'collapsed' | 'wavy' | 'stable' | 'rising';
    timestamp: string;
  }
  
  export interface DriftSummary {
    period: string; // 'daily' | 'weekly' | '15-day'
    dominantTone: 'gentle' | 'neutral' | 'directive';
    toneShift?: string; // e.g. 'gentle → directive'
    cueClusterSummary?: string[];
  }
  
  // Type definition for top-level signatureMap structure
  export interface SignatureMapType {
    cueSeenCount?: Record<string, number>;
    toneLog: ToneEntry[];
    cueFeedbackLog: CueEntry[];
    trendHistory: TrendEntry[];
    challengeLog: ChallengeEntry[];
    personaAnchor: string;
    microtaskCount?: number;
    microtaskLog?: { type: string; timestamp: string }[];
    meta: {
      createdAt: string;
      lastUpdated: string;
      sessions: number;
      speakReplayLog: any[];
    };
  }
  
  // Singleton pattern for SignatureMap
  let signatureMapInstance: SignatureMapType | null = null;
  
  const initializeSignatureMap = (): SignatureMapType => {
    if (!signatureMapInstance) {
      signatureMapInstance = {
        cueSeenCount: {},
        toneLog: [],
        cueFeedbackLog: [],
        trendHistory: [],
        challengeLog: [],
        personaAnchor: localStorage.getItem('initPersona') || 'rhea',
        microtaskCount: 0,
        microtaskLog: [],
        meta: {
          createdAt: new Date().toISOString(),
          lastUpdated: new Date().toISOString(),
          sessions: 0,
          speakReplayLog: [],
        },
      };
      
      // Initialize counters
      signatureMapInstance.microtaskCount = signatureMapInstance.microtaskCount || 0;
      signatureMapInstance.microtaskLog = signatureMapInstance.microtaskLog || [];
      
      // Bind to window
      if (typeof window !== 'undefined') {
        (window as any).signatureMap = signatureMapInstance;
        console.log('🌐 SignatureMap initialized and bound to window');
      }
    }
    return signatureMapInstance;
  };
  
  // Export singleton instance
  export const signatureMap = initializeSignatureMap();
  
  // Export getter method
  export const getSignatureMap = (): SignatureMapType => {
    if (typeof window !== 'undefined' && (window as any).signatureMap) {
      return (window as any).signatureMap;
    }
    return signatureMap;
  };
  
  // Declare global type
  declare global {
    interface Window {
      signatureMap: SignatureMapType;
    }
  }

  