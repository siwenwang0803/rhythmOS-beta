import React, { useState } from 'react'
import Section from '../components/ui/Section'
import { CRETemplate } from '../creTemplateRegistry'

const CRETemplateImporter: React.FC = () => {
  const [templates, setTemplates] = useState<CRETemplate[]>([])

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string)
        if (Array.isArray(json)) {
          setTemplates(json)
          alert(`✅ Successfully imported ${json.length} templates.`)
        } else {
          alert('❌ Invalid JSON format.')
        }
      } catch {
        alert('❌ Error parsing JSON.')
      }
    }
    reader.readAsText(file)
  }

  return (
    <Section title="📥 Import CRE Templates (JSON)">
      <input type="file" accept=".json" onChange={handleFileUpload} className="mb-3" />
      <div className="space-y-2 text-sm">
        {templates.map((t, i) => (
          <div key={i} className="border p-2 rounded bg-white">
            <p className="text-gray-800"><strong>{t.tone}</strong> | {t.stage} | {t.taskType} | {t.variant}</p>
            <p className="text-gray-500 italic">“{t.text}”</p>
          </div>
        ))}
      </div>
    </Section>
  )
}

export default CRETemplateImporter