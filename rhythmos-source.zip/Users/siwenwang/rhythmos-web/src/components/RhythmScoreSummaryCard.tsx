// /components/RhythmScoreSummaryCard.tsx - 修复趋势显示问题完整版

import React, { useState, useEffect } from 'react';
import { 
  getFinalizedSummary, 
  getTodayTotalScore, 
  isTodayFinalized, 
  getTodayDate,
  detectCurrentTrend
} from '../utils/rhythmDayEngine';
import { 
  MAX_DAILY_SCORE,
  MAX_GOAL_SUBTASK_COMBINED_SCORE,
  MAX_CHALLENGE_COUNT,
  MAX_MICROTASK_COUNT
} from '../utils/writeRhythmScore';
import { getXpTracker, getTodayDateKey } from '../utils/xpDailyTracker';
import { signatureMap, getSignatureMap } from '../SignatureMap';
import FeedbackInsightHint from './FeedbackInsightHint';

// 定义正确的最大值常量
const CORRECT_MAX_GOAL_SUBTASK = 4;  // 正确的Goals & Subtasks最大值
const CORRECT_MAX_CHALLENGE = 6;     // 正确的Challenges最大值（6分 = 2个challenges × 3分）
const CORRECT_MAX_MICROTASK = 2;   // 正确的Microtasks最大分数（3个microtask × 0.5分）

// 趋势显示映射
const TREND_DISPLAY = {
  collapsed: { emoji: '🫥', label: 'Collapsed', color: '#AEC6CF' },
  wavy: { emoji: '🌊', label: 'Wavy', color: '#C3B1E1' },
  stable: { emoji: '⚖️', label: 'Stable', color: '#C5D8A4' },
  rising: { emoji: '🔥', label: 'Rising', color: '#FFB347' },
  // 备用的系统趋势（如果没有用户选择的趋势）
  improving: { emoji: '📈', label: 'Improving', color: '#059669' },
  declining: { emoji: '📉', label: 'Declining', color: '#dc2626' }
};

/**
 * 获取当前用户趋势 - 优先显示用户选择的趋势，而不是系统计算的
 */
const getCurrentUserTrend = (): string => {
  try {
    // 1. 优先：用户在 RhythmCheckin 页面手动选择的趋势
    const userSelectedTrend = localStorage.getItem('lastTrend');
    if (userSelectedTrend && ['collapsed', 'wavy', 'stable', 'rising'].includes(userSelectedTrend)) {
      console.log('[TREND] Using user selected trend from RhythmCheckin:', userSelectedTrend);
      return userSelectedTrend;
    }
    
    // 2. 备用：从 SignatureMap 的 trendLog 获取今天的记录
    const signatureMap = getSignatureMap();
    if (signatureMap?.trendLog && signatureMap.trendLog.length > 0) {
      const today = getTodayDate();
      // 查找今天的趋势记录
      const todayTrendEntry = signatureMap.trendLog.find(entry => entry.date === today);
      if (todayTrendEntry && todayTrendEntry.trend) {
        console.log('[TREND] Using trend from SignatureMap trendLog:', todayTrendEntry.trend);
        return todayTrendEntry.trend;
      }
    }
    
    // 3. 最后备用：使用系统自动检测的趋势（基于分数）
    const systemTrend = detectCurrentTrend();
    console.log('[TREND] Falling back to system detected trend:', systemTrend);
    return systemTrend;
  } catch (error) {
    console.error('Error getting current user trend:', error);
    return 'stable'; // 默认值
  }
};

/**
 * 从 signatureMap 获取 microtask 计数 - 优先级最高的数据源
 */
const getTodayMicrotaskCountFromSignature = (): number => {
  try {
    // 首先尝试从 window.signatureMap 获取（最新数据）
    const currentMap = getSignatureMap();
    const count = currentMap?.microtaskCount || 0;
    
    console.log('Reading microtask count from signatureMap:', {
      count,
      logEntries: currentMap?.microtaskLog?.length || 0
    });
    
    return count;
  } catch (error) {
    console.error('Error getting microtask count from signatureMap:', error);
    return 0;
  }
};

/**
 * 备用方案：从 xpTracker 获取 microtask 计数
 */
const getTodayMicrotaskCountFromXp = (): number => {
  try {
    const today = getTodayDateKey();
    const tracker = getXpTracker();
    
    console.log('Reading microtask count from xpTracker:', {
      date: today,
      count: tracker[today]?.microtaskCount || 0,
      rawData: tracker[today]
    });
    
    return tracker[today]?.microtaskCount || 0;
  } catch (error) {
    console.error('Error getting microtask count from xpTracker:', error);
    return 0;
  }
};

/**
 * 综合获取 microtask 计数 - 使用最高的数值
 */
const getTodayMicrotaskCount = (): number => {
  const signatureCount = getTodayMicrotaskCountFromSignature();
  const xpCount = getTodayMicrotaskCountFromXp();
  
  // 使用两者中较大的值，确保不遗漏数据
  const finalCount = Math.max(signatureCount, xpCount);
  
  console.log('Final microtask count calculation:', {
    signatureCount,
    xpCount,
    finalCount
  });
  
  return finalCount;
};

/**
 * 获取今天的Goal和Subtask总分
 */
const getTodayGoalSubtaskScore = (): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) =>
      entry.date === today &&
      (entry.actionType === 'subtask_complete' || entry.actionType === 'goal_complete')
    )
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
};

/**
 * 获取今天完成的挑战总分数（而不是计数）
 */
const getTodayChallengeScore = (): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) => 
      entry.date === today && 
      entry.actionType === 'challenge_complete'
    )
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
};

/**
 * 获取今天的 Microtask 总分数
 * 每个 microtask = 0.5分，所以分数 = 计数 × 0.5
 */
const getTodayMicrotaskScore = (): number => {
  // 方法1：从 rhythmScoreLog 获取直接分数记录
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  const directScore = rhythmScoreLog
    .filter((entry: any) => 
      entry.date === today && 
      entry.actionType === 'microtask_complete'
    )
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
  
  // 方法2：从计数推算分数
  const count = getTodayMicrotaskCount();
  const calculatedScore = count * 0.5;
  
  // 使用两者中较大的值
  const finalScore = Math.max(directScore, calculatedScore);
  
  console.log('Microtask score calculation:', {
    directScore,
    count,
    calculatedScore,
    finalScore
  });
  
  return finalScore;
};

const RhythmScoreSummaryCard: React.FC = () => {
  const [score, setScore] = useState<number>(0);
  const [microEmotion, setMicroEmotion] = useState<string | null>(null);
  const [animateScore, setAnimateScore] = useState<boolean>(false);
  const [goalSubtaskScore, setGoalSubtaskScore] = useState<number>(0);
  const [challengeScore, setChallengeScore] = useState<number>(0);
  const [microtaskScore, setMicrotaskScore] = useState<number>(0);
  const [microtaskCount, setMicrotaskCount] = useState<number>(0); // 添加计数状态
  const [currentTrend, setCurrentTrend] = useState<string>('stable');
  const [nextActionText, setNextActionText] = useState<string>('');

  // 添加强制刷新函数
  const forceUpdate = React.useCallback(() => {
    updateScores(true);
  }, []);

  // 更新分数和计数的函数
  const updateScores = (forceRefresh = false) => {
    console.log('Updating RhythmScoreSummaryCard scores', { forceRefresh });
    
    const finalized = isTodayFinalized();
    const raw = finalized ? getFinalizedSummary()?.score : getTodayTotalScore();
    setScore(typeof raw === 'number' ? raw : 0);

    // 获取分项分数
    const gsScore = getTodayGoalSubtaskScore();
    setGoalSubtaskScore(gsScore);
    
    const chScore = getTodayChallengeScore();
    setChallengeScore(chScore);
    
    const mtScore = getTodayMicrotaskScore();
    setMicrotaskScore(mtScore);
    
    // 获取 microtask 计数
    const mtCount = getTodayMicrotaskCount();
    console.log('Setting microtask count:', mtCount);
    setMicrotaskCount(mtCount);
    
    // 设置下一步建议
    setNextActionText(getNextActionSuggestion(gsScore, chScore, mtScore));
    
    // 🔥 使用修复后的趋势获取函数 - 优先显示用户选择的趋势
    const userTrend = getCurrentUserTrend();
    setCurrentTrend(userTrend);
    
    console.log('[TREND] Updated trend display to:', userTrend);
  };

  // 获取适合当前状态的下一步建议
  const getNextActionSuggestion = (
    goalSubtaskScore: number, 
    challengeScore: number,
    microtaskScore: number  // 改为使用分数而不是计数
  ): string => {
    if (goalSubtaskScore < CORRECT_MAX_GOAL_SUBTASK) {
      return "💡 Work on a goal or subtask to make progress on your priorities.";
    }
    
    if (challengeScore < CORRECT_MAX_CHALLENGE) {
      return "💡 Complete a daily challenge to boost your momentum.";
    }
    
    if (microtaskScore < CORRECT_MAX_MICROTASK) {
      return "💡 Try a microtask for a quick rhythm boost.";
    }
    
    return "💡 Great work! You've completed your daily activities.";
  };

  // 获取趋势显示信息
  const getTrendDisplay = (trend: string) => {
    return TREND_DISPLAY[trend] || TREND_DISPLAY.stable;
  };

  // 组件挂载时加载数据
  useEffect(() => {
    // 初始更新
    updateScores();

    // 读取情感笔记
    const emotion = localStorage.getItem('microEmotion') || null;
    setMicroEmotion(emotion);

    // 触发分数动画
    setTimeout(() => {
      setAnimateScore(true);
    }, 300);
    
    // 监听分数变化和microtask完成事件
    const handleScoreUpdate = () => {
      console.log('rhythm-score-updated event received');
      updateScores();
    };
    
    const handleMicrotaskComplete = (event: Event) => {
      console.log('microtask-completed event received', event);
      
      // 立即更新microtask计数
      const newCount = getTodayMicrotaskCount();
      const newScore = getTodayMicrotaskScore();
      console.log('New microtask data after completion:', { newCount, newScore });
      setMicrotaskCount(newCount);
      setMicrotaskScore(newScore);
      
      // 同时更新其他数据
      updateScores(true);
    };
    
    const handleMicrotaskUpdate = (event: CustomEvent) => {
      console.log('microtask-updated event received', event.detail);
      
      // 从事件详情或重新获取计数
      const newCount = event.detail?.count || getTodayMicrotaskCount();
      console.log('Updating microtask count from event:', newCount);
      setMicrotaskCount(newCount);
      
      // 更新分数
      updateScores(true);
    };
    
    // 🔥 新增：监听趋势更新事件
    const handleTrendUpdate = (event: CustomEvent) => {
      console.log('trend-updated event received', event.detail);
      const newTrend = event.detail?.trend;
      if (newTrend) {
        setCurrentTrend(newTrend);
        console.log('[TREND] Updated from event:', newTrend);
      }
    };
    
    window.addEventListener('rhythm-score-updated', handleScoreUpdate);
    window.addEventListener('microtask-completed', handleMicrotaskComplete);
    window.addEventListener('microtask-updated', handleMicrotaskUpdate as EventListener);
    window.addEventListener('trend-updated', handleTrendUpdate as EventListener);
    
    // 设置定期刷新 (每30秒检查一次最新数据)
    const refreshInterval = setInterval(() => {
      const freshCount = getTodayMicrotaskCount();
      const freshScore = getTodayMicrotaskScore();
      const freshTrend = getCurrentUserTrend();
      
      if (freshCount !== microtaskCount || freshScore !== microtaskScore || freshTrend !== currentTrend) {
        console.log('Periodic refresh detected changes:', {
          countChange: { current: microtaskCount, fresh: freshCount },
          scoreChange: { current: microtaskScore, fresh: freshScore },
          trendChange: { current: currentTrend, fresh: freshTrend }
        });
        updateScores(true);
      }
    }, 30000);
    
    return () => {
      window.removeEventListener('rhythm-score-updated', handleScoreUpdate);
      window.removeEventListener('microtask-completed', handleMicrotaskComplete);
      window.removeEventListener('microtask-updated', handleMicrotaskUpdate as EventListener);
      window.removeEventListener('trend-updated', handleTrendUpdate as EventListener);
      clearInterval(refreshInterval);
    };
  }, [microtaskCount, microtaskScore, currentTrend]); // 添加依赖

  // 获取当前趋势的显示信息
  const trendDisplay = getTrendDisplay(currentTrend);
  
  // UI渲染部分
  return (
    <div className="rounded-xl overflow-hidden" style={{ border: '1px solid rgba(0, 0, 0, 0.05)', boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)' }}>
      {/* 头部显示总分 */}
      <div className="px-4 py-3" style={{ backgroundColor: '#f8fafc', borderBottom: '1px solid rgba(0, 0, 0, 0.05)' }}>
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold" style={{ color: '#334155' }}>Today's Rhythm</h3>
          <div className="text-right">
            <div className={`text-2xl font-bold transition-all duration-500 ${animateScore ? 'scale-110' : ''}`} 
                 style={{ color: score >= 10 ? '#059669' : score >= 7 ? '#d97706' : '#6b7280' }}>
              {score}
            </div>
            <div className="text-xs" style={{ color: '#6b7280' }}>/ {MAX_DAILY_SCORE}</div>
          </div>
        </div>
      </div>

      {/* 内容区域 */}
      <div className="px-4 py-3" style={{ backgroundColor: '#ffffff' }}>
        {/* 分数分解 */}
        <div className="rounded-lg p-3 mb-3" style={{ backgroundColor: 'rgba(255, 255, 255, 0.5)', backdropFilter: 'blur(4px)', border: '1px solid rgba(0, 0, 0, 0.03)' }}>
          <h4 className="text-xs font-medium mb-2" style={{ color: '#333333' }}>
            Today's Score Breakdown
          </h4>
          
          <div className="flex flex-col gap-1">
            {/* Goals & Subtasks 显示分数 */}
            <div className="flex justify-between items-center text-xs">
              <div className="flex items-center gap-1">
                <span>🎯</span>
                <span>Goals & Subtasks</span>
              </div>
              <div>
                <span className="font-medium">{goalSubtaskScore}</span>
                <span className="text-gray-500">/{CORRECT_MAX_GOAL_SUBTASK}</span>
              </div>
            </div>
            
            {/* Challenges 显示分数而不是个数 */}
            <div className="flex justify-between items-center text-xs">
              <div className="flex items-center gap-1">
                <span>🏆</span>
                <span>Challenges</span>
              </div>
              <div>
                <span className="font-medium">{challengeScore}</span>
                <span className="text-gray-500">/{CORRECT_MAX_CHALLENGE}</span>
              </div>
            </div>
            
            {/* Microtasks 显示分数而不是计数 */}
            <div className="flex justify-between items-center text-xs">
              <div className="flex items-center gap-1">
                <span>📝</span>
                <span>Microtasks</span>
              </div>
              <div 
                onClick={forceUpdate} 
                className="cursor-pointer hover:underline" 
                title="Click to refresh microtask score"
              >
                <span className="font-medium">{microtaskScore}</span>
                <span className="text-gray-500">/{CORRECT_MAX_MICROTASK}</span>
                <span className="ml-1 text-xs text-blue-400 opacity-50 hover:opacity-100">↻</span>
              </div>
            </div>
          </div>
          
          {/* Next action suggestion */}
          {nextActionText && (
            <div className="mt-3 pt-2 border-t border-gray-200">
              <p className="text-xs italic" style={{ color: '#666666' }}>
                {nextActionText}
              </p>
            </div>
          )}
        </div>

        {/* 趋势和情感部分 */}
        <div className="flex gap-3">
          {/* 趋势显示 - 使用用户选择的趋势 */}
          <div className="flex-1 rounded-lg p-2" style={{ backgroundColor: 'rgba(243, 244, 246, 0.5)' }}>
            <div className="text-xs" style={{ color: '#6b7280' }}>Trend</div>
            <div className="text-sm font-medium flex items-center gap-1" style={{ color: trendDisplay.color }}>
              <span>{trendDisplay.emoji}</span>
              <span>{trendDisplay.label}</span>
            </div>
          </div>

          {/* 情感显示 */}
          <div className="flex-1 rounded-lg p-2" style={{ backgroundColor: 'rgba(243, 244, 246, 0.5)' }}>
            <div className="text-xs" style={{ color: '#6b7280' }}>Mood</div>
            <div className="text-sm font-medium" style={{ color: '#374151' }}>
              {microEmotion || 'Not recorded'}
            </div>
          </div>
        </div>

        {/* 添加FeedbackInsightHint组件 */}
        <div className="mt-3">
          <FeedbackInsightHint />
        </div>
      </div>
    </div>
  );
};

export default RhythmScoreSummaryCard;









