import React, { useEffect, useState } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell
} from 'recharts';
import { getToneScoreMapByDays } from '../utils/writeToneLog';

const toneColors: Record<string, string> = {
  gentle: '#60A5FA',
  directive: '#F87171',
  visionary: '#FACC15',
  rational: '#A78BFA',
  motivated: '#34D399',
  supportive: '#FDBA74',
  balanced: '#F472B6',
  default: '#9CA3AF'
};

const toneLabels: Record<string, string> = {
  gentle: 'Gentle',
  directive: 'Directive',
  visionary: 'Visionary',
  rational: 'Rational',
  motivated: 'Motivated',
  supportive: 'Supportive',
  balanced: 'Balanced'
};

const ToneScorePanel: React.FC = () => {
  const [data, setData] = useState<{ tone: string; score: number }[]>([]);

  useEffect(() => {
    const map = getToneScoreMapByDays(7);
    const formatted = Object.entries(map).map(([tone, score]) => ({
      tone,
      score
    }));
    setData(formatted);
  }, []);

  if (data.length === 0) {
    return (
      <div className="text-sm text-gray-500 text-center py-8 italic">
        No tone feedback in the last 7 days.
      </div>
    );
  }

  return (
    <div className="bg-white rounded-md shadow-sm p-4">
      <h3 className="text-lg font-semibold mb-2">🎯 Tone Usage Summary</h3>
      <p className="text-sm text-gray-500 mb-4">
        Based on your last 7 days of cue feedback. Aligned = 1.0, Okay = 0.5
      </p>

      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="tone" tickFormatter={(t) => toneLabels[t] || t} />
          <YAxis domain={[0, 5]} allowDecimals />
          <Tooltip formatter={(val: any) => [val.toFixed(1), 'Score']} />
          <Bar dataKey="score" radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={toneColors[entry.tone] || toneColors.default} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ToneScorePanel;
