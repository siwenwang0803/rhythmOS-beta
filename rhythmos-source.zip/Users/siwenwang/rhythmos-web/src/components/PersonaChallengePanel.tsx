// 修改后的 PersonaChallengePanel.tsx - 添加刷新功能
// 统一使用 initPersona 作为活跃身份

import React, { useEffect, useState } from 'react';
import IdentityChallengeCard from './IdentityChallengeCard';
import { generateIdentityChallengeFromPersona } from '../logic/identity/generateIdentityChallengeFromPersona';

const PersonaChallengePanel: React.FC<{
  personaStyle: {
    gradient: string;
  };
  animated?: boolean;
}> = ({ personaStyle, animated = true }) => {
  const [challenges, setChallenges] = useState<
    { cue: string; paragraph: string; action: string }[]
  >([]);
  const [loading, setLoading] = useState(true);
  const [completed, setCompleted] = useState<string[]>([]);
  const [feedbacks, setFeedbacks] = useState<Record<string, string>>({});
  
  // 添加活跃身份状态
  const [activePersona, setActivePersona] = useState(localStorage.getItem('initPersona') || 'rhea');
  const [trend, setTrend] = useState(localStorage.getItem('lastTrend') || 'wavy');

  // 监听身份变化
  useEffect(() => {
    const handlePersonaChange = () => {
      const newPersona = localStorage.getItem('initPersona') || 'rhea';
      if (newPersona !== activePersona) {
        console.log('PersonaChallengePanel - 检测到 initPersona 变化:', newPersona);
        setActivePersona(newPersona);
      }
    };
    
    handlePersonaChange();
    window.addEventListener('persona-changed', handlePersonaChange);
    return () => {
      window.removeEventListener('persona-changed', handlePersonaChange);
    };
  }, [activePersona]);

  // 监听 trend 变化
  useEffect(() => {
    const handleTrendChange = () => {
      const newTrend = localStorage.getItem('lastTrend') || 'wavy';
      if (newTrend !== trend) {
        console.log('PersonaChallengePanel - 检测到 lastTrend 变化:', newTrend);
        setTrend(newTrend);
      }
    };
    
    handleTrendChange();
    const intervalId = setInterval(handleTrendChange, 30000);
    return () => clearInterval(intervalId);
  }, [trend]);

  // Persona information mapping
  const PERSONA_INFO = {
    rhea: { name: 'Rhea', icon: '💗' },
    aurelia: { name: 'Aurelia', icon: '🧠' },
    lucis: { name: 'Lucis', icon: '🌱' },
    niveus: { name: 'Niveus', icon: '📊' },
    caelum: { name: 'Caelum', icon: '💠' }
  };

  // Trend information mapping
  const TREND_LABELS = {
    collapsed: '🧘‍♀️ Calm Reset',
    wavy: '🌊 Wavy Transitions',
    stable: '🌿 Stable Flow',
    rising: '🚀 Rising Momentum'
  };

  const RHYTHM_COLORS = {
    collapsed: '#AEC6CF',
    wavy: '#C3B1E1',
    stable: '#C5D8A4',
    rising: '#FFB347'
  };

  // 检查挑战完成状态
  useEffect(() => {
    const checkCompletionStatus = () => {
      const log = JSON.parse(localStorage.getItem('challengeLog') || '[]');
      const today = new Date().toISOString().split('T')[0];
      
      const todayLog = log.filter((e: any) => e.date === today || e.today === today);
      const completedCues = todayLog.map((e: any) => e.text);
      const feedbackMap: Record<string, string> = {};
      
      todayLog.forEach((e: any) => {
        if (e.feedback) feedbackMap[e.text] = e.feedback;
      });
      
      setCompleted(completedCues);
      setFeedbacks(feedbackMap);
    };

    checkCompletionStatus();
    
    // 监听挑战完成事件
    window.addEventListener('challenge-completed', checkCompletionStatus);
    window.addEventListener('storage', checkCompletionStatus);
    
    return () => {
      window.removeEventListener('challenge-completed', checkCompletionStatus);
      window.removeEventListener('storage', checkCompletionStatus);
    };
  }, []);

  // 生成挑战响应 persona 和 trend 变化
  useEffect(() => {
    const fetchChallenges = async () => {
      setLoading(true);
      try {
        const one = await generateIdentityChallengeFromPersona(activePersona, trend);
        const two = await generateIdentityChallengeFromPersona(activePersona, trend);
        setChallenges([one, two]);
      } catch (error) {
        console.error('Error generating challenges:', error);
        // 如果生成失败，提供默认挑战
        setChallenges([
          {
            cue: "Take a moment to reflect on your current state",
            paragraph: "Self-awareness is the foundation of growth.",
            action: "Spend 5 minutes in quiet reflection"
          },
          {
            cue: "Choose one small action aligned with your values",
            paragraph: "Small consistent actions create lasting change.",
            action: "Identify and complete one value-aligned task"
          }
        ]);
      } finally {
        setLoading(false);
      }
    };
    fetchChallenges();
  }, [activePersona, trend]);

  // 处理挑战完成
  const handleChallengeComplete = (cue: string) => {
    console.log('PersonaChallengePanel - 挑战完成:', cue);
    
    const today = new Date().toISOString().split('T')[0];
    const log = JSON.parse(localStorage.getItem('challengeLog') || '[]');
    
    const challengeEntry = {
      persona: activePersona,
      text: cue,
      time: Date.now(),
      today: today,
      date: today,
      completed: true,
      feedback: undefined
    };
    
    log.push(challengeEntry);
    localStorage.setItem('challengeLog', JSON.stringify(log));
    
    // 更新完成状态
    setCompleted(prev => [...prev, cue]);
    
    // 触发事件
    window.dispatchEvent(new CustomEvent('challenge-completed', { 
      detail: { challenge: cue, persona: activePersona }
    }));
  };

  // 处理挑战反馈
  const handleChallengeFeedback = (cue: string, feedback: 'aligned' | 'okay' | 'not_me') => {
    console.log('PersonaChallengePanel - 反馈:', cue, feedback);
    
    const today = new Date().toISOString().split('T')[0];
    const log = JSON.parse(localStorage.getItem('challengeLog') || '[]');
    
    // 查找并更新已有记录
    let updated = false;
    for (let i = log.length - 1; i >= 0; i--) {
      if (log[i].text === cue && (log[i].today === today || log[i].date === today)) {
        log[i].feedback = feedback;
        updated = true;
        break;
      }
    }
    
    if (!updated) {
      // 如果没有找到记录，创建新的
      log.push({
        persona: activePersona,
        text: cue,
        time: Date.now(),
        today: today,
        date: today,
        completed: true,
        feedback: feedback
      });
    }
    
    localStorage.setItem('challengeLog', JSON.stringify(log));
    setFeedbacks(prev => ({ ...prev, [cue]: feedback }));
  };

  // 刷新单个挑战
  const handleRefreshChallenge = async (challengeIndex: number) => {
    console.log('PersonaChallengePanel - 刷新挑战:', challengeIndex);
    
    try {
      // 生成新挑战
      const newChallenge = await generateIdentityChallengeFromPersona(activePersona, trend);
      
      // 更新挑战列表
      const newChallenges = [...challenges];
      const oldCue = newChallenges[challengeIndex].cue;
      newChallenges[challengeIndex] = newChallenge;
      setChallenges(newChallenges);
      
      // 清除旧挑战的完成状态和反馈
      setCompleted(prev => prev.filter(cue => cue !== oldCue));
      setFeedbacks(prev => {
        const newFeedbacks = { ...prev };
        delete newFeedbacks[oldCue];
        return newFeedbacks;
      });
      
      console.log('PersonaChallengePanel - 挑战刷新成功');
    } catch (error) {
      console.error('PersonaChallengePanel - 刷新失败:', error);
      alert('Failed to refresh challenge. Please try again.');
    }
  };

  const containerAnimation = animated
    ? 'transform transition-all duration-700 translate-y-0 opacity-100'
    : '';

  const currentPersonaInfo = PERSONA_INFO[activePersona] || PERSONA_INFO.rhea;
  const trendColor = RHYTHM_COLORS[trend] || RHYTHM_COLORS.wavy;
  const trendLabel = TREND_LABELS[trend] || '🌀 Mixed Flow';

  return (
    <div className={containerAnimation}>
      <div
        className="rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg"
        style={{
          border: '1px solid rgba(0, 0, 0, 0.05)',
          boxShadow: '0 4px 14px rgba(0, 0, 0, 0.07)',
        }}
      >
        {/* 顶部彩条 */}
        <div className="h-2 w-full" style={{ background: personaStyle.gradient }} />

        <div className="p-6">
          {/* Header with Persona and Trend info */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div 
                className="w-12 h-12 rounded-full flex items-center justify-center transition-transform duration-300 hover:scale-105"
                style={{ 
                  background: personaStyle.gradient,
                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)' 
                }}
              >
                <span className="text-xl">🎯</span>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h3 
                    className="text-lg font-medium"
                    style={{ color: '#333333' }}
                  >
                    Growth Challenges
                  </h3>
                  <span
                    className="text-xs text-gray-500 cursor-pointer w-5 h-5 rounded-full border border-gray-200 inline-flex items-center justify-center hover:bg-gray-100"
                    onClick={() => alert(`🎯 Growth Challenges are small identity-aligned actions.\nThey help you align your behavior with the person you aspire to be.`)}
                    title="Click for explanation"
                  >
                    ⓘ
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Align your actions with who you want to become
                </p>
              </div>
            </div>
            
            {/* 右侧适度大小的Persona显示 */}
            <div 
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg"
              style={{ 
                background: personaStyle.gradient,
                boxShadow: '0 2px 4px rgba(0, 0, 0, 0.08)',
                border: '1px solid rgba(255, 255, 255, 0.3)'
              }}
            >
              <span className="text-lg">{currentPersonaInfo.icon}</span>
              <span className="text-sm font-medium" style={{ color: '#333333' }}>
                {currentPersonaInfo.name}
              </span>
            </div>
          </div>

          {/* 趋势状态 */}
          <div className="flex items-center mb-4">
            <div 
              className="text-xs px-2.5 py-1 rounded-full"
              style={{ 
                backgroundColor: trendColor + '30',
                color: '#333333'
              }}
            >
              {trendLabel}
            </div>
          </div>

          {/* Challenge Cards */}
          {loading ? (
            <p className="text-sm text-gray-400 italic">Loading challenges...</p>
          ) : (
            <div className="space-y-6">
              {challenges.map((challenge, index) => (
                <IdentityChallengeCard
                  key={`${challenge.cue}-${index}`}
                  cue={challenge.cue}
                  paragraph={challenge.paragraph}
                  action={challenge.action}
                  points={3}
                  isCompleted={completed.includes(challenge.cue)}
                  feedback={feedbacks[challenge.cue]}
                  onComplete={() => handleChallengeComplete(challenge.cue)}
                  onFeedback={(value) => handleChallengeFeedback(challenge.cue, value)}
                  onRefresh={() => handleRefreshChallenge(index)} // 添加刷新功能
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PersonaChallengePanel;