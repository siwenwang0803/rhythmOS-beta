// MicroTipHint.tsx

import React from 'react';

interface Props {
  message: string;
}

const MicroTipHint: React.FC<Props> = ({ message }) => {
  return (
    <div className="mt-4 rounded-xl p-4 border shadow-sm text-sm"
         style={{ backgroundColor: '#eef2ff', borderColor: '#c7d2fe' }}>
      <p className="text-indigo-800">
        💡 {message}
      </p>
    </div>
  );
};

export default MicroTipHint;
