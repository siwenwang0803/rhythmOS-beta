// /components/CREFeedbackSignatureMap.tsx

import React from 'react'

const toneLabels = {
  gentle: 'Gentle',
  directive: 'Directive',
  motivated: 'Motivated',
  visionary: 'Visionary',
  rational: 'Rational',
  balanced: 'Balanced'
}

const personaLabels = {
  rhea: 'Rhea',
  caelum: 'Caelum',
  lucis: 'Lucis',
  aurelia: 'Aurelia',
  niveus: 'Niveus'
}

const CREFeedbackSignatureMap: React.FC = () => {
  const raw = localStorage.getItem('signatureFeedbackLog')
  const log = raw ? JSON.parse(raw) : []

  // ✅ 过滤掉无persona或无tone的数据
  const filteredLog = log.filter((entry: any) => entry.persona && entry.tone);

  const map: Record<string, Record<string, { aligned: number; okay: number; not: number }>> = {}

  filteredLog.forEach((entry: any) => {
    const persona = entry.persona
    const tone = entry.tone
    const feedback = entry.feedback

    if (!map[persona]) map[persona] = {}
    if (!map[persona][tone]) map[persona][tone] = { aligned: 0, okay: 0, not: 0 }

    if (feedback === 'aligned') map[persona][tone].aligned++
    else if (feedback === 'okay') map[persona][tone].okay++
    else map[persona][tone].not++
  })

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-bold text-gray-800">🧬 Your Signature Map</h2>
      {Object.entries(map).map(([persona, toneBlock]) => (
        <div key={persona} className="space-y-3">
          <h3 className="text-md font-semibold text-blue-700">{personaLabels[persona] || persona}</h3>
          {Object.entries(toneBlock).map(([tone, stats]) => (
            <div
              key={tone}
              className="pl-4 flex flex-wrap items-center gap-3 text-sm bg-blue-50 border border-blue-100 rounded px-3 py-2"
            >
              <span className="text-gray-700 font-medium">
                {toneLabels[tone] || tone}:
              </span>
              <span className="text-green-700 font-semibold bg-green-100 px-2 py-0.5 rounded text-xs">
                ✅ {stats.aligned} aligned
              </span>
              <span className="text-yellow-800 font-semibold bg-yellow-100 px-2 py-0.5 rounded text-xs">
                😐 {stats.okay} okay
              </span>
              <span className="text-red-700 font-semibold bg-red-100 px-2 py-0.5 rounded text-xs">
                ❌ {stats.not} not-me
              </span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

export default CREFeedbackSignatureMap;


