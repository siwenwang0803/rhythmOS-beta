import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface ToneFeedbackChartProps {
  isDaytime?: boolean;
}

type TimeRange = '7days' | '14days' | '30days';

export const ToneFeedbackChart: React.FC<ToneFeedbackChartProps> = ({ isDaytime = true }) => {
  const [data, setData] = useState<any[]>([]);
  const [timeRange, setTimeRange] = useState<TimeRange>('7days');

  // RhythmOS theme colors based on the UI spec and day/night mode
  const themeColors = {
    background: isDaytime ? '#F5E8C7' : '#2C2C2C',
    panelBg: isDaytime ? '#FFFFFF' : '#3A3A3A',
    text: isDaytime ? '#333333' : '#E0E0E0',
    textMuted: isDaytime ? '#777777' : '#AAAAAA',
    border: isDaytime ? '#E6E6E6' : '#555555',
    accent: '#F7DC6F', // Soft yellow accent from UI spec
    gridLines: isDaytime ? '#EEEEEE' : '#4A4A4A',
  };
  
  // Rhythm states colors from UI spec
  const stateColors = {
    collapsed: '#AEC6CF', // Gentle calming blue
    wavy: '#C3B1E1',     // Transitional lavender
    stable: '#C5D8A4',   // Grounded light green
    rising: '#FFB347',   // Activating orange-yellow
  };
  
  // Persona colors from UI spec for potential tone mapping
  const personaColors = {
    rhea: '#F5CFCF',
    caelum: '#4B6587',
    aurelia: '#D8A7CA',
    niveus: '#A2C4C9',
    lucis: '#C5D8A4', // Added lucis color
  };

  // Get an appropriate color for each tone based on rhythm states or personas
  const getToneColor = (tone: string): string => {
    const lowerTone = tone.toLowerCase();
    
    // Check if tone matches a rhythm state
    if (lowerTone.includes('collapsed') || lowerTone.includes('calm')) {
      return stateColors.collapsed;
    }
    if (lowerTone.includes('wavy') || lowerTone.includes('flow')) {
      return stateColors.wavy;
    }
    if (lowerTone.includes('stable') || lowerTone.includes('balanced')) {
      return stateColors.stable;
    }
    if (lowerTone.includes('rising') || lowerTone.includes('energetic')) {
      return stateColors.rising;
    }
    
    // Check if tone matches a persona
    if (lowerTone.includes('rhea') || lowerTone.includes('emotional')) {
      return personaColors.rhea;
    }
    if (lowerTone.includes('caelum') || lowerTone.includes('motivated')) {
      return personaColors.caelum;
    }
    if (lowerTone.includes('aurelia') || lowerTone.includes('rational')) {
      return personaColors.aurelia;
    }
    if (lowerTone.includes('niveus') || lowerTone.includes('directive')) {
      return personaColors.niveus;
    }
    if (lowerTone.includes('lucis') || lowerTone.includes('visionary')) {
      return personaColors.lucis;
    }
    
    // Default color with alpha transparency based on day/night mode
    return isDaytime ? '#60a5fa' : '#90CAF9';
  };

  // Get display label for time range
  const getTimeRangeLabel = (range: TimeRange): string => {
    switch (range) {
      case '7days': return 'Last 7 Days';
      case '14days': return 'Last 14 Days';
      case '30days': return 'Last 30 Days';
      default: return 'Last 7 Days';
    }
  };

  useEffect(() => {
    const raw = JSON.parse(localStorage.getItem('toneLog') || '[]');
    const now = new Date();
    
    // Calculate cutoff based on selected time range
    const days = timeRange === '7days' ? 7 : timeRange === '14days' ? 14 : 30;
    const cutoff = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
    
    const map: Record<string, number> = {};
    const seen = new Set<string>();

    for (const entry of raw) {
      if (!entry?.tone || !entry?.timestamp || entry.feedback === 'notMe') continue;

      const ts = new Date(entry.timestamp);
      if (ts < cutoff) continue;

      const key = `${entry.cueId}_${entry.tone}_${ts.toISOString().slice(0, 10)}`;
      if (seen.has(key)) continue;
      seen.add(key);

      const score = typeof entry.score === 'number'
        ? entry.score
        : entry.feedback === 'aligned' ? 1 : entry.feedback === 'okay' ? 0.5 : 0;

      map[entry.tone] = (map[entry.tone] || 0) + score;
    }

    const chartData = Object.entries(map).map(([tone, score]) => ({
      tone,
      score: Number(score.toFixed(2)),
      color: getToneColor(tone) // Add color for each tone
    }));

    // Sort data by score in descending order for better visualization
    chartData.sort((a, b) => b.score - a.score);

    setData(chartData);
  }, [timeRange]); // Add timeRange as dependency

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div 
          style={{ 
            backgroundColor: isDaytime ? 'rgba(255, 255, 255, 0.9)' : 'rgba(50, 50, 50, 0.9)',
            border: `1px solid ${themeColors.border}`,
            borderRadius: '6px',
            padding: '8px 12px',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
            color: themeColors.text
          }}
        >
          <p style={{ margin: 0, fontWeight: 600, fontSize: '12px' }}>{payload[0].payload.tone}</p>
          <p style={{ margin: '4px 0 0 0', fontSize: '11px' }}>
            <span style={{ color: payload[0].payload.color }}>{payload[0].value} points</span>
          </p>
        </div>
      );
    }
    return null;
  };

  // Custom bar component to use tone-specific colors
  const CustomBar = (props: any) => {
    const { x, y, width, height, payload } = props;
    return (
      <g>
        <rect 
          x={x} 
          y={y} 
          width={width} 
          height={height} 
          fill={payload.color}
          rx={2}
          ry={2}
          style={{ filter: 'drop-shadow(0px 1px 2px rgba(0,0,0,0.1))' }}
        />
      </g>
    );
  };

  if (data.length === 0) {
    return (
      <div 
        className="rounded-xl p-4"
        style={{ 
          backgroundColor: themeColors.panelBg,
          border: `1px solid ${themeColors.border}`,
          color: themeColors.textMuted,
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
        }}
      >
        {/* Header with time range selector */}
        <div className="flex justify-between items-center mb-4">
          <h3 
            className="text-md font-semibold"
            style={{ color: themeColors.text }}
          >
            🎯 Tone Feedback ({getTimeRangeLabel(timeRange)})
          </h3>
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value as TimeRange)}
            className="text-sm px-3 py-1 rounded-lg border-0 outline-none"
            style={{
              backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.1)',
              color: themeColors.text,
              border: `1px solid ${themeColors.border}`,
              transition: 'all 0.2s ease'
            }}
          >
            <option value="7days">7 Days</option>
            <option value="14days">14 Days</option>
            <option value="30days">30 Days</option>
          </select>
        </div>
        <p className="text-sm">No tone feedback yet</p>
      </div>
    );
  }

  return (
    <div 
      className="w-full rounded-xl p-4"
      style={{ 
        backgroundColor: themeColors.panelBg,
        border: `1px solid ${themeColors.border}`,
        boxShadow: isDaytime ? '0 2px 8px rgba(0, 0, 0, 0.05)' : '0 2px 8px rgba(0, 0, 0, 0.2)',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }}
    >
      {/* Header with time range selector */}
      <div className="flex justify-between items-center mb-4">
        <h3 
          className="text-md font-semibold"
          style={{ color: themeColors.text }}
        >
          🎯 Tone Feedback ({getTimeRangeLabel(timeRange)})
        </h3>
        <select
          value={timeRange}
          onChange={(e) => setTimeRange(e.target.value as TimeRange)}
          className="text-sm px-3 py-1 rounded-lg border-0 outline-none"
          style={{
            backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.1)',
            color: themeColors.text,
            border: `1px solid ${themeColors.border}`,
            transition: 'all 0.2s ease'
          }}
        >
          <option value="7days">7 Days</option>
          <option value="14days">14 Days</option>
          <option value="30days">30 Days</option>
        </select>
      </div>

      <div className="h-64 animate-fade-in">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart 
            data={data} 
            layout="vertical" 
            margin={{ top: 10, bottom: 10, left: 30, right: 10 }}
          >
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke={themeColors.gridLines} 
              horizontal={true} 
              vertical={false}
            />
            <XAxis 
              type="number" 
              domain={[0, Math.max(...data.map(d => d.score)) + 0.5]} 
              stroke={themeColors.text}
              tick={{ fill: themeColors.text, fontSize: 11 }}
            />
            <YAxis 
              type="category" 
              dataKey="tone" 
              stroke={themeColors.text}
              tick={{ fill: themeColors.text, fontSize: 11 }}
              width={100}
              tickFormatter={(value) => value.length > 12 ? `${value.substring(0, 12)}...` : value}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar 
              dataKey="score" 
              shape={<CustomBar />}
              isAnimationActive={true}
              animationDuration={800}
              animationEasing="ease-out"
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Scoring mechanism explanation */}
      <div 
        className="mt-4 p-3 rounded-lg"
        style={{
          backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)',
          border: `1px solid ${themeColors.border}`,
        }}
      >
        <div className="flex items-center justify-between mb-2">
          <span 
            className="text-xs font-medium"
            style={{ color: themeColors.text }}
          >
            📊 Scoring Mechanism
          </span>
          <span 
            className="text-xs"
            style={{ color: themeColors.textMuted }}
          >
            Based on your feedback
          </span>
        </div>
        <div className="space-y-1">
          <div className="flex justify-between text-xs">
            <span style={{ color: themeColors.textMuted }}>
              <span className="inline-block w-2 h-2 rounded-full mr-2" style={{ backgroundColor: '#22c55e' }}></span>
              Aligned
            </span>
            <span style={{ color: themeColors.text, fontWeight: 500 }}>+1.0 point</span>
          </div>
          <div className="flex justify-between text-xs">
            <span style={{ color: themeColors.textMuted }}>
              <span className="inline-block w-2 h-2 rounded-full mr-2" style={{ backgroundColor: '#f59e0b' }}></span>
              Okay
            </span>
            <span style={{ color: themeColors.text, fontWeight: 500 }}>+0.5 points</span>
          </div>
          <div className="flex justify-between text-xs">
            <span style={{ color: themeColors.textMuted }}>
              <span className="inline-block w-2 h-2 rounded-full mr-2" style={{ backgroundColor: '#6b7280' }}></span>
              Not Me (excluded)
            </span>
            <span style={{ color: themeColors.text, fontWeight: 500 }}>+0 points</span>
          </div>
        </div>
        <div 
          className="mt-2 pt-2 text-xs"
          style={{ 
            borderTop: `1px solid ${themeColors.border}`,
            color: themeColors.textMuted 
          }}
        >
          💡 Higher scores indicate tones that resonate better with your identity goals.
        </div>
      </div>
      
      {/* Add animation keyframes with a style tag */}
      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        
        .animate-fade-in {
          animation: fadeIn 0.5s ease-out;
        }
      `}</style>
    </div>
  );
};

export default ToneFeedbackChart;