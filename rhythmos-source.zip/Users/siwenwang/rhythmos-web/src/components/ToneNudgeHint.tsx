// /components/ToneNudgeHint.tsx - 改进版本

import React, { useState, useEffect } from 'react';
import { 
  ToneType, 
  setActivePersonaTone, 
  recordToneSwitch,
  recordToneSuggestion
} from '../utils/tonePreferenceAnalyzer';

// 定义 UI 规范中的颜色和样式
const PERSONAS = {
  rhea: {
    name: 'Rhea',
    description: '温和、共情',
    color: '#F5CFCF',
    lightColor: '#F9E5E5',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)'
  },
  caelum: {
    name: 'Caelum',
    description: '指导性、自信',
    color: '#4B6587',
    lightColor: '#D8E1F0',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)'
  },
  aurelia: {
    name: 'Aurelia',
    description: '理性、直觉',
    color: '#D8A7CA',
    lightColor: '#F2E4EE',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)'
  },
  lucis: {
    name: 'Lucis',
    description: '前瞻、创新',
    color: '#C5D8A4',
    lightColor: '#E8F5C7',
    gradient: 'linear-gradient(135deg, #F5E8C7, #C5D8A4)'
  },
  niveus: {
    name: 'Niveus',
    description: '客观、分析',
    color: '#A2C4C9',
    lightColor: '#E8F5F7',
    gradient: 'linear-gradient(135deg, #F5E8C7, #A2C4C9)'
  }
};

// 音调到 persona 的映射
const TONE_TO_PERSONA: Record<string, string> = {
  gentle: 'rhea',
  supportive: 'rhea',
  balanced: 'niveus',
  motivated: 'caelum',
  directive: 'caelum',
  rational: 'aurelia',
  visionary: 'lucis'
};

// 推荐原因的描述
const REASON_DESCRIPTIONS = {
  fatigue: 'Your current tone isn\'t resonating well with your feedback patterns.',
  strong_preference: 'Your feedback consistently shows a preference for this tone.'
};

interface Props {
  dominant: ToneType;
  suggested: ToneType;
  confidence: number;
  switchReason: 'fatigue' | 'strong_preference';
  onSwitch?: (newTone: ToneType) => void;
  onDismiss?: () => void;
}

const ToneNudgeHint: React.FC<Props> = ({ 
  dominant, 
  suggested, 
  confidence,
  switchReason,
  onSwitch, 
  onDismiss 
}) => {
  const [hasSwitched, setHasSwitched] = useState(false);
  const [animating, setAnimating] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  
  // 🔥 在组件挂载时记录此次推荐
  useEffect(() => {
    recordToneSuggestion(suggested);
    console.log('[TONE_NUDGE] Suggestion shown:', { 
      from: dominant, 
      to: suggested, 
      confidence, 
      reason: switchReason 
    });
  }, [suggested, dominant, confidence, switchReason]);
  
  // 获取相应的 persona
  const dominantPersona = TONE_TO_PERSONA[dominant] || 'rhea';
  const suggestedPersona = TONE_TO_PERSONA[suggested] || 'rhea';
  
  // 获取 persona 样式
  const dominantStyle = PERSONAS[dominantPersona] || PERSONAS.rhea;
  const suggestedStyle = PERSONAS[suggestedPersona] || PERSONAS.rhea;
  
  // 构建描述文本
  const reasonText = REASON_DESCRIPTIONS[switchReason];
  const confidenceText = confidence > 0.8 ? 'highly confident' : 
                        confidence > 0.6 ? 'moderately confident' : 
                        'tentatively suggesting';
  
  const handleSwitch = () => {
    if (hasSwitched || animating) return;
    
    setAnimating(true);
    
    // 设置新的语调
    setActivePersonaTone(suggested);
    
    // 动画效果
    setTimeout(() => {
      setHasSwitched(true);
      setAnimating(false);
      
      console.log('[TONE_NUDGE] User accepted switch:', { from: dominant, to: suggested });
      
      // 如果提供了回调函数，调用它
      if (onSwitch) {
        onSwitch(suggested);
      }
    }, 500);
  };
  
  const handleDismiss = () => {
    setDismissed(true);
    console.log('[TONE_NUDGE] User dismissed suggestion:', { from: dominant, to: suggested });
    
    // 记录用户拒绝了这个建议
    try {
      const dismissals = JSON.parse(localStorage.getItem('toneSuggestionDismissals') || '[]');
      dismissals.push({
        from: dominant,
        to: suggested,
        timestamp: new Date().toISOString(),
        reason: switchReason
      });
      localStorage.setItem('toneSuggestionDismissals', JSON.stringify(dismissals.slice(-30)));
    } catch (error) {
      console.error('Error recording dismissal:', error);
    }
    
    if (onDismiss) onDismiss();
  };
  
  // 如果已经切换或被忽略，不显示组件
  if (dismissed) return null;
  
  return (
    <div 
      className="bg-white rounded-xl p-4 shadow-sm"
      style={{
        border: '1px solid rgba(0,0,0,0.05)',
        transition: 'all 0.3s ease'
      }}
    >
      <div className="flex items-start gap-4">
        <div 
          className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all ${
            animating ? 'animate-spin' : ''
          }`}
          style={{ 
            background: suggestedStyle.gradient,
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
          }}
        >
          <span>{hasSwitched ? '✓' : '🔄'}</span>
        </div>
        
        <div className="flex-1">
          <div className="flex justify-between items-start mb-3">
            <div>
              <p className="text-sm" style={{ color: '#333333' }}>
                {reasonText} Based on your feedback patterns, we're{' '}
                <span className="font-medium" style={{ color: suggestedStyle.color }}>
                  {confidenceText}
                </span>{' '}
                that you might prefer{' '}
                <span 
                  className="mx-1 px-2 py-0.5 rounded-md font-medium"
                  style={{ 
                    backgroundColor: suggestedStyle.lightColor, 
                    color: '#333333', 
                    border: `1px solid ${suggestedStyle.color}20`
                  }}
                >
                  {suggested}
                </span> 
                tone.
              </p>
              
              {/* 🔥 添加置信度指示器 */}
              <div className="mt-2 flex items-center gap-2">
                <span className="text-xs text-gray-500">Confidence:</span>
                <div className="flex gap-1">
                  {[0.2, 0.4, 0.6, 0.8, 1.0].map((threshold, index) => (
                    <div
                      key={index}
                      className="w-3 h-2 rounded-sm"
                      style={{
                        backgroundColor: confidence >= threshold ? suggestedStyle.color : '#e5e5e5'
                      }}
                    />
                  ))}
                </div>
                <span className="text-xs text-gray-500">
                  {Math.round(confidence * 100)}%
                </span>
              </div>
            </div>
            
            {/* 添加关闭按钮 */}
            {!hasSwitched && (
              <button 
                onClick={handleDismiss}
                className="text-gray-400 hover:text-gray-600 p-1 ml-2"
                aria-label="Dismiss suggestion"
                title="Don't show this suggestion again for a while"
              >
                ✕
              </button>
            )}
          </div>
          
          {!hasSwitched ? (
            <button
              onClick={handleSwitch}
              disabled={animating}
              className={`px-4 py-2 rounded-xl text-sm font-medium shadow-sm transition-all duration-200 ${
                animating ? 'opacity-70' : ''
              }`}
              style={{ 
                background: `linear-gradient(135deg, #FFFFFF, ${suggestedStyle.lightColor})`, 
                borderLeft: `3px solid ${suggestedStyle.color}`, 
                color: '#333333',
                boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)'
              }}
              onMouseEnter={(e) => !animating && (e.currentTarget.style.transform = 'translateY(-2px)')}
              onMouseLeave={(e) => !animating && (e.currentTarget.style.transform = 'translateY(0)')}
            >
              ✅ Switch to {suggested} tone
            </button>
          ) : (
            <div 
              className="px-4 py-2 rounded-lg text-sm flex items-center gap-2"
              style={{ 
                backgroundColor: suggestedStyle.lightColor,
                color: '#333333',
                opacity: 0.9
              }}
            >
              <span>✓</span>
              <span>Switched to {suggested} tone successfully!</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ToneNudgeHint;
