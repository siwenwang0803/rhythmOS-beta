// src/components/DevSystemInspector.tsx
import React from 'react';

const DevSystemInspector: React.FC = () => {
  const rhythmScore = localStorage.getItem('rhythmScore');
  const signatureFeedbackLog = localStorage.getItem('signatureFeedbackLog');
  const preferredTone = localStorage.getItem('preferredTone');
  const initPersona = localStorage.getItem('initPersona');
  const subtasks = localStorage.getItem('rhythmSubtasks');

  return (
    <div className="p-4 bg-yellow-50 border border-yellow-300 rounded text-sm mt-10 space-y-2">
      <p><strong>🧪 rhythmScore:</strong> {rhythmScore}</p>
      <p><strong>🧠 signatureFeedbackLog:</strong> {signatureFeedbackLog}</p>
      <p><strong>🎨 preferredTone:</strong> {preferredTone}</p>
      <p><strong>🌟 initPersona:</strong> {initPersona}</p>
      <p><strong>🧩 rhythmSubtasks:</strong> {subtasks}</p>
    </div>
  );
};

export default DevSystemInspector;
