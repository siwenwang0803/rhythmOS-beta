// components/IdentityNarrativeCard.tsx - 完全修复版本

import React, { useEffect, useState } from 'react';

interface IdentityNarrativeCardProps {
  tagId: string; // e.g., 'expressive_guide'
  persona: string; // e.g., 'rhea'
  tone: string; // e.g., 'gentle'
  rhythmSummary?: string; // Optional rhythm comment
  isDaytime?: boolean; // Optional prop to control day/night mode
}

// UI规范中的颜色和样式
const PERSONAS = {
  rhea: {
    name: 'Rhea',
    color: '#F5CFCF',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #694647)',
    icon: '💗'
  },
  aurelia: {
    name: 'Aurelia',
    color: '#D8A7CA',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #5A4555)',
    icon: '🧠'
  },
  lucis: {
    name: 'Lucis',
    color: '#A4D8C5',
    gradient: 'linear-gradient(135deg, #E8F5C7, #A4D8C5)',
    nightGradient: 'linear-gradient(135deg, #495D44, #456056)',
    icon: '🌱'
  },
  niveus: {
    name: 'Niveus',
    color: '#C7C7C7',
    gradient: 'linear-gradient(135deg, #E8E8E8, #C7C7C7)',
    nightGradient: 'linear-gradient(135deg, #4A4A4A, #555555)',
    icon: '📊'
  },
  caelum: {
    name: 'Caelum',
    color: '#4B6587',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #2A3A4F)',
    icon: '💠'
  }
};

// Tone to emoji mapping
const TONE_EMOJI = {
  gentle: '🌸',
  directive: '📌',
  motivated: '🔆',
  rational: '🧩',
  balanced: '⚖️',
  visionary: '🔭',
  default: '🌊'
};

// 标签叙述库 - 内置在组件中，避免外部依赖
const TAG_NARRATIVES: Record<string, (persona: string, tone: string) => string> = {
  expressive_guide: (persona, tone) =>
    `You've expressed yourself as an Expressive Guide — combining a ${tone} tone with ${persona}'s communicative clarity. Your guidance emerges naturally from authentic self-expression.`,
  
  calm_challenger: (persona, tone) =>
    `Your reflections show steady resilience. As a Calm Challenger, you meet resistance with a ${tone} mindset shaped by ${persona}'s perspective, maintaining composure while pushing forward.`,
  
  reflective_builder: (persona, tone) =>
    `As a Reflective Builder, you've cultivated thoughtful rhythm through ${persona}'s ${tone} practice. You construct growth deliberately, piece by piece.`,
  
  structured_support: (persona, tone) =>
    `You provide Structured Support through ${persona}'s ${tone} approach. Your organized nature creates a safe foundation for others to build upon.`,
  
  empathetic_clarity: (persona, tone) =>
    `Your Empathetic Clarity shines through ${persona}'s ${tone} communication. You understand deeply while expressing with precision and care.`,
  
  creative_catalyst: (persona, tone) =>
    `As a Creative Catalyst, your ${persona} perspective with a ${tone} approach sparks innovation and opens new possibilities for yourself and others.`,
  
  mindful_leadership: (persona, tone) =>
    `You embody Mindful Leadership through ${persona}'s ${tone} presence. You lead with awareness, intention, and authentic connection.`,
  
  // 单个特质标签
  structure: (persona, tone) =>
    `Your sense of Structure manifests through ${persona}'s ${tone} approach to organization and clarity.`,
  
  vision: (persona, tone) =>
    `Your Vision emerges through ${persona}'s ${tone} perspective, helping you see the bigger picture and inspire others.`,
  
  clarity: (persona, tone) =>
    `Your Clarity is expressed through ${persona}'s ${tone} communication, cutting through confusion with precise understanding.`,
  
  focus: (persona, tone) =>
    `Your Focus is channeled through ${persona}'s ${tone} approach to concentration and sustained attention.`,
  
  presence: (persona, tone) =>
    `Your Presence radiates through ${persona}'s ${tone} awareness, bringing depth to every interaction.`,
  
  balance: (persona, tone) =>
    `Your Balance is achieved through ${persona}'s ${tone} harmony of different life aspects.`,
  
  calm: (persona, tone) =>
    `Your Calm flows through ${persona}'s ${tone} peace, providing stability in turbulent times.`,
  
  courage: (persona, tone) =>
    `Your Courage emerges through ${persona}'s ${tone} willingness to face challenges head-on.`,
  
  perspective: (persona, tone) =>
    `Your Perspective is shaped by ${persona}'s ${tone} wisdom, offering broader views on complex situations.`,
  
  adaptability: (persona, tone) =>
    `Your Adaptability shows through ${persona}'s ${tone} flexibility in changing circumstances.`,
};

// 获取标签叙述
const getTagNarrative = (tagId: string, persona: string, tone: string): string => {
  const narrativeFunction = TAG_NARRATIVES[tagId];
  
  if (narrativeFunction) {
    return narrativeFunction(persona, tone);
  }
  
  // 默认叙述
  const tagLabel = tagId.split('_').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');
  
  const personaName = PERSONAS[persona as keyof typeof PERSONAS]?.name || persona;
  
  return `This ${tagLabel} expression reflects your unique ${personaName} perspective with a ${tone} approach, showing how you navigate growth and challenges.`;
};

const IdentityNarrativeCard: React.FC<IdentityNarrativeCardProps> = ({
  tagId,
  persona,
  tone,
  rhythmSummary,
  isDaytime = true
}) => {
  const [isAnimated, setIsAnimated] = useState(false);
  const [alignedCount, setAlignedCount] = useState(0);
  
  // 计算对应的 aligned feedback 计数
  useEffect(() => {
    try {
      console.log(`[IdentityNarrativeCard] Calculating aligned count for ${persona}/${tone}`);
      
      let allFeedbackEntries: any[] = [];
      
      // 1. 从 SignatureMap 获取数据
      try {
        if (window.signatureMap && window.signatureMap.cueFeedbackLog) {
          allFeedbackEntries = [...allFeedbackEntries, ...window.signatureMap.cueFeedbackLog];
          console.log(`[IdentityNarrativeCard] Found ${window.signatureMap.cueFeedbackLog.length} entries in SignatureMap`);
        }
      } catch (e) {
        console.warn('[IdentityNarrativeCard] Error accessing window.signatureMap:', e);
      }
      
      // 2. 从 localStorage signatureMap 获取数据
      try {
        const signatureMapStr = localStorage.getItem('signatureMap');
        if (signatureMapStr && signatureMapStr !== 'undefined') {
          const signatureMap = JSON.parse(signatureMapStr);
          if (signatureMap?.cueFeedbackLog) {
            allFeedbackEntries = [...allFeedbackEntries, ...signatureMap.cueFeedbackLog];
            console.log(`[IdentityNarrativeCard] Found ${signatureMap.cueFeedbackLog.length} entries in localStorage signatureMap`);
          }
        }
      } catch (e) {
        console.warn('[IdentityNarrativeCard] Error parsing localStorage signatureMap:', e);
      }
      
      // 3. 从旧的存储位置获取数据
      try {
        const oldFeedbackStr = localStorage.getItem('signatureFeedbackLog');
        if (oldFeedbackStr && oldFeedbackStr !== 'undefined') {
          const oldFeedback = JSON.parse(oldFeedbackStr);
          allFeedbackEntries = [...allFeedbackEntries, ...oldFeedback];
          console.log(`[IdentityNarrativeCard] Found ${oldFeedback.length} entries in old feedback log`);
        }
      } catch (e) {
        console.warn('[IdentityNarrativeCard] Error parsing old feedback log:', e);
      }
      
      // 去重（基于时间戳和内容）
      const uniqueEntries = allFeedbackEntries.reduce((unique: any[], entry: any) => {
        const isDuplicate = unique.some(u => 
          u.timestamp === entry.timestamp && 
          u.cueText === entry.cueText &&
          u.feedback === entry.feedback
        );
        if (!isDuplicate) {
          unique.push(entry);
        }
        return unique;
      }, []);
      
      console.log(`[IdentityNarrativeCard] Total unique feedback entries: ${uniqueEntries.length}`);
      
      // 计算匹配的 aligned feedback 数量
      const count = uniqueEntries.filter((entry: any) => {
        const matchesPersona = entry.persona === persona || entry.personaAnchor === persona;
        const matchesTone = entry.tone === tone;
        const isAligned = entry.feedback === 'aligned';
        
        if (matchesPersona && matchesTone) {
          console.log(`[IdentityNarrativeCard] Matching entry:`, {
            entry: entry,
            isAligned: isAligned
          });
        }
        
        return matchesPersona && matchesTone && isAligned;
      }).length;
      
      console.log(`[IdentityNarrativeCard] Found ${count} aligned entries for ${persona}/${tone}`);
      setAlignedCount(count);
    } catch (error) {
      console.error('[IdentityNarrativeCard] Error calculating aligned count:', error);
      setAlignedCount(0);
    }
  }, [persona, tone]);
  
  // 获取标签叙述
  const narrative = getTagNarrative(tagId, persona, tone);
  
  // 获取对应的persona样式
  const personaStyle = PERSONAS[persona as keyof typeof PERSONAS] || PERSONAS.rhea;
  
  // 获取对应的tone emoji
  const toneEmoji = TONE_EMOJI[tone as keyof typeof TONE_EMOJI] || TONE_EMOJI.default;
  
  // 根据日夜模式调整颜色
  const baseTextColor = isDaytime ? '#333333' : '#E0E0E0';
  const secondaryTextColor = isDaytime ? '#444444' : '#CCCCCC';
  const tertiaryTextColor = isDaytime ? '#666666' : '#AAAAAA';
  const bgOpacity = isDaytime ? 0.8 : 0.6;
  
  // 动画效果
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsAnimated(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);
  
  // 将标签ID转换为可读文本
  const tagLabel = tagId.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  
  // 调试信息
  console.log('[IdentityNarrativeCard] Rendering:', {
    tagId,
    persona,
    tone,
    narrative,
    alignedCount,
    personaStyle: personaStyle.name
  });
  
  return (
    <div 
      style={{
        borderRadius: '12px',
        padding: '24px',
        marginTop: '16px',
        position: 'relative',
        overflow: 'hidden',
        transition: 'all 0.7s ease',
        transform: isAnimated ? 'translateY(0)' : 'translateY(32px)',
        opacity: isAnimated ? 1 : 0,
        backgroundColor: `rgba(255, 255, 255, ${bgOpacity})`,
        backdropFilter: 'blur(12px)',
        border: `1px solid ${isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)'}`,
        boxShadow: isDaytime 
          ? '0 8px 32px rgba(0, 0, 0, 0.06), 0 2px 8px rgba(0, 0, 0, 0.04)'
          : '0 8px 32px rgba(0, 0, 0, 0.15), 0 4px 12px rgba(0, 0, 0, 0.1)'
      }}
    >
      {/* 背景装饰元素 */}
      <div 
        style={{
          position: 'absolute',
          top: '-80px',
          right: '-80px',
          width: '160px',
          height: '160px',
          borderRadius: '50%',
          opacity: 0.08,
          zIndex: 0,
          background: isDaytime ? personaStyle.gradient : personaStyle.nightGradient,
          filter: 'blur(20px)'
        }}
      />
      
      <div 
        style={{
          position: 'absolute',
          bottom: '-80px',
          left: '-80px',
          width: '160px',
          height: '160px',
          borderRadius: '50%',
          opacity: 0.05,
          zIndex: 0,
          background: isDaytime ? personaStyle.gradient : personaStyle.nightGradient,
          filter: 'blur(25px)'
        }}
      />
      
      {/* 标题区域 */}
      <div style={{ 
        display: 'flex', 
        alignItems: 'center', 
        gap: '16px',
        position: 'relative',
        zIndex: 10,
        marginBottom: '20px'
      }}>
        <div 
          style={{
            width: '56px',
            height: '56px',
            borderRadius: '16px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transform: 'scale(1)',
            transition: 'all 0.3s ease',
            background: isDaytime ? personaStyle.gradient : personaStyle.nightGradient,
            boxShadow: isDaytime
              ? `0 4px 16px ${personaStyle.color}40, 0 2px 8px rgba(0,0,0,0.1)`
              : `0 4px 20px rgba(0, 0, 0, 0.3)`,
            cursor: 'pointer'
          }}
          onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
          onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
        >
          <span style={{ fontSize: '24px' }}>{personaStyle.icon}</span>
        </div>
        <div style={{ flex: 1 }}>
          <div 
            style={{
              fontSize: '20px',
              fontWeight: '600',
              color: baseTextColor,
              marginBottom: '6px'
            }}
          >
            Your Identity Expression
          </div>
          <div style={{
            fontSize: '13px',
            color: tertiaryTextColor,
            marginBottom: '6px'
          }}>
            Based on <strong style={{ color: personaStyle.color }}>{alignedCount} aligned responses</strong> from your feedback pattern
          </div>
          <div 
            style={{
              fontSize: '14px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              color: tertiaryTextColor
            }}
          >
            <span>{personaStyle.icon}</span>
            <span style={{ textTransform: 'capitalize', fontWeight: '500' }}>{personaStyle.name}</span>
            <span style={{ opacity: 0.5 }}>•</span>
            <span>{toneEmoji}</span>
            <span style={{ textTransform: 'capitalize' }}>{tone} tone</span>
          </div>
        </div>
      </div>
      
      {/* 分隔线 */}
      <div 
        style={{
          height: '1px',
          width: '100%',
          marginBottom: '20px',
          background: `linear-gradient(to right, ${personaStyle.color}00, ${personaStyle.color}40, ${personaStyle.color}00)`,
          opacity: isDaytime ? 1 : 0.7
        }}
      />
      
      {/* 内容区域 */}
      <div 
        style={{
          lineHeight: 1.7,
          position: 'relative',
          zIndex: 10,
          marginLeft: '8px',
          paddingLeft: '20px',
          borderLeft: `3px solid ${personaStyle.color}60`,
          fontSize: '16px',
          color: secondaryTextColor
        }}
      >
        {narrative}
      </div>
      
      {/* 节奏摘要 */}
      {rhythmSummary && (
        <div 
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '16px',
            marginTop: '20px',
            padding: '16px 20px',
            borderRadius: '12px',
            position: 'relative',
            zIndex: 10,
            backgroundColor: isDaytime 
              ? 'rgba(255, 255, 255, 0.6)'
              : 'rgba(0, 0, 0, 0.3)',
            color: tertiaryTextColor,
            border: isDaytime
              ? `1px solid ${personaStyle.color}30`
              : '1px solid rgba(255, 255, 255, 0.1)'
          }}
        >
          <div 
            style={{
              width: '36px',
              height: '36px',
              borderRadius: '50%',
              flexShrink: 0,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: isDaytime 
                ? `${personaStyle.color}40`
                : 'rgba(255, 255, 255, 0.15)',
              boxShadow: isDaytime
                ? '0 2px 8px rgba(0, 0, 0, 0.05)'
                : '0 2px 8px rgba(0, 0, 0, 0.2)'
            }}
          >
            <span style={{ fontSize: '18px' }}>🌊</span>
          </div>
          <span style={{ fontSize: '15px', fontStyle: 'italic' }}>{rhythmSummary}</span>
        </div>
      )}
      
      {/* 标签指示器 */}
      <div 
        style={{
          position: 'absolute',
          top: '24px',
          right: '24px',
          padding: '8px 16px',
          borderRadius: '24px',
          fontSize: '13px',
          fontWeight: '500',
          zIndex: 10,
          transition: 'all 0.3s ease',
          backgroundColor: isDaytime
            ? `${personaStyle.color}25`
            : 'rgba(255, 255, 255, 0.15)',
          color: baseTextColor,
          border: isDaytime
            ? `1px solid ${personaStyle.color}40`
            : '1px solid rgba(255, 255, 255, 0.15)',
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)',
          cursor: 'pointer'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'scale(1.05)';
          e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.1)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'scale(1)';
          e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.05)';
        }}
      >
        {tagLabel}
      </div>
    </div>
  );
};

export default IdentityNarrativeCard;

