// components/SpeakReplayView.tsx

import React from 'react'

const SpeakReplayView: React.FC = () => {
  const raw = localStorage.getItem('speakReplayLog')
  const log: any[] = raw ? JSON.parse(raw) : []
  const reversed = [...log].reverse()

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-800">
        🗣️ Language Reflections (SPEAK Log)
      </h3>
      {reversed.length === 0 ? (
        <p className="text-sm text-gray-500">No reflections recorded yet.</p>
      ) : (
        reversed.map((entry, i) => (
          <div key={i} className="p-4 bg-white border rounded shadow-sm space-y-1">
            <p className="text-sm text-gray-600">
              <strong>You said:</strong> “{entry.userInput}”
            </p>
            <p className="text-sm text-blue-700">
              <strong>System replied:</strong> “{entry.systemResponse}”
            </p>
            <p className="text-xs text-gray-400 italic">
              Tone: {entry.tone} · Emotion: {entry.emotion} · Persona: {entry.persona}
            </p>
            <p className="text-xs text-gray-400">
              {new Date(entry.timestamp).toLocaleString()}
            </p>
          </div>
        ))
      )}
    </div>
  )
}

export default SpeakReplayView
