import React from 'react';
import { getCurrentTrend } from '../utils/trendScore';

export const RhythmPhaseCue: React.FC = () => {
  const trend = getCurrentTrend();

  const phaseMap: Record<string, { title: string; message: string }> = {
    collapsed: {
      title: '🛠️ Recovery Mode',
      message: "You're in a low rhythm state. Go gently. Focus on compassion and consistency."
    },
    stable: {
      title: '🌊 Rhythm Stabilizing',
      message: "Your rhythm is steady. It's a good time to reinforce core routines."
    },
    rising: {
      title: '🚀 Momentum Rising',
      message: "You're gaining rhythm! Try expanding into a new challenge persona."
    },
    wavy: {
      title: '🔄 Mixed Flow',
      message: "You're in a flexible state. Re-center with a tone or persona you trust."
    }
  };

  const phase = phaseMap[trend];
  if (!phase) return null;

  return (
    <div className="mt-6 p-4 border border-blue-200 bg-blue-50 rounded text-sm text-blue-800 shadow-sm">
      <p className="font-medium mb-1">{phase.title}</p>
      <p>{phase.message}</p>
    </div>
  );
};
