import React, { useState } from 'react'
import { generateSubtaskSuggestions } from '../generateSubtaskSuggestions'
import { writeCREGrowthLog } from '../creGrowthLog'
import { addFeedbackRecord } from '../feedbackRecord'
import { updateRhythmScore } from '../rhythmScore'
import { recordRhythmTrend } from '../trendPathTracker'
import { goalTemplates } from '../templates/goalTemplateRegistry'

const SubtaskSuggestionView: React.FC<{ goal: string; trend: string }> = ({ goal, trend }) => {
  const [accepted, setAccepted] = useState<number[]>([])
 

  const matched = goalTemplates.find(t =>
    goal.toLowerCase().includes(t.intent.toLowerCase())
  )
  
  if (!matched || !Array.isArray(matched.tasks)) {
    return (
      <p className="text-sm text-red-600 italic">
        ⚠️ No subtask pattern matched for this goal.
      </p>
    )
  }
  
  const suggestions = generateSubtaskSuggestions(goal, trend)
  const handleAccept = (i: number) => {
    const s = suggestions[i]

    writeCREGrowthLog({
      creText: s.cue,
      tone: s.tone,
      variant: 'base',
      taskType: s.taskType,
      persona: 'auto',
      trend,
      context: 'subtask',
      accepted: true,
      score: undefined,
      timestamp: Date.now()
    })

    addFeedbackRecord({
      tone: s.tone,
      variant: 'base',
      taskType: s.taskType,
      persona: 'auto',
      score: 5,
      source: 'subtask'
    })

    const { score, state } = updateRhythmScore('complete', 'system')
    console.log('🎯 RhythmScore updated to', score, '→ state:', state)
    recordRhythmTrend(score, state)


    setAccepted([...accepted, i])
  }

  return (
    <div className="space-y-5 mt-6">
      <h3 className="text-md font-semibold text-gray-800">📋 Suggested Subtasks for: “{goal}”</h3>
      {suggestions.map((s, i) => (
        <div key={i} className="border rounded bg-white p-3 space-y-2">
          <p className="text-sm text-gray-700">🧩 {s.text}</p>
          <p className="text-xs text-blue-600 italic">“{s.cue}”</p>
          {!accepted.includes(i) ? (
            <button
              className="text-xs px-3 py-1 bg-green-600 text-white rounded"
              onClick={() => handleAccept(i)}
            >
              ✅ Accept Task
            </button>
          ) : (
            <p className="text-xs text-green-600 italic">Accepted</p>
          )}
          
        </div>
      ))}
    </div>
  )
}

export default SubtaskSuggestionView
