// components/FeedbackLogCollapse.tsx

import React, { useState } from 'react';
import { signatureMap } from '../SignatureMap';

const FeedbackLogCollapse: React.FC = () => {
  const [expanded, setExpanded] = useState(false);

  // 去重：每个 cueText 只保留最新一条反馈
  const uniqueFeedbacks = Object.values(
    signatureMap.cueFeedbackLog.reduce((acc, entry) => {
      acc[entry.cueText] = entry;
      return acc;
    }, {} as Record<string, typeof signatureMap.cueFeedbackLog[0]>)
  )
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 6); // 只显示最近 6 条

  return (
    <div className="border bg-white rounded-md px-4 py-3">
      <div className="flex justify-between items-center cursor-pointer" onClick={() => setExpanded(!expanded)}>
        <div className="text-sm font-medium text-gray-700">
          📄 Feedback Log {expanded ? '▾' : '▸'}
        </div>
        <span className="text-xs text-gray-400">{uniqueFeedbacks.length} recent</span>
      </div>

      {expanded && (
        <ul className="mt-3 space-y-2">
          {uniqueFeedbacks.map((entry, idx) => (
            <li
              key={idx}
              className="bg-gray-50 border border-gray-200 px-3 py-2 rounded text-sm text-gray-700"
            >
              <p className="font-medium text-gray-800 mb-1">“{entry.cueText}”</p>
              <div className="flex flex-wrap items-center gap-2 text-xs text-gray-600">
                <span>
                  {entry.feedback === 'aligned' ? '✅ aligned' : entry.feedback === 'okay' ? '😐 okay' : '❌ not me'}
                </span>
                <span className="text-gray-400">•</span>
                <span>{entry.tone} tone</span>
                <span className="text-gray-400">•</span>
                <span>{entry.persona}</span>
                <span className="text-gray-400">•</span>
                <span>{new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default FeedbackLogCollapse;
