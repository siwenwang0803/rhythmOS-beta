import React from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

interface ToneBarChartProps {
  data: Record<string, number>;
}

/**
 * 获取 tone 显示名称
 */
const getToneDisplayName = (tone: string): string => {
  const toneNames: Record<string, string> = {
    'gentle': 'Gentle',
    'motivated': 'Motivated',
    'directive': 'Directive',
    'rational': 'Rational',
    'visionary': 'Visionary'
  };
  return toneNames[tone] || tone.charAt(0).toUpperCase() + tone.slice(1);
};

/**
 * 获取 tone 颜色
 */
const getToneColor = (tone: string): string => {
  const colorMap: Record<string, string> = {
    'gentle': '#4F8A8B',
    'motivated': '#E16036',
    'directive': '#5D5FEF',
    'rational': '#9333EA',
    'visionary': '#F59E0B',
    'default': '#64748B'
  };
  
  return colorMap[tone] || colorMap.default;
};

/**
 * 为条形图准备数据
 */
const formatDataForBarChart = (data: Record<string, number>) => {
  if (Object.keys(data).length === 0) return [];
  
  // 将数据转换为条形图所需的格式
  return Object.entries(data).map(([tone, score]) => ({
    name: getToneDisplayName(tone),
    score: score,
    fill: getToneColor(tone)
  }));
};

/**
 * 条形图组件 - 替代雷达图
 */
const ToneBarChart: React.FC<ToneBarChartProps> = ({ data }) => {
  // 如果没有数据，显示一个空状态
  if (!data || Object.keys(data).length === 0) {
    return (
      <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg border">
        <p className="text-gray-400">No tone data available</p>
      </div>
    );
  }
  
  // 为条形图准备数据
  const chartData = formatDataForBarChart(data);
  
  return (
    <div style={{ width: '100%', height: 300 }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={chartData}
          margin={{
            top: 10,
            right: 30,
            left: 0,
            bottom: 10,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis 
            dataKey="name" 
            tick={{ fill: '#6B7280', fontSize: 12 }}
          />
          <YAxis 
            domain={[0, 3]} 
            tick={{ fill: '#9CA3AF', fontSize: 10 }}
            tickCount={4}
          />
          <Tooltip
            formatter={(value: number) => [`${value.toFixed(1)}`, 'Score']}
            cursor={{ fill: 'rgba(0, 0, 0, 0.05)' }}
            contentStyle={{
              backgroundColor: 'white',
              border: '1px solid #E5E7EB',
              borderRadius: '6px',
              padding: '8px 12px'
            }}
          />
          <Bar 
            dataKey="score" 
            fill="#8884d8" 
            radius={[4, 4, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ToneBarChart;