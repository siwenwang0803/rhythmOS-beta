import React, { useEffect, useState } from 'react';
import { getSignatureMap } from '../SignatureMap';

interface SignatureReplayPanelProps {
  isDaytime?: boolean; // Optional prop to control day/night mode
}

const FEEDBACK_STORAGE_KEY = 'cueFeedbackLog';

// Helper function to judge if two dates are the same day
const isSameDay = (date1: Date | string, date2: Date | string) => {
  const d1 = typeof date1 === 'string' ? new Date(date1) : date1;
  const d2 = typeof date2 === 'string' ? new Date(date2) : date2;
  
  return d1.getFullYear() === d2.getFullYear() &&
    d1.getMonth() === d2.getMonth() &&
    d1.getDate() === d2.getDate();
};

// 生成一致的唯一键，用于去重
const createUniqueKey = (
  cueId: string, 
  tone: string, 
  timestamp: string
): string => {
  const date = new Date(timestamp);
  const dayKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  return `${cueId}_${tone}_${dayKey}`;
};

// Helper function to get recent feedback entries
const getRecentFeedbacks = (limit = 3) => {
  // 直接从 localStorage 读取最新数据，确保不会读到旧数据
  try {
    const savedRaw = localStorage.getItem(FEEDBACK_STORAGE_KEY);
    if (!savedRaw) return [];

    const cueFeedbackLog = JSON.parse(savedRaw);
    
    // Filter out any debug entries with cueText "You deserve to pause."
    const validEntries = cueFeedbackLog.filter((entry: any) => 
      entry && entry.cueText && entry.cueText !== "You deserve to pause."
    );
    
    // 使用 Map 进行去重，确保相同 uniqueKey 的条目只保留最新的
    const uniqueEntries = new Map();
    
    validEntries.forEach((entry: any) => {
      // 如果没有 uniqueKey，则创建一个
      const key = entry.uniqueKey || createUniqueKey(entry.cueId, entry.tone, entry.timestamp);
      
      // 如果已经有这个 key 的条目，比较时间戳，保留最新的
      if (uniqueEntries.has(key)) {
        const existingEntry = uniqueEntries.get(key);
        const existingTime = new Date(existingEntry.timestamp).getTime();
        const newTime = new Date(entry.timestamp).getTime();
        
        if (newTime > existingTime) {
          uniqueEntries.set(key, entry);
        }
      } else {
        uniqueEntries.set(key, entry);
      }
    });
    
    // 将 Map 转换为数组并按时间排序
    const sorted = Array.from(uniqueEntries.values());
    sorted.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    console.log('Deduped entries:', sorted.length, 'from original:', validEntries.length);
    
    return sorted.slice(0, limit);
  } catch (error) {
    console.error('Failed to parse cueFeedbackLog from localStorage:', error);
    return [];
  }
};

// Load feedback logs from localStorage to signatureMap
const loadFeedbackFromStorage = () => {
  const signatureMap = getSignatureMap();
  
  try {
    const saved = localStorage.getItem(FEEDBACK_STORAGE_KEY);
    if (saved) {
      const parsedData = JSON.parse(saved);
      // Filter out debug entries before setting to signatureMap
      signatureMap.cueFeedbackLog = parsedData.filter((entry: any) => 
        entry && entry.cueText && entry.cueText !== "You deserve to pause."
      );
    } else {
      // Initialize with empty array if nothing in storage
      signatureMap.cueFeedbackLog = [];
    }
  } catch (error) {
    console.error('Failed to load feedback from localStorage:', error);
    signatureMap.cueFeedbackLog = [];
  }
};

// Custom event name for feedback updates
const CUE_FEEDBACK_UPDATED_EVENT = 'cue-feedback-updated';

export const emitFeedbackUpdated = () => {
  const event = new CustomEvent(CUE_FEEDBACK_UPDATED_EVENT);
  window.dispatchEvent(event);
};

// Tone details with icons
const TONE_DETAILS = {
  gentle: { icon: '🌸', description: 'Soft and nurturing approach' },
  directive: { icon: '📌', description: 'Clear and guiding direction' },
  visionary: { icon: '🔭', description: 'Forward-thinking perspective' },
  rational: { icon: '🧩', description: 'Logical, analytical reasoning' },
  motivated: { icon: '🔆', description: 'Energetic, encouraging style' },
  supportive: { icon: '🤝', description: 'Helpful, uplifting approach' },
  balanced: { icon: '⚖️', description: 'Harmonious, even-tempered style' },
  strategic: { icon: '🧭', description: 'Purposeful, planned approach' }
};

// Enhanced UI for feedback badges based on RhythmOS design spec
const FeedbackBadge = ({ feedback, isDaytime }: { feedback: string; isDaytime: boolean }) => {
  // Updated UI colors from RhythmOS UI spec with day/night mode support
  const feedbackConfig = {
    aligned: { 
      bg: isDaytime ? 'rgba(197, 216, 164, 0.2)' : 'rgba(197, 216, 164, 0.15)',
      border: isDaytime ? 'rgba(197, 216, 164, 0.5)' : 'rgba(197, 216, 164, 0.3)',
      text: isDaytime ? '#3E5931' : '#A5C77E', 
      icon: '✓', 
      label: 'Aligned' 
    },
    okay: { 
      bg: isDaytime ? 'rgba(195, 177, 225, 0.2)' : 'rgba(195, 177, 225, 0.15)',
      border: isDaytime ? 'rgba(195, 177, 225, 0.5)' : 'rgba(195, 177, 225, 0.3)',
      text: isDaytime ? '#5C4283' : '#C3B1E1', 
      icon: '≈', 
      label: 'Neutral' 
    },
    notMe: { 
      bg: isDaytime ? 'rgba(174, 198, 207, 0.2)' : 'rgba(174, 198, 207, 0.15)',
      border: isDaytime ? 'rgba(174, 198, 207, 0.5)' : 'rgba(174, 198, 207, 0.3)',
      text: isDaytime ? '#3B5164' : '#AEC6CF', 
      icon: '×', 
      label: 'Not me' 
    }
  };
  
  const config = feedbackConfig[feedback as keyof typeof feedbackConfig] || {
    bg: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.1)',
    border: isDaytime ? 'rgba(0, 0, 0, 0.1)' : 'rgba(255, 255, 255, 0.15)',
    text: isDaytime ? '#666666' : '#AAAAAA', 
    icon: '·',
    label: feedback
  };
  
  return (
    <span 
      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium transition-all duration-200"
      style={{ 
        backgroundColor: config.bg, 
        color: config.text,
        border: `1px solid ${config.border}`
      }}
    >
      <span>{config.icon}</span>
      {config.label}
    </span>
  );
};

// Enhanced persona avatar with RhythmOS design spec colors
const PersonaAvatar = ({ persona, isDaytime }: { persona: string; isDaytime: boolean }) => {
  // New persona colors from the RhythmOS UI spec
  const personaDetails = {
    rhea: {
      color: '#F5CFCF',
      gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
      nightGradient: 'linear-gradient(135deg, #5D4E47, #694647)',
      icon: '💗',
    },
    aurelia: {
      color: '#D8A7CA',
      gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
      nightGradient: 'linear-gradient(135deg, #5D4E47, #5A4555)',
      icon: '🧠',
    },
    lucis: {
      color: '#A4D8C5',
      gradient: 'linear-gradient(135deg, #E8F5C7, #A4D8C5)',
      nightGradient: 'linear-gradient(135deg, #495D44, #456056)',
      icon: '🌱',
    },
    niveus: {
      color: '#C7C7C7',
      gradient: 'linear-gradient(135deg, #E8E8E8, #C7C7C7)',
      nightGradient: 'linear-gradient(135deg, #4A4A4A, #555555)',
      icon: '📊',
    },
    caelum: {
      color: '#4B6587',
      gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
      nightGradient: 'linear-gradient(135deg, #5D4E47, #2A3A4F)',
      icon: '💠',
    },
    default: {
      color: '#C3B1E1',
      gradient: 'linear-gradient(135deg, #F5E8C7, #C3B1E1)',
      nightGradient: 'linear-gradient(135deg, #4A3A60, #544A70)',
      icon: '👤',
    }
  };
  
  // Safely handle potentially empty persona
  const personaKey = persona ? persona.toLowerCase() : 'default';
  const personaInfo = personaDetails[personaKey as keyof typeof personaDetails] || personaDetails.default;
  const initial = persona ? persona.charAt(0).toUpperCase() : '?';
  
  return (
    <div 
      className="w-10 h-10 rounded-full flex items-center justify-center text-lg font-medium transition-all duration-200"
      style={{ 
        background: isDaytime ? personaInfo.gradient : personaInfo.nightGradient,
        boxShadow: isDaytime
          ? '0 2px 6px rgba(0, 0, 0, 0.1)'
          : '0 2px 8px rgba(0, 0, 0, 0.2)'
      }}
    >
      {personaInfo.icon || initial}
    </div>
  );
};

const SignatureReplayPanel: React.FC<SignatureReplayPanelProps> = ({ isDaytime = true }) => {
  const [feedbacks, setFeedbacks] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAnimated, setIsAnimated] = useState(false);

  // 根据日夜模式调整颜色
  const baseTextColor = isDaytime ? '#333333' : '#E0E0E0';
  const secondaryTextColor = isDaytime ? '#666666' : '#AAAAAA';
  const tertiaryTextColor = isDaytime ? '#999999' : '#777777';
  const bgColor = isDaytime 
    ? 'rgba(255, 255, 255, 0.7)'
    : 'rgba(40, 38, 46, 0.7)';
  const cardBgColor = isDaytime
    ? 'rgba(255, 255, 255, 0.5)'
    : 'rgba(255, 255, 255, 0.03)';
  const highlightedCardBgColor = isDaytime
    ? 'rgba(195, 177, 225, 0.1)'
    : 'rgba(195, 177, 225, 0.08)';
  const borderColor = isDaytime
    ? 'rgba(0, 0, 0, 0.05)'
    : 'rgba(255, 255, 255, 0.05)';
  const badgeBgColor = isDaytime
    ? 'rgba(103, 58, 183, 0.1)'
    : 'rgba(103, 58, 183, 0.2)';
  const emptyStateBg = isDaytime
    ? 'rgba(0, 0, 0, 0.02)'
    : 'rgba(255, 255, 255, 0.02)';
  const emptyStateBorder = isDaytime
    ? '1px dashed rgba(0, 0, 0, 0.1)'
    : '1px dashed rgba(255, 255, 255, 0.1)';
  const iconBgColor = isDaytime
    ? 'rgba(0, 0, 0, 0.03)'
    : 'rgba(255, 255, 255, 0.05)';
  const toneBgColor = isDaytime
    ? 'rgba(0, 0, 0, 0.04)'
    : 'rgba(255, 255, 255, 0.07)';

  useEffect(() => {
    // Animation effect
    const animationTimer = setTimeout(() => {
      setIsAnimated(true);
    }, 300);
    
    // Initial load from localStorage to signatureMap
    loadFeedbackFromStorage();
    
    const updateFeedbacks = () => {
      // 从 localStorage 获取最新数据，确保显示所有反馈类型
      const recentFeedbacks = getRecentFeedbacks();
      console.log('Recent feedbacks:', recentFeedbacks);
      setFeedbacks(recentFeedbacks);
      setIsLoading(false);
    };

    // Listen for feedback updates
    window.addEventListener(CUE_FEEDBACK_UPDATED_EVENT, updateFeedbacks);
    
    // Listen for signatureMapUpdated event
    const handleSignatureMapUpdate = (e: CustomEvent) => {
      updateFeedbacks();
    };
    window.addEventListener('signatureMapUpdated', handleSignatureMapUpdate as EventListener);
    
    // Initial update
    updateFeedbacks();
    
    // Periodic refresh to catch external changes
    const intervalId = setInterval(updateFeedbacks, 1000);
    
    return () => {
      window.removeEventListener(CUE_FEEDBACK_UPDATED_EVENT, updateFeedbacks);
      window.removeEventListener('signatureMapUpdated', handleSignatureMapUpdate as EventListener);
      clearInterval(intervalId);
      clearTimeout(animationTimer);
    };
  }, []);

  if (isLoading) {
    return (
      <div 
        className="rounded-xl overflow-hidden"
        style={{ 
          backgroundColor: bgColor,
          backdropFilter: 'blur(8px)',
          border: `1px solid ${borderColor}`,
          boxShadow: isDaytime
            ? '0 4px 20px rgba(0, 0, 0, 0.07)'
            : '0 4px 20px rgba(0, 0, 0, 0.2)'
        }}
      >
        <div className="animate-pulse p-6">
          <div className="flex items-center gap-3 mb-4">
            <div 
              className="w-10 h-10 rounded-xl" 
              style={{ 
                backgroundColor: isDaytime
                  ? 'rgba(0, 0, 0, 0.06)'
                  : 'rgba(255, 255, 255, 0.1)'
              }}
            />
            <div>
              <div 
                className="h-5 rounded w-1/3 mb-2"
                style={{ 
                  backgroundColor: isDaytime
                    ? 'rgba(0, 0, 0, 0.06)'
                    : 'rgba(255, 255, 255, 0.1)'
                }}
              />
              <div 
                className="h-4 rounded w-1/2"
                style={{ 
                  backgroundColor: isDaytime
                    ? 'rgba(0, 0, 0, 0.04)'
                    : 'rgba(255, 255, 255, 0.07)'
                }}
              />
            </div>
          </div>
          <div className="space-y-4">
            <div 
              className="h-20 rounded-xl"
              style={{ 
                backgroundColor: isDaytime
                  ? 'rgba(0, 0, 0, 0.04)'
                  : 'rgba(255, 255, 255, 0.07)'
              }}
            />
            <div 
              className="h-20 rounded-xl"
              style={{ 
                backgroundColor: isDaytime
                  ? 'rgba(0, 0, 0, 0.03)'
                  : 'rgba(255, 255, 255, 0.05)'
              }}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`rounded-xl overflow-hidden transform transition-all duration-700 ${
        isAnimated ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0'
      }`}
      style={{ 
        backgroundColor: bgColor,
        backdropFilter: 'blur(10px)',
        border: `1px solid ${borderColor}`,
        boxShadow: isDaytime
          ? '0 8px 30px rgba(0, 0, 0, 0.07), inset 0 0 15px rgba(0, 0, 0, 0.02)'
          : '0 8px 30px rgba(0, 0, 0, 0.2), inset 0 0 15px rgba(255, 255, 255, 0.01)'
      }}
    >
      <div 
        className="px-6 py-4 border-b"
        style={{ borderColor: borderColor }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div 
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: iconBgColor }}
            >
              <span className="text-lg">📓</span>
            </div>
            <div>
              <h3 
                className="text-lg font-semibold"
                style={{ color: baseTextColor }}
              >
                Recent Feedback
              </h3>
              <p 
                className="text-sm"
                style={{ color: secondaryTextColor }}
              >
                Your signature response history
              </p>
            </div>
          </div>
          <div 
            className="px-3 py-1 rounded-full text-xs"
            style={{ 
              backgroundColor: badgeBgColor,
              color: secondaryTextColor
            }}
          >
            Last {feedbacks.length} entries
          </div>
        </div>
      </div>
      
      <div className="p-6">
        {feedbacks.length === 0 ? (
          <div 
            className="flex flex-col items-center justify-center py-10 text-center rounded-xl"
            style={{ 
              backgroundColor: emptyStateBg,
              border: emptyStateBorder
            }}
          >
            <div 
              className="w-16 h-16 rounded-full flex items-center justify-center mb-4"
              style={{ 
                background: isDaytime
                  ? 'linear-gradient(135deg, #C3B1E1, #AEC6CF)'
                  : 'linear-gradient(135deg, #483D61, #3B5164)',
                boxShadow: isDaytime
                  ? '0 4px 15px rgba(0, 0, 0, 0.1)'
                  : '0 4px 15px rgba(0, 0, 0, 0.3)'
              }}
            >
              <span className="text-2xl">💭</span>
            </div>
            <h4 
              className="text-base font-medium mb-2"
              style={{ color: baseTextColor }}
            >
              No feedback yet
            </h4>
            <p 
              className="text-sm max-w-xs"
              style={{ color: secondaryTextColor }}
            >
              Your response history to rhythm cues will appear here as you interact with them
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {feedbacks.map((entry, index) => {
              // Get tone type to apply appropriate styling
              const toneType = entry.tone?.toLowerCase() || 'neutral';
              const toneInfo = TONE_DETAILS[toneType as keyof typeof TONE_DETAILS] || { icon: '🔹' };
              const isFirst = index === 0;
              
              return (
                <div
                  key={entry.uniqueKey || `${entry.cueId}-${entry.timestamp}`}
                  className="rounded-xl transition-all duration-300 hover:transform hover:scale-[1.01] hover:shadow-lg"
                  style={{ 
                    border: `1px solid ${borderColor}`,
                    backgroundColor: isFirst ? highlightedCardBgColor : cardBgColor,
                    boxShadow: isFirst 
                      ? isDaytime
                        ? '0 4px 12px rgba(0, 0, 0, 0.05)'
                        : '0 4px 12px rgba(0, 0, 0, 0.15)'
                      : isDaytime
                        ? '0 2px 6px rgba(0, 0, 0, 0.02)'
                        : '0 2px 6px rgba(0, 0, 0, 0.1)',
                    transform: isFirst ? 'translateY(0)' : 'translateY(0)',
                    opacity: isFirst ? 1 : 0.9
                  }}
                >
                  <div className="p-4">
                    <div className="flex items-start gap-3">
                      <PersonaAvatar persona={entry.persona} isDaytime={isDaytime} />
                      <div className="flex-1 min-w-0">
                        <p 
                          className="text-base font-medium mb-3 leading-relaxed"
                          style={{ color: baseTextColor }}
                        >
                          "{entry.cueText}"
                        </p>
                        <div className="flex flex-wrap items-center gap-2">
                          <FeedbackBadge feedback={entry.feedback} isDaytime={isDaytime} />
                          
                          <div 
                            className="px-2.5 py-1 rounded-full text-xs font-medium flex items-center gap-1"
                            style={{ 
                              backgroundColor: toneBgColor,
                              color: isDaytime ? '#555555' : '#BBBBBB'
                            }}
                          >
                            <span>{toneInfo.icon}</span>
                            <span className="capitalize">{entry.tone} tone</span>
                          </div>
                          
                          <span 
                            className="text-xs px-2"
                            style={{ color: tertiaryTextColor }}
                          >
                            {new Date(entry.timestamp).toLocaleTimeString([], { 
                              hour: 'numeric', 
                              minute: '2-digit',
                              hour12: true 
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default SignatureReplayPanel;