// /src/components/DevMenu.tsx
// 开发环境快捷菜单

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const DevMenu: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  // 只在开发环境显示
  if (import.meta.env.PROD) {
    return null;
  }

  return (
    <>
      {/* 浮动按钮 */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-4 right-4 z-50 bg-purple-600 text-white rounded-full w-12 h-12 flex items-center justify-center shadow-lg hover:bg-purple-700 transition-colors"
        title="Dev Menu"
      >
        🛠️
      </button>

      {/* 菜单面板 */}
      {isOpen && (
        <div className="fixed bottom-20 right-4 z-50 bg-white rounded-lg shadow-xl p-4 w-64 border border-gray-200">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Dev Tools</h3>
          
          <div className="space-y-2">
            <button
              onClick={() => {
                navigate('/test-openai');
                setIsOpen(false);
              }}
              className="w-full text-left px-3 py-2 text-sm bg-gray-50 hover:bg-gray-100 rounded transition-colors"
            >
              🤖 Test OpenAI Integration
            </button>
            
            <button
              onClick={() => {
                navigate('/');
                setIsOpen(false);
              }}
              className="w-full text-left px-3 py-2 text-sm bg-gray-50 hover:bg-gray-100 rounded transition-colors"
            >
              🏠 Home (Rhythm Checkin)
            </button>
            
            <button
              onClick={() => {
                navigate('/onboarding/step1');
                setIsOpen(false);
              }}
              className="w-full text-left px-3 py-2 text-sm bg-gray-50 hover:bg-gray-100 rounded transition-colors"
            >
              👋 Onboarding Flow
            </button>
            
            <hr className="my-2" />
            
            <button
              onClick={() => {
                localStorage.clear();
                window.location.reload();
              }}
              className="w-full text-left px-3 py-2 text-sm bg-red-50 hover:bg-red-100 text-red-600 rounded transition-colors"
            >
              🗑️ Clear Local Storage
            </button>
            
            <button
              onClick={() => {
                const useGPT = localStorage.getItem('useSignatureGPT') === 'true';
                localStorage.setItem('useSignatureGPT', (!useGPT).toString());
                alert(`GPT Mode: ${!useGPT ? 'ON' : 'OFF'}`);
              }}
              className="w-full text-left px-3 py-2 text-sm bg-blue-50 hover:bg-blue-100 rounded transition-colors"
            >
              🔄 Toggle GPT Mode
            </button>
          </div>
          
          <div className="mt-3 pt-3 border-t border-gray-200">
            <p className="text-xs text-gray-500">
              API Key: {import.meta.env.VITE_OPENAI_API_KEY ? '✅' : '❌'}
            </p>
          </div>
        </div>
      )}
    </>
  );
};

export default DevMenu;