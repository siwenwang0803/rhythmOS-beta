// /components/BadgeGallery.tsx - 扩展版本，包含微任务badge

import React, { useEffect, useState } from 'react';

interface Badge {
  id: string;
  label: string;
  icon: string;
  unlocked: boolean;
  category: 'general' | 'microtask' | 'challenge' | 'streak';
  description?: string;
}

const BadgeGallery: React.FC = () => {
  const [badges, setBadges] = useState<Badge[]>([]);

  // 定义所有可能的badges
  const allBadges: Badge[] = [
    // 原有badges
    { id: 'first-feedback', label: 'First Feedback', icon: '🌱', unlocked: false, category: 'general', description: 'Submitted your first cue feedback' },
    { id: 'rhea-5', label: 'Rhea ×5', icon: '💗', unlocked: false, category: 'general', description: 'Engaged with Rhea persona 5 times' },
    { id: 'caelum-5', label: 'Caelum ×5', icon: '💠', unlocked: false, category: 'general', description: 'Engaged with Caelum persona 5 times' },
    { id: 'daily-streak-3', label: '3-Day Streak', icon: '🔥', unlocked: false, category: 'streak', description: 'Maintained a 3-day activity streak' },
    { id: 'growth-mode', label: 'Growth Mode', icon: '📈', unlocked: false, category: 'general', description: 'Entered sustained growth mode' },
    { id: 'explorer', label: 'Explorer', icon: '🧭', unlocked: false, category: 'general', description: 'Explored different features' },
    
    // 新的微任务badges
    { id: 'microtask-starter', label: 'First Steps', icon: '👟', unlocked: false, category: 'microtask', description: 'Completed your first microtask' },
    { id: 'microtask-momentum', label: 'Momentum Builder', icon: '⚡', unlocked: false, category: 'microtask', description: 'Completed 10 microtasks' },
    { id: 'microtask-master', label: 'Micro Master', icon: '🎯', unlocked: false, category: 'microtask', description: 'Completed 50 microtasks' },
    { id: 'microtask-legend', label: 'Micro Legend', icon: '🏆', unlocked: false, category: 'microtask', description: 'Completed 100 microtasks' },
    
    // 连续天数badges
    { id: 'streak-3', label: 'Streak Starter', icon: '🔥', unlocked: false, category: 'streak', description: '3-day microtask streak' },
    { id: 'streak-7', label: 'Week Warrior', icon: '⚔️', unlocked: false, category: 'streak', description: '7-day microtask streak' },
    { id: 'streak-21', label: 'Habit Master', icon: '🧘', unlocked: false, category: 'streak', description: '21-day microtask streak' },
    { id: 'streak-30', label: 'Consistency King', icon: '👑', unlocked: false, category: 'streak', description: '30-day microtask streak' },
    
    // 特殊achievement badges
    { id: 'weekly-warrior', label: 'Weekly Warrior', icon: '📅', unlocked: false, category: 'microtask', description: '15+ microtasks in one week' },
    { id: 'daily-champion', label: 'Daily Champion', icon: '🌟', unlocked: false, category: 'microtask', description: '5+ microtasks in one day' },
    { id: 'balanced-growth', label: 'Balanced Growth', icon: '⚖️', unlocked: false, category: 'general', description: 'Balanced challenges and microtasks' }
  ];

  // 检查解锁状态
  const checkUnlockStatus = () => {
    const unlockedBadges = JSON.parse(localStorage.getItem('unlockedBadges') || '[]');
    
    // 读取微任务统计数据
    const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
    const microtaskEntries = rhythmScoreLog.filter((entry: any) => entry.actionType === 'microtask_complete');
    
    // 计算统计
    const today = new Date().toISOString().split('T')[0];
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    const weekStartStr = weekStart.toISOString().split('T')[0];
    
    const stats = {
      total: microtaskEntries.length,
      today: microtaskEntries.filter((entry: any) => entry.date === today).length,
      thisWeek: microtaskEntries.filter((entry: any) => entry.date >= weekStartStr).length
    };

    // 计算连续天数
    const dateGroups: Record<string, number> = {};
    microtaskEntries.forEach((entry: any) => {
      const date = entry.date || new Date(entry.timestamp).toISOString().split('T')[0];
      dateGroups[date] = (dateGroups[date] || 0) + 1;
    });

    let currentStreak = 0;
    let streakDate = today;
    while (dateGroups[streakDate]) {
      currentStreak++;
      const prevDate = new Date(streakDate);
      prevDate.setDate(prevDate.getDate() - 1);
      streakDate = prevDate.toISOString().split('T')[0];
    }

    // 更新badges解锁状态
    const updatedBadges = allBadges.map(badge => {
      let shouldUnlock = unlockedBadges.includes(badge.id);
      
      // 自动检查微任务相关badges
      if (!shouldUnlock && badge.category === 'microtask') {
        switch (badge.id) {
          case 'microtask-starter': shouldUnlock = stats.total >= 1; break;
          case 'microtask-momentum': shouldUnlock = stats.total >= 10; break;
          case 'microtask-master': shouldUnlock = stats.total >= 50; break;
          case 'microtask-legend': shouldUnlock = stats.total >= 100; break;
          case 'weekly-warrior': shouldUnlock = stats.thisWeek >= 15; break;
          case 'daily-champion': shouldUnlock = stats.today >= 5; break;
        }
      }
      
      // 检查连续天数badges
      if (!shouldUnlock && badge.category === 'streak') {
        switch (badge.id) {
          case 'streak-3': shouldUnlock = currentStreak >= 3; break;
          case 'streak-7': shouldUnlock = currentStreak >= 7; break;
          case 'streak-21': shouldUnlock = currentStreak >= 21; break;
          case 'streak-30': shouldUnlock = currentStreak >= 30; break;
        }
      }
      
      return { ...badge, unlocked: shouldUnlock };
    });

    setBadges(updatedBadges);
  };

  useEffect(() => {
    checkUnlockStatus();
    
    // 监听解锁事件
    const handleAchievement = () => checkUnlockStatus();
    window.addEventListener('achievement-unlocked', handleAchievement);
    window.addEventListener('storage', handleAchievement);
    
    return () => {
      window.removeEventListener('achievement-unlocked', handleAchievement);
      window.removeEventListener('storage', handleAchievement);
    };
  }, []);

  // 按类别分组
  const categorizedBadges = {
    general: badges.filter(b => b.category === 'general'),
    microtask: badges.filter(b => b.category === 'microtask'),
    streak: badges.filter(b => b.category === 'streak'),
    challenge: badges.filter(b => b.category === 'challenge')
  };

  const CategorySection: React.FC<{ title: string; badges: Badge[]; emoji: string }> = 
    ({ title, badges, emoji }) => (
      <div className="mb-6">
        <h3 className="flex items-center gap-2 text-lg font-semibold mb-3 text-[--text-base]">
          <span>{emoji}</span>
          <span>{title}</span>
          <span className="text-sm font-normal text-gray-500">
            ({badges.filter(b => b.unlocked).length}/{badges.length})
          </span>
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {badges.map((badge) => (
            <div
              key={badge.id}
              className={`rounded-xl p-4 flex flex-col items-center justify-center border transition-all duration-300 cursor-pointer group ${
                badge.unlocked 
                  ? 'bg-white shadow-sm hover:shadow-md' 
                  : 'bg-gray-50 opacity-60 hover:opacity-70'
              }`}
              title={badge.description}
            >
              <div className={`text-3xl mb-2 transition-transform duration-200 group-hover:scale-110 ${
                badge.unlocked ? '' : 'grayscale'
              }`}>
                {badge.unlocked ? badge.icon : '🔒'}
              </div>
              <div className="text-sm text-center text-[--text-base] font-medium">
                {badge.label}
              </div>
              {badge.unlocked && (
                <div className="w-2 h-2 bg-green-500 rounded-full mt-1 animate-pulse"></div>
              )}
            </div>
          ))}
        </div>
      </div>
    );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-[--text-base]">Badge Gallery</h2>
        <div className="text-sm text-gray-500">
          {badges.filter(b => b.unlocked).length} / {badges.length} unlocked
        </div>
      </div>
      
      <CategorySection 
        title="Micro-momentum" 
        badges={categorizedBadges.microtask} 
        emoji="⚡" 
      />
      <CategorySection 
        title="Streaks & Consistency" 
        badges={categorizedBadges.streak} 
        emoji="🔥" 
      />
      <CategorySection 
        title="General Growth" 
        badges={categorizedBadges.general} 
        emoji="🌱" 
      />
      {categorizedBadges.challenge.length > 0 && (
        <CategorySection 
          title="Challenges" 
          badges={categorizedBadges.challenge} 
          emoji="🎯" 
        />
      )}
    </div>
  );
};

export default BadgeGallery;