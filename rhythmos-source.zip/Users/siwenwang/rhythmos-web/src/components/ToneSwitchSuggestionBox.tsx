import React from 'react';

export const getRecentTonePerformance = () => {
  const log = JSON.parse(localStorage.getItem('signatureFeedbackLog') || '[]');
  const recent = log.slice(-10); // last 10 feedbacks

  const toneMap: Record<string, { aligned: number; wrong: number }> = {};

  recent.forEach((entry: any) => {
    const { tone, feedback } = entry;
    if (!tone) return;
    if (!toneMap[tone]) {
      toneMap[tone] = { aligned: 0, wrong: 0 };
    }
    if (feedback === 'aligned') toneMap[tone].aligned++;
    if (feedback === 'wrong' || feedback === 'not-me') toneMap[tone].wrong++;
  });

  const sorted = Object.entries(toneMap).sort(
    (a, b) => b[1].aligned - a[1].aligned
  );

  const top = sorted[0];
  return top ? { tone: top[0], ...top[1] } : null;
};

export const ToneSwitchSuggestionBox: React.FC = () => {
  const bestTone = getRecentTonePerformance();
  const preferred = localStorage.getItem('preferredTone');

  const today = new Date().toISOString().split('T')[0];
  const lastHint = localStorage.getItem('toneHintShown');

  if (!bestTone || bestTone.tone === preferred || lastHint === today) return null;

  const handleSwitch = () => {
    localStorage.setItem('preferredTone', bestTone.tone);
    localStorage.setItem('toneHintShown', today);
    window.location.reload();
  };

  return (
    <div className="mt-6 border p-4 rounded-xl bg-yellow-50 text-sm text-yellow-800">
      <p>🧠 Based on your recent feedback, you often respond best to <strong>{bestTone.tone}</strong> tone.</p>
      <button
        onClick={handleSwitch}
        className="mt-2 px-3 py-1 rounded bg-blue-600 text-white text-sm"
      >
        ✅ Switch to {bestTone.tone} tone now
      </button>
    </div>
  );
};

