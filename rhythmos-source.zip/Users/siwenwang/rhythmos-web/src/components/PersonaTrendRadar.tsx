import React from 'react'
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from 'recharts'
import { getPersonaBiasSummary } from '../CREPersonaBiasMap'

const PersonaTrendRadar: React.FC = () => {
  const { personaUsage } = getPersonaBiasSummary()
  const data = Object.entries(personaUsage).map(([persona, value]) => ({
    persona,
    value
  }))

  if (data.length === 0) return null

  return (
    <div className="mt-8">
      <h3 className="text-md font-semibold mb-2">🧭 Persona Style Radar</h3>
      <ResponsiveContainer width="100%" height={300}>
        <RadarChart outerRadius={90} data={data}>
          <PolarGrid />
          <PolarAngleAxis dataKey="persona" />
          <PolarRadiusAxis angle={30} domain={[0, Math.max(...data.map(d => d.value), 5)]} />
          <Radar name="Usage" dataKey="value" stroke="#4f46e5" fill="#6366f1" fillOpacity={0.6} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  )
}

export default PersonaTrendRadar