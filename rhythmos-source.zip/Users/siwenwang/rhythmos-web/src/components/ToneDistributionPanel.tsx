import React, { useState, useEffect } from 'react';
import { getToneScoreMapByDays, deduplicateToneLog } from '../utils/toneScoreUtils';
import ToneBarChart from './ToneBarChart';

interface ToneScore {
  [key: string]: number;
}

/**
 * 完整的音调分布面板组件 - 使用条形图替代雷达图
 */
const ToneDistributionPanel: React.FC = () => {
  const [toneScores, setToneScores] = useState<ToneScore>({});
  const [isLoading, setIsLoading] = useState<boolean>(true);
  
  // 使用 effect 处理数据加载和处理
  useEffect(() => {
    // 页面加载时执行一次去重操作 - 确保数据准确
    deduplicateToneLog();
    
    // 获取过去 7 天的所有 tone 分数
    const updateScores = () => {
      setIsLoading(true);
      try {
        const scores = getToneScoreMapByDays(7);
        console.log('📊 ToneDistributionPanel - full toneScoreMap data:', scores);
        
        // 无条件保存所有 tone 数据
        setToneScores(scores);
      } catch (error) {
        console.error('Error updating tone scores:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    // 初始更新
    updateScores();
    
    // 处理反馈更新事件
    const handleFeedbackUpdated = () => {
      console.log('📊 Feedback updated event received, refreshing all tone data...');
      updateScores();
    };
    
    // 处理存储变化
    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === 'toneLog' || event.key === 'cueFeedbackLog') {
        console.log('📊 Storage changed, updating tone data');
        updateScores();
      }
    };
    
    // 注册事件监听器
    window.addEventListener('cue-feedback-updated', handleFeedbackUpdated);
    window.addEventListener('tone-radar-update', handleFeedbackUpdated);
    window.addEventListener('storage', handleStorageChange);
    
    // 定期刷新，确保数据最新
    const refreshInterval = setInterval(updateScores, 60000);
    
    // 清理函数
    return () => {
      window.removeEventListener('cue-feedback-updated', handleFeedbackUpdated);
      window.removeEventListener('tone-radar-update', handleFeedbackUpdated);
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(refreshInterval);
    };
  }, []);
  
  // 计算每种 tone 的显示名称
  const getToneDisplayName = (toneKey: string): string => {
    const toneNames: Record<string, string> = {
      'gentle': 'Gentle',
      'motivated': 'Motivated',
      'directive': 'Directive',
      'rational': 'Rational',
      'visionary': 'Visionary'
    };
    return toneNames[toneKey] || toneKey.charAt(0).toUpperCase() + toneKey.slice(1);
  };
  
  // 获取 tone 颜色
  const getToneColor = (tone: string): string => {
    const colorMap: Record<string, string> = {
      'gentle': '#4F8A8B',
      'motivated': '#E16036',
      'directive': '#5D5FEF',
      'rational': '#9333EA',
      'visionary': '#F59E0B',
      'default': '#64748B'
    };
    
    return colorMap[tone] || colorMap.default;
  };
  
  // 计算总分数
  const totalScore = Object.values(toneScores).reduce((sum, score) => sum + score, 0);
  
  return (
    <div className="bg-white rounded-lg shadow-sm border p-5">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold">Tone Distribution</h3>
      </div>
      
      <p className="text-sm text-gray-600 mb-4">
        Based on your feedback in the last 7 days. Aligned = 1.0, Okay = 0.5
      </p>
      
      {isLoading ? (
        <div className="py-8 text-center text-gray-500 animate-pulse">
          <div className="inline-block w-6 h-6 border-2 border-t-blue-500 border-gray-200 rounded-full animate-spin mr-2"></div>
          Loading tone data...
        </div>
      ) : Object.keys(toneScores).length === 0 ? (
        <div className="py-12 text-center text-gray-500 bg-gray-50 rounded-lg border border-dashed">
          <p className="mb-2 text-lg">No tone feedback available yet</p>
          <p className="text-sm">Try giving feedback to different tone types</p>
        </div>
      ) : (
        <>
          {/* Tone 卡片区域 */}
          <div className="mb-6">
            <h4 className="font-medium mb-3">All Active Tones:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {Object.entries(toneScores).map(([tone, score]) => (
                <div 
                  key={tone}
                  className="rounded-lg border shadow-sm p-3 bg-white hover:shadow-md transition-shadow"
                  style={{ borderLeftWidth: '4px', borderLeftColor: getToneColor(tone) }}
                >
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium text-gray-800">
                      {getToneDisplayName(tone)}
                    </span>
                    <span 
                      className="px-2 py-1 rounded-full text-xs font-bold"
                      style={{ backgroundColor: `${getToneColor(tone)}30`, color: getToneColor(tone) }}
                    >
                      {score.toFixed(1)}
                    </span>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2 mt-1">
                    <div 
                      className="h-2 rounded-full transition-all duration-500"
                      style={{ 
                        width: `${Math.min((score / 3) * 100, 100)}%`,
                        backgroundColor: getToneColor(tone)
                      }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* 柱状图区域 - 替代雷达图 */}
          <div className="mb-4">
            <h4 className="font-medium mb-3">Tone Distribution:</h4>
            <div className="h-64 lg:h-72 border rounded-lg shadow-sm p-2">
              <ToneBarChart data={toneScores} />
            </div>
          </div>
          
          {/* 数据总结 */}
          <div className="mt-6 pt-4 border-t border-gray-100">
            <div className="flex justify-between items-center">
              <p className="text-sm text-gray-500">
                Total Tone Score: <span className="font-bold">{totalScore.toFixed(1)}</span>
              </p>
              <p className="text-xs text-gray-400">
                Score explanation: Aligned = 1.0, Okay = 0.5
              </p>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default ToneDistributionPanel;