import React, { useEffect, useState } from 'react';
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid
} from 'recharts';

const TestChart: React.FC = () => {
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    const raw = localStorage.getItem('growthBeliefLog');
    if (!raw) return;
    const parsed = JSON.parse(raw)
      .filter((e: any) => e.persona === 'rhea') // ✅ 确保有数据的 persona
      .sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
      .map((e: any) => ({
        date: e.timestamp.split('T')[0],
        score: e.score
      }));
    setData(parsed);
  }, []);

  return (
    <div style={{ padding: '32px', background: '#fff', border: '1px solid #ccc', marginTop: '20px' }}>
      <h3>Debug: Rhea Belief Trend</h3>
      {data.length < 2 ? (
        <p style={{ color: 'red' }}>⚠️ Not enough data</p>
      ) : (
        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis domain={[1, 5]} ticks={[1, 2, 3, 4, 5]} />
            <Tooltip />
            <Line type="monotone" dataKey="score" stroke="#F5CFCF" />
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  );
};

export default TestChart;
