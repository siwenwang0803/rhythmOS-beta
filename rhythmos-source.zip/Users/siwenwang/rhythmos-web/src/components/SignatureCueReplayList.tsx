// components/SignatureCueReplayList.tsx

import React, { useEffect, useState } from 'react';

interface ReplayItem {
  cue: string;
  persona: string;
  tone: string;
  trend: string;
  timestamp: string;
}

const SignatureCueReplayList: React.FC = () => {
  const [log, setLog] = useState<ReplayItem[]>([]);

  useEffect(() => {
    const raw = localStorage.getItem('signature_cue_replay_log');
    if (raw) {
      try {
        setLog(JSON.parse(raw));
      } catch (e) {
        console.error('Invalid replay log format');
      }
    }
  }, []);

  if (!log || log.length === 0) {
    return <p className="text-sm text-gray-400 italic">No signature cue history found. Try generating a CRE cue first.</p>;
  }

  return (
    <div className="space-y-4">
      {log.map((item, index) => (
        <div key={index} className="p-4 border rounded-xl bg-white shadow-sm space-y-1">
          <p className="text-sm text-gray-700"><strong>Cue:</strong> {item.cue}</p>
          <p className="text-sm text-gray-500">🧠 Persona: {item.persona} | 🎨 Tone: {item.tone} | 🌊 Trend: {item.trend}</p>
          <p className="text-xs text-gray-400 italic">🕓 {new Date(item.timestamp).toLocaleString()}</p>
        </div>
      ))}
    </div>
  );
};

export default SignatureCueReplayList;
