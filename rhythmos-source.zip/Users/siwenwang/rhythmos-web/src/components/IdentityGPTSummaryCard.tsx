// components/IdentityGPTSummaryCard.tsx

import React from 'react';
import { signatureMap } from '../SignatureMap';
import { getMostResonantTone } from '../utils/getMostResonantTone';
import { getTodayTrend } from '../utils/getTodayTrend';


const personaMap = {
  caelum: {
    label: '🔥 Bold & Decisive',
    tone: 'directive',
    quote: 'We speak in momentum.'
  },
  rhea: {
    label: '💙 Gentle & Supportive',
    tone: 'gentle',
    quote: 'We speak gently, so you can begin again.'
  },
  aurelia: {
    label: '💛 Clear & Rational',
    tone: 'balanced',
    quote: 'We reflect with clarity.'
  },
  niveus: {
    label: '🧊 Precise & Logical',
    tone: 'directive',
    quote: 'We guide with quiet precision.'
  },
  lucis: {
    label: '💚 Steady & Grounded',
    tone: 'supportive',
    quote: 'We ground you, so you can grow.'
  }
};

const toneLabels: Record<string, string> = {
  gentle: 'gentle (Rhea)',
  directive: 'directive (Caelum/Niveus)',
  rational: 'rational (Aurelia)',
  visionary: 'visionary (Lucis)',
  supportive: 'supportive (Lucis)',
  motivated: 'motivated (Caelum)',
  balanced: 'balanced (Aurelia)'
};

const IdentityGPTSummaryCard: React.FC = () => {
  const mostTone = getMostResonantTone();
  const persona = signatureMap.personaAnchor || 'rhea';
  const trend = getTodayTrend();

  const personaLabel = personaMap[persona]?.label || persona;
  const toneLabel = toneLabels[mostTone] || mostTone;
  const trendText =
    trend === 'collapsed' ? 'You are in a low rhythm state. The system suggests gentle progress.' :
    trend === 'rising' ? 'You are showing rising momentum. Now is a great time to challenge yourself.' :
    trend === 'stable' ? 'Your rhythm is stable, ideal for steady growth.' :
    'Your state is fluctuating. Flexibility and rhythm adjustment are recommended.';

  return (
    <div className="bg-purple-50 border border-purple-200 rounded p-4 text-sm text-gray-800">
      <p className="font-semibold text-purple-700 mb-1">🧠 Identity Summary</p>
      <p className="mb-1">
        Based on your recent feedback, you most frequently align with the <strong>{personaLabel}</strong> persona,
        and tend to operate in a <strong>{toneLabel}</strong> tone.
      </p>
      <p>{trendText}</p>
    </div>
  );
};

export default IdentityGPTSummaryCard;
