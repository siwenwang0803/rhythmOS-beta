import React from 'react';
import { personaThemeMap } from '../utils/personaThemeMap'; // 路径按你项目调整

type ReplayLastCueBlockProps = {
  cue: {
    cueId: string;
    cueText: string;
    persona: string;
    tone: string;
    trend: string;
    feedback: string;
  };
  persona: string;
  feedback: string;
};

const toneToPersonaMap: Record<string, keyof typeof personaThemeMap> = {
  gentle: 'rhea',
  directive: 'caelum',
  rational: 'aurelia',
  neutral: 'lucis',
  analytical: 'niveus'
};

const feedbackColorMap: Record<string, string> = {
  aligned: '#C8E6C9',
  okay: '#FFF9C4',
  not_me: '#FFCDD2',
};

const ReplayLastCueBlock: React.FC<ReplayLastCueBlockProps> = ({ cue, feedback }) => {
  const personaKey = toneToPersonaMap[cue.tone] || 'lucis';
  const persona = personaThemeMap[personaKey];
  const feedbackColor = feedbackColorMap[feedback] || '#E0E0E0';

  return (
    <div
      className="rounded-xl p-4 space-y-3 shadow-sm border"
      style={{
        background: persona.gradient,
        border: `1px solid ${persona.baseColor}80`,
        boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
      }}
    >
      <div className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center text-xl"
          style={{ backgroundColor: 'white', color: persona.textColor }}
        >
          {persona.emoji}
        </div>
        <div>
          <p className="text-sm font-medium" style={{ color: persona.textColor }}>
            {persona.label} said · <span className="font-semibold">{cue.tone}</span> tone
          </p>
          <div
            className="inline-block mt-1 px-2 py-0.5 rounded-full text-xs"
            style={{ backgroundColor: feedbackColor, color: '#333' }}
          >
            Feedback: {feedback}
          </div>
        </div>
      </div>

      <blockquote
        className="italic border-l-4 pl-4"
        style={{
          color: persona.textColor,
          borderColor: persona.baseColor + '80'
        }}
      >
        {cue.cueText}
      </blockquote>
    </div>
  );
};

export default ReplayLastCueBlock;

