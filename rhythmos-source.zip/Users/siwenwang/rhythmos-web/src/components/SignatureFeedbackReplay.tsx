import React from 'react';

export const SignatureFeedbackReplay: React.FC = () => {
  const raw = JSON.parse(localStorage.getItem('signatureFeedbackLog') || '[]');
  const sorted = raw.slice().sort((a: any, b: any) => b.timestamp - a.timestamp);

  if (sorted.length === 0) return null;

  return (
    <div className="mt-6 border p-4 rounded bg-white shadow-sm text-sm text-gray-700">
      <h3 className="text-md font-semibold mb-2">📖 Feedback History</h3>
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-gray-400 border-b">
            <th>CRE</th>
            <th>Persona</th>
            <th>Tone</th>
            <th>Feedback</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
          {sorted.map((entry: any, i: number) => (
            <tr key={i} className="border-t">
              <td className="max-w-xs truncate pr-2 text-gray-800">{entry.cue}</td>
              <td>{entry.persona}</td>
              <td>{entry.tone}</td>
              <td className="text-blue-600">{entry.feedback}</td>
              <td>{new Date(entry.timestamp).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
