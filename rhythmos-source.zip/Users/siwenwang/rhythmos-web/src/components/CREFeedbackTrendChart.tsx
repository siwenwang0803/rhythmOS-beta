import React from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

interface FeedbackEntry {
  score: number
  timestamp: number
}

const CREFeedbackTrendChart: React.FC = () => {
  const raw = localStorage.getItem('creSampleRatings')
  const ratings: FeedbackEntry[] = raw ? JSON.parse(raw) : []

  const data = ratings
    .slice()
    .sort((a, b) => a.timestamp - b.timestamp)
    .map((r) => ({
      time: new Date(r.timestamp).toLocaleDateString(),
      score: r.score
    }))

  if (data.length === 0) return null

  return (
    <div className="mt-8">
      <h3 className="text-md font-semibold mb-2">📈 CRE Feedback Trend</h3>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={data}>
          <XAxis dataKey="time" tick={{ fontSize: 10 }} />
          <YAxis domain={[0, 5]} tickCount={6} />
          <Tooltip />
          <Line type="monotone" dataKey="score" stroke="#3b82f6" strokeWidth={2} dot={{ r: 2 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

export default CREFeedbackTrendChart