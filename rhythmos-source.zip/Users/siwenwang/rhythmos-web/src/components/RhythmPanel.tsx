import React from 'react'

interface RhythmPanelProps {
  icon?: string
  title: string
  subtitle?: string
  children: React.ReactNode
  tone?: 'default' | 'blue' | 'green' | 'orange'
}

const bgMap = {
  default: 'bg-white border border-gray-200',
  blue: 'bg-blue-50 border border-blue-200',
  green: 'bg-green-50 border border-green-200',
  orange: 'bg-orange-50 border border-orange-200'
}

const RhythmPanel: React.FC<RhythmPanelProps> = ({
  icon,
  title,
  subtitle,
  children,
  tone = 'default'
}) => {
  return (
    <div className={`rounded-xl p-5 shadow-sm ${bgMap[tone]} space-y-2`}>
      <div className="flex items-center gap-2">
        {icon && <span className="text-xl">{icon}</span>}
        <h3 className="text-md font-semibold text-gray-800">{title}</h3>
      </div>
      {subtitle && <p className="text-xs text-gray-500">{subtitle}</p>}
      <div className="pt-2">{children}</div>
    </div>
  )
}

export default RhythmPanel