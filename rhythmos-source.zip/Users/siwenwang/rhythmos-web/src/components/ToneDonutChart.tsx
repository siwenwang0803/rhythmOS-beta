import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { getToneScoreMapByDays } from '../utils/writeToneLog';

interface ToneDonutChartProps {
  isDaytime?: boolean;
}

const toneColors: Record<string, string> = {
  gentle: '#60a5fa',
  supportive: '#22c55e',
  balanced: '#facc15',
  motivated: '#fb923c',
  directive: '#ef4444',
  rational: '#8b5cf6',
  visionary: '#14b8a6'
};

const ToneDonutChart: React.FC<ToneDonutChartProps> = ({ isDaytime = true }) => {
  const scoreMap = getToneScoreMapByDays(3);
  const total = Object.values(scoreMap).reduce((a, b) => a + b, 0);
  const data = Object.entries(scoreMap).map(([tone, value]) => ({
    name: tone,
    value,
    percent: ((value / total) * 100).toFixed(1)
  }));

  // Sort by value to get top tone
  const top = data.sort((a, b) => Number(b.percent) - Number(a.percent))[0] || { name: '', percent: '0.0' };

  // Define text colors based on day/night mode
  const textColor = isDaytime ? '#333333' : '#E0E0E0';
  const mutedTextColor = isDaytime ? '#777777' : '#AAAAAA';

  return (
    <div className="w-full mx-auto flex flex-col items-center justify-center">
      {/* Fixed height wrapper to ensure chart renders fully */}
      <div style={{ width: '100%', height: '220px', position: 'relative' }}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
            <Pie
              data={data}
              innerRadius={60}
              outerRadius={80}
              paddingAngle={2}
              dataKey="value"
              startAngle={90}
              endAngle={-270}
              // These settings are important for proper rendering
              animationBegin={0}
              animationDuration={800}
              animationEasing="ease-out"
              cx="50%"
              cy="50%"
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={toneColors[entry.name] || '#cccccc'} 
                  stroke="none"
                />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        
        {/* Central text - positioned absolute to appear inside donut */}
        {top && top.name && (
          <div 
            style={{ 
              position: 'absolute', 
              top: '50%', 
              left: '50%', 
              transform: 'translate(-50%, -50%)',
              textAlign: 'center',
              width: '100px' 
            }}
          >
            <p 
              style={{ 
                fontSize: '12px', 
                margin: '0 0 4px 0',
                color: mutedTextColor
              }}
            >
              Top Tone
            </p>
            <p 
              style={{ 
                fontSize: '16px', 
                fontWeight: 600, 
                margin: 0,
                color: textColor
              }}
            >
              {top.percent}% 
            </p>
            <p 
              style={{ 
                fontSize: '14px', 
                fontWeight: 500, 
                margin: 0,
                color: toneColors[top.name] || textColor,
                textTransform: 'capitalize'
              }}
            >
              {top.name}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ToneDonutChart;
