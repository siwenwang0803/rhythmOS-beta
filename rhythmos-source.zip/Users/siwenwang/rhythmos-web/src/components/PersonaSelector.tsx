import React, { useEffect, useState } from 'react';
import { cn } from '../utils/cn';

// Define UI spec colors and styles
const PERSONAS = {
  rhea: {
    name: 'Rhea',
    description: 'Gentle & supportive',
    fontStyle: 'Nunito, sans-serif',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    color: '#F5CFCF',
    icon: '💗'
  },
  aurelia: {
    name: 'Aurelia',
    description: 'Balanced & clear',
    fontStyle: 'Inter, sans-serif',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    color: '#D8A7CA',
    icon: '🧠'
  },
  lucis: {
    name: 'Lucis',
    description: 'Visionary & steady',
    fontStyle: 'Inter, sans-serif',
    gradient: 'linear-gradient(135deg, #E8F5C7, #A4D8C5)',
    color: '#A4D8C5',
    icon: '🌱'
  },
  niveus: {
    name: 'Niveus',
    description: 'Structured & direct',
    fontStyle: 'Inter, sans-serif',
    gradient: 'linear-gradient(135deg, #E8E8E8, #C7C7C7)',
    color: '#C7C7C7',
    icon: '📊'
  },
  caelum: {
    name: 'Caelum',
    description: 'Bold & energetic',
    fontStyle: 'Inter, sans-serif',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    color: '#4B6587',
    icon: '💠'
  }
};

// Map personas to tones (preserve existing mapping)
const personaToTone: Record<string, string> = {
  rhea: 'gentle',
  aurelia: 'rational',
  lucis: 'visionary',
  niveus: 'directive',
  caelum: 'motivated'
};

// Reverse mapping from tone to persona for easier lookup
const toneToPersona: Record<string, string> = {
  gentle: 'rhea',
  rational: 'aurelia',
  visionary: 'lucis',
  directive: 'niveus',
  motivated: 'caelum'
};

const PersonaSelector: React.FC = () => {
  const [selected, setSelected] = useState<string | null>(null);
  const [current, setCurrent] = useState<string>('auto');
  const [showToast, setShowToast] = useState(false);

  useEffect(() => {
    // First check if there's a persona override
    const storedPersona = localStorage.getItem('creStyleOverride');
    
    // If no override, check for preferred tone and map to persona
    if (!storedPersona || storedPersona === 'auto') {
      const preferredTone = localStorage.getItem('preferredTone');
      if (preferredTone && toneToPersona[preferredTone]) {
        // Set current to the persona that matches the preferred tone
        setCurrent(toneToPersona[preferredTone]);
      } else {
        // If no preferred tone or no mapping, use auto
        setCurrent('auto');
      }
    } else {
      // If override exists, use that
      setCurrent(storedPersona);
    }
  }, []);

  const handleConfirm = () => {
    if (!selected) return;

    // Update persona override
    if (selected === 'auto') {
      localStorage.removeItem('creStyleOverride');
    } else {
      localStorage.setItem('creStyleOverride', selected);
    }

    // Always update preferred tone based on selected persona
    if (selected !== 'auto') {
      const tone = personaToTone[selected] || 'gentle';
      localStorage.setItem('preferredTone', tone);
      console.log(`[PersonaSelector] Set ${selected} -> ${tone} as preferredTone`);
    }

    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
      window.location.reload(); // Reload to apply changes
    }, 1800);
  };

  return (
    <div 
      className="rounded-xl overflow-hidden"
      style={{ 
        border: '1px solid rgba(0, 0, 0, 0.05)',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)'
      }}
    >
      <div className="px-6 py-4 border-b" style={{ borderColor: 'rgba(0, 0, 0, 0.05)' }}>
        <h2 className="font-semibold" style={{ color: '#333333' }}>Persona tone Preference</h2>
      </div>
      
      <div className="p-6 space-y-4 relative">
        <p 
          className="text-sm mb-4" 
          style={{ color: '#666666' }}
        >
          Select which persona tone resonates with you most for identity training:
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Object.entries(PERSONAS).map(([id, persona]) => {
            const isSelected = selected === id;
            const isCurrent = current === id;
            const tone = personaToTone[id];
            
            return (
              <button
                key={id}
                onClick={() => setSelected(id)}
                className="p-4 rounded-xl transition-all duration-300"
                style={{ 
                  background: isSelected ? persona.gradient : 'rgba(255, 255, 255, 0.7)',
                  border: `1px solid ${isSelected ? 'transparent' : 'rgba(0, 0, 0, 0.05)'}`,
                  boxShadow: isSelected 
                    ? '0 6px 16px rgba(0, 0, 0, 0.1)' 
                    : isCurrent 
                      ? '0 4px 12px rgba(0, 0, 0, 0.08)'
                      : '0 2px 8px rgba(0, 0, 0, 0.05)',
                  transform: isSelected ? 'scale(1.05)' : 'scale(1)'
                }}
                onMouseEnter={(e) => {
                  if (!isSelected) {
                    e.currentTarget.style.transform = 'scale(1.03)';
                    e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.08)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isSelected) {
                    e.currentTarget.style.transform = 'scale(1)';
                    e.currentTarget.style.boxShadow = isCurrent 
                      ? '0 4px 12px rgba(0, 0, 0, 0.08)'
                      : '0 2px 8px rgba(0, 0, 0, 0.05)';
                  }
                }}
              >
                <div className="flex flex-col items-center text-center">
                  <div 
                    className="w-16 h-16 rounded-full mb-3 flex items-center justify-center"
                    style={{ 
                      backgroundColor: persona.color,
                      opacity: 0.9
                    }}
                  >
                    <span className="text-2xl">{persona.icon}</span>
                  </div>
                  
                  <h3 
                    className="font-medium mb-1"
                    style={{ 
                      color: '#333333',
                      fontFamily: persona.fontStyle 
                    }}
                  >
                    {persona.name}
                  </h3>
                  
                  <p 
                    className="text-xs"
                    style={{ 
                      color: isSelected ? '#333333' : '#666666'
                    }}
                  >
                    {persona.description}
                  </p>
                  
                  {/* Show the tone name that this persona represents */}
                  <div 
                    className="mt-1 px-2 py-0.5 rounded-full text-xs"
                    style={{ 
                      backgroundColor: isSelected ? 'rgba(255, 255, 255, 0.3)' : 'rgba(0, 0, 0, 0.03)',
                      color: isSelected ? '#333333' : '#666666'
                    }}
                  >
                    {tone} tone
                  </div>
                  
                  {isCurrent && !isSelected && (
                    <div 
                      className="mt-2 px-2 py-0.5 rounded-full text-xs"
                      style={{ 
                        backgroundColor: 'rgba(0, 0, 0, 0.05)',
                        color: '#666666'
                      }}
                    >
                      Current
                    </div>
                  )}
                </div>
              </button>
            );
          })}
          
          {/* Auto Select Option */}
          <button
            onClick={() => setSelected('auto')}
            className="p-4 rounded-xl transition-all duration-300"
            style={{ 
              background: selected === 'auto' 
                ? 'linear-gradient(135deg, #F5F5F5, #E0E0E0)' 
                : 'rgba(255, 255, 255, 0.7)',
              border: `1px solid ${selected === 'auto' ? 'transparent' : 'rgba(0, 0, 0, 0.05)'}`,
              boxShadow: selected === 'auto' 
                ? '0 6px 16px rgba(0, 0, 0, 0.1)' 
                : current === 'auto' 
                  ? '0 4px 12px rgba(0, 0, 0, 0.08)'
                  : '0 2px 8px rgba(0, 0, 0, 0.05)',
              transform: selected === 'auto' ? 'scale(1.05)' : 'scale(1)'
            }}
            onMouseEnter={(e) => {
              if (selected !== 'auto') {
                e.currentTarget.style.transform = 'scale(1.03)';
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.08)';
              }
            }}
            onMouseLeave={(e) => {
              if (selected !== 'auto') {
                e.currentTarget.style.transform = 'scale(1)';
                e.currentTarget.style.boxShadow = current === 'auto' 
                  ? '0 4px 12px rgba(0, 0, 0, 0.08)'
                  : '0 2px 8px rgba(0, 0, 0, 0.05)';
              }
            }}
          >
            <div className="flex flex-col items-center text-center">
              <div 
                className="w-16 h-16 rounded-full mb-3 flex items-center justify-center"
                style={{ 
                  backgroundColor: '#E0E0E0',
                  opacity: 0.9
                }}
              >
                <span className="text-2xl">🔄</span>
              </div>
              
              <h3 
                className="font-medium mb-1"
                style={{ color: '#333333' }}
              >
                Auto Select
              </h3>
              
              <p 
                className="text-xs"
                style={{ 
                  color: selected === 'auto' ? '#333333' : '#666666'
                }}
              >
                Let the system adapt based on rhythm
              </p>
              
              {current === 'auto' && selected !== 'auto' && (
                <div 
                  className="mt-2 px-2 py-0.5 rounded-full text-xs"
                  style={{ 
                    backgroundColor: 'rgba(0, 0, 0, 0.05)',
                    color: '#666666'
                  }}
                >
                  Current
                </div>
              )}
            </div>
          </button>
        </div>

        {selected && selected !== current && (
          <div className="flex justify-center mt-6">
            <button
              onClick={handleConfirm}
              className="px-5 py-2.5 rounded-xl font-medium transition-all duration-200 shadow-sm"
              style={{ 
                background: selected !== 'auto' 
                  ? PERSONAS[selected]?.gradient || 'linear-gradient(135deg, #F5F5F5, #E0E0E0)'
                  : 'linear-gradient(135deg, #F5F5F5, #E0E0E0)',
                color: '#333333',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
              }}
            >
              ✅ Confirm selection
            </button>
          </div>
        )}

        {showToast && (
          <div 
            className="fixed top-4 right-4 px-4 py-3 rounded-xl shadow-lg animate-fade-in-down"
            style={{ 
              background: selected !== 'auto' 
                ? PERSONAS[selected]?.gradient || 'linear-gradient(135deg, #F5F5F5, #E0E0E0)'
                : 'linear-gradient(135deg, #F5F5F5, #E0E0E0)',
              color: '#333333',
              zIndex: 50,
              boxShadow: '0 4px 16px rgba(0, 0, 0, 0.15)'
            }}
          >
            <div className="flex items-center gap-2">
              <span>✅</span>
              <span>
                {selected === 'auto' 
                  ? 'Switched to automatic persona selection' 
                  : `Persona switched to ${PERSONAS[selected]?.name} (${personaToTone[selected]} tone)`}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PersonaSelector;

