// /src/components/CREVersionToggle.tsx
// CRE 版本切换组件

import React, { useState, useEffect } from 'react';
import { getUseGptCRE, setUseGptCRE } from '../cre/generateCRECue';

export const CREVersionToggle: React.FC = () => {
  const [useGPT, setUseGPT] = useState(getUseGptCRE());

  const handleToggle = (value: boolean) => {
    setUseGPT(value);
    setUseGptCRE(value);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-200">
      <h3 className="text-sm font-medium text-gray-700 mb-3">CRE Generation Mode</h3>
      <div className="space-y-2">
        <label className="flex items-center cursor-pointer">
          <input
            type="radio"
            name="cre-mode"
            checked={!useGPT}
            onChange={() => handleToggle(false)}
            className="mr-2 text-blue-600 focus:ring-blue-500"
          />
          <div>
            <span className="text-sm font-medium text-gray-900">Static (Stable)</span>
            <p className="text-xs text-gray-500">Use pre-written CRE messages</p>
          </div>
        </label>
        
        <label className="flex items-center cursor-pointer">
          <input
            type="radio"
            name="cre-mode"
            checked={useGPT}
            onChange={() => handleToggle(true)}
            className="mr-2 text-blue-600 focus:ring-blue-500"
          />
          <div>
            <span className="text-sm font-medium text-gray-900">AI-Generated (Beta)</span>
            <p className="text-xs text-gray-500">Dynamic CRE using GPT-3.5</p>
          </div>
        </label>
      </div>
      
      <div className={`mt-3 text-xs ${useGPT ? 'text-amber-600' : 'text-gray-500'}`}>
        {useGPT ? '⚡ AI mode active - may use API credits' : '📚 Using static content library'}
      </div>
    </div>
  );
};