import React from 'react';
import { getTodayScoreBreakdown } from '../utils/feedbackInsightSummary';

const FeedbackInsightHint: React.FC = () => {
  const text = getTodayScoreBreakdown();

  return (
    <p className="text-xs text-gray-500 mt-2 italic">
      🔍 {text}
    </p>
  );
};

export default FeedbackInsightHint;
