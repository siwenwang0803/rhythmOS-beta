import React, { useEffect, useState } from 'react';

const BetaBuildBanner: React.FC = () => {
  const [buildInfo, setBuildInfo] = useState<{ version: string; buildTime: string } | null>(null);

  useEffect(() => {
    fetch('/beta-manifest.json')
      .then(res => res.json())
      .then(data => {
        setBuildInfo({ version: data.version, buildTime: data.buildTime });
      });
  }, []);

  if (!buildInfo) return null;

  return (
    <p className="text-xs text-gray-400 text-center mt-4">
      RhythmOS Beta {buildInfo.version} | Built {buildInfo.buildTime}
    </p>
  );
};

export default BetaBuildBanner;
