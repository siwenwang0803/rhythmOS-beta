import React, { useState } from 'react'
import Section from '../components/ui/Section'
import { creTemplates, CRETemplate } from '../creTemplateRegistry'
import { useSearchParams } from 'react-router-dom'

const CRETemplateEditor: React.FC = () => {
  const [templates, setTemplates] = useState<CRETemplate[]>(creTemplates)
  const addTemplate = () => {
    if (!newEntry.text || !newEntry.tone || !newEntry.taskType || !newEntry.stage) return
    setTemplates([...templates, newEntry as CRETemplate])
    setNewEntry({ tone: '', stage: '', taskType: '', variant: 'base', text: '' })
  }
  const [search] = useSearchParams()
const prefill = search.get('prefill') ? JSON.parse(search.get('prefill') || '{}') : {}

const [newEntry, setNewEntry] = useState<Partial<CRETemplate>>({
  tone: prefill.tone || '',
  stage: '',
  taskType: prefill.taskType || '',
  variant: 'base',
  text: ''
})

  return (
    <Section title="📦 CRE Template Editor">
      <div className="grid grid-cols-2 gap-2 mb-3">
        <input value={newEntry.tone} onChange={e => setNewEntry({ ...newEntry, tone: e.target.value })} placeholder="tone" className="border p-1 text-sm" />
        <input value={newEntry.stage} onChange={e => setNewEntry({ ...newEntry, stage: e.target.value })} placeholder="stage" className="border p-1 text-sm" />
        <input value={newEntry.taskType} onChange={e => setNewEntry({ ...newEntry, taskType: e.target.value })} placeholder="taskType" className="border p-1 text-sm" />
        <select value={newEntry.variant} onChange={e => setNewEntry({ ...newEntry, variant: e.target.value as any })} className="border p-1 text-sm">
          <option value="base">base</option>
          <option value="metaphorical">metaphorical</option>
          <option value="concise">concise</option>
          <option value="expansive">expansive</option>
        </select>
        <input value={newEntry.text} onChange={e => setNewEntry({ ...newEntry, text: e.target.value })} placeholder="text" className="col-span-2 border p-1 text-sm" />
      </div>
      <button onClick={addTemplate} className="text-sm bg-blue-600 text-white px-3 py-1 rounded">➕ Add Template</button>

      <div className="mt-4 space-y-2 text-sm">
        {templates.map((t, i) => (
          <div key={i} className="border p-2 rounded bg-white">
            <p className="text-gray-800"><strong>{t.tone}</strong> | {t.stage} | {t.taskType} | {t.variant}</p>
            <p className="text-gray-500 italic">“{t.text}”</p>
          </div>
        ))}
      </div>
    </Section>
  )
}

export default CRETemplateEditor