import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface TaskBehaviorRadarSummaryProps {
  isDaytime?: boolean;
}

/**
 * TaskBehaviorRadarSummary - A visually enhanced component that displays
 * the distribution of completed tasks across different difficulty levels.
 * 
 * Features RhythmOS design system integration and day/night mode support.
 */
export const TaskBehaviorRadarSummary: React.FC<TaskBehaviorRadarSummaryProps> = ({ 
  isDaytime = true 
}) => {
  // Fetch data from localStorage
  const raw = JSON.parse(localStorage.getItem('rhythmSubtasks') || '[]');
  const completed = raw.filter((t: any) => t.status === 'completed');

  // Initialize difficulty categories
  const difficultyMap: Record<string, number> = {
    minimal: 0,
    light: 0,
    normal: 0,
    challenge: 0
  };

  // Count tasks by difficulty
  completed.forEach((t: any) => {
    if (t.difficulty && difficultyMap[t.difficulty] !== undefined) {
      difficultyMap[t.difficulty]++;
    }
  });

  // RhythmOS theme colors based on day/night mode
  const themeColors = {
    text: isDaytime ? '#333333' : '#E0E0E0',          // Dark text / Light text
    textMuted: isDaytime ? '#777777' : '#AAAAAA',     // Muted text colors
    gridLines: isDaytime ? '#EEEEEE' : '#444444',     // Grid line colors
    tooltip: isDaytime ? '#FFFFFF' : '#3A3A3A',       // Tooltip background
    tooltipBorder: isDaytime ? '#E6E6E6' : '#555555', // Tooltip border
  };

  // RhythmOS difficulty level colors
  const difficultyColors = {
    minimal: '#AEC6CF',  // Collapsed - gentle calming blue
    light: '#C3B1E1',    // Wavy - transitional lavender
    normal: '#C5D8A4',   // Stable - grounded light green
    challenge: '#FFB347' // Rising - activating orange-yellow
  };

  // Map to more user-friendly labels
  const difficultyLabels: Record<string, string> = {
    minimal: 'Minimal',
    light: 'Light',
    normal: 'Normal',
    challenge: 'Challenge'
  };

  // Prepare data for chart
  const data = Object.entries(difficultyMap).map(([key, value]) => ({
    difficulty: key,
    label: difficultyLabels[key],
    count: value,
    color: difficultyColors[key as keyof typeof difficultyColors]
  }));

  // If no completed tasks, don't render
  if (data.every(d => d.count === 0)) return null;

  // Calculate max value for Y axis
  const maxCount = Math.max(...data.map(d => d.count));
  const yAxisMax = maxCount <= 5 ? maxCount + 1 : Math.ceil(maxCount * 1.2);

  // Custom tooltip component
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div 
          style={{ 
            backgroundColor: themeColors.tooltip,
            border: `1px solid ${themeColors.tooltipBorder}`,
            padding: '10px 14px',
            borderRadius: '8px',
            boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
            fontSize: '14px'
          }}
        >
          <p 
            style={{ 
              color: data.color, 
              fontWeight: 600,
              margin: '0 0 4px 0',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            <span 
              style={{ 
                display: 'inline-block',
                width: '8px',
                height: '8px',
                backgroundColor: data.color,
                borderRadius: '2px'
              }}
            />
            <span>{data.label}</span>
          </p>
          <p 
            style={{ 
              color: themeColors.text, 
              margin: 0,
              fontWeight: 500
            }}
          >
            {data.count} task{data.count !== 1 ? 's' : ''} completed
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div>
      <ResponsiveContainer width="100%" height={280}>
        <BarChart 
          data={data}
          margin={{ top: 20, right: 10, left: 10, bottom: 10 }}
          barGap={8}
        >
          <XAxis 
            dataKey="label" 
            tick={{ fill: themeColors.text, fontSize: 12 }}
            tickLine={{ stroke: themeColors.gridLines }}
            axisLine={{ stroke: themeColors.gridLines }}
          />
          <YAxis 
            allowDecimals={false}
            domain={[0, yAxisMax]}
            tick={{ fill: themeColors.text, fontSize: 12 }}
            tickLine={{ stroke: themeColors.gridLines }}
            axisLine={{ stroke: themeColors.gridLines }}
            tickCount={6}
          />
          <Tooltip content={<CustomTooltip />} cursor={{ opacity: 0.15 }} />
          <Bar 
            dataKey="count" 
            radius={[4, 4, 0, 0]}
            animationDuration={1200}
            animationEasing="ease-out"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default TaskBehaviorRadarSummary;
