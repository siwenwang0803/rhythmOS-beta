import React, { useState, useEffect } from 'react';

/**
 * 这是一个调试工具组件，用于检查和修复 localStorage 中的子任务数据
 * 在开发环境中使用，解决子任务显示问题
 */
const SubtaskDebugTool: React.FC<{ goalId: string }> = ({ goalId }) => {
  const [subtasksRaw, setSubtasksRaw] = useState<string>('');
  const [subtasks, setSubtasks] = useState<any[]>([]);
  const [fixApplied, setFixApplied] = useState(false);
  const [showTool, setShowTool] = useState(false);

  // 加载子任务数据
  useEffect(() => {
    if (!goalId) return;
    
    const raw = localStorage.getItem('rhythmSubtasks');
    setSubtasksRaw(raw || '[]');
    
    try {
      const parsed = raw ? JSON.parse(raw) : [];
      setSubtasks(parsed);
    } catch (e) {
      console.error('Error parsing subtasks:', e);
      setSubtasks([]);
    }
  }, [goalId]);

  // 寻找当前目标的子任务
  const goalSubtasks = subtasks.filter(
    s => s.goalId === goalId || s.parentGoalId === goalId
  );

  // 修复缺失字段
  const handleFixSubtasks = () => {
    if (!goalId) return;
    
    try {
      // 创建更新后的子任务
      const updatedSubtasks = subtasks.map(s => {
        if (s.goalId === goalId || s.parentGoalId === goalId) {
          // 确保子任务有必要的字段
          return {
            ...s,
            text: s.text || s.title || `Subtask ${s.id.substring(0, 4)}`,
            parentGoalId: s.parentGoalId || s.goalId,
            difficulty: s.difficulty || 'normal'
          };
        }
        return s;
      });
      
      // 保存回 localStorage
      localStorage.setItem('rhythmSubtasks', JSON.stringify(updatedSubtasks));
      
      // 更新状态
      setSubtasks(updatedSubtasks);
      setSubtasksRaw(JSON.stringify(updatedSubtasks));
      setFixApplied(true);
      
      // 触发存储事件通知其他组件
      window.dispatchEvent(new Event('storage'));
      
      // 3秒后刷新页面
      setTimeout(() => {
        window.location.reload();
      }, 3000);
    } catch (e) {
      console.error('Error fixing subtasks:', e);
      alert('Failed to fix subtasks: ' + e);
    }
  };

  if (!showTool) {
    return (
      <div className="text-right mt-4">
        <button onClick={() => setShowTool(true)} className="text-xs text-gray-500 underline">
          Debug Tools
        </button>
      </div>
    );
  }

  return (
    <div className="border border-gray-300 rounded-lg p-4 mt-8 bg-gray-50">
      <h3 className="text-sm font-bold mb-2">Subtask Debug Tool</h3>
      
      <div className="mb-4">
        <p className="text-xs">Goal ID: <code>{goalId}</code></p>
        <p className="text-xs">Found {goalSubtasks.length} subtasks for this goal</p>
      </div>
      
      {goalSubtasks.length > 0 ? (
        <div className="mb-4">
          <h4 className="text-xs font-bold mb-1">Subtasks for this goal:</h4>
          <div className="text-xs overflow-auto max-h-40 bg-white p-2 border rounded">
            {goalSubtasks.map((s, i) => (
              <div key={i} className="mb-2 pb-2 border-b">
                <p>Title: <strong>{s.title || s.text || '(missing)'}</strong></p>
                <p>Text: <strong>{s.text || '(missing)'}</strong></p>
                <p>Status: {s.status}</p>
                <p>Difficulty: {s.difficulty}</p>
                <p>ID: {s.id}</p>
                <p>Has text field: {s.text ? 'Yes' : 'No'}</p>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="bg-yellow-100 p-2 rounded text-xs text-yellow-800 mb-4">
          No subtasks found for this goal
        </div>
      )}
      
      <div className="flex space-x-2">
        <button 
          onClick={handleFixSubtasks}
          className="bg-blue-500 text-white text-xs px-3 py-1 rounded disabled:opacity-50"
          disabled={fixApplied}
        >
          {fixApplied ? 'Fix Applied! Reloading...' : 'Fix Subtasks'}
        </button>
        
        <button 
          onClick={() => setShowTool(false)}
          className="bg-gray-300 text-gray-700 text-xs px-3 py-1 rounded"
        >
          Close
        </button>
      </div>
      
      {fixApplied && (
        <p className="text-xs text-green-600 mt-2">
          Subtasks fixed! Page will reload in 3 seconds.
        </p>
      )}
    </div>
  );
};

export default SubtaskDebugTool;