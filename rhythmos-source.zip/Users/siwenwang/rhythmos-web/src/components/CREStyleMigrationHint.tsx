import React, { useState, useEffect } from 'react'

interface MigrationHintProps {
  migration: {
    shouldSwitch: boolean
    emerging: string | null
    confidence: number
  }
}

const CREStyleMigrationHint: React.FC<MigrationHintProps> = ({ migration }) => {
  const [dismissed, setDismissed] = useState(false)

  useEffect(() => {
    if (localStorage.getItem('creStyleOverride') === migration.emerging) {
      setDismissed(true)
    }
  }, [migration])

  if (!migration.shouldSwitch || !migration.emerging || dismissed) return null

  const handleAdopt = () => {
    localStorage.setItem('creStyleOverride', migration.emerging!)
    setDismissed(true)
  }

  const handleReject = () => {
    localStorage.setItem('creStyleOverride', 'skip')
    setDismissed(true)
  }

  return (
    <div className="mt-6 p-4 bg-yellow-50 border-l-4 border-yellow-400 rounded space-y-2">
      <p className="text-sm text-yellow-700">
        🌀 You’ve been gradually shifting toward a more <strong>{migration.emerging}</strong> tone.
      </p>
      <p className="text-xs text-gray-500">Confidence: {migration.confidence}%</p>
      <p className="text-xs text-gray-600 italic">Would you like us to adapt your rhythm guidance accordingly in future sessions?</p>
      <div className="flex gap-3 mt-2 text-sm">
        <button onClick={handleAdopt} className="px-3 py-1 rounded bg-green-500 text-white">
          ✅ Yes, adopt it
        </button>
        <button onClick={handleReject} className="px-3 py-1 rounded bg-gray-300 text-black">
          ❌ No, stay current
        </button>
        <button onClick={() => setDismissed(true)} className="px-3 py-1 rounded bg-yellow-200 text-black">
          🕒 Skip for now
        </button>
      </div>
    </div>
  )
}

export default CREStyleMigrationHint
