// /components/PersonaIdentityPathSelector.tsx - 修复版本

import React, { useState, useEffect } from 'react';
import { getXpData, getCurrentTitle } from '../utils/xpEngine';

const PERSONAS = {
  rhea: {
    label: 'Rhea',
    icon: '💗',
    desc: 'Gentle, empathic, emotionally attuned',
    gradient: 'from-[#F5E8C7] to-[#F5CFCF]',
    borderColor: '#F5CFCF'
  },
  caelum: {
    label: 'Caelum',
    icon: '💠',
    desc: 'Decisive, strategic, forward-moving',
    gradient: 'from-[#F5E8C7] to-[#4B6587]',
    borderColor: '#4B6587'
  },
  aurelia: {
    label: 'Aurelia',
    icon: '🧠',
    desc: 'Analytical, calm, insight-driven',
    gradient: 'from-[#F5E8C7] to-[#D8A7CA]',
    borderColor: '#D8A7CA'
  },
  lucis: {
    label: 'Lucis',
    icon: '🌱',
    desc: 'Grounded, organic, slow growth',
    gradient: 'from-[#F5E8C7] to-[#F8C1CC]',
    borderColor: '#F8C1CC'
  },
  niveus: {
    label: 'Niveus',
    icon: '📊',
    desc: 'Structured, metric-aware, pattern-seeking',
    gradient: 'from-[#F5E8C7] to-[#DDEBCF]',
    borderColor: '#DDEBCF'
  }
};

const PersonaIdentityPathSelector: React.FC = () => {
  // 使用状态来存储当前选中的persona和XP数据
  const [currentPersona, setCurrentPersona] = useState('rhea');
  const [xpData, setXpData] = useState<Record<string, any>>({});
  
  // 加载初始数据
  useEffect(() => {
    // 获取当前选中的persona
    const stored = localStorage.getItem('initPersona') || 'rhea';
    setCurrentPersona(stored);
    
    // 获取XP数据并设置状态
    updateXpData();
    
    // 添加事件监听以响应XP变化
    window.addEventListener('xp-updated', updateXpData);
    
    return () => {
      window.removeEventListener('xp-updated', updateXpData);
    };
  }, []);
  
  // 更新XP数据的函数
  const updateXpData = () => {
    try {
      const data = getXpData();
      setXpData(data);
      console.log('PersonaIdentityPathSelector - XP数据已更新:', data);
    } catch (error) {
      console.error('获取XP数据时出错:', error);
    }
  };

  // 选择persona的处理函数
  const handleSelect = (persona: string) => {
    if (persona === currentPersona) return;
    
    // 使用更符合设计风格的确认对话框
    const confirmed = window.confirm(`Switch your identity path to ${PERSONAS[persona].label}? All XP will now accumulate here.`);
    if (confirmed) {
      localStorage.setItem('initPersona', persona);
      
      // 触发自定义事件通知组件更新
      window.dispatchEvent(new Event('persona-changed'));
      
      // 使用延迟重载以确保数据正确保存
      setTimeout(() => {
        window.location.reload();
      }, 100);
    }
  };

  // 获取特定persona的XP值
  const getPersonaXp = (persona: string): number => {
    return xpData[persona]?.xp || 0;
  };
  
  // 获取特定persona的标题
  const getPersonaTitle = (persona: string): string => {
    const xp = getPersonaXp(persona);
    return getCurrentTitle(persona, xp);
  };

  return (
    <div className="mt-6 space-y-4 bg-[#F5E8C7]/50 p-6 rounded-lg">
      <div className="flex items-start">
        <div className="bg-[#F7DC6F]/20 p-2 rounded-full mr-3">
          <span className="text-xl">🎯</span>
        </div>
        <div>
          <h2 className="text-lg font-medium text-[#333333]">Your Current Identity Path</h2>
          <p className="text-sm text-[#333333]/70 mt-1">
            XP from microtasks and challenges will be added to this persona.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-5">
        {Object.entries(PERSONAS).map(([key, data]) => {
          const selected = key === currentPersona;
          const personaXp = getPersonaXp(key);
          const title = getPersonaTitle(key);
          
          return (
            <button
              key={key}
              onClick={() => handleSelect(key)}
              className={`w-full rounded-lg border transition-all duration-300 overflow-hidden ${
                selected ? 'shadow-md' : 'shadow-sm hover:shadow'
              }`}
              style={{ 
                borderColor: selected ? data.borderColor : '#E0D9C8',
                borderWidth: selected ? '2px' : '1px'
              }}
            >
              <div className={`w-full h-1 bg-gradient-to-r ${data.gradient}`}></div>
              <div className="p-4 bg-white">
                <div className="flex items-center gap-3">
                  <div 
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-xl ${
                      selected ? `bg-gradient-to-br ${data.gradient}` : 'bg-[#F5E8C7]'
                    }`}
                  >
                    {data.icon}
                  </div>
                  <div className="text-left">
                    <div className="text-base font-medium text-[#333333]">{data.label}</div>
                    <div className="text-xs text-[#333333]/70">{title}</div>
                  </div>
                </div>
                
                {/* 添加XP显示 */}
                <div className="mt-2 pt-2 border-t border-[#E0D9C8]">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-[#333333]/70">Progress:</span>
                    <span className="text-xs font-medium text-[#333333]">{personaXp} XP</span>
                  </div>
                  
                  {/* XP进度条 */}
                  <div className="w-full h-1.5 bg-[#F5E8C7] rounded-full mt-1 overflow-hidden">
                    <div 
                      className={`h-full bg-gradient-to-r ${data.gradient}`}
                      style={{ width: `${Math.min(100, (personaXp / 150) * 100)}%` }}
                    ></div>
                  </div>
                </div>
                
                {selected && (
                  <div className="mt-3 pt-3 border-t border-[#E0D9C8] flex items-center">
                    <div className="px-2 py-1 bg-[#F7DC6F]/20 rounded-full text-xs font-medium text-[#333333]">
                      ✨ Currently Active
                    </div>
                  </div>
                )}
              </div>
            </button>
          );
        })}
      </div>
      
      <div className="mt-4 p-3 bg-white/70 rounded-lg border border-[#E0D9C8] text-sm text-[#333333]/70">
        <span className="text-[#333333] font-medium">Tip:</span> Each persona accumulates XP independently. Choose the one that aligns with your current growth priorities.
      </div>
    </div>
  );
};

export default PersonaIdentityPathSelector;
