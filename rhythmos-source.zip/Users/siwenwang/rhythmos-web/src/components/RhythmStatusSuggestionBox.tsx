import React, { useState, useEffect } from 'react';
import { getFinalizedSummary, getTodayTotalScore, isTodayFinalized } from '../utils/rhythmDayEngine';
import { getSignatureMap } from '../SignatureMap';
import { getToneScoreMapByDays } from '../utils/writeToneLog';

interface RhythmStatusSuggestionBoxProps {
  isDaytime?: boolean; // Optional prop to control day/night mode
}

// 正确的 Tone 到 Persona 映射
const toneToPersonaMap: Record<string, string> = {
  gentle: 'rhea',
  directive: 'niveus',
  visionary: 'lucis',
  rational: 'aurelia',
  motivated: 'caelum',
 
  
};

// 反向查找 - 从前缀映射到正确的显示名称
const prefixToPersonaMap: Record<string, string> = {
  'cre': 'rhea',
  'rhea': 'rhea',
  'niveus': 'niveus',
  'lucis': 'lucis',
  'aurelia': 'aurelia',
  'caelum': 'caelum',
  
};

// Persona details for visualization
const PERSONAS = {
  rhea: {
    color: '#F5CFCF',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #694647)',
    icon: '💗',
    title: 'Gentle, empathic'
  },
  aurelia: {
    color: '#D8A7CA',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #5A4555)',
    icon: '🧠',
    title: 'Rational, intuitive'
  },
  lucis: {
    color: '#A4D8C5',
    gradient: 'linear-gradient(135deg, #E8F5C7, #A4D8C5)',
    nightGradient: 'linear-gradient(135deg, #495D44, #456056)',
    icon: '🌱',
    title: 'Supportive, growth'
  },
  niveus: {
    color: '#C7C7C7',
    gradient: 'linear-gradient(135deg, #E8E8E8, #C7C7C7)',
    nightGradient: 'linear-gradient(135deg, #4A4A4A, #555555)',
    icon: '📊',
    title: 'Directive, balanced'
  },
  caelum: {
    color: '#4B6587',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #2A3A4F)',
    icon: '💠',
    title: 'Directive, confident'
  }
};

// 任务完成表现级别（原来是精神状态）
const PERFORMANCE_LEVELS = {
  peak: {
    title: '🏆 Peak Achievement',
    intro: "Outstanding performance today!",
    color: '#FFB347', // Peak performance color
    description: "You're achieving exceptional results. This is a great time to tackle ambitious goals and maintain momentum."
  },
  strong: {
    title: '⚡ Strong Performance',
    intro: "Solid progress and consistent execution!",
    color: '#C5D8A4', // Strong performance color
    description: ""
  },
  building: {
    title: '🎯 Building Progress',
    intro: "Making steady advances with some variation.",
    color: '#C3B1E1', // Building progress color
    description: "Your performance shows natural ups and downs as you build momentum. Stay focused on your goals and keep pushing forward."
  },
  starting: {
    title: '🌱 Getting Started',
    intro: "Early stages of building momentum.",
    color: '#AEC6CF', // Getting started color
    description: "You're in the early stages of building your performance rhythm. Focus on small, consistent actions to build momentum."
  }
};

// 获取正确的 Persona 名称
const getCorrectPersonaForTone = (tone: string): string => {
  return toneToPersonaMap[tone] || 'rhea';
};

// 获取规范化的 persona 名称
const getNormalizedPersona = (rawPersona: string): string => {
  return prefixToPersonaMap[rawPersona?.toLowerCase()] || 'rhea';
};

const safeNumber = (input: any): number => {
  if (typeof input === 'number' && !isNaN(input)) return input;
  const parsed = parseFloat(String(input));
  return isNaN(parsed) ? 0 : parsed;
};

const getToneAndPersonaFromToneMap = () => {
  // 使用 getSignatureMap() 而不是直接引用 signatureMap
  const signatureMap = getSignatureMap();
  // 使用 toneScoreMap 
  const toneScoreMap = getToneScoreMapByDays(7);
  
  // 排序获取主要 tone
  const sortedTones = Object.entries(toneScoreMap).sort((a, b) => b[1] - a[1]);
  
  if (sortedTones.length === 0) {
    return { dominantTone: 'unknown', dominantPersona: 'unknown', sortedTones: [] };
  }
  
  // 获取主要 tone
  const [dominantTone] = sortedTones[0];
  
  // ✅ 使用正确的映射获取 persona
  const dominantPersona = getCorrectPersonaForTone(dominantTone);
  
  console.log('📊 Dominant tone and persona:', { dominantTone, dominantPersona });
  
  return { dominantTone, dominantPersona, sortedTones };
};

// Tone details with icons
const TONE_DETAILS = {
  gentle: { icon: '🌸', description: 'Soft and nurturing approach' },
  directive: { icon: '📌', description: 'Clear and guiding direction' },
  visionary: { icon: '🔭', description: 'Forward-thinking perspective' },
  rational: { icon: '🧩', description: 'Logical, analytical reasoning' },
  motivated: { icon: '🔆', description: 'Energetic, encouraging style' },
  supportive: { icon: '🤝', description: 'Helpful, uplifting approach' },
  balanced: { icon: '⚖️', description: 'Harmonious, even-tempered style' },
  strategic: { icon: '🧭', description: 'Purposeful, planned approach' }
};

export const RhythmStatusSuggestionBox: React.FC<RhythmStatusSuggestionBoxProps> = ({ isDaytime = true }) => {
  const { dominantTone, dominantPersona, sortedTones } = getToneAndPersonaFromToneMap();
  const [isAnimated, setIsAnimated] = useState(false);
  
  // Animation effect
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsAnimated(true);
    }, 300);
    
    return () => clearTimeout(timer);
  }, []);
  
  // 根据日夜模式调整颜色
  const baseTextColor = isDaytime ? '#333333' : '#E0E0E0';
  const secondaryTextColor = isDaytime ? '#666666' : '#AAAAAA';
  const tertiaryTextColor = isDaytime ? '#999999' : '#777777';
  const accentTextColor = isDaytime ? '#673AB7' : '#B39DDB';
  const bgColor = isDaytime 
    ? 'rgba(255, 255, 255, 0.7)'
    : 'rgba(40, 38, 46, 0.7)';
  const borderColor = isDaytime
    ? 'rgba(0, 0, 0, 0.05)'
    : 'rgba(255, 255, 255, 0.05)';
  
  const finalized = isTodayFinalized();
  const rawScore = finalized ? getFinalizedSummary()?.score : getTodayTotalScore();
  const score = safeNumber(rawScore);
  
  // 根据分数区间划定表现级别（原来是状态）
  let performanceLevel;
  if (score >= 9) {
    performanceLevel = PERFORMANCE_LEVELS.peak;
  } else if (score >= 6) {
    performanceLevel = PERFORMANCE_LEVELS.strong;
  } else if (score >= 3) {
    performanceLevel = PERFORMANCE_LEVELS.building;
  } else {
    performanceLevel = PERFORMANCE_LEVELS.starting;
  }
  
  // Fallback 处理无数据情况
  const hasToneData = dominantTone !== 'unknown';
  
  // Get persona info if available
  const personaInfo = hasToneData 
    ? PERSONAS[dominantPersona as keyof typeof PERSONAS] || PERSONAS.rhea
    : PERSONAS.rhea;
  
  // Get tone info if available
  const toneInfo = hasToneData
    ? TONE_DETAILS[dominantTone as keyof typeof TONE_DETAILS] || { icon: '🔹', description: 'Your preferred tone' }
    : { icon: '🔹', description: '' };
  
  return (
    <div 
      className={`rounded-xl overflow-hidden transform transition-all duration-700 ${
        isAnimated ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0'
      }`}
      style={{ 
        backgroundColor: bgColor,
        backdropFilter: 'blur(10px)',
        border: `1px solid ${borderColor}`,
        boxShadow: isDaytime
          ? '0 8px 30px rgba(0, 0, 0, 0.07), inset 0 0 15px rgba(0, 0, 0, 0.02)'
          : '0 8px 30px rgba(0, 0, 0, 0.2), inset 0 0 15px rgba(255, 255, 255, 0.01)'
      }}
    >
      {/* Top accent bar */}
      <div 
        className="h-1.5 w-full" 
        style={{ background: performanceLevel.color }}
      />
      
      <div className="p-6">
        <div className="flex items-start gap-4">
          <div 
            className="w-12 h-12 rounded-xl flex-shrink-0 flex items-center justify-center"
            style={{ 
              background: isDaytime
                ? `linear-gradient(135deg, ${performanceLevel.color}30, ${performanceLevel.color}70)`
                : `linear-gradient(135deg, ${performanceLevel.color}30, ${performanceLevel.color}50)`,
              boxShadow: isDaytime
                ? `0 4px 12px ${performanceLevel.color}30`
                : `0 4px 12px rgba(0, 0, 0, 0.2)`
            }}
          >
            <span className="text-xl">{performanceLevel.title.split(' ')[0]}</span>
          </div>
          
          <div className="flex-1">
            <h3 
              className="text-lg font-semibold mb-1"
              style={{ color: baseTextColor }}
            >
              {performanceLevel.title.split(' ').slice(1).join(' ')}
            </h3>
            
            <p 
              className="mb-3 text-base"
              style={{ color: secondaryTextColor }}
            >
              {performanceLevel.intro}
            </p>
            
            <p 
              className="text-sm"
              style={{ color: secondaryTextColor }}
            >
              {performanceLevel.description}
            </p>
          </div>
        </div>
        
        {/* Separator */}
        <div 
          className="h-px w-full my-5" 
          style={{ 
            background: isDaytime
              ? 'rgba(0, 0, 0, 0.05)'
              : 'rgba(255, 255, 255, 0.05)'
          }}
        />
        
        {/* Tone and persona information */}
        <div className="space-y-4">
          <p 
            className="text-base"
            style={{ color: secondaryTextColor }}
          >
            {hasToneData ? (
              <>
                Past feedback shows you align most with:
              </>
            ) : (
              'No tone feedback data yet. Start giving feedback to see your patterns.'
            )}
          </p>
          
          {hasToneData && (
            <div className="flex flex-wrap gap-2 mt-2">
              <div 
                className="px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5"
                style={{ 
                  background: isDaytime
                    ? 'rgba(0, 0, 0, 0.03)'
                    : 'rgba(255, 255, 255, 0.05)',
                  color: baseTextColor
                }}
              >
                <span>{toneInfo.icon}</span>
                <span className="capitalize">{dominantTone} tone</span>
              </div>
              
              <div 
                className="px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5"
                style={{ 
                  background: isDaytime
                    ? `${personaInfo.color}20`
                    : `${personaInfo.color}30`,
                  color: baseTextColor,
                  border: isDaytime
                    ? `1px solid ${personaInfo.color}30`
                    : `1px solid ${personaInfo.color}40`
                }}
              >
                <span>{personaInfo.icon}</span>
                <span className="capitalize">{dominantPersona}</span>
              </div>
            </div>
          )}
          
          {/* Performance score visualization */}
          <div 
            className="mt-5 p-4 rounded-xl border"
            style={{
              borderColor: isDaytime 
                ? 'rgba(0, 0, 0, 0.05)' 
                : 'rgba(255, 255, 255, 0.05)',
              backgroundColor: isDaytime 
                ? 'rgba(255, 255, 255, 0.5)' 
                : 'rgba(255, 255, 255, 0.03)'
            }}
          >
            <div className="flex items-center justify-between mb-2">
              <span 
                className="text-sm font-medium"
                style={{ color: baseTextColor }}
              >
                Current performance score
              </span>
              <span 
                className="text-xl font-bold"
                style={{ color: baseTextColor }}
              >
                {score.toFixed(1)}/10
              </span>
            </div>
            
            <div 
              className="h-2 w-full rounded-full overflow-hidden"
              style={{ 
                backgroundColor: isDaytime
                  ? 'rgba(0, 0, 0, 0.05)'
                  : 'rgba(255, 255, 255, 0.05)'
              }}
            >
              <div 
                className="h-full rounded-full"
                style={{ 
                  width: `${score * 10}%`,
                  background: performanceLevel.color,
                  boxShadow: `0 0 10px ${performanceLevel.color}80`
                }}
              />
            </div>
            
            {/* Performance level markers */}
            <div className="flex justify-between mt-1 px-1">
              <span 
                className="text-xs"
                style={{ color: tertiaryTextColor }}
              >
                Starting
              </span>
              <span 
                className="text-xs"
                style={{ color: tertiaryTextColor }}
              >
                Building
              </span>
              <span 
                className="text-xs"
                style={{ color: tertiaryTextColor }}
              >
                Strong
              </span>
              <span 
                className="text-xs"
                style={{ color: tertiaryTextColor }}
              >
                Peak
              </span>
            </div>
          </div>
          
          {/* Tips based on the current performance level */}
          <div className="mt-4">
            <p 
              className="text-sm font-medium mb-2"
              style={{ color: baseTextColor }}
            >
              Suggestion for your current performance level:
            </p>
            <p
              className="text-sm"
              style={{ color: secondaryTextColor }}
            >
              {score >= 9 ? (
                "You're at peak performance! Keep pushing on your most challenging goals while maintaining this exceptional momentum."
              ) : score >= 6 ? (
                "Strong performance continues! Maintain this consistent execution while looking for opportunities to optimize further."
              ) : score >= 3 ? (
                "You're building good progress. Focus on consistency and gradual improvement to reach the next performance level."
              ) : (
                "Early stages of building momentum. Focus on small, achievable goals to establish a foundation for stronger performance."
              )}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RhythmStatusSuggestionBox;