// 修复 Week 计算的 MicrotaskStreakHint 组件

import React, { useState, useEffect } from 'react';

interface MicrotaskStats {
  total: number;          
  today: number;          
  thisWeek: number;       
  currentStreak: number;  
  bestStreak: number;     
}

interface MicrotaskStreakHintProps {
  isDaytime?: boolean;
}

const MicrotaskStreakHint: React.FC<MicrotaskStreakHintProps> = ({ isDaytime = true }) => {
  const [stats, setStats] = useState<MicrotaskStats>({
    total: 0,
    today: 0,
    thisWeek: 0,
    currentStreak: 0,
    bestStreak: 0
  });
  const [selectedView, setSelectedView] = useState<'today' | 'streak' | 'total' | 'week'>('today');
  const [isLoading, setIsLoading] = useState(true);

  // 主题配色
  const theme = {
    background: 'linear-gradient(135deg, rgba(116, 185, 255, 0.08) 0%, rgba(166, 206, 227, 0.12) 100%)',
    cardBg: 'rgba(255, 255, 255, 0.85)',
    buttonBg: 'rgba(116, 185, 255, 0.1)',
    buttonActive: 'rgba(116, 185, 255, 0.2)',
    buttonHover: 'rgba(116, 185, 255, 0.15)',
    text: '#2c3e50',
    textSecondary: '#5a6c7d',
    textMuted: '#8492a6',
    accent: '#74b9ff',
    accentLight: 'rgba(116, 185, 255, 0.1)',
    border: 'rgba(116, 185, 255, 0.15)',
    borderLight: 'rgba(116, 185, 255, 0.08)',
    shadow: 'rgba(116, 185, 255, 0.1)',
    shadowHover: 'rgba(116, 185, 255, 0.15)',
    success: '#00b894',
    successBg: 'rgba(0, 184, 148, 0.1)',
  };

  // 获取今天的日期键 (YYYY-MM-DD 格式)
  const getTodayKey = () => {
    return new Date().toISOString().split('T')[0];
  };

  // 修复的本周开始日期计算
  const getWeekStartKey = () => {
    const now = new Date();
    // 获取本周第一天 (周日)
    const dayOfWeek = now.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - dayOfWeek);
    startOfWeek.setHours(0, 0, 0, 0);
    const weekStartKey = startOfWeek.toISOString().split('T')[0];
    
    console.log('📅 本周计算:', {
      今天: now.toISOString().split('T')[0],
      今天是星期几: dayOfWeek,
      本周开始: weekStartKey,
      相差天数: dayOfWeek
    });
    
    return weekStartKey;
  };

  // 检查日期是否在本周内
  const isThisWeek = (dateKey: string, weekStart: string): boolean => {
    const date = new Date(dateKey);
    const weekStartDate = new Date(weekStart);
    const weekEndDate = new Date(weekStartDate);
    weekEndDate.setDate(weekStartDate.getDate() + 6); // 本周末 (周六)
    
    const inRange = dateKey >= weekStart && dateKey <= weekEndDate.toISOString().split('T')[0];
    
    console.log('🔍 检查日期是否在本周:', {
      检查日期: dateKey,
      本周开始: weekStart,
      本周结束: weekEndDate.toISOString().split('T')[0],
      是否在范围内: inRange
    });
    
    return inRange;
  };

  // 修复的微任务统计计算
  const calculateMicrotaskStats = (): MicrotaskStats => {
    console.log('\n=== 🔍 开始计算微任务统计 ===');
    
    const today = getTodayKey();
    const weekStart = getWeekStartKey();
    
    console.log('📅 日期信息:', {
      today,
      weekStart,
      currentTime: new Date().toISOString()
    });

    // 1. SignatureMap 数据分析
    let totalFromSignature = 0;
    let todayFromSignature = 0;
    let weekFromSignature = 0;
    let signatureMapEntries: any[] = [];
    
    try {
      const signatureMap = (window as any).signatureMap || {};
      totalFromSignature = signatureMap.microtaskCount || 0;
      signatureMapEntries = signatureMap.microtaskLog || [];
      
      console.log('🗺️ SignatureMap 分析:', {
        totalCount: totalFromSignature,
        logEntries: signatureMapEntries.length,
        rawLog: signatureMapEntries
      });

      // 分析每个条目
      signatureMapEntries.forEach((entry, index) => {
        if (entry.timestamp) {
          const entryDate = new Date(entry.timestamp);
          const entryDateKey = entryDate.toISOString().split('T')[0];
          
          console.log(`📝 SignatureMap 条目 ${index}:`, {
            时间戳: entry.timestamp,
            日期键: entryDateKey,
            是否今天: entryDateKey === today,
            是否本周: isThisWeek(entryDateKey, weekStart)
          });
          
          if (entryDateKey === today) {
            todayFromSignature++;
          }
          
          if (isThisWeek(entryDateKey, weekStart)) {
            weekFromSignature++;
          }
        }
      });
      
      console.log('🗺️ SignatureMap 统计:', {
        今天: todayFromSignature,
        本周: weekFromSignature
      });
      
    } catch (error) {
      console.error('❌ SignatureMap 读取错误:', error);
    }

    // 2. XpTracker 数据分析
    let todayFromXpTracker = 0;
    let weekFromXpTracker = 0;
    let xpTrackerEntries: any = {};
    
    try {
      const xpTracker = JSON.parse(localStorage.getItem('xpTracker') || '{}');
      xpTrackerEntries = xpTracker;
      todayFromXpTracker = xpTracker[today]?.microtaskCount || 0;
      
      console.log('📊 XpTracker 分析:', {
        全部条目: Object.keys(xpTracker),
        今天数据: xpTracker[today],
        今天计数: todayFromXpTracker
      });
      
      // 计算本周的 XpTracker 数据
      Object.keys(xpTracker).forEach(dateKey => {
        const dayData = xpTracker[dateKey];
        if (dayData && dayData.microtaskCount && isThisWeek(dateKey, weekStart)) {
          weekFromXpTracker += dayData.microtaskCount;
          console.log(`📊 XpTracker ${dateKey}: +${dayData.microtaskCount} (累计本周: ${weekFromXpTracker})`);
        }
      });
      
      console.log('📊 XpTracker 本周总计:', weekFromXpTracker);
      
    } catch (error) {
      console.error('❌ XpTracker 读取错误:', error);
    }

    // 3. RhythmScoreLog 数据分析
    let todayFromRhythm = 0;
    let totalFromRhythm = 0;
    let weekFromRhythm = 0;
    let rhythmEntries: any[] = [];
    
    try {
      const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
      rhythmEntries = rhythmScoreLog.filter((entry: any) => 
        entry.actionType === 'microtask_complete'
      );
      
      totalFromRhythm = rhythmEntries.length;
      
      console.log('🎵 RhythmScoreLog 分析:', {
        全部日志: rhythmScoreLog.length,
        微任务条目: rhythmEntries.length,
        条目详情: rhythmEntries
      });

      // 分析每个条目的日期
      rhythmEntries.forEach((entry, index) => {
        let entryDateKey = '';
        if (entry.date) {
          entryDateKey = entry.date;
        } else if (entry.timestamp) {
          entryDateKey = new Date(entry.timestamp).toISOString().split('T')[0];
        }
        
        console.log(`🎵 RhythmLog 条目 ${index}:`, {
          条目: entry,
          日期键: entryDateKey,
          是否今天: entryDateKey === today,
          是否本周: isThisWeek(entryDateKey, weekStart)
        });
        
        if (entryDateKey === today) {
          todayFromRhythm++;
        }
        
        if (isThisWeek(entryDateKey, weekStart)) {
          weekFromRhythm++;
        }
      });
      
      console.log('🎵 RhythmScoreLog 统计:', {
        今天: todayFromRhythm,
        本周: weekFromRhythm
      });
      
    } catch (error) {
      console.error('❌ RhythmScoreLog 读取错误:', error);
    }

    // 4. 最终计算 - 取各数据源的最大值
    const finalTotal = Math.max(totalFromSignature, totalFromRhythm);
    const finalToday = Math.max(todayFromSignature, todayFromXpTracker, todayFromRhythm);
    const finalWeek = Math.max(weekFromSignature, weekFromXpTracker, weekFromRhythm);
    
    console.log('🎯 最终统计结果:', {
      总数: {
        SignatureMap: totalFromSignature,
        RhythmLog: totalFromRhythm,
        '最终值': finalTotal
      },
      今天: {
        SignatureMap: todayFromSignature,
        XpTracker: todayFromXpTracker,
        RhythmLog: todayFromRhythm,
        '最终值': finalToday
      },
      本周: {
        SignatureMap: weekFromSignature,
        XpTracker: weekFromXpTracker,
        RhythmLog: weekFromRhythm,
        '最终值': finalWeek
      }
    });

    // 5. 连续天数计算
    const { currentStreak, bestStreak } = calculateStreaksDetailed(signatureMapEntries, xpTrackerEntries, today);

    const result = {
      total: finalTotal,
      today: finalToday,
      thisWeek: finalWeek,
      currentStreak,
      bestStreak
    };

    console.log('🏁 最终返回结果:', result);
    console.log('=== 🔍 计算结束 ===\n');

    return result;
  };

  // 连续天数计算
  const calculateStreaksDetailed = (signatureEntries: any[], xpEntries: any, today: string) => {
    console.log('\n--- 🔥 连续天数计算开始 ---');
    
    // 收集所有活跃日期
    const activeDates = new Set<string>();
    
    // 从 SignatureMap.microtaskLog 收集
    signatureEntries.forEach(entry => {
      if (entry.timestamp) {
        const dateKey = new Date(entry.timestamp).toISOString().split('T')[0];
        activeDates.add(dateKey);
        console.log(`📝 SignatureMap 活跃日期: ${dateKey}`);
      }
    });
    
    // 从 xpTracker 收集
    Object.keys(xpEntries).forEach(dateKey => {
      if (xpEntries[dateKey] && xpEntries[dateKey].microtaskCount && xpEntries[dateKey].microtaskCount > 0) {
        activeDates.add(dateKey);
        console.log(`📊 XpTracker 活跃日期: ${dateKey}`);
      }
    });
    
    const sortedDates = Array.from(activeDates).sort((a, b) => b.localeCompare(a));
    console.log('📅 所有活跃日期 (倒序):', sortedDates);
    
    if (sortedDates.length === 0) {
      console.log('❌ 没有活跃日期');
      return { currentStreak: 0, bestStreak: 0 };
    }
    
    // 计算当前连续天数
    let currentStreak = 0;
    
    if (sortedDates[0] === today) {
      // 今天有活动
      currentStreak = 1;
      console.log('✅ 今天有活动，开始计算连续天数');
      
      for (let i = 1; i < sortedDates.length; i++) {
        const currentDate = new Date(sortedDates[i-1]);
        const prevDate = new Date(sortedDates[i]);
        const daysDiff = Math.round((currentDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24));
        
        console.log(`🔍 比较 ${sortedDates[i-1]} 和 ${sortedDates[i]}: 相差 ${daysDiff} 天`);
        
        if (daysDiff === 1) {
          currentStreak++;
          console.log(`✅ 连续，当前连续天数: ${currentStreak}`);
        } else {
          console.log(`❌ 不连续，停止计算`);
          break;
        }
      }
    } else {
      // 今天没有活动，检查昨天
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayKey = yesterday.toISOString().split('T')[0];
      
      console.log(`🔍 今天没有活动，检查昨天: ${yesterdayKey}`);
      
      if (sortedDates.includes(yesterdayKey)) {
        console.log('✅ 昨天有活动，从昨天开始计算');
        const startIndex = sortedDates.indexOf(yesterdayKey);
        currentStreak = 1;
        
        for (let i = startIndex + 1; i < sortedDates.length; i++) {
          const currentDate = new Date(sortedDates[i-1]);
          const prevDate = new Date(sortedDates[i]);
          const daysDiff = Math.round((currentDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24));
          
          if (daysDiff === 1) {
            currentStreak++;
          } else {
            break;
          }
        }
      }
    }
    
    // 计算历史最佳
    let bestStreak = currentStreak;
    let tempStreak = 1;
    
    for (let i = 1; i < sortedDates.length; i++) {
      const currentDate = new Date(sortedDates[i-1]);
      const prevDate = new Date(sortedDates[i]);
      const daysDiff = Math.round((currentDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysDiff === 1) {
        tempStreak++;
      } else {
        bestStreak = Math.max(bestStreak, tempStreak);
        tempStreak = 1;
      }
    }
    bestStreak = Math.max(bestStreak, tempStreak);
    
    const result = { currentStreak, bestStreak };
    console.log('🏁 连续天数结果:', result);
    console.log('--- 🔥 连续天数计算结束 ---\n');
    
    return result;
  };

  // 更新数据
  const updateStats = () => {
    console.log('\n🔄 开始更新统计数据...');
    setIsLoading(true);
    const newStats = calculateMicrotaskStats();
    setStats(newStats);
    setIsLoading(false);
    console.log('✅ 统计数据更新完成\n');
  };

  // 初始化和事件监听
  useEffect(() => {
    updateStats();

    const handleUpdate = () => {
      console.log('🔔 收到事件，准备更新统计...');
      setTimeout(updateStats, 100);
    };
    
    const events = ['microtask-completed', 'microtask-updated', 'rhythm-score-updated', 'storage'];
    events.forEach(event => {
      window.addEventListener(event, handleUpdate);
    });

    return () => {
      events.forEach(event => {
        window.removeEventListener(event, handleUpdate);
      });
    };
  }, []);

  // 获取显示数据
  const getDisplayData = () => {
    switch (selectedView) {
      case 'today':
        return { value: stats.today, label: 'Completed today', emoji: '📅', desc: "Today's progress" };
      case 'total':
        return { value: stats.total, label: 'Total completed', emoji: '🏆', desc: 'All-time microtasks' };
      case 'week':
        return { value: stats.thisWeek, label: 'This week', emoji: '📊', desc: 'Weekly momentum' };
      case 'streak':
        return { value: stats.currentStreak, label: 'Day streak', emoji: '🔥', desc: `Best: ${stats.bestStreak} days` };
      default:
        return { value: stats.today, label: 'Completed today', emoji: '📅', desc: "Today's progress" };
    }
  };

  const display = getDisplayData();

  if (isLoading) {
    return (
      <div style={{
        borderRadius: '12px',
        padding: '20px',
        background: theme.cardBg,
        border: `1px solid ${theme.borderLight}`,
        boxShadow: `0 2px 8px ${theme.shadow}`,
        backdropFilter: 'blur(10px)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            width: '16px',
            height: '16px',
            border: `2px solid ${theme.accent}`,
            borderTop: '2px solid transparent',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite'
          }} />
          <span style={{ color: theme.textSecondary, fontSize: '14px' }}>
            Loading momentum data...
          </span>
        </div>
        <style>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  return (
    <div style={{
      borderRadius: '12px',
      padding: '20px',
      background: theme.cardBg,
      border: `1px solid ${theme.borderLight}`,
      boxShadow: `0 2px 8px ${theme.shadow}`,
      backdropFilter: 'blur(10px)',
      position: 'relative',
      overflow: 'hidden',
      transition: 'all 0.3s ease'
    }}>
      {/* 装饰背景 */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: '3px',
        background: theme.background,
        borderRadius: '12px 12px 0 0'
      }} />

      {/* 顶部视图切换 */}
      <div style={{
        display: 'flex',
        gap: '4px',
        marginBottom: '16px',
        padding: '4px',
        backgroundColor: theme.buttonBg,
        borderRadius: '8px'
      }}>
        {[
          { key: 'today', icon: '📅', label: 'Today' },
          { key: 'streak', icon: '🔥', label: 'Streak' },
          { key: 'total', icon: '🏆', label: 'Total' },
          { key: 'week', icon: '📊', label: 'Week' }
        ].map(({ key, icon, label }) => (
          <button
            key={key}
            onClick={() => setSelectedView(key as any)}
            style={{
              flex: 1,
              padding: '8px 6px',
              fontSize: '11px',
              fontWeight: '500',
              borderRadius: '6px',
              border: 'none',
              backgroundColor: selectedView === key ? theme.buttonActive : 'transparent',
              color: selectedView === key ? theme.text : theme.textMuted,
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '2px'
            }}
          >
            <span style={{ fontSize: '14px' }}>{icon}</span>
            <span style={{ fontSize: '9px' }}>{label}</span>
          </button>
        ))}
      </div>

      {/* 主要统计显示 */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
            <span style={{ 
              fontSize: '28px',
              opacity: stats.currentStreak > 0 ? 1 : 0.7,
              transition: 'opacity 0.3s ease'
            }}>
              {display.emoji}
            </span>
            <span style={{ 
              fontSize: '32px', 
              fontWeight: '700', 
              color: theme.text
            }}>
              {display.value}
            </span>
          </div>
          <p style={{
            fontSize: '15px',
            fontWeight: '600',
            color: theme.text,
            margin: '0 0 4px 0'
          }}>
            {display.label}
          </p>
          <p style={{
            fontSize: '12px',
            color: theme.textSecondary,
            margin: 0
          }}>
            {display.desc}
          </p>
        </div>

        {/* 刷新按钮 */}
        <button
          onClick={updateStats}
          style={{
            padding: '10px 14px',
            fontSize: '12px',
            fontWeight: '500',
            backgroundColor: theme.buttonBg,
            color: theme.textSecondary,
            border: `1px solid ${theme.border}`,
            borderRadius: '8px',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            display: 'flex',
            alignItems: 'center',
            gap: '5px'
          }}
        >
          🔄 <span>Refresh</span>
        </button>
      </div>

   
    </div>
  );
};

export default MicrotaskStreakHint;


