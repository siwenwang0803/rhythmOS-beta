import React from 'react';

// RhythmOS colors from the UI spec
const rhythmColors = {
  sand: '#F5E8C7',    // Sand base: warmth and psychological safety
  collapsed: '#AEC6CF', // Gentle calming blue
  wavy: '#C3B1E1',    // Transitional lavender
  stable: '#C5D8A4',  // Grounded light green
  rising: '#FFB347',  // Activating orange-yellow
  accent: '#F7DC6F'   // Soft yellow for CTA/completion
};

const TaskTimelineChart: React.FC = () => {
  const subtasks = JSON.parse(localStorage.getItem('rhythmSubtasks') || '[]');
  
  // Format date for grouping
  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toISOString().split('T')[0];
  };
  
  // Format date in a more readable way
  const formatDisplayDate = (dateStr: string) => {
    const d = new Date(dateStr);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    // Check if date is today or yesterday
    if (d.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (d.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    }
    
    // Otherwise return formatted date
    return d.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: d.getFullYear() !== today.getFullYear() ? 'numeric' : undefined 
    });
  };
  
  const completedTasks = subtasks
    .filter((s: any) => s.status === 'completed' && s.completedAt)
    .sort((a: any, b: any) => new Date(a.completedAt).getTime() - new Date(b.completedAt).getTime());
  
  // Group tasks by date
  const tasksByDate: Record<string, any[]> = {};
  completedTasks.forEach((task: any) => {
    const date = formatDate(task.completedAt);
    if (!tasksByDate[date]) {
      tasksByDate[date] = [];
    }
    tasksByDate[date].push(task);
  });

  // Get color based on difficulty
  const getDifficultyColor = (difficulty: string) => {
    switch(difficulty?.toLowerCase()) {
      case 'minimal': return rhythmColors.collapsed;
      case 'light': return rhythmColors.wavy;
      case 'normal': return rhythmColors.stable;
      case 'challenge': return rhythmColors.rising;
      default: return rhythmColors.sand;
    }
  };

  // Get icon based on difficulty
  const getDifficultyIcon = (difficulty: string) => {
    switch(difficulty?.toLowerCase()) {
      case 'minimal': return '⭐';
      case 'light': return '⭐';
      case 'normal': return '⭐';
      case 'challenge': return '🌟';
      default: return '⭐';
    }
  };
  
  // If no completed tasks, show empty state
  if (completedTasks.length === 0) {
    return (
      <div className="mt-6">
        <div className="flex items-center mb-4">
          <span className="text-xl mr-2">📅</span>
          <h2 className="text-lg font-semibold">Task Completion Timeline</h2>
        </div>
        <div className="bg-gray-50 border border-gray-100 rounded-lg p-6 text-center">
          <p className="text-gray-500 text-sm">No completed tasks yet.</p>
          <p className="text-gray-400 text-xs mt-2">Completed tasks will appear here.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-6">
      <div className="flex items-center mb-4">
        <span className="text-xl mr-2">📅</span>
        <h2 className="text-lg font-semibold">Task Completion Timeline</h2>
      </div>
      
      <div className="relative pl-6 border-l-2 border-gray-200">
        {Object.entries(tasksByDate).map(([date, tasks], dateIndex) => (
          <div key={date} className="mb-6 relative">
            {/* Date indicator */}
            <div 
              className="absolute -left-8 w-6 h-6 rounded-full flex items-center justify-center z-10 shadow-sm"
              style={{ 
                backgroundColor: '#FFFFFF',
                border: `2px solid ${rhythmColors.sand}`
              }}
            >
              <span className="text-xs">📌</span>
            </div>
            
            <div className="mb-2">
              <span 
                className="text-sm font-medium px-3 py-1 rounded-full"
                style={{ 
                  backgroundColor: `${rhythmColors.sand}30`,
                  color: '#333333'
                }}
              >
                {formatDisplayDate(date)}
              </span>
            </div>
            
            <div className="space-y-3">
              {tasks.map((task: any, taskIndex: number) => (
                <div 
                  key={task.id} 
                  className="bg-white rounded-lg p-3 shadow-sm border transition-all duration-300 hover:shadow-md"
                  style={{ 
                    borderColor: getDifficultyColor(task.difficulty),
                    borderLeftWidth: '3px',
                    transform: `translateX(${taskIndex % 2 === 0 ? '0' : '8px'})`,
                    maxWidth: 'calc(100% - 8px)'
                  }}
                >
                  <div className="flex items-start">
                    <div 
                      className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center mr-3 mt-1"
                      style={{ 
                        backgroundColor: getDifficultyColor(task.difficulty) + '30',
                        color: '#333333'
                      }}
                    >
                      <span className="text-xs">{getDifficultyIcon(task.difficulty)}</span>
                    </div>
                    
                    <div className="flex-1">
                      <div className="text-gray-800 text-sm font-medium">
                        {task.text || task.title}
                      </div>
                      
                      <div className="mt-1 flex items-center justify-between">
                        <span 
                          className="text-xs px-2 py-0.5 rounded"
                          style={{ 
                            backgroundColor: getDifficultyColor(task.difficulty) + '20',
                            color: '#555555'
                          }}
                        >
                          {task.difficulty}
                        </span>
                        
                        <span className="text-xs text-gray-400">
                          {new Date(task.completedAt).toLocaleTimeString('en-US', { 
                            hour: 'numeric', 
                            minute: '2-digit',
                            hour12: true 
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TaskTimelineChart;

