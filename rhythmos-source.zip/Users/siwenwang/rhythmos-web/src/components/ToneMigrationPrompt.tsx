import React from 'react'

interface ToneMigrationPromptProps {
  current: string
  suggested: string
  onAccept: (persona: string) => void
  onReject: () => void
}

const personaMap: Record<string, { name: string; emoji: string; quote: string }> = {
  rhea: {
    name: 'Rhea',
    emoji: '💙',
    quote: 'We speak gently, so you can begin again.',
  },
  aurelia: {
    name: 'Aurelia',
    emoji: '💛',
    quote: 'We reflect with clarity.',
  },
  lucis: {
    name: 'Lucis',
    emoji: '💚',
    quote: 'We ground you, so you can grow.',
  },
  niveus: {
    name: 'Niveus',
    emoji: '🧊',
    quote: 'We guide with quiet precision.',
  },
  caelum: {
    name: 'Caelum',
    emoji: '❤️‍🔥',
    quote: 'We speak in momentum.',
  },
}

const ToneMigrationPrompt: React.FC<ToneMigrationPromptProps> = ({
  current,
  suggested,
  onAccept,
  onReject,
}) => {
  const next = personaMap[suggested]

  return (
    <div className="border border-yellow-300 bg-yellow-50 rounded-xl p-4 shadow-md space-y-2">
      <p className="text-sm font-medium text-yellow-800">
        🌬️ Your rhythm is evolving.
      </p>
      <p className="text-sm text-gray-700">
        You've recently been resonating more with <strong>{suggested}</strong> tones.
        Would you like to try <span className="underline">{next.name}</span>'s voice?
      </p>
      <blockquote className="text-xs italic text-gray-500 pl-2 border-l-2 border-yellow-400">
        {next.emoji} {next.quote}
      </blockquote>
      <div className="flex space-x-3 pt-2">
        <button
          className="text-sm px-3 py-1 bg-yellow-400 text-white rounded-md"
          onClick={() => onAccept(suggested)}
        >
          ✅ Switch to {next.name}
        </button>
        <button
          className="text-sm px-3 py-1 text-yellow-700 underline"
          onClick={onReject}
        >
          Not now
        </button>
      </div>
    </div>
  )
}

export default ToneMigrationPrompt
