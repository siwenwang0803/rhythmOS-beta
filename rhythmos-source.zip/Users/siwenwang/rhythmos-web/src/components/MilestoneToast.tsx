import React, { useEffect, useState } from 'react'
import { MilestoneEntry } from '../milestoneTracker'

const MilestoneToast: React.FC<{ milestone: MilestoneEntry }> = ({ milestone }) => {
  const [visible, setVisible] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => setVisible(false), 5000)
    return () => clearTimeout(timer)
  }, [])

  if (!visible) return null

  return (
    <div className="fixed bottom-6 right-6 bg-green-600 text-white text-sm px-4 py-2 rounded-xl shadow-lg z-50">
      ✅ {milestone.message}
    </div>
  )
}

export default MilestoneToast