import React, { useState, useEffect } from 'react';
import { getTagUnlockNarrative } from '../components/TagUnlockNarrator';

interface DigestUnlockedTagsSummaryProps {
  tags?: string[]; // optional - if not provided, will auto-detect
  isDaytime?: boolean;
}

interface TagCondition {
  id: string;
  name: string;
  description: string;
  emoji: string;
  checkCondition: (userData: any) => boolean;
  category: 'microtask' | 'challenge' | 'feedback' | 'streak';
}

// Define all unlockable tags with improved names and emojis
const TAG_CONDITIONS: TagCondition[] = [
  // Microtask tags
  {
    id: 'first_microtask',
    name: 'First Steps',
    emoji: '👣',
    description: 'Completed your first microtask',
    category: 'microtask',
    checkCondition: (userData) => userData.totalMicrotasks >= 1
  },
  {
    id: 'consistency_builder',
    name: 'Consistency Builder',
    emoji: '🏗️',
    description: 'Completed 5 microtasks',
    category: 'microtask',
    checkCondition: (userData) => userData.totalMicrotasks >= 5
  },
  {
    id: 'momentum_master',
    name: 'Momentum Master',
    emoji: '🚀',
    description: 'Completed 15 microtasks',
    category: 'microtask',
    checkCondition: (userData) => userData.totalMicrotasks >= 15
  },
  
  // Streak tags
  {
    id: 'streak_starter',
    name: 'Streak Starter',
    emoji: '🔥',
    description: '3 consecutive days of activity',
    category: 'streak',
    checkCondition: (userData) => userData.currentStreak >= 3
  },
  {
    id: 'week_warrior',
    name: 'Week Warrior',
    emoji: '⚔️',
    description: '7 consecutive days of activity',
    category: 'streak',
    checkCondition: (userData) => userData.currentStreak >= 7
  },
  
  // Challenge tags
  {
    id: 'challenge_explorer',
    name: 'Challenge Explorer',
    emoji: '🗺️',
    description: 'Completed your first challenge',
    category: 'challenge',
    checkCondition: (userData) => userData.totalChallenges >= 1
  },
  {
    id: 'growth_seeker',
    name: 'Growth Seeker',
    emoji: '🌱',
    description: 'Completed 5 challenges',
    category: 'challenge',
    checkCondition: (userData) => userData.totalChallenges >= 5
  },
  
  // Feedback tags
  {
    id: 'expressive_guide',
    name: 'Expressive Guide',
    emoji: '💬',
    description: 'Provided 3 feedback responses',
    category: 'feedback',
    checkCondition: (userData) => userData.totalFeedback >= 3
  },
  {
    id: 'supportive_guardian',
    name: 'Supportive Guardian',
    emoji: '🛡️',
    description: 'Provided 5 feedback responses',
    category: 'feedback',
    checkCondition: (userData) => userData.totalFeedback >= 5
  }
];

// Calculate user data from localStorage
const calculateUserData = () => {
  try {
    console.log('[TagSystem] Calculating user data...');
    
    // Read from localStorage
    const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
    const challengeAttempts = JSON.parse(localStorage.getItem('challengeAttempts') || '[]');
    
    console.log('[TagSystem] Raw data:', {
      rhythmScoreLog: rhythmScoreLog.length,
      challengeAttempts: challengeAttempts.length
    });
    
    // Calculate microtasks
    const microtaskEntries = rhythmScoreLog.filter((entry: any) => 
      entry.actionType === 'microtask_complete' || 
      entry.actionType === 'microtask' ||
      entry.type === 'microtask'
    );
    
    // Calculate challenges  
    const completedChallenges = challengeAttempts.filter((attempt: any) => 
      attempt.completed === true || attempt.status === 'completed'
    );
    
    // Calculate feedback entries
    const feedbackEntries = rhythmScoreLog.filter((entry: any) => 
      entry.actionType === 'feedback' || 
      entry.type === 'feedback' ||
      (entry.feedback && entry.feedback.length > 0)
    );
    
    // Calculate streak
    const calculateStreak = () => {
      if (rhythmScoreLog.length === 0) return 0;
      
      // Group entries by date
      const dateGroups: {[key: string]: any[]} = {};
      rhythmScoreLog.forEach((entry: any) => {
        const date = new Date(entry.timestamp || entry.date).toDateString();
        if (!dateGroups[date]) dateGroups[date] = [];
        dateGroups[date].push(entry);
      });
      
      // Get sorted dates
      const sortedDates = Object.keys(dateGroups).sort((a, b) => 
        new Date(b).getTime() - new Date(a).getTime()
      );
      
      // Calculate consecutive days from today
      let streak = 0;
      const today = new Date().toDateString();
      
      for (const date of sortedDates) {
        const daysDiff = Math.round((new Date(today).getTime() - new Date(date).getTime()) / (1000 * 60 * 60 * 24));
        if (daysDiff === streak) {
          streak++;
        } else {
          break;
        }
      }
      
      return streak;
    };
    
    const userData = {
      totalMicrotasks: microtaskEntries.length,
      totalChallenges: completedChallenges.length,
      totalFeedback: feedbackEntries.length,
      currentStreak: calculateStreak()
    };
    
    console.log('[TagSystem] Calculated user data:', userData);
    return userData;
    
  } catch (error) {
    console.error('[TagSystem] Error calculating user data:', error);
    return {
      totalMicrotasks: 0,
      totalChallenges: 0,
      totalFeedback: 0,
      currentStreak: 0
    };
  }
};

// Check which tags should be unlocked
const checkTagUnlocks = (userData: any): string[] => {
  console.log('[TagSystem] Checking tag unlocks for data:', userData);
  
  const unlockedTags: string[] = [];
  
  TAG_CONDITIONS.forEach(condition => {
    if (condition.checkCondition(userData)) {
      unlockedTags.push(condition.id);
      console.log(`[TagSystem] Tag unlocked: ${condition.id} (${condition.name})`);
    }
  });
  
  console.log('[TagSystem] Total unlocked tags:', unlockedTags);
  return unlockedTags;
};

// Save unlocked tags to localStorage
const saveUnlockedTags = (tags: string[]) => {
  try {
    localStorage.setItem('unlockedTags', JSON.stringify(tags));
    console.log('[TagSystem] Saved unlocked tags:', tags);
  } catch (error) {
    console.error('[TagSystem] Error saving unlocked tags:', error);
  }
};

// Get previously unlocked tags
const getSavedUnlockedTags = (): string[] => {
  try {
    const saved = localStorage.getItem('unlockedTags');
    return saved ? JSON.parse(saved) : [];
  } catch (error) {
    console.error('[TagSystem] Error loading saved tags:', error);
    return [];
  }
};

/**
 * DigestUnlockedTagsSummary - Enhanced component for displaying unlocked tags
 */
const DigestUnlockedTagsSummary: React.FC<DigestUnlockedTagsSummaryProps> = ({ 
  tags,
  isDaytime = true 
}) => {
  const [displayTags, setDisplayTags] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [debugInfo, setDebugInfo] = useState<any>(null);

  // Auto-detect tags if not provided
  useEffect(() => {
    console.log('[DigestUnlockedTagsSummary] Starting tag detection...');
    setIsLoading(true);
    
    try {
      if (tags && tags.length > 0) {
        // Use provided tags
        console.log('[DigestUnlockedTagsSummary] Using provided tags:', tags);
        setDisplayTags(tags);
        setDebugInfo({ provided: true, tags });
      } else {
        // Auto-detect tags
        console.log('[DigestUnlockedTagsSummary] Auto-detecting tags...');
        const userData = calculateUserData();
        const currentlyUnlocked = checkTagUnlocks(userData);
        const previouslyUnlocked = getSavedUnlockedTags();
        
        // Get all unlocked tags (combine current + previous)
        const allUnlockedTags = [...new Set([...previouslyUnlocked, ...currentlyUnlocked])];
        
        // Save the updated list
        saveUnlockedTags(allUnlockedTags);
        
        setDisplayTags(allUnlockedTags);
        setDebugInfo({
          provided: false,
          userData,
          currentlyUnlocked,
          previouslyUnlocked,
          allUnlockedTags
        });
      }
    } catch (error) {
      console.error('[DigestUnlockedTagsSummary] Error in tag detection:', error);
      setDisplayTags([]);
      setDebugInfo({ error: error.message });
    } finally {
      setIsLoading(false);
    }
  }, [tags]);

  // Listen for data updates
  useEffect(() => {
    const handleDataUpdate = () => {
      console.log('[DigestUnlockedTagsSummary] Data updated, rechecking tags...');
      if (!tags) {
        // Only recheck if we're auto-detecting
        const userData = calculateUserData();
        const currentlyUnlocked = checkTagUnlocks(userData);
        const previouslyUnlocked = getSavedUnlockedTags();
        const allUnlockedTags = [...new Set([...previouslyUnlocked, ...currentlyUnlocked])];
        
        saveUnlockedTags(allUnlockedTags);
        setDisplayTags(allUnlockedTags);
      }
    };

    // Listen for various events that might indicate data changes
    window.addEventListener('microtask-completed', handleDataUpdate);
    window.addEventListener('challenge-completed', handleDataUpdate);
    window.addEventListener('feedback-submitted', handleDataUpdate);
    window.addEventListener('storage', handleDataUpdate);

    return () => {
      window.removeEventListener('microtask-completed', handleDataUpdate);
      window.removeEventListener('challenge-completed', handleDataUpdate);
      window.removeEventListener('feedback-submitted', handleDataUpdate);
      window.removeEventListener('storage', handleDataUpdate);
    };
  }, [tags]);

  // Theme colors
  const theme = {
    background: isDaytime ? '#FFFFFF' : '#2A2A2A',
    cardBg: isDaytime ? '#FFFFFF' : '#3A3A3A',
    text: isDaytime ? '#1F2937' : '#F3F4F6',
    textSecondary: isDaytime ? '#6B7280' : '#9CA3AF',
    textMuted: isDaytime ? '#9CA3AF' : '#6B7280',
    border: isDaytime ? '#E5E7EB' : '#4B5563',
    accent: '#F59E0B',
    success: '#10B981',
    warning: '#F59E0B',
    shadow: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(0, 0, 0, 0.3)',
    highlight: isDaytime ? 'rgba(245, 158, 11, 0.1)' : 'rgba(245, 158, 11, 0.2)',
  };

  // Get tag info by ID
  const getTagInfo = (tagId: string) => {
    return TAG_CONDITIONS.find(tag => tag.id === tagId) || {
      id: tagId,
      name: tagId.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' '),
      emoji: '🏷️',
      description: 'Achievement unlocked',
      category: 'microtask' as const
    };
  };

  // Tag-specific growth suggestions
  const getGrowthSuggestion = (tagId: string): string => {
    const suggestions: Record<string, string> = {
      'first_microtask': 'Celebrate this milestone! Consider establishing a daily routine with small, achievable tasks.',
      'consistency_builder': 'You\'re developing excellent habits! Try linking microtasks to existing routines for sustained growth.',
      'momentum_master': 'Impressive dedication! Explore how your microtasks connect to your broader life goals.',
      'streak_starter': 'Great momentum! Focus on maintaining consistency rather than perfection.',
      'week_warrior': 'A full week of commitment! Consider gradually increasing your daily challenges.',
      'challenge_explorer': 'Congratulations on embracing challenges! Reflect on the insights you\'ve gained.',
      'growth_seeker': 'You\'re actively pursuing growth! Think about which challenges sparked the most learning.',
      'expressive_guide': 'Your feedback creates positive impact! Consider expanding your mentoring reach.',
      'supportive_guardian': 'You\'re a consistent source of wisdom! Your guidance helps others grow.',
    };
    
    return suggestions[tagId] || 'Continue to explore and develop this strength in your daily life.';
  };

  // Calculate progress to next tag unlock
  const getProgressToNextUnlock = () => {
    const userData = debugInfo?.userData || calculateUserData();
    
    // Find the next tag to unlock
    const upcomingTags = TAG_CONDITIONS.filter(condition => 
      !displayTags.includes(condition.id)
    ).sort((a, b) => {
      // Sort by how close user is to unlocking
      const aProgress = getTagProgress(a, userData);
      const bProgress = getTagProgress(b, userData);
      return bProgress - aProgress;
    });
    
    if (upcomingTags.length === 0) return { progress: 100, nextTag: null };
    
    const nextTag = upcomingTags[0];
    const progress = getTagProgress(nextTag, userData);
    
    return { progress, nextTag };
  };

  // Calculate progress towards a specific tag
  const getTagProgress = (tag: TagCondition, userData: any): number => {
    switch (tag.category) {
      case 'microtask':
        const microtaskTarget = tag.id === 'first_microtask' ? 1 :
                               tag.id === 'consistency_builder' ? 5 : 15;
        return Math.min(100, (userData.totalMicrotasks / microtaskTarget) * 100);
      
      case 'streak':
        const streakTarget = tag.id === 'streak_starter' ? 3 : 7;
        return Math.min(100, (userData.currentStreak / streakTarget) * 100);
      
      case 'challenge':
        const challengeTarget = tag.id === 'challenge_explorer' ? 1 : 5;
        return Math.min(100, (userData.totalChallenges / challengeTarget) * 100);
      
      case 'feedback':
        const feedbackTarget = tag.id === 'expressive_guide' ? 3 : 5;
        return Math.min(100, (userData.totalFeedback / feedbackTarget) * 100);
      
      default:
        return 0;
    }
  };

  if (isLoading) {
    return (
      <div style={{
        backgroundColor: theme.cardBg,
        borderRadius: '12px',
        padding: '24px',
        border: `1px solid ${theme.border}`,
        boxShadow: `0 2px 8px ${theme.shadow}`,
        textAlign: 'center'
      }}>
        <div style={{
          fontSize: '32px',
          marginBottom: '12px'
        }}>🔍</div>
        <p style={{
          color: theme.textSecondary,
          fontSize: '14px',
          margin: 0
        }}>
          Discovering your unlocked achievements...
        </p>
      </div>
    );
  }
  
  if (!displayTags || displayTags.length === 0) {
    const userData = debugInfo?.userData || calculateUserData();
    
    return (
      <div style={{
        backgroundColor: theme.cardBg,
        borderRadius: '12px',
        padding: '24px',
        border: `1px solid ${theme.border}`,
        boxShadow: `0 2px 8px ${theme.shadow}`,
      }}>
        <div style={{
          textAlign: 'center',
          marginBottom: '24px'
        }}>
          <div style={{
            fontSize: '48px',
            marginBottom: '12px'
          }}>🌱</div>
          <h3 style={{ 
            fontSize: '18px', 
            fontWeight: 600, 
            margin: '0 0 8px 0',
            color: theme.text
          }}>
            Your Achievement Journey Begins
          </h3>
          <p style={{
            color: theme.textSecondary,
            fontSize: '14px',
            margin: 0
          }}>
            Complete activities to unlock your first achievement badge
          </p>
        </div>
        
        <div style={{
          backgroundColor: theme.highlight,
          borderRadius: '8px',
          padding: '16px',
          marginBottom: '24px'
        }}>
          <h4 style={{
            fontSize: '14px',
            fontWeight: 600,
            color: theme.text,
            margin: '0 0 12px 0'
          }}>
            Current Progress
          </h4>
          
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '12px'
          }}>
            <div style={{
              backgroundColor: theme.cardBg,
              padding: '12px',
              borderRadius: '6px',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '20px', marginBottom: '4px' }}>📝</div>
              <div style={{ fontSize: '18px', fontWeight: 'bold', color: theme.text }}>{userData.totalMicrotasks}</div>
              <div style={{ fontSize: '12px', color: theme.textMuted }}>Microtasks</div>
            </div>
            
            <div style={{
              backgroundColor: theme.cardBg,
              padding: '12px',
              borderRadius: '6px',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '20px', marginBottom: '4px' }}>🔥</div>
              <div style={{ fontSize: '18px', fontWeight: 'bold', color: theme.text }}>{userData.currentStreak}</div>
              <div style={{ fontSize: '12px', color: theme.textMuted }}>Day Streak</div>
            </div>
            
            <div style={{
              backgroundColor: theme.cardBg,
              padding: '12px',
              borderRadius: '6px',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '20px', marginBottom: '4px' }}>🎯</div>
              <div style={{ fontSize: '18px', fontWeight: 'bold', color: theme.text }}>{userData.totalChallenges}</div>
              <div style={{ fontSize: '12px', color: theme.textMuted }}>Challenges</div>
            </div>
            
            <div style={{
              backgroundColor: theme.cardBg,
              padding: '12px',
              borderRadius: '6px',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '20px', marginBottom: '4px' }}>💭</div>
              <div style={{ fontSize: '18px', fontWeight: 'bold', color: theme.text }}>{userData.totalFeedback}</div>
              <div style={{ fontSize: '12px', color: theme.textMuted }}>Feedback</div>
            </div>
          </div>
        </div>
        
        <div style={{
          backgroundColor: isDaytime ? 'rgba(59, 130, 246, 0.05)' : 'rgba(59, 130, 246, 0.1)',
          border: `1px solid ${isDaytime ? 'rgba(59, 130, 246, 0.2)' : 'rgba(59, 130, 246, 0.3)'}`,
          borderRadius: '8px',
          padding: '16px',
          textAlign: 'center'
        }}>
          <div style={{ fontSize: '20px', marginBottom: '8px' }}>✨</div>
          <p style={{
            fontSize: '13px',
            color: theme.textSecondary,
            margin: 0,
            lineHeight: 1.5
          }}>
            Your first achievement badge awaits! Complete any microtask, challenge, or provide feedback to unlock your first tag.
          </p>
        </div>
        
        {/* Debug info */}
        <div 
          onClick={() => console.log('[DigestUnlockedTagsSummary] Debug info:', debugInfo)}
          style={{
            fontSize: '12px',
            color: theme.textMuted,
            cursor: 'pointer',
            textAlign: 'center',
            marginTop: '16px',
            textDecoration: 'underline'
          }}
        >
          🔧 Debug info
        </div>
      </div>
    );
  }

  const { progress, nextTag } = getProgressToNextUnlock();

  return (
    <div style={{
      backgroundColor: theme.cardBg,
      borderRadius: '12px',
      padding: '24px',
      border: `1px solid ${theme.border}`,
      boxShadow: `0 2px 8px ${theme.shadow}`,
    }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '20px'
      }}>
        <h3 style={{ 
          fontSize: '18px', 
          fontWeight: 600, 
          margin: 0,
          color: theme.text,
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <span style={{ fontSize: '20px' }}>🏆</span>
          Achievement Badges
        </h3>
        <div style={{
          backgroundColor: theme.highlight,
          color: theme.text,
          padding: '4px 12px',
          borderRadius: '20px',
          fontSize: '12px',
          fontWeight: 600
        }}>
          {displayTags.length} Unlocked
        </div>
      </div>
      
      {/* Unlocked tags grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '16px',
        marginBottom: '24px'
      }}>
        {displayTags.map((tagId) => {
          const tagInfo = getTagInfo(tagId);
          const narrative = getTagUnlockNarrative(tagId);
          
          return (
            <div 
              key={tagId} 
              style={{
                backgroundColor: theme.highlight,
                borderRadius: '12px',
                padding: '20px',
                border: `1px solid ${isDaytime ? 'rgba(245, 158, 11, 0.3)' : 'rgba(245, 158, 11, 0.4)'}`,
                transition: 'transform 0.2s ease, box-shadow 0.2s ease',
                cursor: 'default'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = `0 4px 16px ${theme.shadow}`;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              <div style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '12px'
              }}>
                <div style={{
                  fontSize: '32px',
                  lineHeight: 1
                }}>
                  {tagInfo.emoji}
                </div>
                <div style={{ flex: 1 }}>
                  <h4 style={{
                    fontSize: '16px',
                    fontWeight: 600,
                    color: theme.text,
                    margin: '0 0 4px 0'
                  }}>
                    {tagInfo.name}
                  </h4>
                  
                  <p style={{
                    fontSize: '13px',
                    color: theme.textSecondary,
                    margin: '0 0 12px 0'
                  }}>
                    {tagInfo.description}
                  </p>
                  
                  {narrative && (
                    <p style={{
                      fontSize: '14px',
                      color: theme.text,
                      lineHeight: 1.5,
                      margin: '0 0 16px 0',
                      fontStyle: 'italic'
                    }}>
                      "{narrative}"
                    </p>
                  )}
                  
                  <div style={{
                    backgroundColor: isDaytime ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.2)',
                    borderLeft: `3px solid ${theme.accent}`,
                    padding: '10px 12px',
                    borderRadius: '0 6px 6px 0',
                    fontSize: '13px',
                    color: theme.text
                  }}>
                    <span style={{ fontWeight: 500 }}>💡 Growth tip:</span> {getGrowthSuggestion(tagId)}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Progress to next unlock */}
      {nextTag && (
        <div style={{
          backgroundColor: isDaytime ? 'rgba(99, 102, 241, 0.05)' : 'rgba(99, 102, 241, 0.1)',
          border: `1px solid ${isDaytime ? 'rgba(99, 102, 241, 0.2)' : 'rgba(99, 102, 241, 0.3)'}`,
          borderRadius: '12px',
          padding: '20px',
          marginBottom: '24px'
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: '12px'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span style={{ fontSize: '20px' }}>{nextTag.emoji}</span>
              <span style={{
                fontSize: '14px',
                fontWeight: 600,
                color: theme.text
              }}>
                Next: {nextTag.name}
              </span>
            </div>
            <span style={{
              fontSize: '14px',
              fontWeight: 600,
              color: theme.accent
            }}>
              {Math.round(progress)}%
            </span>
          </div>
          
          <div style={{
            height: '8px',
            backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.1)' : 'rgba(255, 255, 255, 0.1)',
            borderRadius: '4px',
            overflow: 'hidden',
            marginBottom: '8px'
          }}>
            <div style={{
              height: '100%',
              width: `${progress}%`,
              backgroundColor: theme.accent,
              borderRadius: '4px',
              transition: 'width 1s ease-out'
            }} />
          </div>
          
          <p style={{
            fontSize: '13px',
            color: theme.textSecondary,
            margin: 0
          }}>
            {nextTag.description}
          </p>
        </div>
      )}
      
      {/* Weekly reflection */}
      <div style={{
        backgroundColor: isDaytime ? 'rgba(236, 72, 153, 0.05)' : 'rgba(236, 72, 153, 0.1)',
        border: `1px solid ${isDaytime ? 'rgba(236, 72, 153, 0.2)' : 'rgba(236, 72, 153, 0.3)'}`,
        borderRadius: '12px',
        padding: '20px'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'flex-start',
          gap: '12px'
        }}>
          <span style={{
            fontSize: '24px',
            lineHeight: 1
          }}>
            💭
          </span>
          <div>
            <h4 style={{
              fontSize: '14px',
              fontWeight: 600,
              color: theme.text,
              margin: '0 0 8px 0'
            }}>
              Weekly Reflection
            </h4>
            <p style={{
              fontSize: '14px',
              color: theme.text,
              lineHeight: 1.6,
              margin: 0
            }}>
              How might these unlocked qualities guide your choices this week? Consider the unique strengths you're developing and how they can shape your daily rhythms.
            </p>
          </div>
        </div>
      </div>
      
      {/* Debug info */}
      <div 
        onClick={() => console.log('[DigestUnlockedTagsSummary] Debug info:', debugInfo)}
        style={{
          fontSize: '12px',
          color: theme.textMuted,
          cursor: 'pointer',
          textAlign: 'center',
          marginTop: '16px',
          textDecoration: 'underline'
        }}
      >
        🔧 Debug info
      </div>
    </div>
  );
};

export default DigestUnlockedTagsSummary;