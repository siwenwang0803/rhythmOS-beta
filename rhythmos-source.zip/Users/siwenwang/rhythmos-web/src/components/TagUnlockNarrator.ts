// TagUnlockNarrator.ts (expanded)

/**
 * Return system narrative text when a tag is unlocked.
 */

export function getTagUnlockNarrative(tagId: string): string {
    switch (tagId) {
      case 'gentle_builder':
        return '🎉 Gentle Builder unlocked! You’ve completed 10 reset microtasks — building rhythm through gentle repetition.';
      case 'resilient_resetter':
        return '💪 Resilient Resetter unlocked! You’ve completed 25 reset actions — your consistency is becoming a strength.';
      case 'directive_climber':
        return '🚀 Directive Climber unlocked! You’ve given 10 aligned directive reflections — showing bold identity momentum.';
      case 'multi_voice_explorer':
        return '🎭 Multi-Voice Explorer unlocked! You’ve reflected across 5 different tones — embracing expressive diversity.';
      case 'balanced_reflector':
        return '⚖️ Balanced Reflector unlocked! A balance of 3 okay and 3 aligned responses shows thoughtful feedback growth.';
      case 'identity_consistent':
        return '🧭 Consistency Master unlocked! You’ve stayed aligned with one identity for 3 entries in a row.';
      default:
        return `🎉 New identity tag unlocked: ${tagId}`;
    }
  }
  
  /**
   * Return tags unlocked in the last N days.
   */
  export function getWeeklyUnlockedTags(days = 7): string[] {
    const signatureMap = window.signatureMap || globalThis.signatureMap;
    const tagLog = signatureMap?.tagLog || [];
  
    const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  
    // tagLog[] can be array of strings or objects { tagId, timestamp }
    const unlocked = tagLog
      .filter((entry: any) => {
        if (typeof entry === 'string') return true; // fallback
        if (entry?.timestamp) {
          const ts = new Date(entry.timestamp);
          return ts >= cutoff;
        }
        return false;
      })
      .map((entry: any) => (typeof entry === 'string' ? entry : entry.tagId));
  
    return Array.from(new Set(unlocked)); // remove duplicates
  }
  
  