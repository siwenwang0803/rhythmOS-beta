// components/RecommendedCREBlockList.tsx

import React from 'react'
import { getRecommendedCREBlockList } from '../logic/getRecommendedCREBlockList'
import { CREBlock } from '../cre/creBlockLibrary'

const RecommendedCREBlockList: React.FC = () => {
  const blocks: CREBlock[] = getRecommendedCREBlockList(3)

  if (blocks.length === 0) {
    return <p className="text-sm text-gray-500 italic">No recommended CREs found. Give more feedback to improve suggestions.</p>
  }

  return (
    <div className="space-y-4">
      {blocks.map((block, i) => (
        <div key={i} className="border bg-white p-4 rounded shadow-sm space-y-2">
          <p className="text-base font-semibold text-gray-800">“{block.cue}”</p>
          <p className="text-sm text-gray-600 whitespace-pre-wrap">{block.paragraph}</p>
          <p className="text-xs text-gray-500">
            Persona: <strong>{block.persona}</strong> · Tone: <strong>{block.tone}</strong>
          </p>
        </div>
      ))}
    </div>
  )
}

export default RecommendedCREBlockList
