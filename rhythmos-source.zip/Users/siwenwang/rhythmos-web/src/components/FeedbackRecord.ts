// feedbackRecord.ts

export interface CREFeedbackEntry {
  taskType: string
  variant: string
  tone: string
  persona: string
  score: number
  source: 'system' | 'studio' | 'replay'
  timestamp: number
}

export function addFeedbackRecord(entry: CREFeedbackEntry) {
  const raw = localStorage.getItem('creFeedbackLog')
  const log = raw ? JSON.parse(raw) : []
  log.push(entry)
  localStorage.setItem('creFeedbackLog', JSON.stringify(log))
}