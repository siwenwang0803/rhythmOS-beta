import React from 'react'
import { CREGrowthLogEntry } from '../creGrowthLog'
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

const CRETrainingSummary: React.FC = () => {
  const raw = localStorage.getItem('creGrowthLog')
  const log: CREGrowthLogEntry[] = raw ? JSON.parse(raw) : []

  const variantUsage: Record<string, number> = {}
  const flowData: { time: string; score: number }[] = []

  for (const e of log) {
    if (e.variant) variantUsage[e.variant] = (variantUsage[e.variant] || 0) + 1
    if (e.score !== undefined) {
      flowData.push({
        time: new Date(e.timestamp).toLocaleDateString(),
        score: e.score
      })
    }
  }

  const radarData = Object.entries(variantUsage).map(([variant, count]) => ({
    variant,
    count
  }))

  return (
    <div className="mt-10 space-y-8">
      <h2 className="text-xl font-bold text-gray-800">📊 CRE Training Summary</h2>

      {radarData.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-gray-700 mb-1">Style Variant Radar</h3>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={radarData}>
              <PolarGrid />
              <PolarAngleAxis dataKey="variant" />
              <PolarRadiusAxis />
              <Radar name="Use" dataKey="count" stroke="#4f46e5" fill="#818cf8" fillOpacity={0.6} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      )}

      {flowData.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-gray-700 mb-1">Flow Score Trend</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={flowData}>
              <XAxis dataKey="time" tick={{ fontSize: 10 }} />
              <YAxis domain={[0, 5]} />
              <Tooltip />
              <Line type="monotone" dataKey="score" stroke="#10b981" strokeWidth={2} dot={{ r: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  )
}

export default CRETrainingSummary