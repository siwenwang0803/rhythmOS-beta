// /components/HowXpWorks.tsx

import React, { useState } from 'react';
import XpInfoModal from './XpInfoModal';

const HowXpWorks: React.FC = () => {
  const [modalOpen, setModalOpen] = useState(false);
  
  return (
    <div className="bg-white rounded-lg p-4 mt-6 shadow-sm border border-[#333333]/10">
      <h3 className="text-md font-medium text-[#333333] mb-3">How XP Works</h3>
      <p className="text-sm text-[#333333]/80">
        Earn experience by completing identity cues, providing feedback, and maintaining consistency. 
        Each persona levels up with different actions aligned to their nature.
      </p>
      <div className="mt-3 p-3 bg-[#F7DC6F]/10 rounded-lg">
        <h4 className="text-sm font-medium text-[#333333]">Daily XP Opportunities:</h4>
        <ul className="mt-2 text-sm text-[#333333]/80 space-y-1">
          <li className="flex items-baseline">
         
         
          </li>
          <li className="flex items-baseline">
            <span className="text-[#F7DC6F] mr-2">•</span>
            <span>Challenge completion: <b>+6 XP</b> (max twice daily)</span>
          </li>
          <li className="flex items-baseline">
            <span className="text-[#F7DC6F] mr-2">•</span>
            <span>Microtask completion: <b>+2 XP</b> (max three times daily)</span>
          </li>
        </ul>
      </div>
      <div className="mt-4 flex justify-end">
        <button 
          onClick={() => setModalOpen(true)} 
          className="text-sm bg-[#F7DC6F]/20 hover:bg-[#F7DC6F]/30 transition-colors text-[#333333] py-1 px-3 rounded-md"
        >
          Learn More
        </button>
      </div>
      
      <XpInfoModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </div>
  );
};

export default HowXpWorks;