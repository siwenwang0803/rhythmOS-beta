// 修复后的 SubtaskSuggestionCard.tsx 代码片段

import React, { useState, useRef } from 'react';
import { SuggestedSubtask } from '../logic/subtask/generateSubtaskSuggestions';
import { writeRhythmScore } from '../utils/writeRhythmScore';

interface Props {
  subtask: SuggestedSubtask;
  goalId: string; // 必需传入goalId
  onMarkComplete?: () => void;
  isCompleted?: boolean;
  subtaskScore?: number; // 可选的子任务分数
}

// 分数动画组件
const ScoreAnimation = ({ isVisible, onAnimationEnd, points = 0.5 }: { isVisible: boolean, onAnimationEnd: () => void, points?: number }) => {
  React.useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onAnimationEnd();
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onAnimationEnd]);

  if (!isVisible) return null;

  // 定义动画的CSS样式
  const animationStyle = {
    animation: 'float-up 1.5s ease-out forwards',
    textShadow: '0 0 3px rgba(0,0,0,0.3), 0 0 5px rgba(0,0,0,0.2)',
    zIndex: 10,
  };

  // 定义一次性使用的样式
  const keyframes = `
    @keyframes float-up {
      0% {
        opacity: 0;
        transform: translate(0, 0);
      }
      20% {
        opacity: 1;
      }
      100% {
        opacity: 0;
        transform: translate(0, -50px);
      }
    }
  `;

  return (
    <>
      <style>{keyframes}</style>
      <div 
        className="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 text-sm font-bold text-green-600"
        style={animationStyle}
      >
        +{points} Rhythm
      </div>
    </>
  );
};

const SubtaskSuggestionCard: React.FC<Props> = ({ 
  subtask, 
  goalId, 
  onMarkComplete, 
  isCompleted = false,
  subtaskScore = 0.5 // 默认子任务分数为0.5分
}) => {
  const [completed, setCompleted] = useState(isCompleted);
  const [showAnimation, setShowAnimation] = useState(false);
  const [actualScore, setActualScore] = useState(0); // 只定义一次状态变量
  const cardRef = useRef<HTMLDivElement>(null);
  
  const handleMarkComplete = () => {
    if (completed) return;
    
    // 写入节奏分数 (子任务默认0.5分，但传入goalId进行单Goal分数限制)
    // 修改为接收实际记录的分数
    const actualScore = writeRhythmScore(subtaskScore, 'subtask_complete', goalId);
    
    // 只有在实际加分大于0时才更新状态和显示动画
    if (actualScore > 0) {
      // 更新UI状态
      setCompleted(true);
      
      // 设置实际得分
      setActualScore(actualScore);
      setShowAnimation(true);
      
      // 调用父组件的回调
      if (onMarkComplete) onMarkComplete();
      
      // 触发更新事件
      window.dispatchEvent(new Event('rhythm-score-updated'));
    }
  };
  
  return (
    <div 
      ref={cardRef}
      className="bg-white p-4 rounded-xl shadow-sm mb-3 relative"
    >
      <div className="flex items-start gap-3 mb-2">
        <div className="text-lg">
          🧭
        </div>
        <div className="flex-1 font-medium">
          {subtask.text}
        </div>
      </div>

      <div className="text-sm text-gray-600 ml-8 mb-3">
        {subtask.cue}
      </div>

      <div className="flex items-center justify-between">
        <div className="text-xs text-gray-500">
          {subtask.tone} tone · {subtask.taskType}
        </div>

        {!completed ? (
          <button 
            onClick={handleMarkComplete}
            className="px-3 py-1.5 bg-blue-50 text-blue-700 rounded-md text-sm hover:bg-blue-100 transition"
          >
            ✅ Mark as done
          </button>
        ) : (
          <div className="px-3 py-1.5 bg-green-50 text-green-700 rounded-md text-sm">
            ✅ Completed
          </div>
        )}
      </div>
      
      {/* 分数动画 */}
      {cardRef.current && showAnimation && (
        <ScoreAnimation 
          isVisible={showAnimation} 
          onAnimationEnd={() => setShowAnimation(false)} 
          points={actualScore}
        />
      )}
    </div>
  );
};

export default SubtaskSuggestionCard;