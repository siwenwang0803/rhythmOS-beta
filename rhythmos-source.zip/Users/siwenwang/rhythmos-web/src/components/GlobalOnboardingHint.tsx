import React from 'react';
import { useNavigate } from 'react-router-dom';

const GlobalOnboardingHint: React.FC = () => {
  const navigate = useNavigate();
  const initPersona = localStorage.getItem('initPersona');
  const dismissed = localStorage.getItem('globalOnboardingHintDismissed');

  if (initPersona || dismissed === 'true') return null;

  const handleDismiss = () => {
    localStorage.setItem('globalOnboardingHintDismissed', 'true');
  };

  return (
    <div className="mb-6 px-4 py-3 bg-blue-50 border border-blue-300 rounded-lg shadow-sm flex items-center justify-between text-sm text-blue-900">
      <div>
        🎓 First time here? Start with the onboarding flow.
      </div>
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate('/onboarding/step1')}
          className="px-3 py-1 bg-blue-600 text-white rounded text-xs"
        >
          Start Onboarding
        </button>
        <button
          onClick={handleDismiss}
          className="text-blue-500 hover:underline text-xs"
        >
          Dismiss
        </button>
      </div>
    </div>
  );
};

export default GlobalOnboardingHint;
