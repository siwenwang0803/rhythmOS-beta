// RhythmFeedbackHint.tsx

import React from 'react'

interface RhythmFeedbackHintProps {
  trend: string
  tone: string
  persona: string
}

// 系统节奏状态主句 + 副句结构
const FEEDBACK_HINTS: Record<
  string,
  { headline: string; subline: string }
> = {
  collapsed: {
    headline: 'We’re here with you.',
    subline: 'Soft support is our starting point.',
  },
  wavy: {
    headline: 'Your rhythm is balancing.',
    subline: 'We’ll move with care, one tone at a time.',
  },
  stable: {
    headline: 'You’re holding steady.',
    subline: 'Clarity leads. You’re in sync with your rhythm.',
  },
  rising: {
    headline: 'You’re gaining momentum.',
    subline: 'Expect sharper, more directive guidance.',
  },
}

// persona 个性描述句
const personaSummary: Record<string, string> = {
  rhea: 'We speak gently, so you can begin again.',
  aurelia: 'We reflect with clarity.',
  lucis: 'We ground you, so you can grow.',
  niveus: 'We guide with quiet precision.',
  caelum: 'We speak in momentum.',
}

const RhythmFeedbackHint: React.FC<RhythmFeedbackHintProps> = ({
  trend,
  tone,
  persona,
}) => {
  const hint = FEEDBACK_HINTS[trend] || {
    headline: 'Feedback received.',
    subline: 'Your rhythm has been updated.',
  }

  const personaLine = personaSummary[persona] || ''

  return (
    <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-sm text-gray-700 shadow-sm space-y-1">
      <p className="font-medium">📡 Feedback Registered</p>
      <p className="">{hint.headline}</p>
      <p className="text-gray-600">{hint.subline}</p>
      <p className="text-xs text-gray-500 italic">
        Persona: {persona} · Tone: {tone}
      </p>
      {personaLine && (
        <p className="text-xs text-gray-400 mt-1 italic">{personaLine}</p>
      )}
    </div>
  )
}

export default RhythmFeedbackHint

