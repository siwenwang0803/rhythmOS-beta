// /components/XpInfoModal.tsx

import React from 'react';
import { titleMap, xpMilestones } from '../utils/xpEngine';

interface XpInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// 添加到 XpInfoModal.tsx 文件顶部

const personaColorMap: Record<string, string> = {
    rhea: "#F5CFCF",
    caelum: "#4B6587",
    aurelia: "#D8A7CA",
    lucis: "#F8C1CC",
    niveus: "#DDEBCF"
  };

const personaDescriptions: Record<string, {
  description: string;
  actions: string[];
  color: string;
}> = {
  rhea: {
    description: "Focuses on emotional understanding and empathic connection.",
    actions: [
      "Provide emotional reflections (+5 XP)",
      "Complete vulnerability exercises (+8 XP)",
      "Daily emotional check-ins (+3 XP)"
    ],
    color: "#F5CFCF"
  },
  caelum: {
    description: "Emphasizes clarity, decisiveness, and focused action.",
    actions: [
      "Complete action-oriented tasks (+5 XP)",
      "Decision making exercises (+8 XP)",
      "Set clear boundaries (+3 XP)"
    ],
    color: "#4B6587"
  },
  aurelia: {
    description: "Rational analysis and structured reflection.",
    actions: [
      "Analytical problem-solving (+5 XP)",
      "System evaluation exercises (+8 XP)",
      "Critical thinking practice (+3 XP)"
    ],
    color: "#D8A7CA"
  },
  lucis: {
    description: "Cultivates calm presence and grounded action.",
    actions: [
      "Mindfulness practices (+5 XP)",
      "Embodiment exercises (+8 XP)",
      "Present-moment awareness (+3 XP)"
    ],
    color: "#F8C1CC"
  },
  niveus: {
    description: "Pattern recognition and structured growth cycles.",
    actions: [
      "Identify behavioral patterns (+5 XP)",
      "Feedback integration (+8 XP)",
      "Create growth metrics (+3 XP)"
    ],
    color: "#DDEBCF"
  }
};

const XpInfoModal: React.FC<XpInfoModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-auto">
      <div className="bg-[#F5E8C7] rounded-lg w-full max-w-3xl max-h-[90vh] overflow-auto">
        <div className="sticky top-0 bg-[#F5E8C7] p-6 pb-3 border-b border-[#333333]/10 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-[#333333]">The RhythmOS Experience System</h2>
          <button 
            onClick={onClose} 
            className="w-8 h-8 flex items-center justify-center rounded-full bg-[#F7DC6F]/20 hover:bg-[#F7DC6F]/40 text-[#333333] transition-colors"
          >
            &times;
          </button>
        </div>
        
        <div className="p-6 space-y-8">
          {/* System Explanation */}
          <div className="bg-white/80 rounded-lg p-4 shadow-sm">
            <h3 className="text-xl font-semibold text-[#333333] mb-3">Understanding XP & Growth</h3>
            <p className="text-[#333333]/80">
              The RhythmOS experience system tracks your development across five personas, each representing 
              a key aspect of a balanced identity. As you engage with identity cues, provide feedback, and 
              maintain consistency, you earn XP that reflects your growth in each dimension.
            </p>
            
            <div className="mt-4 p-3 bg-[#F7DC6F]/20 rounded-lg">
              <p className="text-sm text-[#333333]/80 italic">
                "Your identity isn't fixed—it's a dynamic interplay of different aspects that grow and 
                evolve through consistent action aligned with your values."
              </p>
            </div>
          </div>
          
          {/* Persona XP Guide */}
          

{/* Persona XP Guide */}
<div>
  <h3 className="text-xl font-semibold text-[#333333] mb-4">Persona XP Guide</h3>
  
  <div className="bg-white rounded-lg p-5 shadow-sm mb-6">
    <h4 className="text-lg font-medium text-[#333333] mb-3">Daily XP Opportunities</h4>
    
    <div className="overflow-x-auto">
      <table className="w-full bg-white rounded-lg">
        <thead>
          <tr className="bg-[#F7DC6F]/20">
            <th className="p-3 text-left">Activity</th>
            <th className="p-3 text-left">XP Earned</th>
            <th className="p-3 text-left">Daily Limit</th>
            <th className="p-3 text-left">Max Potential XP</th>
          </tr>
        </thead>
        <tbody>

          <tr className="border-t border-[#333333]/10">
            <td className="p-3">Challenge Completion</td>
            <td className="p-3">+6 XP</td>
            <td className="p-3">Twice daily</td>
            <td className="p-3">12 XP</td>
          </tr>
          <tr className="border-t border-[#333333]/10">
            <td className="p-3">Microtask Completion</td>
            <td className="p-3">+2 XP</td>
            <td className="p-3">Three times daily</td>
            <td className="p-3">6 XP</td>
          </tr>
          <tr className="border-t border-[#333333]/10 font-medium bg-[#F7DC6F]/10">
            <td className="p-3">Total Potential Daily XP</td>
            <td className="p-3"></td>
            <td className="p-3"></td>
            <td className="p-3">18 XP</td>
          </tr>
        </tbody>
      </table>
    </div>
    
    <p className="mt-4 text-sm text-[#333333]/80">
      The system is designed to reward consistent daily engagement rather than occasional intensive sessions. 
      Daily limits ensure balanced growth across all activities and personas.
    </p>
  </div>

</div>
          
          {/* Level Progression */}
          <div>
            <h3 className="text-xl font-semibold text-[#333333] mb-4">Level Progression</h3>
            
            <div className="overflow-x-auto">
              <table className="w-full bg-white rounded-lg shadow-sm">
                <thead>
                  <tr className="bg-[#F7DC6F]/20">
                    <th className="p-3 text-left">Level</th>
                    <th className="p-3 text-left">XP Range</th>
                    <th className="p-3 text-left">Rhea</th>
                    <th className="p-3 text-left">Caelum</th>
                    <th className="p-3 text-left">Aurelia</th>
                    <th className="p-3 text-left">Lucis</th>
                    <th className="p-3 text-left">Niveus</th>
                  </tr>
                </thead>
                <tbody>
                  {[0, 1, 2].map((level) => (
                    <tr key={level} className="border-t border-[#333333]/10">
                      <td className="p-3 font-medium">{level + 1}</td>
                      <td className="p-3">
                        {level === 0 
                          ? `0-${xpMilestones[1]-1}` 
                          : level === 1 
                            ? `${xpMilestones[1]}-${xpMilestones[2]-1}` 
                            : `${xpMilestones[2]}+`
                        }
                      </td>
                      <td className="p-3">{titleMap.rhea[level]}</td>
                      <td className="p-3">{titleMap.caelum[level]}</td>
                      <td className="p-3">{titleMap.aurelia[level]}</td>
                      <td className="p-3">{titleMap.lucis[level]}</td>
                      <td className="p-3">{titleMap.niveus[level]}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          
          {/* Special Rewards */}
          <div className="bg-gradient-to-r from-[#F5E8C7] to-[#F7DC6F]/30 rounded-lg p-5 shadow-sm">
            <h3 className="text-xl font-semibold text-[#333333] mb-3">Special Rewards & Synergies</h3>
            
            <div className="space-y-3">
              <div className="bg-white/70 p-3 rounded-lg">
                <h4 className="font-medium flex items-center"><span className="mr-2">🔓</span> Level 3 Unlocks</h4>
                <p className="text-sm mt-1 text-[#333333]/80">
                  Reaching level 3 in any persona unlocks advanced identity tools and reflection capabilities specific to that persona's strengths.
                </p>
              </div>
              
              <div className="bg-white/70 p-3 rounded-lg">
                <h4 className="font-medium flex items-center"><span className="mr-2">⚡</span> Persona Synergy</h4>
                <p className="text-sm mt-1 text-[#333333]/80">
                  Having multiple personas at level 2+ creates powerful synergy effects, unlocking unique growth pathways and advanced reflection tools.
                </p>
              </div>
              
              <div className="bg-white/70 p-3 rounded-lg">
                <h4 className="font-medium flex items-center"><span className="mr-2">🌟</span> Growth Accelerators</h4>
                <p className="text-sm mt-1 text-[#333333]/80">
                  Maintaining 5-day streaks activates XP multipliers, accelerating your growth across all personas. Consistency compounds growth!
                </p>
              </div>
            </div>
          </div>
          
          {/* Growth Strategy */}
          <div className="bg-white rounded-lg p-5 shadow-sm">
            <h3 className="text-xl font-semibold text-[#333333] mb-3">Growth Strategy Tips</h3>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-[#AEC6CF] text-white w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mr-3">1</div>
                <div>
                  <h4 className="font-medium">Focus on active persona first</h4>
                  <p className="text-sm text-[#333333]/80 mt-1">
                    Prioritize growth for your currently active persona to unlock its full potential before diversifying.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-[#C3B1E1] text-white w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mr-3">2</div>
                <div>
                  <h4 className="font-medium">Complement with opposite strengths</h4>
                  <p className="text-sm text-[#333333]/80 mt-1">
                    For balanced growth, invest in personas that complement your active persona's attributes.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-[#C5D8A4] text-white w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mr-3">3</div>
                <div>
                  <h4 className="font-medium">Daily micro-actions compound</h4>
                  <p className="text-sm text-[#333333]/80 mt-1">
                    Small daily actions consistently performed yield more stable growth than occasional large efforts.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="sticky bottom-0 bg-[#F5E8C7] p-6 pt-3 border-t border-[#333333]/10 flex justify-end">
          <button 
            onClick={onClose}
            className="px-5 py-2 bg-[#F7DC6F] hover:bg-[#F7DC6F]/80 transition-colors rounded-lg text-[#333333] font-medium shadow-sm hover:shadow"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};

export default XpInfoModal;