// /components/CREFeedbackBox.tsx

import React, { useState, useEffect, useRef } from 'react';
import { getSignatureMap } from '../SignatureMap';
import { getTodayTrend } from '../utils/getTodayTrend';
import { shouldShowMicroTip } from '../logic/shouldShowMicroTip';
import { getMicroTip } from '../logic/MicroTipEngine';
import MicroTipHint from './MicroTipHint';
import { writeToneLogEntry } from '../utils/writeToneLog';
import { addFeedbackEntry } from '../utils/feedbackLogWriter';
import { addXp } from '../utils/xpEngine';
import { getXpTracker, saveXpTracker, getTodayDateKey } from '../utils/xpDailyTracker';

const RHYTHM_COLORS = {
  collapsed: '#AEC6CF',
  wavy: '#C3B1E1',
  stable: '#C5D8A4',
  rising: '#FFB347'
};

const PERSONAS = {
  rhea: {
    color: '#F5CFCF',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)'
  },
  caelum: {
    color: '#4B6587',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)'
  },
  aurelia: {
    color: '#D8A7CA',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)'
  }
};

interface Props {
  cueId: string;
  cue: string;
  paragraph: string;
  tone: string;
  persona: string;
  trend: string;
  onFeedbackSubmit?: (feedback: 'aligned' | 'okay' | 'notMe') => void;
}

const getFeedbackScore = (feedback: 'aligned' | 'okay' | 'notMe'): number => {
  switch (feedback) {
    case 'aligned': return 1;
    case 'okay': return 0.5;
    case 'notMe': return 0;
    default: return 0;
  }
};

const isSameDay = (date1: Date | string, date2: Date | string) => {
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  return d1.getFullYear() === d2.getFullYear() && d1.getMonth() === d2.getMonth() && d1.getDate() === d2.getDate();
};

const getCorrectedTrend = (cueText: string, defaultTrend: string): string => {
  if (cueText.includes("Consistency grows even through softness")) return "wavy";
  if (cueText.includes("Stay soft but steady")) return "collapsed";
  if (cueText.includes("Gentleness can be strength too")) return "wavy";
  if (cueText.includes("You don't have to rush")) return "collapsed";
  if (cueText.includes("Rhythm born from patience outlasts")) return "wavy";
  return defaultTrend;
};

const CREFeedbackBox: React.FC<Props> = ({ cueId, cue, paragraph, tone, persona, trend, onFeedbackSubmit }) => {
  const [currentFeedback, setCurrentFeedback] = useState<string | null>(null);
  const [showMicroTipState, setShowMicroTipState] = useState<boolean>(false);
  const [microTipMessageState, setMicroTipMessageState] = useState<string>('');
  const [animating, setAnimating] = useState<boolean>(false);
  const lastCheckRef = useRef<{ cueId: string, feedback: string | null }>({ cueId: '', feedback: null });
  const submittingRef = useRef<boolean>(false);

  const actualTrendRef = useRef<string>(getTodayTrend());
  const correctedTrendRef = useRef<string>("");

  useEffect(() => {
    const systemTrend = getTodayTrend();
    actualTrendRef.current = systemTrend;
    correctedTrendRef.current = getCorrectedTrend(cue, systemTrend);
    console.log('Trend detection:', {
      system: systemTrend,
      props: trend,
      corrected: correctedTrendRef.current,
      cue
    });
  }, [cue, trend]);

  useEffect(() => {
    const today = new Date();
    try {
      const cueFeedbackLogRaw = localStorage.getItem('cueFeedbackLog');
      let cueFeedbackLog = [];
      if (cueFeedbackLogRaw) {
        cueFeedbackLog = JSON.parse(cueFeedbackLogRaw);
      }
      const entry = cueFeedbackLog.find((e: any) =>
        e && e.cueId === cueId && isSameDay(e.timestamp, today)
      );
      setCurrentFeedback(entry ? entry.feedback : null);
    } catch (error) {
      console.error('Error loading current feedback state:', error);
      setCurrentFeedback(null);
    }
  }, [cueId]);

  const checkAndSetMicroTip = (feedback: string) => {
    if (!feedback) return;
    if (lastCheckRef.current.cueId === cueId && lastCheckRef.current.feedback === feedback) return;
    lastCheckRef.current = { cueId, feedback };

    const currentTrend = correctedTrendRef.current;
    const shouldShow = shouldShowMicroTip(cueId, feedback);
    const message = shouldShow ? getMicroTip(currentTrend, feedback) : '';
    setShowMicroTipState(shouldShow);
    setMicroTipMessageState(shouldShow ? message : '');
  };

  const handleFeedback = (feedback: 'aligned' | 'okay' | 'notMe') => {
    if (submittingRef.current) return;
    submittingRef.current = true;
    setAnimating(true);
    setTimeout(() => {
      submittingRef.current = false;
      setAnimating(false);
    }, 800);
    
    // 使用之前存储在ref中的correctedTrend
    const correctedTrend = correctedTrendRef.current;
    const timestamp = new Date().toISOString();
    
    if (feedback === 'aligned') {
      const raw = localStorage.getItem('signature_prompt_memory');
      const memory = raw ? JSON.parse(raw) : {};
    
      const newFragment = {
        cueText: cue,
        cueId,
        tone,
        persona,
        trend: correctedTrend,
        keywords: cue.split(' ').slice(0, 3), // 暂用前三词作为关键词
        timestamp,
      };
    
      const existing = memory.highScoreCueFragments || [];
      memory.highScoreCueFragments = [...existing, newFragment].slice(-50); // 保留最新50条
      memory.updatedAt = new Date().toISOString();
    
      localStorage.setItem('signature_prompt_memory', JSON.stringify(memory));
      console.log('🧠 High score cue saved to memory:', newFragment);
    }

    const score = getFeedbackScore(feedback);

    if (cue !== 'You deserve to pause.') {
      writeToneLogEntry({ cueId, cueText: cue, tone, feedback, trend: correctedTrend, persona, timestamp, score });
      addFeedbackEntry({ cueId, cueText: cue, tone, persona, trend: correctedTrend, feedback, score, timestamp });
    }

    setCurrentFeedback(feedback);
    if (onFeedbackSubmit) onFeedbackSubmit(feedback);
    window.dispatchEvent(new Event('cue-feedback-updated'));
  };

  const feedbackOptions = [
    { value: 'aligned', label: 'Aligned', icon: '✓', bgColor: RHYTHM_COLORS.stable, textColor: '#333333' },
    { value: 'okay', label: 'Okay', icon: '≈', bgColor: '#F7DC6F', textColor: '#333333' },
    { value: 'notMe', label: 'Not me', icon: '×', bgColor: '#F5CFCF', textColor: '#333333' }
  ];

  useEffect(() => {
    if (currentFeedback) {
      checkAndSetMicroTip(currentFeedback);
    } else {
      setShowMicroTipState(false);
      setMicroTipMessageState('');
    }
  }, [currentFeedback, cueId]);

  if (cue === 'You deserve to pause.') return null;

  const personaStyle = PERSONAS[persona] || PERSONAS.rhea;
  const rhythmColor = RHYTHM_COLORS[trend] || RHYTHM_COLORS.wavy;

  return (
    <div className="mt-6">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-medium flex items-center gap-2" style={{ color: '#333333' }}>
          <span className="w-2 h-2 rounded-full inline-block animate-pulse" style={{ backgroundColor: rhythmColor }}></span>
          How did this cue feel to you?
        </p>
        {currentFeedback && (
          <p className="text-xs" style={{ color: '#666666' }}>
            Already rated today. Tap to change.
          </p>
        )}
      </div>

      <div className="flex gap-3">
        {feedbackOptions.map((option) => (
          <button
            key={option.value}
            onClick={() => handleFeedback(option.value as 'aligned' | 'okay' | 'notMe')}
            className={`flex-1 py-3 rounded-xl flex items-center justify-center gap-2 transition-all duration-300 ${
              animating && currentFeedback === option.value ? 'scale-105' : ''
            }`}
            style={{
              backgroundColor: option.bgColor,
              color: option.textColor,
              boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
              transform: animating && currentFeedback === option.value ? 'scale(1.05)' : 'scale(1)',
              border: currentFeedback === option.value ? `2px solid ${option.textColor}` : '1px solid rgba(0, 0, 0, 0.05)'
            }}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
            onMouseLeave={(e) => {
              if (animating && currentFeedback === option.value) {
                e.currentTarget.style.transform = 'scale(1.05)';
              } else {
                e.currentTarget.style.transform = 'translateY(0)';
              }
            }}
          >
            <span className="text-lg">{option.icon}</span>
            <span>{option.label}</span>
          </button>
        ))}
      </div>

      {animating && currentFeedback && (
        <div className="mt-3 text-center text-sm transition-opacity duration-500" style={{ color: '#666666', opacity: animating ? 1 : 0 }}>
          Feedback received - updating your rhythm pattern...
        </div>
      )}

      {showMicroTipState && microTipMessageState && (
        <div className="mt-4">
          <MicroTipHint message={microTipMessageState} />
        </div>
      )}
    </div>
  );
};

export default CREFeedbackBox;

