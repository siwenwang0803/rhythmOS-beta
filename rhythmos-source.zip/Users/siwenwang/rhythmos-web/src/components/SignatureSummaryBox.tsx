import React, { useState, useEffect } from 'react';
import { getSignatureMap } from '../SignatureMap';

interface SignatureSummaryBoxProps {
  isDaytime?: boolean; // Optional prop to control day/night mode
}

// 正确的 Tone 到 Persona 映射
const toneToPersonaMap: Record<string, string> = {
  gentle: 'rhea',
  directive: 'niveus',
  visionary: 'lucis',
  rational: 'aurelia',
  motivated: 'caelum',
  supportive: 'maya',
  balanced: 'sage',
  strategic: 'jordan'
};

// 获取对应 tone 的正确 persona
const getCorrectPersonaForTone = (tone: string): string => {
  return toneToPersonaMap[tone] || 'rhea';
};

// Persona details for visualization
const PERSONAS = {
  rhea: {
    color: '#F5CFCF',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #694647)',
    icon: '💗',
    title: 'Gentle, empathic'
  },
  aurelia: {
    color: '#D8A7CA',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #5A4555)',
    icon: '🧠',
    title: 'Rational, intuitive'
  },
  lucis: {
    color: '#A4D8C5',
    gradient: 'linear-gradient(135deg, #E8F5C7, #A4D8C5)',
    nightGradient: 'linear-gradient(135deg, #495D44, #456056)',
    icon: '🌱',
    title: 'Supportive, growth'
  },
  niveus: {
    color: '#C7C7C7',
    gradient: 'linear-gradient(135deg, #E8E8E8, #C7C7C7)',
    nightGradient: 'linear-gradient(135deg, #4A4A4A, #555555)',
    icon: '📊',
    title: 'Directive, balanced'
  },
  caelum: {
    color: '#4B6587',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #2A3A4F)',
    icon: '💠',
    title: 'Directive, confident'
  },
  maya: {
    color: '#FFD8B1',
    gradient: 'linear-gradient(135deg, #FFE8C7, #FFD8B1)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #6B5D4F)',
    icon: '🌟',
    title: 'Supportive, encouraging'
  },
  sage: {
    color: '#B5D8B2',
    gradient: 'linear-gradient(135deg, #DEF5C7, #B5D8B2)',
    nightGradient: 'linear-gradient(135deg, #495D44, #456048)',
    icon: '🌿',
    title: 'Balanced, wise'
  },
  jordan: {
    color: '#A0C4DE',
    gradient: 'linear-gradient(135deg, #C7E8F5, #A0C4DE)',
    nightGradient: 'linear-gradient(135deg, #364B5D, #405060)',
    icon: '🌊',
    title: 'Strategic, thoughtful'
  }
};

// Tone details with icons
const TONE_DETAILS = {
  gentle: { icon: '🌸', description: 'Soft and nurturing approach' },
  directive: { icon: '📌', description: 'Clear and guiding direction' },
  visionary: { icon: '🔭', description: 'Forward-thinking perspective' },
  rational: { icon: '🧩', description: 'Logical, analytical reasoning' },
  motivated: { icon: '🔆', description: 'Energetic, encouraging style' },
  supportive: { icon: '🤝', description: 'Helpful, uplifting approach' },
  balanced: { icon: '⚖️', description: 'Harmonious, even-tempered style' },
  strategic: { icon: '🧭', description: 'Purposeful, planned approach' }
};

const SignatureSummaryBox: React.FC<SignatureSummaryBoxProps> = ({ isDaytime = true }) => {
  const signatureMap = getSignatureMap();
  const [isAnimated, setIsAnimated] = useState(false);
  
  // Animation effect
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsAnimated(true);
    }, 300);
    
    return () => clearTimeout(timer);
  }, []);
  
  const cueLog = signatureMap.cueFeedbackLog || [];
  const challengeLog = signatureMap.challengeLog || [];
  const speakLog = signatureMap.speakReplayLog || [];
  const toneLog = signatureMap.toneLog || [];

  // 初始化计数器
  const toneCounts: Record<string, number> = {};

  // 辅助函数 - 增加计数
  const addCount = (map: Record<string, number>, key: string) => {
    if (!key) return; // 跳过 undefined 或 null
    map[key] = (map[key] || 0) + 1;
  };

  // 从 cueFeedbackLog 中获取数据
  cueLog.forEach((entry) => {
    if (entry.feedback === 'aligned') {
      if (entry.tone) addCount(toneCounts, entry.tone);
    }
  });

  // 从 speakReplayLog 中获取数据
  speakLog.forEach((entry) => {
    if (entry.tone) {
      addCount(toneCounts, entry.tone);
    }
  });
  
  // 从 toneLog 中获取数据
  toneLog.forEach((entry) => {
    if (entry.feedback === 'aligned') {
      if (entry.tone) addCount(toneCounts, entry.tone);
    }
  });

  // 获取最多的 tone
  let topTone = 'gentle';
  
  const sortedTones = Object.entries(toneCounts).sort((a, b) => b[1] - a[1]);
  if (sortedTones.length > 0 && sortedTones[0][0]) {
    topTone = sortedTones[0][0];
  }
  
  // ✅ 使用正确的映射获取 persona
  const topPersona = getCorrectPersonaForTone(topTone);
  
  // 调试日志
  console.log('📊 SignatureSummaryBox - toneCounts:', toneCounts);
  console.log('📊 SignatureSummaryBox - topTone:', topTone);
  console.log('📊 SignatureSummaryBox - topPersona:', topPersona);
  console.log('📊 SignatureSummaryBox - mapping used:', toneToPersonaMap);

  // Get persona info
  const personaInfo = PERSONAS[topPersona as keyof typeof PERSONAS] || PERSONAS.rhea;
  
  // Get tone info
  const toneInfo = TONE_DETAILS[topTone as keyof typeof TONE_DETAILS] || { 
    icon: '🔹', 
    description: 'Your preferred communication style' 
  };
  
  // 根据日夜模式调整颜色
  const baseTextColor = isDaytime ? '#333333' : '#E0E0E0';
  const secondaryTextColor = isDaytime ? '#666666' : '#AAAAAA';
  const personaGradient = isDaytime ? personaInfo.gradient : personaInfo.nightGradient;
  
  // Get total alignment count
  const totalAlignments = Object.values(toneCounts).reduce((sum, count) => sum + count, 0);

  return (
    <div 
      className={`rounded-xl overflow-hidden transform transition-all duration-700 ${
        isAnimated ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0'
      }`}
      style={{ 
        backgroundColor: isDaytime ? 'rgba(255, 255, 255, 0.7)' : 'rgba(40, 38, 46, 0.7)',
        backdropFilter: 'blur(10px)',
        border: isDaytime ? '1px solid rgba(0, 0, 0, 0.05)' : '1px solid rgba(255, 255, 255, 0.05)',
        boxShadow: isDaytime 
          ? '0 8px 30px rgba(0, 0, 0, 0.07), inset 0 0 15px rgba(0, 0, 0, 0.02)'
          : '0 8px 30px rgba(0, 0, 0, 0.2), inset 0 0 15px rgba(255, 255, 255, 0.01)'
      }}
    >
      {/* Top accent bar */}
      <div 
        className="h-1.5 w-full" 
        style={{ background: personaGradient }}
      />
      
      <div className="p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div 
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ 
                background: isDaytime 
                  ? 'rgba(0, 0, 0, 0.03)'
                  : 'rgba(255, 255, 255, 0.05)'
              }}
            >
              <span className="text-base">🧬</span>
            </div>
            <h3 
              className="text-base font-medium"
              style={{ color: baseTextColor }}
            >
              Signature Summary
            </h3>
          </div>
          
          {totalAlignments > 0 && (
            <div 
              className="px-3 py-1 rounded-full text-xs flex items-center gap-1"
              style={{ 
                backgroundColor: isDaytime
                  ? 'rgba(0, 0, 0, 0.05)'
                  : 'rgba(255, 255, 255, 0.07)',
                color: secondaryTextColor
              }}
            >
              <span>{totalAlignments} alignment{totalAlignments !== 1 ? 's' : ''}</span>
            </div>
          )}
        </div>
        
        <div className="flex gap-4 items-start">
          <div 
            className="w-12 h-12 rounded-xl flex-shrink-0 flex items-center justify-center"
            style={{ 
              background: personaGradient,
              boxShadow: isDaytime
                ? '0 4px 12px rgba(0, 0, 0, 0.05)'
                : '0 4px 12px rgba(0, 0, 0, 0.2)'
            }}
          >
            <span className="text-xl">{personaInfo.icon}</span>
          </div>
          
          <div className="flex-1">
            <p 
              className="leading-relaxed mb-2"
              style={{ color: secondaryTextColor }}
            >
              Based on your feedback history, you currently align most with:
            </p>
            
            <div className="flex flex-wrap gap-2 mb-3">
              <div 
                className="px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5"
                style={{ 
                  background: isDaytime
                    ? `${personaInfo.color}20`
                    : `${personaInfo.color}30`,
                  color: baseTextColor,
                  border: isDaytime
                    ? `1px solid ${personaInfo.color}30`
                    : `1px solid ${personaInfo.color}40`
                }}
              >
                <span>{personaInfo.icon}</span>
                <span className="capitalize">{topPersona}</span>
              </div>
              
              <div 
                className="px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5"
                style={{ 
                  background: isDaytime
                    ? 'rgba(0, 0, 0, 0.03)'
                    : 'rgba(255, 255, 255, 0.05)',
                  color: baseTextColor
                }}
              >
                <span>{toneInfo.icon}</span>
                <span className="capitalize">{topTone} tone</span>
              </div>
            </div>
            
            <p 
              className="text-xs"
              style={{ color: secondaryTextColor }}
            >
              {personaInfo.title} • {toneInfo.description}
            </p>
          </div>
        </div>
        
        {/* Top tones visualization */}
        {sortedTones.length > 1 && (
          <div 
            className="mt-4 pt-4 border-t"
            style={{ 
              borderColor: isDaytime
                ? 'rgba(0, 0, 0, 0.05)'
                : 'rgba(255, 255, 255, 0.05)'
            }}
          >
            <div 
              className="text-xs font-medium mb-2"
              style={{ color: secondaryTextColor }}
            >
              Your tone preferences:
            </div>
            
            <div className="space-y-2">
              {sortedTones.slice(0, 3).map(([tone, count]) => {
                const toneDetail = TONE_DETAILS[tone as keyof typeof TONE_DETAILS];
                const percentage = Math.round((count / totalAlignments) * 100);
                
                return (
                  <div key={tone} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <div 
                        className="flex items-center gap-1"
                        style={{ color: baseTextColor }}
                      >
                        <span>{toneDetail?.icon || '🔹'}</span>
                        <span className="capitalize">{tone}</span>
                      </div>
                      <div style={{ color: secondaryTextColor }}>
                        {count} ({percentage}%)
                      </div>
                    </div>
                    
                    <div 
                      className="h-1.5 w-full rounded-full"
                      style={{ 
                        backgroundColor: isDaytime
                          ? 'rgba(0, 0, 0, 0.05)'
                          : 'rgba(255, 255, 255, 0.05)'
                      }}
                    >
                      <div 
                        className="h-full rounded-full"
                        style={{ 
                          width: `${percentage}%`,
                          background: personaGradient
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SignatureSummaryBox;




