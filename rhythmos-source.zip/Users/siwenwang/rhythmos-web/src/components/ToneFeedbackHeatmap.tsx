import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { createUniqueKey } from '../utils/feedbackLogWriter';

interface ToneFeedbackHeatmapProps {
  isDaytime?: boolean;
}

/**
 * ToneFeedbackHeatmap - Visualizes feedback distribution by tone
 * 
 * This component displays a stacked bar chart showing the distribution of 
 * 'aligned', 'okay', and 'notMe' feedback for each tone in the system.
 * Supports day/night mode and follows the RhythmOS design specification.
 */
export const ToneFeedbackHeatmap: React.FC<ToneFeedbackHeatmapProps> = ({ isDaytime = true }) => {
  // RhythmOS theme colors based on UI spec and day/night mode
  const themeColors = {
    background: isDaytime ? '#F5E8C7' : '#2C2C2C', // Sand base / Dark mode bg
    panelBg: isDaytime ? '#FFFFFF' : '#3A3A3A',     // White / Dark panel bg
    text: isDaytime ? '#333333' : '#E0E0E0',        // Dark text / Light text
    textMuted: isDaytime ? '#777777' : '#AAAAAA',   // Muted text colors
    border: isDaytime ? '#E6E6E6' : '#555555',      // Light/dark borders
    shadow: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(0, 0, 0, 0.2)',
    accent: '#F7DC6F',  // Soft yellow accent from UI spec
  };
  
  // Feedback color scheme based on RhythmOS spec
  const feedbackColors = {
    aligned: '#C5D8A4', // RhythmOS Stable color (green)
    okay: '#C3B1E1',    // RhythmOS Wavy color (lavender)
    notMe: '#AEC6CF'    // RhythmOS Collapsed color (blue)
  };

  const data = useMemo(() => {
    // Read toneLog from localStorage
    const raw = localStorage.getItem('toneLog');
    const toneLog = raw ? JSON.parse(raw) : [];

    // Initialize a map to store feedback counts by tone
    const toneMap: Record<string, { aligned: number; okay: number; notMe: number; total: number }> = {};
    
    // Use a Set to track unique entries (using uniqueKey)
    const seen = new Set<string>();

    // Process each entry in the toneLog
    [...toneLog].reverse().forEach((entry: any) => {
      if (!entry || !entry.tone || !entry.feedback || !entry.timestamp) return;

      // Get or create uniqueKey for deduplication
      const uniqueKey = entry.uniqueKey || createUniqueKey(entry.cueId, entry.tone, entry.timestamp);
      
      // Skip if we've already seen this entry
      if (seen.has(uniqueKey)) return;
      seen.add(uniqueKey);

      // Initialize the tone entry if it doesn't exist
      if (!toneMap[entry.tone]) {
        toneMap[entry.tone] = { aligned: 0, okay: 0, notMe: 0, total: 0 };
      }

      // Increment the appropriate counter based on feedback type
      if (entry.feedback === 'aligned') toneMap[entry.tone].aligned++;
      else if (entry.feedback === 'okay') toneMap[entry.tone].okay++;
      else if (entry.feedback === 'notMe') toneMap[entry.tone].notMe++;
      
      // Track total count for sorting
      toneMap[entry.tone].total++;
    });

    // Convert the map to an array for the chart
    const result = Object.entries(toneMap).map(([tone, counts]) => ({
      tone,
      aligned: counts.aligned,
      okay: counts.okay,
      notMe: counts.notMe,
      total: counts.total
    }));
    
    // Sort by total count (descending) to prioritize most frequent tones
    return result.sort((a, b) => b.total - a.total);
  }, []);

  // Custom tooltip component following RhythmOS design
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const totalItems = payload.reduce((sum: number, item: any) => sum + (item.value || 0), 0);
      
      return (
        <div 
          style={{ 
            backgroundColor: isDaytime ? 'rgba(255, 255, 255, 0.95)' : 'rgba(50, 50, 50, 0.95)',
            border: `1px solid ${themeColors.border}`,
            borderRadius: '8px',
            padding: '8px 12px',
            boxShadow: `0 2px 8px ${themeColors.shadow}`,
            color: themeColors.text,
            fontSize: '12px',
            lineHeight: 1.4
          }}
        >
          <p style={{ 
            margin: '0 0 4px 0', 
            fontWeight: 600, 
            borderBottom: `1px solid ${themeColors.border}`,
            paddingBottom: '4px'
          }}>
            {label}
          </p>
          {payload.map((entry: any, index: number) => (
            <div key={`tooltip-${index}`} style={{ 
              display: 'flex', 
              justifyContent: 'space-between',
              margin: '2px 0'
            }}>
              <span style={{ 
                display: 'flex', 
                alignItems: 'center',
                marginRight: '12px'
              }}>
                <span style={{ 
                  display: 'inline-block',
                  width: '8px',
                  height: '8px',
                  backgroundColor: entry.fill,
                  marginRight: '4px',
                  borderRadius: '2px'
                }}></span>
                <span>{entry.name}:</span>
              </span>
              <span style={{ fontWeight: 500 }}>
                {entry.value} ({Math.round((entry.value / totalItems) * 100)}%)
              </span>
            </div>
          ))}
          <div style={{ 
            borderTop: `1px solid ${themeColors.border}`,
            marginTop: '4px',
            paddingTop: '4px',
            display: 'flex',
            justifyContent: 'space-between',
            fontWeight: 600
          }}>
            <span>Total:</span>
            <span>{totalItems}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  // Custom Legend for better styling
  const CustomLegend = ({ payload }: any) => {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        margin: '8px 0',
        gap: '16px'
      }}>
        {payload.map((entry: any, index: number) => (
          <div key={`legend-${index}`} style={{ 
            display: 'flex', 
            alignItems: 'center',
            fontSize: '12px',
            color: themeColors.text
          }}>
            <span style={{ 
              display: 'inline-block',
              width: '10px',
              height: '10px',
              backgroundColor: entry.color,
              marginRight: '4px',
              borderRadius: '2px'
            }}></span>
            <span>{entry.value}</span>
          </div>
        ))}
      </div>
    );
  };

  // If there's no data, show a placeholder
  if (data.length === 0) {
    return (
      <div 
        className="mt-6 p-4 rounded-xl"
        style={{
          backgroundColor: themeColors.panelBg,
          border: `1px solid ${themeColors.border}`,
          boxShadow: `0 2px 8px ${themeColors.shadow}`,
          color: themeColors.textMuted,
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
        }}
      >
        <h3 
          className="text-md font-semibold mb-2"
          style={{ color: themeColors.text }}
        >
          🎨 Tone Feedback Heatmap
        </h3>
        <p>No tone feedback available.</p>
      </div>
    );
  }

  // Render the chart
  return (
    <div 
      className="mt-6 p-4 rounded-xl"
      style={{
        backgroundColor: themeColors.panelBg,
        border: `1px solid ${themeColors.border}`,
        boxShadow: `0 2px 8px ${themeColors.shadow}`,
        color: themeColors.text,
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }}
    >
      <h3 className="text-md font-semibold mb-2">🎨 Tone Feedback Heatmap</h3>
      <div className="animate-fade-in">
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={data} margin={{ top: 10, right: 10, left: 10, bottom: 5 }}>
            <XAxis 
              dataKey="tone" 
              tick={{ fill: themeColors.text, fontSize: 11 }}
              tickFormatter={(value) => value.length > 10 ? `${value.substring(0, 10)}...` : value}
            />
            <YAxis 
              allowDecimals={false} 
              tick={{ fill: themeColors.text, fontSize: 11 }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend content={<CustomLegend />} />
            <Bar 
              dataKey="aligned" 
              stackId="a" 
              fill={feedbackColors.aligned}
              name="Aligned" 
              radius={[0, 0, 0, 0]}
              isAnimationActive={true}
              animationDuration={800}
              animationEasing="ease-out"
            />
            <Bar 
              dataKey="okay" 
              stackId="a" 
              fill={feedbackColors.okay} 
              name="Okay"
              radius={[0, 0, 0, 0]}
              isAnimationActive={true}
              animationDuration={800}
              animationEasing="ease-out"
              animationBegin={100}
            />
            <Bar 
              dataKey="notMe" 
              stackId="a" 
              fill={feedbackColors.notMe} 
              name="Not Me"
              radius={[0, 0, 4, 4]}
              isAnimationActive={true}
              animationDuration={800}
              animationEasing="ease-out"
              animationBegin={200}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <p 
        className="text-xs mt-2 text-center"
        style={{ color: themeColors.textMuted }}
      >
        Distribution of feedback by tone
      </p>
      
      {/* Add animation keyframes with a style tag */}
      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(5px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fade-in {
          animation: fadeIn 0.5s ease-out;
        }
      `}</style>
    </div>
  );
};

export default ToneFeedbackHeatmap;

