import React from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface FeedbackEntry {
  tone: string
  score: number
  timestamp: number
}

interface TrendPoint {
  date: string
  [tone: string]: number | string
}

function formatDate(ts: number): string {
  return new Date(ts).toISOString().split('T')[0]
}

const CREVariantTrendChart: React.FC = () => {
  const raw = localStorage.getItem('creSampleRatings')
  const ratings: FeedbackEntry[] = raw ? JSON.parse(raw) : []

  const grouped: Record<string, Record<string, number[]>> = {}

  ratings.forEach((entry) => {
    const date = formatDate(entry.timestamp)
    if (!grouped[date]) grouped[date] = {}
    if (!grouped[date][entry.tone]) grouped[date][entry.tone] = []
    grouped[date][entry.tone].push(entry.score)
  })

  const data: TrendPoint[] = Object.entries(grouped).map(([date, tones]) => {
    const point: TrendPoint = { date }
    for (const tone in tones) {
      const scores = tones[tone]
      const avg = scores.reduce((a, b) => a + b, 0) / scores.length
      point[tone] = parseFloat(avg.toFixed(2))
    }
    return point
  })

  return (
    <div className="w-full">
      <h3 className="text-md font-semibold mb-3 text-gray-800">📈 CRE Tone Score Trends</h3>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={data}>
          <XAxis dataKey="date" />
          <YAxis domain={[0, 5]} />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="gentle" stroke="#8884d8" />
          <Line type="monotone" dataKey="motivated" stroke="#82ca9d" />
          <Line type="monotone" dataKey="directive" stroke="#ff7300" />
          <Line type="monotone" dataKey="visionary" stroke="#888888" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

export default CREVariantTrendChart
