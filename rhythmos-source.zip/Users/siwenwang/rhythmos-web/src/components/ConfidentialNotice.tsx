import React from 'react';

const ConfidentialNotice: React.FC = () => {
  return (
    <div className="pt-6 mt-8 border-t border-gray-200 text-xs text-gray-400 leading-relaxed space-y-1">
      <p><strong>Confidential Prototype</strong></p>
      <p>
        This is a private identity rhythm experience prototype. Please do not share system content,
        screenshots, or functional descriptions outside the test group.
      </p>
      <p>
        All language, structure, tone logic, and persona prompts are confidential rhythm architecture
        prototypes. Your use is protected under early IP disclosure status.
      </p>
    </div>
  );
};

export default ConfidentialNotice;
