// components/ResonanceInputBlock.tsx (v2 - with passiveTrendScore influence)

import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { matchCREBlockFromInput } from '../logic/resonanceResponseEngine'
import { updatePassiveTrendScore,writePassiveToneLog } from '../rhea-echo/signaturePassiveWriter'

const ResonanceInputBlock: React.FC = () => {
  const [input, setInput] = useState('')
  const [error, setError] = useState(false)
  const navigate = useNavigate()

  const handleSubmit = () => {
    if (!input.trim()) {
      setError(true)
      return
    }

    const block = matchCREBlockFromInput(input)
    if (block) {
      localStorage.setItem('resonance_cre_cue', block.cue)
      localStorage.setItem('resonance_cre_paragraph', block.paragraph)
      localStorage.setItem('resonance_cre_tone', block.tone)
      localStorage.setItem('resonance_cre_persona', block.persona)
      localStorage.setItem('resonance_input_text', input)

      if (block?.tone) {
        updatePassiveTrendScore(block.tone)
        writePassiveToneLog({
          tone: block.tone,
          emotionSignal: input,
          timestamp: Date.now()
        })
      }
      

      // Passive trendScore update only
      updatePassiveTrendScore(block.tone)

      navigate('/identity/train')
    } else {
      setError(true)
    }
  }

  return (
    <div className="bg-white p-4 rounded-xl shadow-sm space-y-4">
      <h3 className="text-lg font-semibold text-gray-800">💬 Say something to your rhythm system</h3>
      <p className="text-sm text-gray-500">Write a sentence that reflects how you're feeling right now.</p>
      <textarea
        value={input}
        onChange={(e) => {
          setInput(e.target.value)
          setError(false)
        }}
        placeholder="e.g. I feel stuck. I wish I had more clarity."
        className="w-full border px-4 py-2 rounded text-sm"
      />
      {error && <p className="text-xs text-red-500">Please write something so I can respond.</p>}

    </div>
  )
}

export default ResonanceInputBlock
