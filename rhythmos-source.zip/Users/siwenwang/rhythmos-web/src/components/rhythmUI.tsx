import React from 'react'

export const Section: React.FC<{ title?: string; children: React.ReactNode }> = ({ title, children }) => (
  <section className="space-y-2 mt-6">
    {title && <h2 className="text-lg font-semibold text-gray-700">{title}</h2>}
    <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm space-y-2">{children}</div>
  </section>
)

export const RhythmCard: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="rounded-xl bg-white border border-gray-100 shadow-sm p-4">{children}</div>
)

export const RhythmButton: React.FC<{
  onClick?: () => void
  variant?: 'primary' | 'secondary'
  children: React.ReactNode
}> = ({ onClick, variant = 'primary', children }) => {
  const style =
    variant === 'primary'
      ? 'bg-blue-600 text-white hover:bg-blue-700'
      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
  return (
    <button onClick={onClick} className={`px-4 py-2 rounded text-sm font-medium ${style}`}>
      {children}
    </button>
  )
}