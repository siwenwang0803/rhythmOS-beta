import React from 'react'
import { getCREClusterMap } from '../creClusterMap'

const CREClusterMapView: React.FC = () => {
  const clusters = getCREClusterMap()

  const tones = ['gentle', 'directive', 'motivated', 'visionary']
  const taskTypes = ['minimal', 'light', 'normal', 'challenge']

  return (
    <div className="mt-8">
      <h3 className="text-md font-semibold mb-2">🗺️ CRE Cluster Map (Tone × Task)</h3>
      <div className="grid grid-cols-5 gap-2 text-sm text-center">
        <div></div>
        {taskTypes.map((t) => (
          <div key={t} className="font-bold text-gray-600">{t}</div>
        ))}
        {tones.map((tone) => (
          <React.Fragment key={tone}>
            <div className="font-bold text-left text-gray-700">{tone}</div>
            {taskTypes.map((task) => {
              const cluster = clusters.find(c => c.tone === tone && c.taskType === task)
              return (
                <div key={task} className="bg-gray-100 border rounded p-2">
                  {cluster ? (
                    <>
                      <p>{cluster.count} items</p>
                      <p className="text-xs text-gray-400">{cluster.examples[0]?.text.slice(0, 40)}...</p>
                    </>
                  ) : (
                    <p className="text-gray-400 italic text-xs">—</p>
                  )}
                </div>
              )
            })}
          </React.Fragment>
        ))}
      </div>
    </div>
  )
}

export default CREClusterMapView