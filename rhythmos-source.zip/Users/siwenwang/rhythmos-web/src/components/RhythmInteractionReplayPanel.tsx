import React, { useState, useEffect } from 'react';
import { signatureMap, getSignatureMap } from '../SignatureMap';

interface RhythmInteractionReplayPanelProps {
  isDaytime?: boolean;
}

/**
 * RhythmInteractionReplayPanel - Displays recent identity cue and language reflection interactions
 * 
 * This component shows a collapsible panel with the most recent cue feedbacks and speak logs,
 * styled according to the RhythmOS design specification with day/night mode support.
 */
const RhythmInteractionReplayPanel: React.FC<RhythmInteractionReplayPanelProps> = ({ isDaytime = true }) => {
  const [expanded, setExpanded] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [speakLogsExpanded, setSpeakLogsExpanded] = useState(true); // Language Reflections 默认展开
  const [cueLogsExpanded, setCueLogsExpanded] = useState(true); // Identity Cues 默认展开
  const [data, setData] = useState({
    cueFeedbacks: [],
    speakLogs: []
  });
  const [debugMode, setDebugMode] = useState(false);
  
  // RhythmOS theme colors based on UI spec and day/night mode
  const themeColors = {
    background: isDaytime ? '#F5E8C7' : '#2C2C2C', // Sand base / Dark mode bg
    panelBg: isDaytime ? '#FFFFFF' : '#3A3A3A',     // White / Dark panel bg
    panelAltBg: isDaytime ? '#F8F8F5' : '#454545',  // Slight variant for nested panels
    text: isDaytime ? '#333333' : '#E0E0E0',        // Dark text / Light text
    textMuted: isDaytime ? '#777777' : '#AAAAAA',   // Muted text colors
    border: isDaytime ? '#E6E6E6' : '#555555',      // Light/dark borders
    borderLight: isDaytime ? '#EEEEEE' : '#4A4A4A', // Lighter border variant
    shadow: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(0, 0, 0, 0.2)',
    accent: '#F7DC6F', // Soft yellow accent from UI spec
  };
  
  // RhythmOS persona colors from the UI spec
  const personaColors = {
    rhea: '#F5CFCF',   // Gentle, empathic
    caelum: '#4B6587', // Directive, confident
    aurelia: '#D8A7CA', // Rational, intuitive
    niveus: '#A2C4C9',  // Alternative pale teal mentioned in spec
    lucis: '#C5D8A4',   // Added lucis
  };
  
  // RhythmOS state colors from the UI spec
  const stateColors = {
    collapsed: '#AEC6CF', // Gentle calming blue
    wavy: '#C3B1E1',      // Transitional lavender
    stable: '#C5D8A4',    // Grounded light green
    rising: '#FFB347',    // Activating orange-yellow
  };

  // 获取最新数据 - 增强版本
  const refreshData = () => {
    try {
      console.log('=== RhythmInteractionReplayPanel: Refreshing data ===');
      
      // 从最新的 signatureMap 获取数据
      const currentMap = getSignatureMap();
      
      // 获取 cue feedbacks
      const cueFeedbacks = currentMap.cueFeedbackLog || [];
      
      // 尝试从多个位置获取 speak logs
      let speakLogs = [];
      
      // 1. 直接从 speakReplayLog 获取
      if (currentMap.speakReplayLog && currentMap.speakReplayLog.length > 0) {
        speakLogs = [...currentMap.speakReplayLog];
        console.log('Found speak logs in speakReplayLog:', speakLogs.length);
      }
      
      // 2. 从 meta.speakReplayLog 获取（备用位置）
      if (speakLogs.length === 0 && currentMap.meta?.speakReplayLog && currentMap.meta.speakReplayLog.length > 0) {
        speakLogs = [...currentMap.meta.speakReplayLog];
        console.log('Found speak logs in meta.speakReplayLog:', speakLogs.length);
      }
      
      // 3. 尝试从 localStorage 获取（如果上面都没有）
      if (speakLogs.length === 0) {
        try {
          const localSpeakLogs = localStorage.getItem('speakReplayLog');
          if (localSpeakLogs) {
            const parsed = JSON.parse(localSpeakLogs);
            if (Array.isArray(parsed)) {
              speakLogs = parsed;
              console.log('Found speak logs in localStorage:', speakLogs.length);
            }
          }
        } catch (e) {
          console.warn('Error reading speak logs from localStorage:', e);
        }
      }
      
      console.log('Final speak logs count:', speakLogs.length);
      console.log('Sample speak log:', speakLogs.length > 0 ? speakLogs[0] : 'none');
      
      console.log('RhythmInteractionReplayPanel - Data summary:', {
        cueFeedbackLog: cueFeedbacks.length,
        speakLogs: speakLogs.length,
        signatureMapExists: !!currentMap,
        hasDirectSpeakLog: !!(currentMap.speakReplayLog && currentMap.speakReplayLog.length > 0),
        hasMetaSpeakLog: !!(currentMap.meta?.speakReplayLog && currentMap.meta.speakReplayLog.length > 0)
      });
      
      setData({
        cueFeedbacks,
        speakLogs
      });
      
    } catch (error) {
      console.error('Error refreshing RhythmInteractionReplayPanel data:', error);
    }
  };

  useEffect(() => {
    // 初始数据加载
    refreshData();
    
    // 监听数据更新事件
    const handleDataUpdate = (event?: any) => {
      console.log('RhythmInteractionReplayPanel - Data update event received:', event?.type || 'manual');
      setTimeout(refreshData, 100); // 小延迟确保数据已更新
    };
    
    // 监听各种可能的事件
    window.addEventListener('cue-feedback-updated', handleDataUpdate);
    window.addEventListener('speak-log-updated', handleDataUpdate);
    window.addEventListener('signatureMap-updated', handleDataUpdate);
    
    // 定期刷新作为备用机制
    const intervalId = setInterval(() => {
      console.log('RhythmInteractionReplayPanel - Periodic refresh');
      refreshData();
    }, 10000); // 每10秒刷新一次
    
    return () => {
      window.removeEventListener('cue-feedback-updated', handleDataUpdate);
      window.removeEventListener('speak-log-updated', handleDataUpdate);
      window.removeEventListener('signatureMap-updated', handleDataUpdate);
      clearInterval(intervalId);
    };
  }, []);

  // Handle panel expansion with animation
  const toggleExpanded = () => {
    setIsAnimating(true);
    setExpanded(!expanded);
    // Reset animation flag after animation completes
    setTimeout(() => setIsAnimating(false), 300);
  };

  // Get color based on persona name
  const getPersonaColor = (persona?: string): string => {
    if (!persona) return '#CCCCCC'; // fallback color
    
    const lowerPersona = persona.toLowerCase();
    return personaColors[lowerPersona as keyof typeof personaColors] || '#CCCCCC';
  };
  
  // Get color based on tone/emotion that might match a rhythm state
  const getToneColor = (tone: string): string => {
    const lowerTone = tone.toLowerCase();
    
    if (lowerTone.includes('collapsed') || lowerTone.includes('calm')) {
      return stateColors.collapsed;
    }
    if (lowerTone.includes('wavy') || lowerTone.includes('flow')) {
      return stateColors.wavy;
    }
    if (lowerTone.includes('stable') || lowerTone.includes('balanced')) {
      return stateColors.stable;
    }
    if (lowerTone.includes('rising') || lowerTone.includes('energetic')) {
      return stateColors.rising;
    }
    
    // Default color
    return isDaytime ? '#DDDDDD' : '#666666';
  };

  // 处理最近的 cue feedbacks（去重）
  const recentCueFeedbacks = Object.values(
    data.cueFeedbacks.reduce((acc, entry) => {
      acc[entry.cueText] = entry;
      return acc;
    }, {} as Record<string, any>)
  )
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 3);

  // 处理最近的 speak logs
  const recentSpeakLogs = [...data.speakLogs]
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 3);

  const total = recentCueFeedbacks.length + recentSpeakLogs.length;

  // Tag styling function - creates consistent tag styles
  const createTagStyle = (color: string) => ({
    display: 'inline-block',
    backgroundColor: `${color}33`, // Adding transparency
    color: isDaytime ? '#333333' : '#E0E0E0',
    padding: '1px 6px',
    borderRadius: '4px',
    fontSize: '10px',
    marginRight: '4px'
  });

  // 修复动画样式，避免冲突
  const getAnimationStyle = (index: number) => {
    if (!isAnimating) return {};
    
    return {
      animation: 'fadeInDown 0.3s ease-out',
      animationDelay: `${index * 0.1}s`,
      animationFillMode: 'both'
    };
  };

  // 调试信息
  const getDebugInfo = () => {
    const currentMap = getSignatureMap();
    return {
      signatureMapExists: !!currentMap,
      cueFeedbackLogExists: !!currentMap.cueFeedbackLog,
      cueFeedbackLogLength: currentMap.cueFeedbackLog?.length || 0,
      speakReplayLogExists: !!currentMap.speakReplayLog,
      speakReplayLogLength: currentMap.speakReplayLog?.length || 0,
      metaSpeakReplayLogExists: !!currentMap.meta?.speakReplayLog,
      metaSpeakReplayLogLength: currentMap.meta?.speakReplayLog?.length || 0,
      localStorageSpeakLog: !!localStorage.getItem('speakReplayLog'),
      currentDataSpeakLogs: data.speakLogs.length,
      sampleSpeakLog: data.speakLogs.length > 0 ? data.speakLogs[0] : null
    };
  };

  return (
    <div 
      style={{
        backgroundColor: themeColors.panelBg,
        border: `1px solid ${themeColors.border}`,
        borderRadius: '12px',
        padding: '16px',
        boxShadow: `0 2px 8px ${themeColors.shadow}`,
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }}
    >
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          cursor: 'pointer',
          color: themeColors.text,
          userSelect: 'none'
        }}
        onClick={toggleExpanded}
      >
        <div style={{ 
          fontSize: '14px', 
          fontWeight: 600,
          display: 'flex',
          alignItems: 'center',
          gap: '6px'
        }}>
          <span>📘</span>
          <span>Recent Reflections</span>
          <span style={{ 
            transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            transform: expanded ? 'rotate(0deg)' : 'rotate(-90deg)',
            display: 'inline-block'
          }}>
            ▾
          </span>
        </div>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <span style={{ fontSize: '12px', color: themeColors.textMuted }}>
            {total} total ({recentCueFeedbacks.length} cues, {recentSpeakLogs.length} messages)
          </span>
          {/* 调试按钮 */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setDebugMode(!debugMode);
              console.log('Debug - Current data:', getDebugInfo());
              refreshData();
            }}
            style={{
              fontSize: '10px',
              padding: '2px 6px',
              backgroundColor: debugMode ? '#FF6B6B' : themeColors.accent,
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              color: '#333'
            }}
          >
            🔄
          </button>
        </div>
      </div>

      {/* 调试信息 */}
      {debugMode && (
        <div 
          style={{
            marginTop: '12px',
            padding: '8px',
            backgroundColor: themeColors.panelAltBg,
            borderRadius: '8px',
            fontSize: '11px',
            color: themeColors.textMuted
          }}
        >
          <div style={{ marginBottom: '4px' }}><strong>Debug Info:</strong></div>
          {Object.entries(getDebugInfo()).map(([key, value]) => (
            <div key={key}>
              <strong>{key}:</strong> {typeof value === 'object' ? JSON.stringify(value, null, 2) : String(value)}
            </div>
          ))}
        </div>
      )}

      <div 
        style={{
          maxHeight: expanded ? '1000px' : '0px',
          overflow: 'hidden',
          marginTop: expanded ? '12px' : '0px',
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          opacity: expanded ? 1 : 0
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          {/* Language Reflection Section */}
          {recentSpeakLogs.length > 0 && (
            <div>
              <div 
                style={{
                  fontSize: '13px',
                  fontWeight: 600,
                  color: themeColors.text,
                  marginBottom: '12px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  cursor: 'pointer',
                  userSelect: 'none',
                  padding: '4px 0'
                }}
                onClick={() => setSpeakLogsExpanded(!speakLogsExpanded)}
              >
                <span>🗣️</span>
                <span>Language Reflections</span>
                <span style={{
                  fontSize: '11px',
                  color: themeColors.textMuted,
                  fontWeight: 400
                }}>
                  ({recentSpeakLogs.length})
                </span>
                <span style={{ 
                  transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  transform: speakLogsExpanded ? 'rotate(0deg)' : 'rotate(-90deg)',
                  display: 'inline-block',
                  fontSize: '11px',
                  marginLeft: 'auto'
                }}>
                  ▾
                </span>
              </div>
              <div 
                style={{
                  maxHeight: speakLogsExpanded ? '1000px' : '0px',
                  overflow: 'hidden',
                  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  opacity: speakLogsExpanded ? 1 : 0
                }}
              >
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  {recentSpeakLogs.map((entry, idx) => {
                    const personaColor = getPersonaColor(entry.persona || 'aurelia');
                    const toneColor = getToneColor(entry.tone || '');
                    const emotionColor = getToneColor(entry.emotion || '');
                    
                    return (
                      <div
                        key={`speak-${idx}-${entry.timestamp}`}
                        style={{
                          backgroundColor: isDaytime ? '#F8F8F8' : '#454545',
                          border: `1px solid ${themeColors.borderLight}`,
                          borderLeft: `3px solid ${personaColor}`,
                          borderRadius: '8px',
                          padding: '12px',
                          fontSize: '14px',
                          color: themeColors.text,
                          boxShadow: `0 1px 3px ${themeColors.shadow}`,
                          ...getAnimationStyle(idx)
                        }}
                      >
                        <p style={{ 
                          fontSize: '12px', 
                          fontWeight: 600, 
                          color: isDaytime ? '#555555' : '#CCCCCC', 
                          marginBottom: '8px',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px'
                        }}>
                          <span>💬</span>
                          <span>Message Exchange</span>
                        </p>
                        <p style={{ 
                          marginBottom: '6px',
                          fontSize: '14px',
                          color: themeColors.text
                        }}>
                          <strong>You:</strong> "{entry.userInput}"
                        </p>
                        <p style={{ 
                          marginBottom: '8px',
                          fontSize: '14px',
                          fontStyle: 'italic',
                          color: isDaytime ? personaColor : '#CCCCCC'
                        }}>
                          <strong>System:</strong> "{entry.systemResponse}"
                        </p>
                        <div style={{ 
                          fontSize: '12px', 
                          color: themeColors.textMuted,
                          display: 'flex',
                          flexWrap: 'wrap',
                          alignItems: 'center',
                          gap: '6px',
                          marginTop: '4px'
                        }}>
                          {entry.tone && (
                            <>
                              <span style={createTagStyle(toneColor)}>{entry.tone}</span>
                              <span style={{ color: isDaytime ? '#CCCCCC' : '#666666' }}>•</span>
                            </>
                          )}
                          {entry.emotion && (
                            <>
                              <span style={createTagStyle(emotionColor)}>{entry.emotion}</span>
                              <span style={{ color: isDaytime ? '#CCCCCC' : '#666666' }}>•</span>
                            </>
                          )}
                          {entry.persona && (
                            <>
                              <span style={createTagStyle(personaColor)}>{entry.persona}</span>
                              <span style={{ color: isDaytime ? '#CCCCCC' : '#666666' }}>•</span>
                            </>
                          )}
                          <span>
                            {new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Identity Cue Section */}
          {recentCueFeedbacks.length > 0 && (
            <div>
              <div 
                style={{
                  fontSize: '13px',
                  fontWeight: 600,
                  color: themeColors.text,
                  marginBottom: '12px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  cursor: 'pointer',
                  userSelect: 'none',
                  padding: '4px 0'
                }}
                onClick={() => setCueLogsExpanded(!cueLogsExpanded)}
              >
                <span>🧩</span>
                <span>Identity Cues</span>
                <span style={{
                  fontSize: '11px',
                  color: themeColors.textMuted,
                  fontWeight: 400
                }}>
                  ({recentCueFeedbacks.length})
                </span>
                <span style={{ 
                  transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  transform: cueLogsExpanded ? 'rotate(0deg)' : 'rotate(-90deg)',
                  display: 'inline-block',
                  fontSize: '11px',
                  marginLeft: 'auto'
                }}>
                  ▾
                </span>
              </div>
              <div 
                style={{
                  maxHeight: cueLogsExpanded ? '1000px' : '0px',
                  overflow: 'hidden',
                  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  opacity: cueLogsExpanded ? 1 : 0
                }}
              >
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  {recentCueFeedbacks.map((entry, idx) => {
                    const personaColor = getPersonaColor(entry.persona);
                    const toneColor = getToneColor(entry.tone);
                    
                    return (
                      <div
                        key={`cue-${idx}-${entry.timestamp}`}
                        style={{
                          backgroundColor: isDaytime ? '#F8F8F8' : '#454545',
                          border: `1px solid ${themeColors.borderLight}`,
                          borderLeft: `3px solid ${personaColor}`,
                          borderRadius: '8px',
                          padding: '12px',
                          fontSize: '14px',
                          color: themeColors.text,
                          boxShadow: `0 1px 3px ${themeColors.shadow}`,
                          ...getAnimationStyle(idx + recentSpeakLogs.length)
                        }}
                      >
                        <p style={{ 
                          fontSize: '12px', 
                          fontWeight: 600, 
                          color: isDaytime ? '#555555' : '#CCCCCC', 
                          marginBottom: '8px',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px'
                        }}>
                          <span>💭</span>
                          <span>Identity Reflection</span>
                        </p>
                        <p style={{ 
                          marginBottom: '8px',
                          fontSize: '14px',
                          fontStyle: 'italic',
                          color: themeColors.text
                        }}>
                          "{entry.cueText}"
                        </p>
                        <div style={{ 
                          fontSize: '12px', 
                          color: themeColors.textMuted,
                          display: 'flex',
                          flexWrap: 'wrap',
                          alignItems: 'center',
                          gap: '6px'
                        }}>
                          <span>
                            {entry.feedback === 'aligned' ? '✅ aligned' : 
                             entry.feedback === 'okay' ? '😐 okay' : '❌ not me'}
                          </span>
                          <span style={{ color: isDaytime ? '#CCCCCC' : '#666666' }}>•</span>
                          <span style={createTagStyle(toneColor)}>{entry.tone}</span>
                          <span style={{ color: isDaytime ? '#CCCCCC' : '#666666' }}>•</span>
                          <span style={createTagStyle(personaColor)}>{entry.persona}</span>
                          <span style={{ color: isDaytime ? '#CCCCCC' : '#666666' }}>•</span>
                          <span>
                            {new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Empty state */}
          {total === 0 && (
            <div style={{ textAlign: 'center', padding: '20px' }}>
              <p style={{ 
                fontSize: '14px', 
                color: themeColors.textMuted, 
                fontStyle: 'italic',
                marginBottom: '8px'
              }}>
                No interaction logs found yet.
              </p>
              <p style={{ 
                fontSize: '12px', 
                color: themeColors.textMuted,
              }}>
                Try using the "Message your rhythm system" feature to see language reflections here.
              </p>
            </div>
          )}
        </div>
      </div>
      
      {/* Add animation keyframes with a style tag */}
      <style>{`
        @keyframes fadeInDown {
          from {
            opacity: 0;
            transform: translateY(-8px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
};

export default RhythmInteractionReplayPanel;

