import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';

// Persona details from UI specification
const personaDetails = {
  rhea: {
    color: '#F5CFCF',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    icon: '💗',
    description: 'Gentle, empathic, emotional safety'
  },
  caelum: {
    color: '#4B6587',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    icon: '💠',
    description: 'Directive, confident, clarity'
  },
  lucis: {
    color: '#A4D8C5',
    gradient: 'linear-gradient(135deg, #E8F5C7, #A4D8C5)',
    icon: '🌱',
    description: 'Supportive, growth-focused'
  },
  aurelia: {
    color: '#D8A7CA',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    icon: '🧠',
    description: 'Rational, intuitive, neutral'
  },
  niveus: {
    color: '#C7C7C7',
    gradient: 'linear-gradient(135deg, #E8E8E8, #C7C7C7)',
    icon: '📊',
    description: 'Balanced, analytical, practical'
  }
};

// Custom tooltip component
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const personaInfo = personaDetails[label.toLowerCase() as keyof typeof personaDetails];
    const icon = personaInfo?.icon || '👤';
    
    return (
      <div 
        style={{ 
          backgroundColor: 'rgba(255, 255, 255, 0.95)',
          padding: '10px 14px',
          borderRadius: '8px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          border: '1px solid rgba(103, 58, 183, 0.2)',
          fontSize: '14px'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '5px' }}>
          <span>{icon}</span>
          <span style={{ fontWeight: 600, color: '#333' }}>{label}</span>
        </div>
        
        <div style={{ marginTop: '8px' }}>
          {payload.map((entry: any, index: number) => (
            <div 
              key={`item-${index}`} 
              style={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: '6px',
                margin: '3px 0'
              }}
            >
              <span 
                style={{ 
                  display: 'inline-block', 
                  width: '8px', 
                  height: '8px', 
                  borderRadius: '50%', 
                  backgroundColor: entry.fill 
                }}
              />
              <span style={{ color: '#555' }}>
                {entry.name === 'aligned' ? '✅ Aligned' : 
                 entry.name === 'okay' ? '😐 Okay' : 
                 entry.name === 'not_me' ? '❌ Not me' : entry.name}: 
                <b style={{ marginLeft: '4px' }}>{entry.value}</b>
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  }
  return null;
};

// Custom legend that uses the RhythmOS design language
const CustomLegend = ({ payload }: any) => {
  if (!payload) return null;
  
  const feedbackStyles = {
    aligned: { bg: 'rgba(197, 216, 164, 0.2)', text: '#3E5931', icon: '✅', label: 'Aligned' },
    okay: { bg: 'rgba(195, 177, 225, 0.2)', text: '#5C4283', icon: '😐', label: 'Okay' },
    not_me: { bg: 'rgba(174, 198, 207, 0.2)', text: '#3B5164', icon: '❌', label: 'Not me' }
  };
  
  return (
    <div className="flex justify-center gap-3 mt-3">
      {payload.map((entry: any) => {
        const feedbackType = entry.dataKey as keyof typeof feedbackStyles;
        const style = feedbackStyles[feedbackType] || { bg: 'rgba(0, 0, 0, 0.05)', text: '#666', icon: '•', label: entry.dataKey };
        
        return (
          <div 
            key={entry.dataKey}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs"
            style={{ 
              backgroundColor: style.bg,
              color: style.text
            }}
          >
            <span 
              style={{ 
                display: 'inline-block', 
                width: '8px', 
                height: '8px', 
                borderRadius: '50%', 
                backgroundColor: entry.color 
              }}
            />
            <span>{style.icon} {style.label}</span>
          </div>
        );
      })}
    </div>
  );
};

export const ChallengeStatsView: React.FC = () => {
  const raw = JSON.parse(localStorage.getItem('challengeLog') || '[]');

  // ✅ 按 persona + text 分组，只保留最新反馈
  const latestMap: Record<string, any> = {};
  raw.forEach((entry: any) => {
    const key = `${entry.persona}_${entry.text}`;
    if (!latestMap[key] || entry.time > latestMap[key].time) {
      latestMap[key] = entry;
    }
  });

  const personaFeedbackCount: Record<string, Record<string, number>> = {};

  Object.values(latestMap).forEach((entry: any) => {
    const persona = entry.persona || 'unknown';
    const feedback = entry.feedback || 'aligned'; // fallback
    if (!personaFeedbackCount[persona]) {
      personaFeedbackCount[persona] = { aligned: 0, okay: 0, not_me: 0 };
    }
    if (feedback === 'aligned') personaFeedbackCount[persona].aligned += 1;
    if (feedback === 'okay') personaFeedbackCount[persona].okay += 1;
    if (feedback === 'not_me') personaFeedbackCount[persona].not_me += 1;
  });

  const data = Object.entries(personaFeedbackCount).map(([persona, feedbacks]) => ({
    persona,
    ...feedbacks
  }));

  if (data.length === 0) return null;

  const last = raw.sort((a: any, b: any) => b.time - a.time)[0];
  const lastDate = last ? new Date(last.time).toLocaleDateString() : null;

  // Calculate total challenges per persona for summary display
  const personaTotals = data.map(d => ({
    persona: d.persona,
    total: (d.aligned || 0) + (d.okay || 0) + (d.not_me || 0),
    aligned: d.aligned || 0,
    okay: d.okay || 0,
    not_me: d.not_me || 0
  })).sort((a, b) => b.total - a.total);

  return (
    <div 
      className="rounded-xl overflow-hidden"
      style={{ 
        backgroundColor: 'rgba(255, 255, 255, 0.7)',
        backdropFilter: 'blur(8px)',
        border: '1px solid rgba(0, 0, 0, 0.05)',
        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.07)'
      }}
    >
      <div className="px-6 py-4 border-b" style={{ borderColor: 'rgba(0, 0, 0, 0.05)' }}>
        <div className="flex items-center gap-3">
          <div 
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: 'rgba(0, 0, 0, 0.03)' }}
          >
            <span className="text-lg">🏁</span>
          </div>
          
          <div>
            <h3 
              className="text-lg font-semibold"
              style={{ color: '#333333' }}
            >
              Identity Challenge History
            </h3>
            <p 
              className="text-sm"
              style={{ color: '#666666' }}
            >
              Based on your identity training feedback logs
            </p>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        {/* Persona feedback summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {personaTotals.map((d) => {
            const personaInfo = personaDetails[d.persona.toLowerCase() as keyof typeof personaDetails];
            const gradient = personaInfo?.gradient || 'linear-gradient(135deg, #E8E8E8, #C7C7C7)';
            const icon = personaInfo?.icon || '👤';
            
            return (
              <div 
                key={d.persona}
                className="rounded-xl p-4 flex items-center gap-4"
                style={{ 
                  background: 'rgba(255, 255, 255, 0.5)',
                  border: '1px solid rgba(0, 0, 0, 0.05)',
                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.03)'
                }}
              >
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ 
                    background: gradient,
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)'
                  }}
                >
                  <span className="text-xl">{icon}</span>
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4 
                      className="text-base font-medium"
                      style={{ color: '#333333' }}
                    >
                      {d.persona}
                    </h4>
                    <div 
                      className="px-2.5 py-0.5 rounded-full text-xs"
                      style={{ 
                        backgroundColor: 'rgba(0, 0, 0, 0.05)',
                        color: '#666666'
                      }}
                    >
                      {d.total} total
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    <div 
                      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs"
                      style={{ 
                        backgroundColor: 'rgba(197, 216, 164, 0.2)',
                        color: '#3E5931'
                      }}
                    >
                      <span>✅</span>
                      <span>{d.aligned}</span>
                    </div>
                    
                    <div 
                      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs"
                      style={{ 
                        backgroundColor: 'rgba(195, 177, 225, 0.2)',
                        color: '#5C4283'
                      }}
                    >
                      <span>😐</span>
                      <span>{d.okay}</span>
                    </div>
                    
                    <div 
                      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs"
                      style={{ 
                        backgroundColor: 'rgba(174, 198, 207, 0.2)',
                        color: '#3B5164'
                      }}
                    >
                      <span>❌</span>
                      <span>{d.not_me}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        {/* Chart visualization */}
        <div 
          className="rounded-xl p-4"
          style={{ 
            background: 'linear-gradient(135deg, rgba(245, 232, 199, 0.05), rgba(255, 255, 255, 0.9))',
            border: '1px solid rgba(0, 0, 0, 0.05)',
            boxShadow: 'inset 0 0 15px rgba(0, 0, 0, 0.02)'
          }}
        >
          <ResponsiveContainer width="100%" height={250}>
            <BarChart 
              data={data}
              margin={{ top: 20, right: 20, left: 10, bottom: 30 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(103, 58, 183, 0.08)" vertical={false} />
              <XAxis 
                dataKey="persona" 
                tick={{ fontSize: 12, fill: '#666666' }}
                tickLine={{ stroke: 'rgba(103, 58, 183, 0.2)' }}
                axisLine={{ stroke: 'rgba(103, 58, 183, 0.2)', strokeWidth: 1 }}
              />
              <YAxis 
                allowDecimals={false}
                tick={{ fontSize: 12, fill: '#666666' }}
                tickLine={{ stroke: 'rgba(103, 58, 183, 0.2)' }}
                axisLine={{ stroke: 'rgba(103, 58, 183, 0.2)', strokeWidth: 1 }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend content={<CustomLegend />} />
              <Bar 
                dataKey="aligned" 
                stackId="a" 
                fill="#C5D8A4" 
                radius={[4, 4, 0, 0]}
              />
              <Bar 
                dataKey="okay" 
                stackId="a" 
                fill="#C3B1E1" 
                radius={[0, 0, 0, 0]}
              />
              <Bar 
                dataKey="not_me" 
                stackId="a" 
                fill="#AEC6CF" 
                radius={[0, 0, 4, 4]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        {/* Last challenge date */}
        {lastDate && (
          <div 
            className="mt-4 text-center px-4 py-2 rounded-full text-sm inline-flex items-center gap-2 mx-auto"
            style={{ 
              backgroundColor: 'rgba(0, 0, 0, 0.03)',
              color: '#666666'
            }}
          >
            <span>🗓️</span>
            <span>Last challenge completed on: {lastDate}</span>
          </div>
        )}
      </div>
    </div>
  );
};






