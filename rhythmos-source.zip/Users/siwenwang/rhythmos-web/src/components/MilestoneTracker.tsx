// /components/MilestoneTracker.tsx - 扩展版本，包含微任务里程碑

import React, { useEffect, useState } from 'react';

interface Milestone {
  id: string;
  label: string;
  done: boolean;
  icon: string;
  category: 'general' | 'microtask' | 'challenge' | 'streak';
  threshold?: number;
  current?: number;
  description?: string;
}

const MilestoneTracker: React.FC = () => {
  const [milestones, setMilestones] = useState<Milestone[]>([]);

  // 定义所有里程碑
  const allMilestones: Milestone[] = [
    // 原有里程碑
    { id: 'first-feedback', label: 'First Feedback Submitted', done: false, icon: '✅', category: 'general', description: 'Submit your first cue feedback' },
    { id: 'first-challenge', label: 'First Challenge Completed', done: false, icon: '🏁', category: 'challenge', description: 'Complete your first identity challenge' },
    { id: 'first-reflection', label: 'First Reflection Written', done: false, icon: '🖋️', category: 'general', description: 'Write your first reflection' },
    { id: '100-xp', label: '100 XP Accumulated', done: false, icon: '🎯', category: 'general', threshold: 100, description: 'Accumulate 100 experience points' },
    { id: '10-cues-rated', label: '10 Cues Rated', done: false, icon: '📘', category: 'general', threshold: 10, description: 'Rate 10 different cues' },
    
    // 微任务里程碑
    { id: 'first-microtask', label: 'First Microtask Completed', done: false, icon: '🚀', category: 'microtask', threshold: 1, description: 'Complete your first microtask' },
    { id: '10-microtasks', label: '10 Microtasks Completed', done: false, icon: '🎯', category: 'microtask', threshold: 10, description: 'Build momentum with 10 microtasks' },
    { id: '50-microtasks', label: '50 Microtasks Completed', done: false, icon: '🏆', category: 'microtask', threshold: 50, description: 'Achieve consistency with 50 microtasks' },
    { id: '100-microtasks', label: '100 Microtasks Completed', done: false, icon: '👑', category: 'microtask', threshold: 100, description: 'Master micro-momentum with 100 microtasks' },
    
    // 连续天数里程碑
    { id: '3-day-streak', label: '3-Day Microtask Streak', done: false, icon: '🔥', category: 'streak', threshold: 3, description: 'Maintain microtasks for 3 consecutive days' },
    { id: '7-day-streak', label: '7-Day Microtask Streak', done: false, icon: '⚔️', category: 'streak', threshold: 7, description: 'Complete one week of consistent microtasks' },
    { id: '21-day-streak', label: '21-Day Microtask Streak', done: false, icon: '🧘', category: 'streak', threshold: 21, description: 'Form a habit with 21 days of microtasks' },
    { id: '30-day-streak', label: '30-Day Microtask Streak', done: false, icon: '🌟', category: 'streak', threshold: 30, description: 'Achieve mastery with 30 days straight' },
    
    // 特殊里程碑
    { id: 'daily-5-microtasks', label: '5 Microtasks in One Day', done: false, icon: '⚡', category: 'microtask', threshold: 5, description: 'Complete 5 microtasks in a single day' },
    { id: 'weekly-20-microtasks', label: '20 Microtasks in One Week', done: false, icon: '📊', category: 'microtask', threshold: 20, description: 'Complete 20 microtasks within one week' }
  ];

  // 检查里程碑状态
  const checkMilestoneStatus = () => {
    const unlockedMilestones = JSON.parse(localStorage.getItem('unlockedMilestones') || '[]');
    
    // 读取各种数据
    const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
    const challengeLog = JSON.parse(localStorage.getItem('challengeLog') || '[]');
    const personaXpLog = JSON.parse(localStorage.getItem('personaXpLog') || '{}');
    
    // 计算微任务统计
    const microtaskEntries = rhythmScoreLog.filter((entry: any) => entry.actionType === 'microtask_complete');
    const challengeEntries = challengeLog.filter((entry: any) => entry.completed !== false);
    
    const today = new Date().toISOString().split('T')[0];
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    const weekStartStr = weekStart.toISOString().split('T')[0];
    
    const stats = {
      totalMicrotasks: microtaskEntries.length,
      todayMicrotasks: microtaskEntries.filter((entry: any) => entry.date === today).length,
      weekMicrotasks: microtaskEntries.filter((entry: any) => entry.date >= weekStartStr).length,
      totalChallenges: challengeEntries.length,
      totalXp: Object.values(personaXpLog).reduce((sum: number, persona: any) => sum + (persona.xp || 0), 0)
    };

    // 计算微任务连续天数
    const microtaskDateGroups: Record<string, number> = {};
    microtaskEntries.forEach((entry: any) => {
      const date = entry.date || new Date(entry.timestamp).toISOString().split('T')[0];
      microtaskDateGroups[date] = (microtaskDateGroups[date] || 0) + 1;
    });

    let microtaskStreak = 0;
    let streakDate = today;
    while (microtaskDateGroups[streakDate]) {
      microtaskStreak++;
      const prevDate = new Date(streakDate);
      prevDate.setDate(prevDate.getDate() - 1);
      streakDate = prevDate.toISOString().split('T')[0];
    }

    // 更新里程碑状态
    const updatedMilestones = allMilestones.map(milestone => {
      let isDone = unlockedMilestones.includes(milestone.id);
      let currentValue = 0;

      // 自动检查完成状态
      if (!isDone && milestone.threshold) {
        switch (milestone.id) {
          case 'first-microtask':
          case '10-microtasks':
          case '50-microtasks':
          case '100-microtasks':
            currentValue = stats.totalMicrotasks;
            isDone = currentValue >= milestone.threshold;
            break;
          
          case '3-day-streak':
          case '7-day-streak':
          case '21-day-streak':
          case '30-day-streak':
            currentValue = microtaskStreak;
            isDone = currentValue >= milestone.threshold;
            break;
          
          case 'daily-5-microtasks':
            currentValue = stats.todayMicrotasks;
            isDone = currentValue >= milestone.threshold;
            break;
          
          case 'weekly-20-microtasks':
            currentValue = stats.weekMicrotasks;
            isDone = currentValue >= milestone.threshold;
            break;
          
          case 'first-challenge':
            currentValue = stats.totalChallenges;
            isDone = currentValue >= 1;
            break;
          
          case '100-xp':
            currentValue = stats.totalXp;
            isDone = currentValue >= milestone.threshold;
            break;
        }
      }

      return { 
        ...milestone, 
        done: isDone, 
        current: milestone.threshold ? currentValue : undefined 
      };
    });

    setMilestones(updatedMilestones);
  };

  useEffect(() => {
    checkMilestoneStatus();
    
    // 监听更新事件
    const handleUpdate = () => checkMilestoneStatus();
    
    ['achievement-unlocked', 'microtask-completed', 'challenge-completed', 'xp-updated', 'storage'].forEach(event => {
      window.addEventListener(event, handleUpdate);
    });
    
    return () => {
      ['achievement-unlocked', 'microtask-completed', 'challenge-completed', 'xp-updated', 'storage'].forEach(event => {
        window.removeEventListener(event, handleUpdate);
      });
    };
  }, []);

  // 按类别分组
  const categorizedMilestones = {
    microtask: milestones.filter(m => m.category === 'microtask'),
    streak: milestones.filter(m => m.category === 'streak'),
    challenge: milestones.filter(m => m.category === 'challenge'),
    general: milestones.filter(m => m.category === 'general')
  };

  const CategorySection: React.FC<{ title: string; milestones: Milestone[]; emoji: string }> = 
    ({ title, milestones, emoji }) => (
      <div className="mb-6">
        <h3 className="flex items-center gap-2 text-lg font-semibold mb-3 text-[--text-base]">
          <span>{emoji}</span>
          <span>{title}</span>
          <span className="text-sm font-normal text-gray-500">
            ({milestones.filter(m => m.done).length}/{milestones.length})
          </span>
        </h3>
        <div className="space-y-2">
          {milestones.map((milestone, index) => (
            <div
              key={milestone.id}
              className={`flex items-center gap-3 p-3 rounded-xl border transition-all duration-300 ${
                milestone.done 
                  ? 'bg-white shadow-sm border-green-200' 
                  : 'bg-gray-50 opacity-60 border-gray-200'
              }`}
              title={milestone.description}
            >
              <div className={`text-xl transition-all duration-200 ${
                milestone.done ? 'scale-110' : 'grayscale'
              }`}>
                {milestone.icon}
              </div>
              <div className="flex-1">
                <div className="text-sm text-[--text-base] font-medium">
                  {milestone.label}
                </div>
                {milestone.threshold && milestone.current !== undefined && (
                  <div className="flex items-center gap-2 mt-1">
                    <div className="text-xs text-gray-500">
                      {milestone.current} / {milestone.threshold}
                    </div>
                    <div className="flex-1 h-1.5 bg-gray-200 rounded-full">
                      <div 
                        className="h-full bg-blue-500 rounded-full transition-all duration-500"
                        style={{ 
                          width: `${Math.min(100, (milestone.current / milestone.threshold) * 100)}%` 
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>
              {milestone.done && (
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              )}
            </div>
          ))}
        </div>
      </div>
    );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-[--text-base]">Milestone Progress</h2>
        <div className="text-sm text-gray-500">
          {milestones.filter(m => m.done).length} / {milestones.length} completed
        </div>
      </div>
      
      <CategorySection 
        title="Micro-momentum" 
        milestones={categorizedMilestones.microtask} 
        emoji="⚡" 
      />
      <CategorySection 
        title="Streaks" 
        milestones={categorizedMilestones.streak} 
        emoji="🔥" 
      />
      <CategorySection 
        title="Challenges" 
        milestones={categorizedMilestones.challenge} 
        emoji="🎯" 
      />
      <CategorySection 
        title="General Growth" 
        milestones={categorizedMilestones.general} 
        emoji="🌱" 
      />
    </div>
  );
};

export default MilestoneTracker;
