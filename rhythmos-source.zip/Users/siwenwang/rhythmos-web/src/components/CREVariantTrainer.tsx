// components/CREVariantTrainer.tsx

import React from 'react';

const CREVariantTrainer: React.FC = () => {
  return (
    <div className="p-4 bg-[#f9f9f9] rounded-lg border space-y-2">
      <p className="text-sm text-gray-700 font-medium">🧪 Variant Trainer (Beta)</p>
      <p className="text-sm text-gray-500">You will be able to rate alternative tone variants here in future versions.</p>
      <p className="text-xs text-gray-400 italic">Coming soon: rate CRE cues to refine your Signature tone model.</p>
    </div>
  );
};

export default CREVariantTrainer;
