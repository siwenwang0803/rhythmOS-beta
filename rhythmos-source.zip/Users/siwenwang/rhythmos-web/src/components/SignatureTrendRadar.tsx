// components/SignatureTrendRadar.tsx

import React from 'react'

const SignatureTrendRadar: React.FC = () => {
  const log = JSON.parse(localStorage.getItem('signatureFeedbackLog') || '[]')

  const personaToneStats: Record<string, number> = {}

  log.forEach((entry: any) => {
    const key = `${entry.persona}_${entry.tone}`
    const weight = entry.feedback === 'aligned' ? 3 : entry.feedback === 'okay' ? 1 : -1
    personaToneStats[key] = (personaToneStats[key] || 0) + weight
  })

  const sorted = Object.entries(personaToneStats).sort((a, b) => b[1] - a[1])

  return (
    <div className="space-y-4">
      <h3 className="text-md font-semibold text-gray-700">🧠 Style Resonance Summary</h3>
      {sorted.map(([key, score]) => {
        const [persona, tone] = key.split('_')
        return (
          <div key={key} className="flex items-center text-sm text-gray-700">
            <span className="w-40 font-medium">{persona} × {tone}</span>
            <div className="flex-1 h-3 bg-blue-100 rounded overflow-hidden ml-2">
              <div
                className="h-full bg-blue-600"
                style={{ width: `${Math.min(score * 5, 100)}%` }}
              ></div>
            </div>
            <span className="ml-2">{score}</span>
          </div>
        )
      })}
    </div>
  )
}

export default SignatureTrendRadar
