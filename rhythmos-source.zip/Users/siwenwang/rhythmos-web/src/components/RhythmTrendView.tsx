// /components/RhythmTrendView.tsx

import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, ReferenceLine } from 'recharts';

// Rhythm state colors from the UI specification
const RHYTHM_COLORS = {
  collapsed: '#AEC6CF', // gentle calming blue
  wavy: '#C3B1E1',     // transitional lavender
  stable: '#C5D8A4',   // grounded light green
  rising: '#FFB347'    // activating orange-yellow
};

// Performance level labels and emojis (based on task completion)
const RHYTHM_STATES = {
  collapsed: { emoji: '🌱', label: 'Getting Started' },
  wavy: { emoji: '🎯', label: 'Building Progress' },
  stable: { emoji: '⚡', label: 'Strong Performance' },
  rising: { emoji: '🏆', label: 'Peak Achievement' }
};

interface RhythmTrendViewProps {
  isDaytime?: boolean; // Optional prop to control day/night mode
}

const safeNumber = (input: any): number => {
  if (typeof input === 'number' && !isNaN(input)) return input;
  const parsed = parseFloat(String(input));
  return isNaN(parsed) ? 0 : parsed;
};

// Custom tooltip component with enhanced styling
const CustomTooltip = ({ active, payload, label, isDaytime }: any) => {
  if (active && payload && payload.length) {
    const score = payload[0].value;
    
    // Determine performance level based on score
    let performanceLevel = 'collapsed';
    if (score >= 3 && score < 5) performanceLevel = 'wavy';
    else if (score >= 5 && score < 7.5) performanceLevel = 'stable';
    else if (score >= 7.5) performanceLevel = 'rising';
    
    const stateColor = RHYTHM_COLORS[performanceLevel as keyof typeof RHYTHM_COLORS];
    const stateInfo = RHYTHM_STATES[performanceLevel as keyof typeof RHYTHM_STATES];
    
    return (
      <div 
        style={{ 
          backgroundColor: isDaytime ? 'rgba(255, 255, 255, 0.95)' : 'rgba(40, 38, 46, 0.95)',
          padding: '12px 16px',
          borderRadius: '12px',
          boxShadow: isDaytime 
            ? '0 4px 20px rgba(0, 0, 0, 0.1)'
            : '0 4px 20px rgba(0, 0, 0, 0.3)',
          border: `1px solid ${stateColor}${isDaytime ? '40' : '60'}`,
          fontSize: '14px',
          transition: 'all 0.2s ease',
          color: isDaytime ? '#333' : '#e0e0e0'
        }}
      >
        <div style={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: '8px', 
          marginBottom: '8px',
          paddingBottom: '8px',
          borderBottom: isDaytime 
            ? '1px solid rgba(0, 0, 0, 0.05)'
            : '1px solid rgba(255, 255, 255, 0.1)'
        }}>
          <span style={{ fontSize: '18px' }}>{stateInfo.emoji}</span>
          <span style={{ fontWeight: 600 }}>{label}</span>
        </div>
        
        <div style={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between',
          marginBottom: '6px'
        }}>
          <span style={{ color: isDaytime ? '#666' : '#aaa' }}>Score:</span>
          <span style={{ 
            fontWeight: 'bold', 
            fontSize: '16px',
            color: isDaytime ? '#333' : '#fff'
          }}>{score.toFixed(1)}</span>
        </div>
        
        <div style={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between' 
        }}>
          <span style={{ color: isDaytime ? '#666' : '#aaa' }}>Performance:</span>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            backgroundColor: `${stateColor}${isDaytime ? '20' : '40'}`,
            padding: '4px 8px',
            borderRadius: '12px',
            fontSize: '12px'
          }}>
            <div style={{ 
              width: '8px', 
              height: '8px', 
              borderRadius: '50%', 
              backgroundColor: stateColor 
            }} />
            <span>{stateInfo.emoji} {stateInfo.label}</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

const RhythmTrendView: React.FC<RhythmTrendViewProps> = ({ isDaytime = true }) => {
  const dailySummaryLog = JSON.parse(localStorage.getItem('dailySummaryLog') || '[]');
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const [isAnimated, setIsAnimated] = useState(false);
  
  // Animation effect
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsAnimated(true);
    }, 300);
    
    return () => clearTimeout(timer);
  }, []);
  
  // 根据日夜模式调整颜色
  const baseTextColor = isDaytime ? '#333333' : '#E0E0E0';
  const secondaryTextColor = isDaytime ? '#666666' : '#AAAAAA';
  const gridColor = isDaytime 
    ? 'rgba(103, 58, 183, 0.08)'
    : 'rgba(255, 255, 255, 0.08)';
  const axisColor = isDaytime 
    ? 'rgba(103, 58, 183, 0.2)'
    : 'rgba(255, 255, 255, 0.2)';

  // Format the date to be more readable
  const formatDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return `${date.getMonth() + 1}/${date.getDate()}`;
    } catch (e) {
      return dateStr;
    }
  };

  const data = dailySummaryLog.map((entry: any, idx: number) => ({
    time: formatDate(entry.date),
    score: safeNumber(entry.score),
    rawDate: entry.date,
    idx
  }));

  // Ensure we have at least 3 data points for a better visual
  if (data.length < 3) {
    // Add today if it doesn't exist
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];
    
    if (!data.some(d => d.rawDate === todayStr)) {
      data.push({
        time: formatDate(todayStr),
        score: 0,
        rawDate: todayStr,
        idx: data.length
      });
    }
    
    // Add yesterday if needed
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    
    if (!data.some(d => d.rawDate === yesterdayStr)) {
      data.push({
        time: formatDate(yesterdayStr),
        score: 0,
        rawDate: yesterdayStr,
        idx: data.length
      });
    }
    
    // Sort by date
    data.sort((a, b) => new Date(a.rawDate).getTime() - new Date(b.rawDate).getTime());
  }

  if (data.length === 0) return (
    <div 
      className="text-sm italic text-center py-16 rounded-xl border"
      style={{ 
        color: secondaryTextColor,
        borderColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)',
        backgroundColor: isDaytime ? 'rgba(255, 255, 255, 0.5)' : 'rgba(255, 255, 255, 0.03)',
        backdropFilter: 'blur(8px)'
      }}
    >
      <div className="flex flex-col items-center gap-3">
        <div 
          className="w-16 h-16 rounded-full flex items-center justify-center text-2xl"
          style={{ 
            background: isDaytime 
              ? 'linear-gradient(135deg, #f0f0f0, #e0e0e0)'
              : 'linear-gradient(135deg, #3a3a3a, #2a2a2a)',
            boxShadow: isDaytime
              ? '0 4px 15px rgba(0, 0, 0, 0.05)'
              : '0 4px 15px rgba(0, 0, 0, 0.2)'
          }}
        >
          📈
        </div>
        <p>No performance data available yet.</p>
        <p className="text-xs opacity-75">Your daily achievement progress will be visualized here.</p>
      </div>
    </div>
  );

  // Get dynamic dot styling based on score value and hover state
  const getDotStyle = (score: number, idx: number) => {
    // Determine performance level based on score
    let performanceLevel = 'collapsed';
    if (score >= 3 && score < 5) performanceLevel = 'wavy';
    else if (score >= 5 && score < 7.5) performanceLevel = 'stable';
    else if (score >= 7.5) performanceLevel = 'rising';
    
    const color = RHYTHM_COLORS[performanceLevel as keyof typeof RHYTHM_COLORS];
    const isHovered = hoveredIdx === idx;
    
    return {
      r: isHovered ? 6 : 4,
      strokeWidth: isHovered ? 2 : 1,
      stroke: color,
      fill: isDaytime ? 'white' : '#252430',
      cursor: 'pointer',
      // Add animation for smooth transitions
      transition: 'r 0.2s ease, strokeWidth 0.2s ease'
    };
  };

  // Handle dot hover
  const handleDotMouseEnter = (idx: number) => {
    setHoveredIdx(idx);
  };
  
  const handleDotMouseLeave = () => {
    setHoveredIdx(null);
  };

  return (
    <div 
      className={`mt-5 transform transition-all duration-700 ${
        isAnimated ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0'
      }`}
    >
      <div 
        style={{ 
          width: '100%', 
          borderRadius: '16px',
          overflow: 'hidden',
          background: isDaytime
            ? 'linear-gradient(135deg, rgba(245, 232, 199, 0.05), rgba(255, 255, 255, 0.9))'
            : 'linear-gradient(135deg, rgba(40, 38, 46, 0.9), rgba(50, 48, 58, 0.8))',
          padding: '24px 10px 20px',
          boxShadow: isDaytime
            ? '0 8px 30px rgba(0, 0, 0, 0.07), inset 0 0 15px rgba(0, 0, 0, 0.02)'
            : '0 8px 30px rgba(0, 0, 0, 0.2), inset 0 0 15px rgba(255, 255, 255, 0.01)',
          border: isDaytime
            ? '1px solid rgba(0, 0, 0, 0.05)'
            : '1px solid rgba(255, 255, 255, 0.05)',
          backdropFilter: 'blur(10px)'
        }}
      >
        {/* Chart Title */}
        <div 
          className="flex items-center justify-between px-6 mb-6"
        >
          <div className="flex items-center gap-2">
            <div 
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ 
                background: isDaytime
                  ? 'rgba(0, 0, 0, 0.03)'
                  : 'rgba(255, 255, 255, 0.05)'
              }}
            >
              <span className="text-lg">📈</span>
            </div>
            <h3 
              className="text-base font-medium"
              style={{ color: baseTextColor }}
            >
              Daily Performance Trend
            </h3>
          </div>
          
          <div 
            className="px-3 py-1 rounded-full text-xs flex items-center gap-1"
            style={{ 
              backgroundColor: isDaytime
                ? 'rgba(0, 0, 0, 0.05)'
                : 'rgba(255, 255, 255, 0.07)',
              color: secondaryTextColor
            }}
          >
            <span>Last {data.length} days</span>
          </div>
        </div>
        
        <ResponsiveContainer width="100%" height={280}>
          <LineChart 
            data={data}
            margin={{ top: 20, right: 24, left: 10, bottom: 20 }}
            onMouseLeave={handleDotMouseLeave}
          >
            {/* Background shading for score ranges */}
            <defs>
              <linearGradient id="collapsedArea" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={`${RHYTHM_COLORS.collapsed}30`} stopOpacity={0.8} />
                <stop offset="100%" stopColor={`${RHYTHM_COLORS.collapsed}10`} stopOpacity={0.2} />
              </linearGradient>
              
              <linearGradient id="wavyArea" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={`${RHYTHM_COLORS.wavy}30`} stopOpacity={0.8} />
                <stop offset="100%" stopColor={`${RHYTHM_COLORS.wavy}10`} stopOpacity={0.2} />
              </linearGradient>
              
              <linearGradient id="stableArea" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={`${RHYTHM_COLORS.stable}30`} stopOpacity={0.8} />
                <stop offset="100%" stopColor={`${RHYTHM_COLORS.stable}10`} stopOpacity={0.2} />
              </linearGradient>
              
              <linearGradient id="risingArea" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={`${RHYTHM_COLORS.rising}30`} stopOpacity={0.8} />
                <stop offset="100%" stopColor={`${RHYTHM_COLORS.rising}10`} stopOpacity={0.2} />
              </linearGradient>
              
              {/* Gradient for the line */}
              <linearGradient id="colorGradient" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor={isDaytime ? "#9C27B0" : "#B048CE"} />
                <stop offset="100%" stopColor={isDaytime ? "#673AB7" : "#8E67CF"} />
              </linearGradient>
            </defs>
            
            {/* Performance level boundary lines */}
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke={gridColor}
              vertical={false}
              opacity={0.6}
            />
            
            {/* Performance level boundary lines */}
            <ReferenceLine y={3} stroke={RHYTHM_COLORS.collapsed} strokeDasharray="3 3" strokeWidth={1} />
            <ReferenceLine y={5} stroke={RHYTHM_COLORS.wavy} strokeDasharray="3 3" strokeWidth={1} />
            <ReferenceLine y={7.5} stroke={RHYTHM_COLORS.stable} strokeDasharray="3 3" strokeWidth={1} />
            
            <XAxis 
              dataKey="time" 
              tick={{ fontSize: 12, fill: secondaryTextColor }}
              tickLine={{ stroke: axisColor }}
              axisLine={{ stroke: axisColor, strokeWidth: 1 }}
            />
            <YAxis 
              domain={[0, 10]}
              tick={{ fontSize: 12, fill: secondaryTextColor }}
              tickLine={{ stroke: axisColor }}
              axisLine={{ stroke: axisColor, strokeWidth: 1 }}
              ticks={[0, 2, 4, 6, 8, 10]}
            />
            <Tooltip content={(props) => <CustomTooltip {...props} isDaytime={isDaytime} />} />
            <Line 
              type="monotone" 
              dataKey="score" 
              stroke="url(#colorGradient)" 
              strokeWidth={2.5}
              activeDot={false}
              dot={(props: any) => {
                const { cx, cy, payload, index } = props;
                const dotStyle = getDotStyle(payload.score, payload.idx);
                return (
                  <circle 
                    key={`dot-${payload.idx}-${index}`}
                    cx={cx} 
                    cy={cy} 
                    {...dotStyle}
                    onMouseEnter={() => handleDotMouseEnter(payload.idx)}
                  />
                );
              }}
            />
          </LineChart>
        </ResponsiveContainer>
        
        {/* Performance level labels on the right side */}
        <div 
          className="absolute right-6 top-1/2 transform -translate-y-1/2 flex flex-col gap-3 opacity-70"
          style={{ pointerEvents: 'none' }}
        >
          <div className="text-xs" style={{ color: RHYTHM_COLORS.rising }}>Peak Achievement</div>
          <div className="text-xs" style={{ color: RHYTHM_COLORS.stable }}>Strong Performance</div>
          <div className="text-xs" style={{ color: RHYTHM_COLORS.wavy }}>Building Progress</div>
          <div className="text-xs" style={{ color: RHYTHM_COLORS.collapsed }}>Getting Started</div>
        </div>
      </div>
      
      {/* Legend for performance levels */}
      <div 
        className="flex flex-wrap gap-2 justify-center mt-5"
        style={{ padding: '0 10px' }}
      >
        {Object.entries(RHYTHM_STATES).map(([state, info]) => (
          <div 
            key={state}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs transition-all duration-200 hover:transform hover:scale-105"
            style={{ 
              backgroundColor: isDaytime
                ? `${RHYTHM_COLORS[state as keyof typeof RHYTHM_COLORS]}20`
                : `${RHYTHM_COLORS[state as keyof typeof RHYTHM_COLORS]}30`,
              color: baseTextColor,
              border: isDaytime
                ? `1px solid ${RHYTHM_COLORS[state as keyof typeof RHYTHM_COLORS]}30`
                : `1px solid ${RHYTHM_COLORS[state as keyof typeof RHYTHM_COLORS]}40`,
              cursor: 'pointer'
            }}
          >
            <div 
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: RHYTHM_COLORS[state as keyof typeof RHYTHM_COLORS] }}
            />
            <span>{info.emoji}</span>
            <span style={{ fontSize: '12px' }}>
              {info.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RhythmTrendView;









