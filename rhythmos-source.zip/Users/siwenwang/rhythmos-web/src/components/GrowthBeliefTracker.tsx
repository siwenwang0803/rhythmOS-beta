// 修改后的 GrowthBeliefTracker.tsx
// 统一使用 initPersona 作为活跃身份

import React, { useState, useEffect } from 'react';

// UI 规范中的颜色和样式
const PERSONAS = {
  rhea: {
    name: 'Rhea',
    color: '#F5CFCF',
    lightColor: '#F9E5E5',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    icon: '💗'
  },
  caelum: {
    name: 'Caelum',
    color: '#4B6587',
    lightColor: '#D8E1F0',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    icon: '💠'
  },
  aurelia: {
    name: 'Aurelia',
    color: '#D8A7CA',
    lightColor: '#F2E4EE',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    icon: '🧠'
  },
  niveus: {
    name: 'Niveus',
    color: '#E8D5C4',
    lightColor: '#F3ECE7',
    gradient: 'linear-gradient(135deg, #F5E8C7, #E8D5C4)',
    icon: '📊'
  },
  lucis: {
    name: 'Lucis',
    color: '#A4D8C5',
    lightColor: '#E4F2ED',
    gradient: 'linear-gradient(135deg, #E8F5C7, #A4D8C5)',
    icon: '🌱'
  }
};

const GrowthBeliefTracker: React.FC = () => {
  const [rating, setRating] = useState<number>(3);
  const [submitted, setSubmitted] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [activePersona, setActivePersona] = useState<string>('rhea');

  // 监听身份变化 - 简化为只使用 initPersona
  useEffect(() => {
    const handlePersonaChange = () => {
      const newPersona = localStorage.getItem('initPersona') || 'rhea';
      if (newPersona !== activePersona) {
        console.log('[GrowthBeliefTracker] 检测到 initPersona 变化:', newPersona);
        setActivePersona(newPersona);
      }
    };
    
    // 初始设置
    handlePersonaChange();
    
    // 监听事件
    window.addEventListener('persona-changed', handlePersonaChange);
    return () => {
      window.removeEventListener('persona-changed', handlePersonaChange);
    };
  }, [activePersona]);

  // 获取对应 persona 的样式
  const personaStyle = PERSONAS[activePersona] || PERSONAS.rhea;
  
  // 评分等级标签
  const ratingLabels = {
    1: 'Not at all',
    2: 'Slightly',
    3: 'Moderately',
    4: 'Very much',
    5: 'Completely'
  };

  const handleSubmit = () => {
    const record = {
      persona: activePersona,
      score: rating,
      timestamp: Date.now()
    };
    const raw = localStorage.getItem('growthBeliefLog');
    const log = raw ? JSON.parse(raw) : [];
    log.push(record);
    localStorage.setItem('growthBeliefLog', JSON.stringify(log.slice(-50)));
    setSubmitted(true);
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRating(parseInt(e.target.value));
  };

  // 自定义滑块的CSS样式
  useEffect(() => {
    const sliderColor = personaStyle.color;
    const lightColor = personaStyle.lightColor;
    
    // 创建一个动态样式元素
    const styleEl = document.createElement('style');
    styleEl.innerHTML = `
      .slider-${activePersona} {
        -webkit-appearance: none;
        width: 100%;
        height: 8px;
        border-radius: 8px;
        background: #e0e0e0;
        outline: none;
        transition: all 0.2s;
      }
      
      .slider-${activePersona}::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 24px;
        height: 24px;
        border-radius: 50%;
        background: ${sliderColor};
        border: 3px solid white;
        cursor: pointer;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
        transition: all 0.2s;
      }
      
      .slider-${activePersona}::-moz-range-thumb {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        background: ${sliderColor};
        border: 3px solid white;
        cursor: pointer;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
        transition: all 0.2s;
      }
      
      .slider-${activePersona}::-webkit-slider-thumb:hover,
      .slider-${activePersona}::-webkit-slider-thumb:active {
        transform: scale(1.1);
        box-shadow: 0 3px 8px rgba(0, 0, 0, 0.2);
      }
      
      .slider-${activePersona}::-moz-range-thumb:hover,
      .slider-${activePersona}::-moz-range-thumb:active {
        transform: scale(1.1);
        box-shadow: 0 3px 8px rgba(0, 0, 0, 0.2);
      }
      
      .slider-${activePersona}::-webkit-slider-runnable-track {
        background: linear-gradient(to right, 
          ${lightColor} 0%, 
          ${lightColor} ${(rating - 1) * 25}%, 
          #e0e0e0 ${(rating - 1) * 25}%, 
          #e0e0e0 100%);
        height: 8px;
        border-radius: 8px;
        transition: background 0.3s;
      }
      
      .slider-active-thumb {
        transform: scale(1.15) !important;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.25) !important;
      }
    `;
    document.head.appendChild(styleEl);
    
    return () => {
      document.head.removeChild(styleEl);
    };
  }, [activePersona, rating, personaStyle]);

  return (
    <div 
      className="rounded-xl overflow-hidden"
      style={{ 
        border: '1px solid rgba(0, 0, 0, 0.05)',
        boxShadow: '0 2px 10px rgba(0, 0, 0, 0.03)'
      }}
    >
      {/* 顶部颜色条 */}
      <div 
        className="h-1 w-full"
        style={{ background: personaStyle.gradient }}
      />
      
      <div 
        className="p-6"
        style={{ 
          backgroundColor: 'rgba(255, 255, 255, 0.7)',
          backdropFilter: 'blur(8px)'
        }}
      >
        {/* 标题和图标 */}
        <div className="flex items-start gap-4 mb-4">
          <div 
            className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ 
              background: personaStyle.gradient,
              boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)'
            }}
          >
            <span>{personaStyle.icon}</span>
          </div>
          
          <div>
            <h4 
              className="text-lg font-medium mb-1" 
              style={{ color: '#333333' }}
            >
              How close were you to being {personaStyle.name} today?
            </h4>
            <p 
              className="text-xs" 
              style={{ color: '#666666' }}
            >
              Rate how aligned you felt with this identity from 1 to 5.
            </p>
          </div>
        </div>

        {!submitted ? (
          <div className="space-y-4">
            {/* 滑块评分 */}
            <div className="py-3 px-2 relative">
              <input
                type="range"
                min="1"
                max="5"
                step="1"
                value={rating}
                onChange={handleSliderChange}
                onMouseDown={() => setIsDragging(true)}
                onMouseUp={() => setIsDragging(false)}
                onTouchStart={() => setIsDragging(true)}
                onTouchEnd={() => setIsDragging(false)}
                className={`slider-${activePersona} w-full`}
              />
              
              {/* 数值标签 */}
              <div className="flex justify-between mt-4">
                {[1, 2, 3, 4, 5].map((value) => (
                  <div 
                    key={value}
                    className="flex flex-col items-center transition-all"
                    style={{
                      transform: value === rating ? 'scale(1.1)' : 'scale(1)',
                      transition: 'all 0.2s'
                    }}
                  >
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center mb-1"
                      style={{
                        backgroundColor: value <= rating ? personaStyle.color : '#e0e0e0',
                        color: value <= rating ? 'white' : '#666',
                        fontWeight: value === rating ? 'bold' : 'normal',
                        boxShadow: value === rating ? '0 2px 6px rgba(0, 0, 0, 0.15)' : 'none',
                        transform: isDragging && value === rating ? 'scale(1.15)' : 'scale(1)',
                        transition: 'all 0.2s'
                      }}
                    >
                      {value}
                    </div>
                    {value === rating && (
                      <div 
                        className="text-xs animate-fade-in-up absolute"
                        style={{
                          bottom: '-14px',
                          left: `${(value - 1) * 25}%`,
                          width: '100%',
                          maxWidth: '80px',
                          marginLeft: value === 1 ? '0' : value === 5 ? '-60px' : '-40px',
                          textAlign: 'center',
                          color: '#666666',
                          fontWeight: '500'
                        }}
                      >
                        {ratingLabels[value as keyof typeof ratingLabels]}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            {/* 评分说明 */}
            <div className="flex justify-between px-2 text-xs mt-6" style={{ color: '#666666' }}>
              <div>Not at all</div>
              <div>Completely</div>
            </div>
            
            {/* 提交按钮 */}
            <div className="mt-6 text-center">
              <button
                onClick={handleSubmit}
                className="px-5 py-2.5 rounded-xl transition-all duration-200 inline-flex items-center gap-2"
                style={{ 
                  background: personaStyle.gradient,
                  color: '#333333',
                  boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.15)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.1)';
                }}
              >
                <span>✓</span>
                <span>Submit Rating</span>
              </button>
            </div>
          </div>
        ) : (
          <div 
            className="p-4 rounded-xl border animate-fade-in-up"
            style={{ 
              backgroundColor: 'rgba(255, 255, 255, 0.7)',
              borderColor: personaStyle.color + '40',
              boxShadow: '0 2px 6px rgba(0, 0, 0, 0.04)'
            }}
          >
            <div className="flex items-center gap-3">
              <div 
                className="w-8 h-8 rounded-full flex items-center justify-center"
                style={{ 
                  backgroundColor: personaStyle.color,
                  opacity: 0.8,
                  color: 'white'
                }}
              >
                ✓
              </div>
              <div>
                <p 
                  className="text-sm font-medium" 
                  style={{ color: '#333333' }}
                >
                  You logged your identity alignment as <strong>{rating} / 5</strong>
                </p>
                <p 
                  className="text-xs mt-1" 
                  style={{ color: '#666666' }}
                >
                  {ratingLabels[rating as keyof typeof ratingLabels]}
                </p>
              </div>
            </div>
            
            {/* 重置按钮 */}
            <div className="mt-3 text-center">
              <button
                onClick={() => setSubmitted(false)}
                className="text-xs px-3 py-1 rounded-md transition-all duration-200"
                style={{ 
                  backgroundColor: 'rgba(0, 0, 0, 0.05)',
                  color: '#666666'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'rgba(0, 0, 0, 0.08)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'rgba(0, 0, 0, 0.05)';
                }}
              >
                Rate again
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default GrowthBeliefTracker;