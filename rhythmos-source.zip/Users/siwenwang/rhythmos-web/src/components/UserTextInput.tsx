// components/UserTextInput.tsx

import React, { useState } from 'react';
import { triggerToneFromText } from '../rhea-echo/toneTrigger';
import { mapEmotionToTone } from '../rhea-echo/toneSwitchEngine';
import { writePassiveToneLog } from '../rhea-echo/signaturePassiveWriter';
import { generateCREStyleReply } from '../speak-interface/CRECueResponder';
import { writeSpeakReplayLog } from '../speak-interface/speakReplayWriter';
import { signatureMap, getSignatureMap } from '../SignatureMap';

// 定义 UI 规范中的颜色和样式
const RHYTHM_COLORS = {
  collapsed: '#AEC6CF', // 平静的蓝色
  wavy: '#C3B1E1',     // 过渡的薰衣草色
  stable: '#C5D8A4',    // 稳定的绿色
  rising: '#FFB347'     // 激活的橙黄色
};

const PERSONAS = {
  rhea: {
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    color: '#F5CFCF',
    icon: '💗'
  },
  caelum: {
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    color: '#4B6587',
    icon: '💠'
  },
  aurelia: {
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    color: '#D8A7CA',
    icon: '🧠'
  },
  lucis: {
    gradient: 'linear-gradient(135deg, #F5E8C7, #C5D8A4)',
    color: '#C5D8A4',
    icon: '🌱'
  },
  niveus: {
    gradient: 'linear-gradient(135deg, #F5E8C7, #A2C4C9)',
    color: '#A2C4C9',
    icon: '📊'
  }
};

interface Props {
  onSubmit?: (text: string) => void;
}

const UserTextInput: React.FC<Props> = ({ onSubmit }) => {
  const [text, setText] = useState('');
  const [response, setResponse] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  
  // 当前 persona
  const currentPersona = localStorage.getItem('initPersona') || 'rhea';
  const personaStyle = PERSONAS[currentPersona] || PERSONAS.rhea;
  
  // 当前节奏状态
  const currentTrend = localStorage.getItem('lastTrend') || 'wavy';
  const rhythmColor = RHYTHM_COLORS[currentTrend] || RHYTHM_COLORS.wavy;

  const handleSubmit = () => {
    if (!text.trim()) return;

    try {
      const currentText = text;
      setSubmitted(true);
      setText('');

      const emotion = triggerToneFromText(currentText);
      const tone = mapEmotionToTone(emotion);
      const persona = localStorage.getItem('initPersona') || 'rhea';

      writePassiveToneLog({ emotion, tone, timestamp: Date.now() });

      // 模拟打字效果
      setIsTyping(true);
      
      setTimeout(() => {
        const reply = generateCREStyleReply(currentText, tone, persona);
        setResponse(reply);
        setIsTyping(false);
        
        // 确保 speakReplayLog 存在
        if (!signatureMap.speakReplayLog) {
          signatureMap.speakReplayLog = [];
        }
        
        // 创建日志条目
        const logEntry = {
          userInput: currentText,
          systemResponse: reply,
          tone,
          emotion,
          persona,
          timestamp: new Date().toISOString(),
        };
        
        // 添加到 signatureMap
        signatureMap.speakReplayLog.push(logEntry);
        
        // 同时添加到 meta.speakReplayLog 作为备用位置
        if (!signatureMap.meta.speakReplayLog) {
          signatureMap.meta.speakReplayLog = [];
        }
        signatureMap.meta.speakReplayLog.push(logEntry);
        
        console.log('UserTextInput - Added speak log entry:', {
          logEntry,
          totalLogs: signatureMap.speakReplayLog.length,
          signatureMapUpdated: true
        });

        // 写入到其他存储位置
        writeSpeakReplayLog({
          userInput: currentText,
          systemResponse: reply,
          emotion,
          tone,
          persona,
          timestamp: Date.now(),
        });

        // 触发更新事件，通知其他组件
        const speakLogEvent = new CustomEvent('speak-log-updated', {
          detail: { 
            logEntry,
            totalLogs: signatureMap.speakReplayLog.length
          }
        });
        window.dispatchEvent(speakLogEvent);
        
        // 也触发通用的 signatureMap 更新事件
        window.dispatchEvent(new CustomEvent('signatureMap-updated'));
        
        console.log('UserTextInput - Events dispatched:', {
          speakLogUpdated: true,
          signatureMapUpdated: true
        });

        onSubmit?.(currentText);
      }, 800); // 延迟模拟思考和打字

      setTimeout(() => {
        setSubmitted(false);
      }, 1500);
    } catch (error) {
      console.error('Error in handleSubmit:', error);
      setIsTyping(false);
      setSubmitted(false);
    }
  };

  return (
    <div className="space-y-4 relative">
      <div className="flex items-center gap-3 mb-2">
        <div 
          className="w-8 h-8 rounded-xl flex items-center justify-center" 
          style={{ 
            background: personaStyle.gradient,
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)'
          }}
        >
          <span className="text-lg">{personaStyle.icon}</span>
        </div>
        <div>
          <h3 className="text-sm font-medium" style={{ color: '#333333' }}>
            Message your rhythm system
          </h3>
          <p className="text-xs" style={{ color: '#666666' }}>
            Express your thoughts and receive personalized reflection
          </p>
        </div>
      </div>
      
      <div 
        className="rounded-xl overflow-hidden"
        style={{ 
          border: '1px solid rgba(0, 0, 0, 0.05)',
          boxShadow: 'inset 0 2px 4px rgba(0, 0, 0, 0.02)'
        }}
      >
        <textarea
          className="w-full px-4 py-3 text-sm leading-relaxed transition-all duration-300 focus:outline-none"
          style={{ 
            backgroundColor: 'rgba(255, 255, 255, 0.7)',
            backdropFilter: 'blur(8px)',
            color: '#333333',
            resize: 'none'
          }}
          placeholder="e.g. I feel stuck. I wish I had more clarity."
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
          onFocus={(e) => {
            e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
          }}
          onBlur={(e) => {
            e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.7)';
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && e.ctrlKey) {
              handleSubmit();
            }
          }}
          disabled={isTyping || submitted}
        />
      </div>
      
      <div className="flex gap-3 items-center">
        <button
          onClick={handleSubmit}
          disabled={!text.trim() || isTyping || submitted}
          className="inline-flex items-center text-sm px-5 py-2.5 rounded-xl font-medium transition-all duration-200 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
          style={{ 
            backgroundColor: '#F5E8C7', // 主题基础沙色
            color: '#333333',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)',
            border: '1px solid rgba(0, 0, 0, 0.05)'
          }}
          onMouseEnter={(e) => {
            if (!e.currentTarget.disabled) {
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.08)';
            }
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = '0 2px 4px rgba(0, 0, 0, 0.05)';
          }}
        >
          <span className="mr-2">📨</span>
          {isTyping ? 'Processing...' : 'Send'}
        </button>
        
        <span 
          className={`text-sm font-medium transition-opacity duration-300 ${submitted ? 'opacity-100' : 'opacity-0'}`}
          style={{ color: '#666666' }}
        >
          ✅ Message sent
        </span>
      </div>
      
      {(response || isTyping) && (
        <div 
          className={`rounded-xl transition-all duration-300 overflow-hidden mt-4`}
          style={{ 
            border: `1px solid ${personaStyle.color}20`, // 20% 透明度的边框
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)',
            background: 'rgba(255, 255, 255, 0.9)'
          }}
        >
          <div 
            className="h-1 w-full"
            style={{ background: personaStyle.gradient }}
          />
          
          <div 
            className="p-4 text-sm"
            style={{ 
              backgroundColor: 'rgba(255, 255, 255, 0.7)',
              backdropFilter: 'blur(8px)',
              color: '#333333'
            }}
          >
            {isTyping ? (
              <div className="flex items-center gap-2">
                <div className="flex gap-1.5">
                  <span 
                    className="w-2 h-2 rounded-full"
                    style={{ 
                      backgroundColor: personaStyle.color, 
                      animation: 'pulse 1.5s ease-in-out infinite',
                      animationDelay: '0ms'
                    }}
                  ></span>
                  <span 
                    className="w-2 h-2 rounded-full"
                    style={{ 
                      backgroundColor: personaStyle.color, 
                      animation: 'pulse 1.5s ease-in-out infinite',
                      animationDelay: '200ms'
                    }}
                  ></span>
                  <span 
                    className="w-2 h-2 rounded-full"
                    style={{ 
                      backgroundColor: personaStyle.color, 
                      animation: 'pulse 1.5s ease-in-out infinite',
                      animationDelay: '400ms'
                    }}
                  ></span>
                </div>
                <span className="text-xs" style={{ color: '#666666' }}>
                  Thinking...
                </span>
              </div>
            ) : (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <div 
                    className="w-6 h-6 rounded-full flex items-center justify-center"
                    style={{ 
                      backgroundColor: personaStyle.color,
                      opacity: 0.8
                    }}
                  >
                    <span className="text-xs">{personaStyle.icon}</span>
                  </div>
                  <p className="text-xs font-medium" style={{ color: '#666666' }}>
                    System Response
                  </p>
                </div>
                <p className="leading-relaxed">{response}</p>
              </div>
            )}
          </div>
        </div>
      )}
      
      <div className="text-xs text-center mt-2" style={{ color: '#666666' }}>
        Press Ctrl+Enter to send your message
      </div>
      
      {/* 添加脉冲动画的样式 */}
      <style>{`
        @keyframes pulse {
          0%, 100% {
            opacity: 0.4;
            transform: scale(0.8);
          }
          50% {
            opacity: 1;
            transform: scale(1);
          }
        }
      `}</style>
    </div>
  );
};

export default UserTextInput;






