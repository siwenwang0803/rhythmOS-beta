// 优化的 ChallengeReplayPanel.tsx - 基于你的现有代码修复记录丢失问题

import React, { useState, useEffect } from 'react';
import { getSignatureMap } from '../SignatureMap';
import { identityAnchoringChallenges } from '../data/identityAnchoringChallenges_v2';

const normalizeTimestamp = (t: number | string) => {
  return typeof t === 'string' ? new Date(t).getTime() : t;
};

interface ChallengeReplayPanelProps {
  isDaytime?: boolean;
}

const ChallengeReplayPanel: React.FC<ChallengeReplayPanelProps> = ({ isDaytime = true }) => {
  const [scope, setScope] = useState<'recent' | 'all'>('recent');
  const [logs, setLogs] = useState<any[]>([]);

  // Theme colors based on day/night mode
  const themeColors = {
    background: isDaytime ? '#F5E8C7' : '#2C2C2C',
    panelBg: isDaytime ? '#FFFFFF' : '#3A3A3A',
    panelAltBg: isDaytime ? '#F8F8F5' : '#454545',
    text: isDaytime ? '#333333' : '#E0E0E0',
    textMuted: isDaytime ? '#777777' : '#AAAAAA',
    border: isDaytime ? '#E6E6E6' : '#555555',
    borderLight: isDaytime ? '#EEEEEE' : '#4A4A4A',
    shadow: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(0, 0, 0, 0.2)',
    accentPrimary: '#F7DC6F',
  };

  // Persona colors from UI spec
  const personaColors = {
    rhea: '#F5CFCF',
    caelum: '#4B6587',
    aurelia: '#D8A7CA',
    niveus: '#A2C4C9',
    lucis: '#C5D8A4',
  };

  useEffect(() => {
    const refreshData = () => {
      try {
        console.log('=== ChallengeReplayPanel: 开始数据刷新 ===');
        
        let allLogs = [];
        const today = new Date().toISOString().split('T')[0];
        
        // 1. 从 challengeLog 获取挑战记录
        const challengeLogRaw = localStorage.getItem('challengeLog');
        const challengeLog = challengeLogRaw ? JSON.parse(challengeLogRaw) : [];
        console.log('localStorage challengeLog entries:', challengeLog);
        
        // 2. 从 signatureMap 获取挑战记录
        let signatureLogs = [];
        try {
          const currentSignatureMap = getSignatureMap();
          signatureLogs = currentSignatureMap?.challengeLog || [];
          console.log('SignatureMap challenge logs:', signatureLogs);
        } catch (signatureMapError) {
          console.log('Error accessing SignatureMap:', signatureMapError);
          // 如果无法获取 SignatureMap，尝试从 window 对象获取
          if (typeof window !== 'undefined' && (window as any).signatureMap) {
            signatureLogs = (window as any).signatureMap.challengeLog || [];
            console.log('SignatureMap from window:', signatureLogs);
          }
        }
        
        // 3. 从 rhythmScoreLog 获取挑战完成记录 - 新增
        const rhythmScoreLogRaw = localStorage.getItem('rhythmScoreLog');
        const rhythmScoreLog = rhythmScoreLogRaw ? JSON.parse(rhythmScoreLogRaw) : [];
        const challengeCompletions = rhythmScoreLog.filter((entry: any) => 
          entry.actionType === 'challenge_complete'
        );
        console.log('RhythmScoreLog 挑战完成记录:', challengeCompletions);
        
        // 4. 处理 signatureMap 数据 - 统一格式
        const processedSignatureLogs = signatureLogs.map((entry: any) => ({
          text: entry.text || entry.cue || 'Unknown challenge',
          persona: entry.persona || entry.personaAnchor || 'rhea',
          time: entry.timestamp ? new Date(entry.timestamp).getTime() : Date.now(),
          date: entry.timestamp ? entry.timestamp.split('T')[0] : today,
          feedback: entry.feedback || undefined,
          completed: entry.completed !== undefined ? entry.completed : true,
          source: 'signatureMap'
        }));
        
        // 5. 处理 challengeLog 数据 - 统一格式
        const processedChallengeLog = challengeLog.map((entry: any) => ({
          text: entry.text || entry.cue || 'Unknown challenge',
          persona: entry.persona || 'rhea',
          time: entry.time || Date.now(),
          date: entry.date || entry.today || today,
          feedback: entry.feedback || undefined,
          completed: entry.completed !== undefined ? entry.completed : true,
          source: 'challengeLog'
        }));
        
        // 6. 从 rhythmScoreLog 的完成记录推断挑战 - 新增
        const inferredChallenges = challengeCompletions.map((completion: any) => ({
          text: `Challenge completed (${completion.date || today})`,
          persona: localStorage.getItem('initPersona') || 'rhea',
          time: completion.timestamp ? new Date(completion.timestamp).getTime() : Date.now(),
          date: completion.date || today,
          feedback: undefined,
          completed: true,
          source: 'rhythmScoreLog',
          inferred: true
        }));
        
        // 7. 合并所有数据源
        allLogs = [...processedChallengeLog, ...processedSignatureLogs, ...inferredChallenges];
        
        // 8. 改进的去重逻辑 - 基于时间、文本相似度和日期
        const uniqueLogs = [];
        const processedKeys = new Set();
        
        // 先按时间排序，优先处理最近的记录
        allLogs.sort((a, b) => normalizeTimestamp(b.time) - normalizeTimestamp(a.time));
        
        for (const log of allLogs) {
          // 创建唯一键：persona_日期_时间范围
          const timeSlot = Math.floor(normalizeTimestamp(log.time) / (5 * 60 * 1000)); // 5分钟时间窗口
          const uniqueKey = `${log.persona}_${log.date}_${timeSlot}`;
          
          // 检查是否已经有相似的记录
          let isDuplicate = false;
          
          // 检查是否与已有记录重复
          for (const existingLog of uniqueLogs) {
            const existingTimeSlot = Math.floor(normalizeTimestamp(existingLog.time) / (5 * 60 * 1000));
            const existingKey = `${existingLog.persona}_${existingLog.date}_${existingTimeSlot}`;
            
            // 如果是相同的时间段、相同persona、相同日期
            if (existingKey === uniqueKey) {
              // 如果新记录有反馈而旧记录没有，或者新记录不是推断的
              if ((log.feedback && !existingLog.feedback) || (!log.inferred && existingLog.inferred)) {
                // 替换旧记录
                const index = uniqueLogs.indexOf(existingLog);
                uniqueLogs[index] = log;
              }
              isDuplicate = true;
              break;
            }
          }
          
          // 如果不是重复记录，添加到列表
          if (!isDuplicate) {
            uniqueLogs.push(log);
          }
        }
        
        // 9. 过滤并最终排序
        const finalLogs = uniqueLogs
          .filter(log => log.completed !== false)
          .sort((a, b) => normalizeTimestamp(b.time) - normalizeTimestamp(a.time));
        
        console.log('最终处理的日志:', finalLogs);
        console.log('有反馈的日志:', finalLogs.filter(log => log.feedback));
        console.log('推断的挑战:', finalLogs.filter(log => log.inferred));
        
        setLogs(finalLogs);
        
        // 10. 如果发现数据不一致，尝试修复 challengeLog
        const realChallenges = finalLogs.filter(log => !log.inferred && log.source !== 'rhythmScoreLog');
        if (realChallenges.length > challengeLog.length) {
          console.log('检测到数据不一致，尝试修复 challengeLog...');
          const repairedChallengeLog = realChallenges.map(log => ({
            text: log.text,
            persona: log.persona,
            time: log.time,
            date: log.date,
            today: log.date, // 保持向后兼容
            completed: log.completed,
            feedback: log.feedback
          }));
          localStorage.setItem('challengeLog', JSON.stringify(repairedChallengeLog));
          console.log('challengeLog 已修复');
        }
        
      } catch (error) {
        console.error('Error processing challenge logs:', error);
        setLogs([]);
      }
    };

    // 初始加载
    refreshData();
    
    // 设置事件监听器
    const handleChallengeUpdate = () => {
      console.log('Challenge update detected, refreshing data...');
      setTimeout(refreshData, 100);
    };
    
    // 监听更新事件
    window.addEventListener('challenge-completed', handleChallengeUpdate);
    window.addEventListener('challenge-feedback-updated', handleChallengeUpdate);
    window.addEventListener('storage', handleChallengeUpdate);
    
    return () => {
      window.removeEventListener('challenge-completed', handleChallengeUpdate);
      window.removeEventListener('challenge-feedback-updated', handleChallengeUpdate);
      window.removeEventListener('storage', handleChallengeUpdate);
    };
  }, []);

  // 根据范围过滤日志
  let filteredLogs = logs;
  if (scope === 'recent') {
    filteredLogs = logs.slice(0, 3);
  }

  // 反馈标签映射
  const feedbackTag = (f: string | undefined) => {
    if (!f) return '📝 No feedback yet';
    switch (f) {
      case 'aligned': return '✅ Aligned';
      case 'okay': return '😐 Okay';
      case 'not_me': return '❌ Not me';
      case 'completed': return '✅ Completed';
      default: return '📝 No feedback';
    }
  };

  // 获取挑战行动文本
  const getChallengeAction = (cueText: string, persona?: string): string => {
    if (!persona || cueText.startsWith('Challenge completed')) return cueText;
    
    try {
      const list = identityAnchoringChallenges[persona.toLowerCase()] || [];
      const found = list.find((c) => c.cue === cueText);
      return found?.action || cueText;
    } catch (error) {
      console.log('Error getting challenge action:', error);
      return cueText;
    }
  };

  // 获取 persona 颜色
  const getPersonaColor = (persona: string): string => {
    const lowerPersona = persona.toLowerCase();
    return personaColors[lowerPersona as keyof typeof personaColors] || '#CCCCCC';
  };

  return (
    <div 
      className="rounded-xl px-4 py-4 mt-6 space-y-4"
      style={{
        backgroundColor: themeColors.panelBg,
        border: `1px solid ${themeColors.border}`,
        boxShadow: `0 2px 8px ${themeColors.shadow}`,
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }}
    >
      <div className="flex items-center justify-between mb-2">
        <div 
          className="text-sm font-semibold flex items-center gap-2"
          style={{ color: themeColors.text }}
        >
          📂 Challenge Feedback History
          <span 
            className="text-xs px-2 py-1 rounded-full"
            style={{ 
              backgroundColor: themeColors.accentPrimary + '30',
              color: themeColors.text
            }}
          >
            {logs.length} total
          </span>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={scope}
            onChange={(e) => setScope(e.target.value as 'recent' | 'all')}
            className="text-sm px-2 py-1 rounded-lg shadow-sm"
            style={{
              backgroundColor: themeColors.panelAltBg,
              border: `1px solid ${themeColors.borderLight}`,
              color: themeColors.text,
              outline: 'none'
            }}
          >
            <option value="recent">Last 3</option>
            <option value="all">All</option>
          </select>
          
          {/* 调试按钮 */}
          <button
            onClick={() => {
              console.log('=== Challenge Data Debug ===');
              console.log('Displayed logs:', logs);
              console.log('challengeLog:', JSON.parse(localStorage.getItem('challengeLog') || '[]'));
              console.log('rhythmScoreLog challenges:', JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]').filter((e: any) => e.actionType === 'challenge_complete'));
              console.log('signatureMap challenges:', (window as any).signatureMap?.challengeLog);
              alert('Debug info logged to console');
            }}
            className="text-xs px-2 py-1 rounded text-gray-500 hover:text-gray-700"
            title="Debug challenge data"
          >
            🐛
          </button>
        </div>
      </div>

      {filteredLogs.length === 0 ? (
        <div>
          <p 
            className="text-sm italic"
            style={{ color: themeColors.textMuted }}
          >
            No challenge records found.
          </p>
          <div className="mt-2 space-y-1">
            <p className="text-xs" style={{ color: themeColors.textMuted }}>
              💡 Complete challenges and provide feedback to see your history here.
            </p>
            <p className="text-xs" style={{ color: themeColors.textMuted }}>
              🔍 Challenge feedback helps track your identity alignment over time.
            </p>
          </div>
        </div>
      ) : (
        <div>
          {/* 统计信息 */}
          <div className="mb-4 grid grid-cols-3 gap-2">
            <div 
              className="text-center p-2 rounded-lg"
              style={{ backgroundColor: themeColors.panelAltBg }}
            >
              <div className="text-lg font-bold" style={{ color: themeColors.text }}>
                {logs.filter(l => l.completed !== false).length}
              </div>
              <div className="text-xs" style={{ color: themeColors.textMuted }}>
                Completed
              </div>
            </div>
            <div 
              className="text-center p-2 rounded-lg"
              style={{ backgroundColor: themeColors.panelAltBg }}
            >
              <div className="text-lg font-bold" style={{ color: themeColors.text }}>
                {logs.filter(l => l.feedback).length}
              </div>
              <div className="text-xs" style={{ color: themeColors.textMuted }}>
                With Feedback
              </div>
            </div>
            <div 
              className="text-center p-2 rounded-lg"
              style={{ backgroundColor: themeColors.panelAltBg }}
            >
              <div className="text-lg font-bold" style={{ color: themeColors.text }}>
                {logs.filter(l => !l.inferred).length}
              </div>
              <div className="text-xs" style={{ color: themeColors.textMuted }}>
                Recorded
              </div>
            </div>
          </div>
          
          <ul className="space-y-3" style={{ animation: 'fadeInUp 0.5s ease-out' }}>
            {filteredLogs.map((entry, idx) => {
              const personaColor = getPersonaColor(entry.persona);
              const hasRealFeedback = entry.feedback && entry.feedback !== 'completed';
              
              return (
                <li
                  key={`${entry.persona}-${entry.text}-${entry.date}-${idx}`}
                  className="px-4 py-3 rounded-lg text-sm"
                  style={{
                    backgroundColor: entry.inferred ? 
                      `${themeColors.panelAltBg}80` : themeColors.panelAltBg,
                    border: `1px solid ${themeColors.borderLight}`,
                    borderLeft: `3px solid ${personaColor}`,
                    boxShadow: `0 1px 3px ${themeColors.shadow}`,
                    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                    opacity: entry.inferred ? 0.8 : 1
                  }}
                >
                  <p 
                    className="font-medium mb-1 leading-tight"
                    style={{ color: themeColors.text }}
                  >
                    "{getChallengeAction(entry.text, entry.persona)}"
                    {entry.inferred && (
                      <span 
                        className="ml-2 text-xs px-1 py-0.5 rounded"
                        style={{ 
                          backgroundColor: '#FFF3CD', 
                          color: '#856404',
                          fontSize: '10px'
                        }}
                      >
                        inferred
                      </span>
                    )}
                  </p>
                  <div 
                    className="text-xs flex flex-wrap gap-2 items-center"
                    style={{ color: themeColors.textMuted }}
                  >
                    {/* 反馈状态 */}
                    <span 
                      className={`px-2 py-1 rounded ${hasRealFeedback ? 'font-medium' : ''}`}
                      style={{ 
                        backgroundColor: hasRealFeedback 
                          ? (entry.feedback === 'aligned' ? '#d4eff0' : 
                             entry.feedback === 'okay' ? '#fff4e6' : '#ffe6e6')
                          : 'transparent',
                        color: hasRealFeedback 
                          ? (entry.feedback === 'aligned' ? '#0f5c5c' : 
                             entry.feedback === 'okay' ? '#b85c00' : '#c41e3a')
                          : themeColors.textMuted
                      }}
                    >
                      {feedbackTag(entry.feedback)}
                    </span>
                    
                    <span style={{ color: isDaytime ? '#CCCCCC' : '#666666' }}>•</span>
                    
                    {/* Persona */}
                    <span 
                      className="capitalize"
                      style={{
                        backgroundColor: `${personaColor}33`,
                        color: isDaytime ? '#333333' : '#E0E0E0',
                        padding: '1px 6px',
                        borderRadius: '4px',
                        fontSize: '10px'
                      }}
                    >
                      {entry.persona}
                    </span>
                    
                    <span style={{ color: isDaytime ? '#CCCCCC' : '#666666' }}>•</span>
                    
                    {/* 时间 */}
                    <span>
                      {new Date(normalizeTimestamp(entry.time)).toLocaleString(undefined, {
                        dateStyle: 'short',
                        timeStyle: 'short'
                      })}
                    </span>
                    
                    {/* 数据源标识（调试用） */}
                    {entry.source && (
                      <>
                        <span style={{ color: isDaytime ? '#CCCCCC' : '#666666' }}>•</span>
                        <span style={{ fontSize: '9px', opacity: 0.7 }}>
                          {entry.source}
                        </span>
                      </>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
};

export default ChallengeReplayPanel;