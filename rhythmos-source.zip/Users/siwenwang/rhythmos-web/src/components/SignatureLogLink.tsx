import React from 'react'
import { useNavigate } from 'react-router-dom'
import RhythmButton from './ui/RhythmButton'

const SignatureLogLink: React.FC = () => {
  const navigate = useNavigate()

  return (
    <div className="text-center mt-6">
      <p className="text-sm text-gray-500 mb-2">
        Want to see how your feedback shaped your rhythm?
      </p>
      <RhythmButton variant="muted" onClick={() => navigate('/log-history')}>
        🔎 View Signature Feedback Log
      </RhythmButton>
    </div>
  )
}

export default SignatureLogLink
