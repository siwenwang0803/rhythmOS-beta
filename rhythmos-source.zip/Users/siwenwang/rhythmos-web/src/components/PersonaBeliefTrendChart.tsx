// components/PersonaBeliefTrendChart.tsx

import React, { useState, useMemo } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  ReferenceLine
} from 'recharts';
import { format, subDays, isAfter } from 'date-fns';

// 扩展 persona 颜色和样式定义
const PERSONAS: Record<string, {
  name: string,
  color: string,
  lightColor: string,
  gradient: string,
  icon: string
}> = {
  rhea: {
    name: 'Rhea',
    color: '#F5CFCF',
    lightColor: '#F9E5E5',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    icon: '💗'
  },
  aurelia: {
    name: 'Aurelia',
    color: '#D8A7CA',
    lightColor: '#F2E4EE',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    icon: '🧠'
  },
  caelum: {
    name: 'Caelum',
    color: '#4B6587',
    lightColor: '#D8E1F0',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    icon: '💠'
  },
  niveus: {
    name: 'Niveus',
    color: '#A2C4C9',
    lightColor: '#E8F4F6',
    gradient: 'linear-gradient(135deg, #F5E8C7, #A2C4C9)',
    icon: '📊'
  },
  lucis: {
    name: 'Lucis',
    color: '#C5D8A4',
    lightColor: '#EDF5E7',
    gradient: 'linear-gradient(135deg, #F5E8C7, #C5D8A4)',
    icon: '🌱'
  }
};

// 时间范围选项
const TIME_RANGES = [
  { value: 7, label: '7 days' },
  { value: 14, label: '14 days' },
  { value: 30, label: '30 days' },
];

// 简单的模式检测函数
const checkForPattern = (scores: number[]) => {
  if (scores.length < 7) return false;
  
  let patternScore = 0;
  for (let i = 0; i < scores.length - 3; i++) {
    const pattern1 = scores[i] < scores[i+1] && scores[i+1] > scores[i+2];
    const pattern2 = scores[i] > scores[i+1] && scores[i+1] < scores[i+2];
    if (pattern1 || pattern2) patternScore++;
  }
  
  return patternScore > scores.length / 4;
};

// 更全面的趋势分析函数
const generateInsights = (scores: number[], persona: string) => {
  if (scores.length < 4) return { insights: [] };
  
  const personaInfo = PERSONAS[persona];
  const insights = [];
  
  // 基础指标计算
  const avg = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length;
  const overall = avg(scores);
  const recent = avg(scores.slice(-5));
  const first = avg(scores.slice(0, Math.floor(scores.length / 2)));
  const second = avg(scores.slice(Math.floor(scores.length / 2)));
  const delta = second - first;
  
  // 计算波动性 (标准差)
  const variance = scores.reduce((sum, score) => sum + Math.pow(score - overall, 2), 0) / scores.length;
  const stdDev = Math.sqrt(variance);
  
  // 分析高分天和低分天
  const highDays = scores.filter(s => s >= 4).length;
  const lowDays = scores.filter(s => s <= 2).length;
  const highDaysPercent = Math.round((highDays / scores.length) * 100);
  const lowDaysPercent = Math.round((lowDays / scores.length) * 100);
  
  // 分析稳定性
  const isStable = stdDev < 0.8;
  const isWavy = stdDev > 1.2;
  
  // 检测模式
  const hasPattern = checkForPattern(scores);
  
  // 生成主要趋势洞察
  if (delta > 0.5) {
    insights.push({
      type: 'trend',
      icon: '📈',
      title: 'Growing Connection',
      text: `Your alignment with ${personaInfo.name} has been increasing by ${delta.toFixed(1)} points on average.`
    });
  } else if (delta < -0.5) {
    insights.push({
      type: 'trend',
      icon: '📉',
      title: 'Decreasing Connection',
      text: `Your alignment with ${personaInfo.name} has been decreasing by ${Math.abs(delta).toFixed(1)} points on average.`
    });
  } else if (isStable) {
    insights.push({
      type: 'trend',
      icon: '🌱',
      title: 'Stable Identity',
      text: `You've maintained a consistent connection with your ${personaInfo.name} identity.`
    });
  } else if (isWavy) {
    insights.push({
      type: 'trend',
      icon: '🌊',
      title: 'Fluctuating Identity',
      text: `Your ${personaInfo.name} identity has been fluctuating significantly.`
    });
  }
  
  // 生成强度洞察
  if (overall > 4) {
    insights.push({
      type: 'strength',
      icon: '⭐',
      title: 'Strong Identity',
      text: `You have a very strong connection to your ${personaInfo.name} identity.`
    });
  } else if (overall < 2.5) {
    insights.push({
      type: 'strength',
      icon: '🌱',
      title: 'Developing Identity',
      text: `Your ${personaInfo.name} identity is still developing and has room to grow.`
    });
  }
  
  // 添加高/低日洞察
  if (highDaysPercent > 40) {
    insights.push({
      type: 'frequency',
      icon: '🔆',
      title: 'Frequent High Alignment',
      text: `You deeply connected with ${personaInfo.name} on ${highDaysPercent}% of days.`
    });
  } else if (lowDaysPercent > 40) {
    insights.push({
      type: 'frequency',
      icon: '🔅',
      title: 'Frequent Low Alignment',
      text: `You found it challenging to connect with ${personaInfo.name} on ${lowDaysPercent}% of days.`
    });
  }
  
  // 如果检测到模式，添加模式洞察
  if (hasPattern) {
    insights.push({
      type: 'pattern',
      icon: '🔄',
      title: 'Cyclical Pattern',
      text: `Your ${personaInfo.name} identity follows a cyclical pattern. You may have regular high and low periods.`
    });
  }
  
  // 添加健康建议
  if (isWavy && recent < 3) {
    insights.push({
      type: 'suggestion',
      icon: '💡',
      title: 'Stabilization Opportunity',
      text: `Consider practices that can help stabilize your ${personaInfo.name} identity.`
    });
  } else if (!isWavy && overall < 3) {
    insights.push({
      type: 'suggestion',
      icon: '💡',
      title: 'Growth Opportunity',
      text: `Focus on experiences that strengthen your ${personaInfo.name} identity.`
    });
  } else if (overall > 3.5 && stdDev < 0.5) {
    insights.push({
      type: 'suggestion',
      icon: '💡',
      title: 'Challenge Opportunity',
      text: `You have a strong, stable ${personaInfo.name} identity. Consider testing it in new contexts.`
    });
  }
  
  return {
    overall,
    recent,
    delta,
    stdDev,
    highDaysPercent,
    lowDaysPercent,
    insights: insights.slice(0, 3) // 限制为前3个最相关的洞察
  };
};

// 自定义提示框组件
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const personaKey = payload[0].dataKey.split('.')[0];
    const personaColor = PERSONAS[personaKey]?.color || '#888';
    
    return (
      <div style={{
        padding: '12px',
        backgroundColor: 'white',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
        borderRadius: '8px',
        border: '1px solid #f0f0f0'
      }}>
        <p style={{ 
          fontSize: '14px', 
          fontWeight: '500',
          color: '#333',
          margin: '0 0 4px 0'
        }}>
          {label}
        </p>
        <p style={{ 
          fontSize: '14px', 
          fontWeight: '500',
          color: personaColor,
          margin: 0
        }}>
          Rating: {payload[0].value}
        </p>
      </div>
    );
  }
  return null;
};

// 实际组件定义
const PersonaBeliefTrendChart: React.FC = () => {
  const [selected, setSelected] = useState('aurelia'); // 默认为 aurelia
  const [timeRange, setTimeRange] = useState(14); // 默认显示14天
  const [hoveredDate, setHoveredDate] = useState<string | null>(null);
  
  // 处理从 localStorage 读取数据 - 移除了硬编码示例数据
  const getPersonaLog = (persona: string, days: number) => {
    try {
      const raw = localStorage.getItem('growthBeliefLog');
      if (!raw) return [];
      
      const log = JSON.parse(raw);
      
      // 计算日期范围
      const cutoffDate = subDays(new Date(), days);
      
      // 过滤并排序数据
      const filteredData = log
        .filter((entry: any) => {
          return entry.persona && 
                 entry.persona.toLowerCase() === persona.toLowerCase() &&
                 entry.timestamp &&
                 entry.score !== undefined;
        })
        .filter((entry: any) => isAfter(new Date(entry.timestamp), cutoffDate))
        .sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      
      // 格式化数据 - 只返回真实数据，不生成示例数据
      return filteredData.map((entry: any) => ({
        date: format(new Date(entry.timestamp), 'MMM d'),
        fullDate: new Date(entry.timestamp),
        [`${persona}`]: entry.score
      }));
    } catch (error) {
      console.error('Error loading persona log:', error);
      return [];
    }
  };
  
  // 获取数据并计算趋势 - 现在只使用真实数据
  const data = useMemo(() => getPersonaLog(selected, timeRange), [selected, timeRange]);
  const scores = data.map(d => d[selected as keyof typeof d] as number);
  
  // 计算趋势洞察
  const getTrendInsight = (scores: number[]) => {
    if (scores.length < 4) return { text: 'Not enough data to detect trend.', icon: '📊' };
    
    const half = Math.floor(scores.length / 2);
    const avg = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length;
    const delta = avg(scores.slice(half)) - avg(scores.slice(0, half));
    
    // 检测波动模式 - 计算标准差
    const mean = avg(scores);
    const variance = scores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) / scores.length;
    const stdDev = Math.sqrt(variance);
    const isWavy = stdDev > 1.2;
    
    // 根据不同条件返回不同文本和图标
    if (isWavy) {
      return { 
        text: 'Your alignment has been fluctuating recently.', 
        icon: '🌊',
        color: '#C3B1E1'
      };
    } else if (delta > 0.5) {
      return { 
        text: 'Your alignment with this identity is growing.', 
        icon: '📈',
        color: '#FFB347'
      };
    } else if (delta < -0.5) {
      return { 
        text: 'Your alignment has been declining recently.', 
        icon: '📉',
        color: '#AEC6CF'
      };
    } else {
      return { 
        text: 'Your alignment has been stable recently.', 
        icon: '➡️',
        color: '#C5D8A4'
      };
    }
  };
  
  const trend = getTrendInsight(scores);
  const personaStyle = PERSONAS[selected];
  
  // 计算移动平均线数据（平滑趋势线）
  const getMovingAverage = (data: any[], windowSize = 3) => {
    if (data.length < windowSize) return [];
    
    return data.map((point, i) => {
      if (i < windowSize - 1) return { ...point, ma: null };
      
      let sum = 0;
      for (let j = 0; j < windowSize; j++) {
        sum += data[i - j][selected];
      }
      
      return {
        ...point,
        ma: sum / windowSize
      };
    });
  };
  
  const movingAvgData = getMovingAverage(data);
  
  // 计算个人平均值
  const personalAvg = scores.length > 0 ? 
    scores.reduce((sum, score) => sum + score, 0) / scores.length : 0;
    
  // 生成高级洞察
  const { insights, overall, recent, stdDev } = useMemo(() => 
    generateInsights(scores, selected), [scores, selected]);
  
  return (
    <div style={{
      borderRadius: '12px',
      overflow: 'hidden',
      border: '1px solid #e5e5e5',
      backgroundColor: 'white',
      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)'
    }}>
      {/* 顶部颜色条 */}
      <div 
        style={{
          height: '4px',
          width: '100%',
          background: personaStyle.gradient
        }}
      />
      
      <div style={{ padding: '20px' }}>
        {/* 标题和选择器区域 */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '16px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{
              width: '40px',
              height: '40px',
              borderRadius: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              background: personaStyle.gradient,
              boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)'
            }}>
              <span>{personaStyle.icon}</span>
            </div>
            
            <div>
              <h3 style={{
                fontSize: '18px',
                fontWeight: '500',
                color: '#333',
                margin: '0 0 4px 0'
              }}>
                Identity Alignment Trend
              </h3>
              <p style={{
                fontSize: '12px',
                color: '#6b7280',
                margin: 0
              }}>
                Track how consistently you embody your chosen identity
              </p>
            </div>
          </div>
          
          <div style={{ display: 'flex', gap: '8px' }}>
            {/* Persona选择器 */}
            <div style={{ position: 'relative' }}>
              <select
                style={{
                  appearance: 'none',
                  backgroundColor: 'white',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  padding: '8px 32px 8px 12px',
                  fontSize: '14px',
                  color: '#333',
                  outline: 'none',
                  cursor: 'pointer'
                }}
                value={selected}
                onChange={(e) => setSelected(e.target.value)}
              >
                {Object.keys(PERSONAS).map(p => (
                  <option key={p} value={p}>
                    {PERSONAS[p].name}
                  </option>
                ))}
              </select>
              <div style={{
                pointerEvents: 'none',
                position: 'absolute',
                top: '50%',
                right: '8px',
                transform: 'translateY(-50%)',
                color: '#9ca3af'
              }}>
                <svg style={{ width: '16px', height: '16px', fill: 'currentColor' }} viewBox="0 0 20 20">
                  <path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* 时间范围选择器 */}
        <div style={{
          display: 'flex',
          marginBottom: '16px',
          border: '1px solid #e5e7eb',
          borderRadius: '8px',
          padding: '2px'
        }}>
          {TIME_RANGES.map((range) => (
            <button
              key={range.value}
              style={{
                flex: 1,
                padding: '6px 0',
                fontSize: '12px',
                fontWeight: '500',
                borderRadius: '6px',
                border: 'none',
                cursor: 'pointer',
                transition: 'all 0.2s',
                backgroundColor: timeRange === range.value 
                  ? personaStyle.lightColor 
                  : 'transparent',
                color: timeRange === range.value ? '#333' : '#6b7280'
              }}
              onClick={() => setTimeRange(range.value)}
            >
              {range.label}
            </button>
          ))}
        </div>
        
        {/* 图表区域 */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '4px'
        }}>
          {data.length === 0 ? (
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '60px 20px',
              color: '#9ca3af',
              textAlign: 'center'
            }}>
              <svg style={{
                width: '64px',
                height: '64px',
                marginBottom: '16px',
                opacity: 0.5
              }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2" />
              </svg>
              <h4 style={{ 
                fontSize: '16px', 
                fontWeight: '500',
                color: '#374151',
                margin: '0 0 8px 0'
              }}>
                No Data Available
              </h4>
              <p style={{ 
                fontSize: '14px',
                margin: '0 0 16px 0',
                maxWidth: '300px'
              }}>
                Start rating your {personaStyle.name} alignment to see your trend here. 
                Your first data points will appear after you begin tracking.
              </p>
              <div style={{
                padding: '8px 16px',
                backgroundColor: personaStyle.lightColor,
                borderRadius: '6px',
                fontSize: '12px',
                color: '#374151'
              }}>
                💡 Tip: Rate your alignment daily for better insights
              </div>
            </div>
          ) : data.length < 2 ? (
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '48px 20px',
              color: '#9ca3af',
              textAlign: 'center'
            }}>
              <div style={{
                width: '48px',
                height: '48px',
                borderRadius: '50%',
                backgroundColor: personaStyle.lightColor,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '16px'
              }}>
                <span style={{ fontSize: '24px' }}>{personaStyle.icon}</span>
              </div>
              <h4 style={{ 
                fontSize: '16px', 
                fontWeight: '500',
                color: '#374151',
                margin: '0 0 8px 0'
              }}>
                Need More Data Points
              </h4>
              <p style={{ 
                fontSize: '14px',
                margin: 0,
                maxWidth: '280px'
              }}>
                You have {data.length} data point. Add a few more ratings to see your {personaStyle.name} alignment trend.
              </p>
            </div>
          ) : (
            <div style={{ height: '260px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart 
                  data={data} 
                  margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                  onMouseMove={(e) => {
                    if (e.activeLabel) {
                      setHoveredDate(e.activeLabel);
                    }
                  }}
                  onMouseLeave={() => setHoveredDate(null)}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                  <XAxis 
                    dataKey="date" 
                    fontSize={11} 
                    tickLine={false} 
                    axisLine={false} 
                    tick={{ fill: '#888' }}
                    interval={timeRange > 14 ? 'preserveEnd' : 0}
                  />
                  <YAxis 
                    domain={[1, 5]} 
                    ticks={[1, 2, 3, 4, 5]} 
                    fontSize={11} 
                    tickLine={false} 
                    axisLine={false}
                    tick={{ fill: '#888' }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  
                  {/* 平均线 */}
                  <ReferenceLine 
                    y={personalAvg} 
                    stroke="#92A3B6" 
                    strokeDasharray="3 3" 
                    strokeWidth={1}
                  />
                  
                  {/* 移动平均线 */}
                  <Line
                    type="monotone"
                    dataKey="ma"
                    stroke={personaStyle.color}
                    strokeWidth={1.5}
                    strokeDasharray="5 5"
                    dot={false}
                    activeDot={false}
                    isAnimationActive={true}
                    strokeOpacity={0.7}
                  />
                  
                  {/* 主数据线 */}
                  <Line
                    type="monotone"
                    dataKey={selected}
                    stroke={personaStyle.color}
                    strokeWidth={2.5}
                    dot={{ 
                      r: 4, 
                      fill: 'white', 
                      stroke: personaStyle.color, 
                      strokeWidth: 2 
                    }}
                    activeDot={{ 
                      r: 6, 
                      stroke: 'white', 
                      strokeWidth: 2,
                      fill: personaStyle.color
                    }}
                    isAnimationActive={true}
                    connectNulls={true}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* 仅当没有高级洞察时显示简单趋势信息 */}
        {data.length >= 2 && (!insights || insights.length === 0) && (
          <div style={{
            marginTop: '16px',
            padding: '12px',
            borderRadius: '8px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            backgroundColor: trend.color ? `${trend.color}20` : personaStyle.lightColor,
            borderLeft: `3px solid ${trend.color || personaStyle.color}`
          }}>
            <div style={{ fontSize: '20px' }}>{trend.icon}</div>
            <p style={{ fontSize: '14px', color: '#333', margin: 0 }}>
              {trend.text}
            </p>
          </div>
        )}
        
        {/* 高级洞察面板 */}
        {insights && insights.length > 0 && (
          <div style={{ marginTop: '20px' }}>
            <h4 style={{
              fontSize: '14px',
              fontWeight: '500',
              marginBottom: '12px',
              color: '#555'
            }}>
              Identity Insights
            </h4>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {insights.map((insight, idx) => (
                <div 
                  key={idx}
                  style={{
                    padding: '12px',
                    borderRadius: '8px',
                    border: `1px solid ${personaStyle.color}30`,
                    backgroundColor: 'white',
                    borderLeft: `3px solid ${personaStyle.color}`
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div style={{ fontSize: '20px' }}>{insight.icon}</div>
                    <div>
                      <h5 style={{
                        fontSize: '14px',
                        fontWeight: '500',
                        color: '#333',
                        margin: '0 0 4px 0'
                      }}>
                        {insight.title}
                      </h5>
                      <p style={{
                        fontSize: '12px',
                        color: '#666',
                        margin: 0
                      }}>
                        {insight.text}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* 统计摘要 */}
            <div style={{
              marginTop: '16px',
              paddingTop: '16px',
              borderTop: '1px solid #e5e7eb',
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: '8px'
            }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Overall Average</div>
                <div style={{
                  fontSize: '18px',
                  fontWeight: '500',
                  marginTop: '4px',
                  color: personaStyle.color
                }}>
                  {overall?.toFixed(1) || '-'}/5
                </div>
              </div>
              
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Recent Average</div>
                <div style={{
                  fontSize: '18px',
                  fontWeight: '500',
                  marginTop: '4px',
                  color: personaStyle.color
                }}>
                  {recent?.toFixed(1) || '-'}/5
                </div>
              </div>
              
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Consistency</div>
                <div style={{
                  fontSize: '18px',
                  fontWeight: '500',
                  marginTop: '4px',
                  color: personaStyle.color
                }}>
                  {stdDev < 0.8 ? 'High' : stdDev < 1.2 ? 'Medium' : 'Low'}
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* 底部信息 */}
        <div style={{
          marginTop: '16px',
          paddingTop: '12px',
          borderTop: '1px solid #e5e7eb',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <p style={{ fontSize: '12px', color: '#6b7280', margin: 0 }}>
            {data.length > 0 
              ? `Showing ${data.length} data points from the past ${timeRange} days`
              : `Ready to track data for the past ${timeRange} days`
            }
          </p>
          {data.length > 0 && (
            <button style={{
              fontSize: '12px',
              color: '#2563eb',
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '4px'
            }}>
              View detailed analysis
              <svg style={{ width: '12px', height: '12px' }} viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default PersonaBeliefTrendChart;
