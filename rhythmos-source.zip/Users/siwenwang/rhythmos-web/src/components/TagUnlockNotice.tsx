// TagUnlockNotice.tsx - 修复版本

import React from 'react';

interface Props {
  tagId: string;
  isDaytime?: boolean;
}

// 标签解锁叙述库
const TAG_UNLOCK_NARRATIVES: Record<string, string> = {
  'expressive_guide': 'You\'ve become an Expressive Guide! Your ability to communicate with clarity and warmth helps others find their way.',
  'structured_support': 'You\'ve unlocked Structured Support! Your organized approach provides others with reliable guidance and stability.',
  'empathetic_clarity': 'You\'ve developed Empathetic Clarity! You have the gift of understanding others deeply while communicating with precision.',
  'creative_catalyst': 'You\'ve become a Creative Catalyst! Your innovative thinking inspires new possibilities in yourself and others.',
  'mindful_leadership': 'You\'ve unlocked Mindful Leadership! You lead with awareness, presence, and authentic intention.',
  'calm_challenger': 'You\'ve become a Calm Challenger! You face obstacles with steady resilience and thoughtful determination.',
  'reflective_builder': 'You\'ve unlocked Reflective Builder! You construct your growth through thoughtful practice and careful consideration.',
  'structure': 'You\'ve developed a sense of Structure! Your organized approach brings clarity to complex situations.',
  'vision': 'You\'ve unlocked Vision! Your ability to see the bigger picture guides your decisions and inspires others.',
  'clarity': 'You\'ve achieved Clarity! Your clear thinking and communication cut through confusion.',
  'focus': 'You\'ve developed Focus! Your ability to concentrate deeply allows you to achieve meaningful results.',
  'presence': 'You\'ve cultivated Presence! Your mindful awareness brings depth to every interaction.',
  'balance': 'You\'ve found Balance! Your ability to harmonize different aspects of life creates stability.',
  'calm': 'You\'ve achieved Calm! Your peaceful presence provides a steady anchor in turbulent times.',
  'courage': 'You\'ve unlocked Courage! Your willingness to face challenges head-on opens new possibilities.',
  'perspective': 'You\'ve gained Perspective! Your broader view helps you navigate complex situations with wisdom.',
  'adaptability': 'You\'ve developed Adaptability! Your flexibility allows you to thrive in changing circumstances.',
  // 添加更多标签...
};

// 格式化标签名称
const formatTagName = (tagId: string): string => {
  return tagId.split('_').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');
};

// 获取标签解锁叙述
const getTagUnlockNarrative = (tagId: string): string => {
  const narrative = TAG_UNLOCK_NARRATIVES[tagId];
  if (narrative) {
    return narrative;
  }
  
  // 如果没有找到特定的叙述，生成一个通用的
  const formattedName = formatTagName(tagId);
  return `You've unlocked the ${formattedName} tag! This reflects a new dimension of your personal growth and identity development.`;
};

const TagUnlockNotice: React.FC<Props> = ({ tagId, isDaytime = true }) => {
  const message = getTagUnlockNarrative(tagId);
  const formattedName = formatTagName(tagId);
  
  // 调试信息
  console.log('[TagUnlockNotice] Rendering:', { tagId, formattedName, message });
  
  // 主题颜色
  const colors = {
    background: isDaytime ? '#fffbea' : '#451a03',
    border: isDaytime ? '#facc15' : '#f59e0b',
    text: isDaytime ? '#92400e' : '#fbbf24',
    textSecondary: isDaytime ? '#92400e' : '#f3f4f6',
    tagBackground: isDaytime ? '#fef3c7' : '#92400e40',
  };
  
  return (
    <div style={{
      borderRadius: '12px',
      border: `1px solid ${colors.border}`,
      padding: '16px',
      marginTop: '16px',
      fontSize: '14px',
      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
      backgroundColor: colors.background,
      transition: 'all 0.3s ease',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* 背景装饰 */}
      <div style={{
        position: 'absolute',
        top: '-10px',
        right: '-10px',
        width: '60px',
        height: '60px',
        backgroundColor: colors.border,
        borderRadius: '50%',
        opacity: 0.1,
        zIndex: 0
      }} />
      
      <div style={{ 
        display: 'flex', 
        alignItems: 'flex-start', 
        gap: '12px',
        position: 'relative',
        zIndex: 1
      }}>
        <span style={{ 
          fontSize: '24px',
          lineHeight: 1,
          marginTop: '2px',
          filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.1))'
        }}>
          🏷️
        </span>
        <div style={{ flex: 1 }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            marginBottom: '8px'
          }}>
            <div style={{
              fontSize: '12px',
              color: colors.text,
              fontWeight: '700',
              textTransform: 'uppercase',
              letterSpacing: '1px',
              padding: '4px 8px',
              backgroundColor: colors.tagBackground,
              borderRadius: '6px',
              border: `1px solid ${colors.border}40`
            }}>
              ✨ New Tag Unlocked
            </div>
            <div style={{
              fontSize: '13px',
              color: colors.text,
              fontWeight: '600',
              padding: '2px 6px',
              backgroundColor: `${colors.border}20`,
              borderRadius: '4px'
            }}>
              {formattedName}
            </div>
          </div>
          <p style={{
            color: colors.textSecondary,
            fontWeight: '500',
            margin: 0,
            lineHeight: 1.6,
            fontSize: '14px'
          }}>
            {message}
          </p>
          
          {/* 成长提示 */}
          <div style={{
            marginTop: '12px',
            padding: '8px 12px',
            backgroundColor: `${colors.border}10`,
            borderRadius: '8px',
            border: `1px solid ${colors.border}30`
          }}>
            <div style={{
              fontSize: '12px',
              color: colors.text,
              fontWeight: '600',
              marginBottom: '4px'
            }}>
              💡 What this means:
            </div>
            <div style={{
              fontSize: '13px',
              color: colors.textSecondary,
              lineHeight: 1.4
            }}>
              This tag represents patterns in your behavior and feedback that show you're developing this quality consistently.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TagUnlockNotice;
