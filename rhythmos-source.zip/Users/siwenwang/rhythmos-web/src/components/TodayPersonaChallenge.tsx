// /components/TodayPersonaChallenges.tsx

import React, { useEffect, useState } from 'react';
import { generateIdentityChallengeFromPersona } from '../logic/identity/generateIdentityChallengeFromPersona';
import IdentityChallengeCard from './IdentityChallengeCard';

const TodayPersonaChallenges: React.FC = () => {
  const [challenges, setChallenges] = useState<
    { cue: string; paragraph: string; action: string }[]
  >([]);
  const [loading, setLoading] = useState(true);
  const persona = localStorage.getItem('targetPersona') || 'lucis';
  const trend = localStorage.getItem('lastTrend') || 'wavy';

  useEffect(() => {
    const fetchChallenges = async () => {
      setLoading(true);
      const one = await generateIdentityChallengeFromPersona(persona, trend);
      const two = await generateIdentityChallengeFromPersona(persona, trend);
      setChallenges([one, two]);
      setLoading(false);
    };
    fetchChallenges();
  }, [persona, trend]);

  if (loading || challenges.length === 0) {
    return (
      <div className="text-sm text-gray-400 italic px-4 py-6">
        Loading identity challenges...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {challenges.map((challenge, index) => (
        <IdentityChallengeCard
          key={index}
          cue={challenge.cue}
          paragraph={challenge.paragraph}
          action={challenge.action}
        />
      ))}
    </div>
  );
};

export default TodayPersonaChallenges;

