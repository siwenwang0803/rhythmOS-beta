import React from 'react'

const IdentityTrainShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="max-w-screen-xl mx-auto py-12 px-6 space-y-16">
      <header className="space-y-1">
        <h1 className="text-3xl font-bold text-gray-800">🌿 Identity Rhythm Training</h1>
        <p className="text-sm text-gray-500 max-w-xl">
          Align your daily actions, feedback, and reflection with who you want to become.
        </p>
      </header>

      {/* ✅ 关键！渲染传入的 children */}
      {children}
    </div>
  )
}

export default IdentityTrainShell
