// /components/RhythmMicrotaskPanel.tsx - 修复微任务计数同步问题

import React, { useState, useRef, useEffect } from 'react';
import { addXp, forceRefreshAllXpData } from '../utils/xpEngine';
import { getXpTracker, saveXpTracker, getTodayDateKey, logMicrotaskXp } from '../utils/xpDailyTracker';
import { writeRhythmScore, MAX_MICROTASK_COUNT } from '../utils/writeRhythmScore';
import { updateMicrotaskLog } from '../utils/updateMicrotaskLog';
import { getSignatureMap } from '../SignatureMap';

// XP动画组件
const XpAnimation = ({ isVisible, onAnimationEnd, xpAmount }: { isVisible: boolean, onAnimationEnd: () => void, xpAmount: number }) => {
  React.useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onAnimationEnd();
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onAnimationEnd]);

  if (!isVisible) return null;

  const keyframes = `
    @keyframes fade-up {
      0% {
        opacity: 0;
        transform: translateY(10px);
      }
      20% {
        opacity: 1;
      }
      100% {
        opacity: 0;
        transform: translateY(-20px);
      }
    }
  `;

  return (
    <>
      <style>{keyframes}</style>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-green-100 text-green-800 px-4 py-2 rounded-full text-lg font-bold"
        style={{ animation: 'fade-up 1.5s ease-out forwards' }}>
        +{xpAmount} XP
      </div>
    </>
  );
};

const RhythmMicrotaskPanel: React.FC = () => {
  const [showXpAnimation, setShowXpAnimation] = useState(false);
  const buttonRef = useRef(null);
  const [completedCount, setCompletedCount] = useState(0);
  
  // 在组件加载时获取最新的微任务计数
  useEffect(() => {
    // 初始加载时更新计数
    updateMicrotaskCount();
    
    // 添加事件监听以响应微任务在其他地方完成
    const handleMicrotaskUpdate = () => {
      console.log('检测到microtask-completed事件，更新计数');
      updateMicrotaskCount();
    };
    
    window.addEventListener('microtask-completed', handleMicrotaskUpdate);
    window.addEventListener('microtask-updated', handleMicrotaskUpdate);
    
    return () => {
      window.removeEventListener('microtask-completed', handleMicrotaskUpdate);
      window.removeEventListener('microtask-updated', handleMicrotaskUpdate);
    };
  }, []);
  
  // 统一的微任务计数读取函数 - 从多个数据源读取并返回最大值
  const updateMicrotaskCount = () => {
    try {
      const today = getTodayDateKey();
      
      // 方法1: 从 xpTracker 读取
      const tracker = getXpTracker();
      const xpTrackerCount = tracker[today]?.microtaskCount || 0;
      
      // 方法2: 从 signatureMap 读取
      const signatureMap = getSignatureMap();
      const signatureMapCount = signatureMap.microtaskCount || 0;
      
      // 方法3: 从 rhythmScoreLog 统计今天的微任务完成数
      const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
      const rhythmScoreCount = rhythmScoreLog.filter((entry: any) => 
        entry.date === today && entry.actionType === 'microtask_complete'
      ).length;
      
      // 取最大值作为真实计数
      const finalCount = Math.max(xpTrackerCount, signatureMapCount, rhythmScoreCount);
      
      console.log('Microtask count analysis:', {
        today,
        xpTrackerCount,
        signatureMapCount,
        rhythmScoreCount,
        finalCount
      });
      
      setCompletedCount(finalCount);
      return finalCount;
    } catch (error) {
      console.error('Error updating microtask count:', error);
      setCompletedCount(0);
      return 0;
    }
  };
  
  const microtasks = [
    '📝 Write a short journal entry',
    '🚶‍♂️ Take a 10-minute walk',
    '🧘‍♀️ Breathe for 1 minute',
    '💭 Reflect silently for 3 minutes',
    '📤 Send one thoughtful message to someone you care about'
  ];

  const handleComplete = () => {
    try {
      // 获取当前计数
      const currentCount = updateMicrotaskCount();
      
      // 检查是否已达到每日微任务上限
      if (currentCount >= MAX_MICROTASK_COUNT) {
        alert(`🟡 You've already completed ${MAX_MICROTASK_COUNT} microtasks today. Great job!`);
        return;
      }

      const today = getTodayDateKey();
      const newCount = currentCount + 1;

      // 更新所有数据源
      console.log('=== 开始微任务完成处理 ===');
      
      // 1. 更新 xpTracker
      const tracker = getXpTracker();
      if (!tracker[today]) tracker[today] = {};
      tracker[today].microtaskCount = newCount;
      saveXpTracker(tracker);
      console.log('✅ 更新 xpTracker，新计数:', newCount);
      
      // 2. 更新 signatureMap（使用现有函数）
      updateMicrotaskLog('manual_completion');
      console.log('✅ 更新 signatureMap');
      
      // 3. 记录微任务完成到 rhythmScoreLog（微任务本身不增加节奏分数，值为0）
      writeRhythmScore(0, 'microtask_complete');
      console.log('✅ 记录到 rhythmScoreLog');
      
      // 4. 添加XP
      const activePersona = localStorage.getItem('initPersona') || 'rhea';
      console.log(`✅ 为 ${activePersona} 添加 2 XP`);
      addXp(activePersona, 2);
      
      // 5. 记录微任务XP（如果还有剩余次数）
      if (logMicrotaskXp()) {
        console.log('✅ 记录微任务XP');
      } else {
        console.log('⚠️ 微任务XP已达上限');
      }
      
      // 6. 更新UI状态
      setCompletedCount(newCount);
      
      // 7. 显示动画
      setShowXpAnimation(true);
      
      // 8. 触发所有相关的更新事件
      window.dispatchEvent(new CustomEvent('microtask-completed', { 
        detail: { count: newCount, date: today } 
      }));
      window.dispatchEvent(new CustomEvent('microtask-updated', { 
        detail: { count: newCount } 
      }));
      window.dispatchEvent(new Event('rhythm-score-updated'));
      window.dispatchEvent(new Event('xp-updated'));
      
      // 9. 强制刷新所有XP数据
      forceRefreshAllXpData();
      
      console.log('=== 微任务完成处理结束 ===');
      
      // 10. 验证更新 (延迟执行)
      setTimeout(() => {
        const verifiedCount = updateMicrotaskCount();
        console.log('🔍 验证更新后的微任务计数:', verifiedCount);
        if (verifiedCount !== newCount) {
          console.warn('⚠️ 计数验证失败，预期:', newCount, '实际:', verifiedCount);
          setCompletedCount(verifiedCount);
        }
      }, 200);
      
    } catch (error) {
      console.error('微任务完成处理出错:', error);
      // 发生错误时重新获取计数
      updateMicrotaskCount();
    }
  };

  return (
    <div className="bg-white rounded-xl p-5 shadow-sm relative">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-md font-medium">🛠️ Suggested Microtask</h3>
        <div className="text-xs text-gray-400">
          Count: {completedCount}/{MAX_MICROTASK_COUNT}
        </div>
      </div>

      <div className="text-sm mb-4">
        Based on today's identity cue, try one of the following:
      </div>

      <div className="space-y-2 mb-4">
        {microtasks.map((m, i) => (
          <div key={i} className="flex items-start gap-2 text-sm p-2 bg-gray-50 rounded-md">
            {m}
          </div>
        ))}
      </div>

      <div className="flex flex-col space-y-2 items-center">
        <button
          ref={buttonRef}
          onClick={handleComplete}
          disabled={completedCount >= MAX_MICROTASK_COUNT}
          className={`w-full py-2 rounded-md text-sm font-medium ${
            completedCount >= MAX_MICROTASK_COUNT 
              ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
              : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
          }`}
        >
          ✅ I've completed a microtask
        </button>
        
        {/* XP Animation */}
        {buttonRef.current && showXpAnimation && (
          <XpAnimation 
            isVisible={showXpAnimation} 
            onAnimationEnd={() => setShowXpAnimation(false)}
            xpAmount={2}
          />
        )}
      </div>
      
      {/* 完成计数器 - 添加点击刷新功能 */}
      <div 
        className="text-xs text-center mt-4 text-gray-500 cursor-pointer hover:underline"
        onClick={updateMicrotaskCount}
        title="Click to refresh count"
      >
        {completedCount}/{MAX_MICROTASK_COUNT} microtasks completed today
        <div className="text-xs text-gray-400 mt-1">
          (Click to sync)
        </div>
      </div>
    </div>
  );
};

export default RhythmMicrotaskPanel;

