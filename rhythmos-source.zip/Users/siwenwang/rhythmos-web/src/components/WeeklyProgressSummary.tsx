import React, { useMemo } from 'react';
import { getToneScoreMapByDays } from '../utils/writeToneLog';

interface WeeklyProgressSummaryProps {
  isDaytime?: boolean;
}

/**
 * WeeklyProgressSummary - Provides week-over-week comparison and progress tracking
 * 
 * Shows tone trends, achievements, and actionable recommendations based on 
 * the user's weekly progress, focusing on change rather than current state.
 */
const WeeklyProgressSummary: React.FC<WeeklyProgressSummaryProps> = ({ isDaytime = true }) => {
  // RhythmOS theme colors
  const themeColors = {
    background: isDaytime ? '#F5E8C7' : '#2C2C2C',   // Sand base / Dark mode bg
    panelBg: isDaytime ? '#FFFFFF' : '#3A3A3A',      // White / Dark panel bg
    panelAltBg: isDaytime ? '#F8F8F5' : '#454545',   // Lighter/darker alt panel
    text: isDaytime ? '#333333' : '#E0E0E0',         // Dark text / Light text
    textMuted: isDaytime ? '#777777' : '#AAAAAA',    // Muted text colors
    border: isDaytime ? '#E6E6E6' : '#555555',       // Light/dark borders
    shadow: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(0, 0, 0, 0.2)',
    accent: '#F7DC6F', // Soft yellow accent from UI spec
  };
  
  // RhythmOS state colors
  const stateColors = {
    collapsed: '#AEC6CF', // Gentle calming blue
    wavy: '#C3B1E1',      // Transitional lavender
    stable: '#C5D8A4',    // Grounded light green
    rising: '#FFB347',    // Activating orange-yellow
  };

  // Tone colors (from ToneDonutChart)
  const toneColors: Record<string, string> = {
    gentle: '#60a5fa',
    supportive: '#22c55e',
    balanced: '#facc15',
    motivated: '#fb923c',
    directive: '#ef4444',
    rational: '#8b5cf6',
    visionary: '#14b8a6'
  };

  // Get a random rhythm state (for demo purposes)
  // Move this function definition before it's used in useMemo
  const getRandomRhythmState = () => {
    const states = ['stable', 'wavy', 'rising', 'collapsed'];
    return states[Math.floor(Math.random() * states.length)];
  };

  // Analyze tone and rhythm data (week-over-week comparison)
  const weeklyData = useMemo(() => {
    // Get this week and last week tone scores
    const thisWeekTones = getToneScoreMapByDays(7);
    const lastWeekTones = getToneScoreMapByDays(14, 7); // Data from 7-14 days ago
    
    // Calculate totals and sort
    const thisWeekTotal = Object.values(thisWeekTones).reduce((sum, score) => sum + score, 0);
    const lastWeekTotal = Object.values(lastWeekTones).reduce((sum, score) => sum + score, 0);
    
    // Get dominant tones for this week and last week
    const thisWeekDominant = Object.entries(thisWeekTones)
      .sort((a, b) => b[1] - a[1])[0] || ['balanced', 0];
      
    const lastWeekDominant = Object.entries(lastWeekTones)
      .sort((a, b) => b[1] - a[1])[0] || ['balanced', 0];
    
    // Calculate tone changes
    const toneChanges: Record<string, {current: number, previous: number, change: number}> = {};
    
    // Merge all tone keys
    const allTones = [...new Set([...Object.keys(thisWeekTones), ...Object.keys(lastWeekTones)])];
    
    allTones.forEach(tone => {
      const current = thisWeekTones[tone] || 0;
      const previous = lastWeekTones[tone] || 0;
      toneChanges[tone] = {
        current,
        previous,
        change: current - previous
      };
    });
    
    // Significant changes sorted by magnitude
    const significantChanges = Object.entries(toneChanges)
      .filter(([_, data]) => Math.abs(data.change) > 0)
      .sort((a, b) => Math.abs(b[1].change) - Math.abs(a[1].change))
      .slice(0, 3); // Take top 3 with largest changes
    
    // Sample rhythm state distribution
    // In a real implementation, this would come from the user's rhythmScoreLog
    const rhythmState = getRandomRhythmState();
    
    // Calculate tone strength percentage with better handling for empty data
    const toneStrength = thisWeekTotal > 0 
      ? ((thisWeekDominant[1] / thisWeekTotal) * 100).toFixed(1)
      : "0.0";
    
    return {
      thisWeekDominant,
      lastWeekDominant, 
      toneTrend: thisWeekDominant[0] === lastWeekDominant[0] ? 'consistent' : 'shifted',
      toneStrength,
      significantChanges,
      rhythmState
    };
  }, []);

  // Get descriptive text for tone changes
  const getToneChangeDescription = (tone: string, change: number): string => {
    // Logic to generate descriptions based on tone and change magnitude
    if (change > 10) return `Significantly increased ${tone} tendency`;
    if (change > 5) return `Enhanced ${tone} tendency`;
    if (change > 0) return `Slightly increased ${tone} tendency`;
    if (change < -10) return `Substantially decreased ${tone} tendency`;
    if (change < -5) return `Reduced ${tone} tendency`;
    if (change < 0) return `Slightly decreased ${tone} tendency`;
    return `Maintained stable ${tone} tendency`;
  };

  // Map tones to personas
  const getTonePersona = (tone: string): string => {
    const tonePersonaMap: Record<string, string> = {
      gentle: 'Rhea',
      supportive: 'Rhea',
      balanced: 'Aurelia',
      motivated: 'Caelum',
      directive: 'Caelum',
      rational: 'Aurelia',
      visionary: 'Niveus'
    };
    
    return tonePersonaMap[tone] || 'Balanced';
  };

  // Get weekly recommendations
  const getWeeklySuggestions = (): string[] => {
    const { thisWeekDominant, rhythmState } = weeklyData;
    const dominantTone = thisWeekDominant[0];
    
    // Recommendations based on dominant tone and rhythm state
    // (These should come from a more comprehensive data source)
    const suggestions: Record<string, string[]> = {
      gentle: [
        'Reserve more personal space to nurture your gentle tendencies',
        'Try incorporating directive elements in key situations for balance',
        'Log which environments help you maintain a gentle state versus which disrupt it'
      ],
      supportive: [
        'Ensure you attend to your own needs while supporting others',
        'Set clear boundaries to avoid overextending yourself',
        'Schedule daily "do not disturb" time for yourself'
      ],
      balanced: [
        'Continue your current balancing practices',
        'Document which factors help you maintain equilibrium',
        'Experiment with moderate challenges at the edge of your comfort zone'
      ],
      motivated: [
        'Ensure your motivation consistently translates into action',
        'Build more structured workflows to leverage your high energy',
        'Monitor potential decision errors from overexcitement'
      ],
      directive: [
        'Add more listening moments before making decisions',
        'Regularly review whether your goals and direction remain appropriate',
        'Try relaxing control in certain situations and observe the results'
      ],
      rational: [
        'Attend to emotional impacts alongside logical analysis',
        'Try blending intuition with analysis when problem-solving',
        'Collaborate with people of different thinking styles to expand your perspective'
      ],
      visionary: [
        'Ensure you translate vision into actionable steps',
        'Build systems to capture and evaluate your ideas',
        'Seek practical partners who can help implement your concepts'
      ]
    };
    
    // Get suggestions based on dominant tone, or use defaults
    return suggestions[dominantTone] || [
      'Notice daily energy level fluctuations and adjust activities accordingly',
      'Experiment with different work and rest patterns to find your optimal rhythm',
      'Track which activities energize or deplete you'
    ];
  };

  // Get color based on rhythm state
  const getStateColor = (state: string): string => {
    return stateColors[state as keyof typeof stateColors] || '#CCCCCC';
  };

  // Get color based on tone
  const getToneColor = (tone: string): string => {
    return toneColors[tone] || '#CCCCCC';
  };

  // Generate suggestions
  const suggestions = getWeeklySuggestions();

  return (
    <div 
      style={{
        backgroundColor: themeColors.panelBg,
        borderRadius: '12px',
        border: `1px solid ${themeColors.border}`,
        boxShadow: `0 4px 12px ${themeColors.shadow}`,
        overflow: 'hidden',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }}
    >
      {/* Top color strip showing dominant tone */}
      <div 
        style={{ 
          height: '6px', 
          backgroundColor: getToneColor(weeklyData.thisWeekDominant[0])
        }}
      />
      
      {/* Header section */}
      <div style={{ padding: '20px' }}>
        <h3 
          style={{ 
            fontSize: '18px', 
            fontWeight: 600, 
            color: themeColors.text,
            margin: '0 0 16px 0',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}
        >
          <span role="img" aria-label="Weekly Report">📊</span>
          <span>Week-over-Week Changes</span>
        </h3>
        
        {/* Dominant tone change */}
        <div 
          style={{
            padding: '16px',
            backgroundColor: isDaytime ? 'rgba(245, 232, 199, 0.1)' : 'rgba(74, 85, 104, 0.1)',
            borderRadius: '10px',
            marginBottom: '20px',
            border: `1px solid ${isDaytime ? 'rgba(245, 232, 199, 0.3)' : 'rgba(74, 85, 104, 0.3)'}`
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <div 
                style={{ 
                  fontSize: '14px', 
                  fontWeight: 600,
                  marginBottom: '4px',
                  color: themeColors.text
                }}
              >
                Dominant Tone
              </div>
              <div 
                style={{ 
                  fontSize: '22px', 
                  fontWeight: 700,
                  color: getToneColor(weeklyData.thisWeekDominant[0]),
                  display: 'flex',
                  alignItems: 'baseline',
                  gap: '6px',
                  textTransform: 'capitalize'
                }}
              >
                {weeklyData.thisWeekDominant[0]}
                <span 
                  style={{ 
                    fontSize: '14px', 
                    fontWeight: 500,
                    color: themeColors.textMuted
                  }}
                >
                  {weeklyData.toneStrength}%
                </span>
              </div>
              <div 
                style={{ 
                  fontSize: '14px',
                  color: themeColors.textMuted,
                  marginTop: '4px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px'
                }}
              >
                <span>Persona:</span>
                <span 
                  style={{ 
                    color: themeColors.text,
                    fontWeight: 500
                  }}
                >
                  {getTonePersona(weeklyData.thisWeekDominant[0])}
                </span>
              </div>
            </div>
            
            <div
              style={{
                padding: '6px 12px',
                borderRadius: '16px',
                backgroundColor: isDaytime ? 'white' : 'rgba(58, 58, 58, 0.8)',
                fontSize: '13px',
                color: weeklyData.toneTrend === 'consistent' ? '#4CAF50' : '#FF9800',
                border: `1px solid ${weeklyData.toneTrend === 'consistent' ? 'rgba(76, 175, 80, 0.3)' : 'rgba(255, 152, 0, 0.3)'}`,
                display: 'flex',
                alignItems: 'center',
                gap: '4px'
              }}
            >
              <span>
                {weeklyData.toneTrend === 'consistent' ? 'Consistent' : 'Shifted'}
              </span>
              <span>
                {weeklyData.toneTrend === 'consistent' ? '✓' : '↔'}
              </span>
            </div>
          </div>
          
          <div 
            style={{ 
              fontSize: '14px',
              color: themeColors.text,
              marginTop: '12px' 
            }}
          >
            {weeklyData.toneTrend === 'consistent' 
              ? `You've maintained a consistent ${weeklyData.thisWeekDominant[0]} tone this week compared to last week.` 
              : `Your dominant tone has shifted from ${weeklyData.lastWeekDominant[0]} to ${weeklyData.thisWeekDominant[0]} this week.`
            }
          </div>
        </div>
        
        {/* Significant changes section */}
        {weeklyData.significantChanges.length > 0 && (
          <div style={{ marginBottom: '20px' }}>
            <h4 
              style={{ 
                fontSize: '16px', 
                fontWeight: 600, 
                margin: '0 0 12px 0',
                color: themeColors.text
              }}
            >
              Notable Changes
            </h4>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {weeklyData.significantChanges.map(([tone, data], index) => (
                <div 
                  key={tone}
                  style={{
                    display: 'flex',
                    padding: '12px',
                    backgroundColor: isDaytime ? 'rgba(245, 232, 199, 0.05)' : 'rgba(74, 85, 104, 0.05)',
                    borderRadius: '8px',
                    border: `1px solid ${isDaytime ? themeColors.border : 'rgba(74, 85, 104, 0.2)'}`,
                    alignItems: 'center',
                    gap: '12px'
                  }}
                >
                  <div 
                    style={{ 
                      width: '32px',
                      height: '32px',
                      borderRadius: '50%',
                      backgroundColor: getToneColor(tone),
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'white',
                      fontSize: '14px',
                      fontWeight: 700
                    }}
                  >
                    {data.change > 0 ? '↑' : '↓'}
                  </div>
                  <div>
                    <div 
                      style={{ 
                        fontSize: '14px',
                        fontWeight: 500,
                        color: themeColors.text,
                        textTransform: 'capitalize'
                      }}
                    >
                      {getToneChangeDescription(tone, data.change)}
                    </div>
                    <div 
                      style={{ 
                        fontSize: '13px',
                        color: themeColors.textMuted,
                        marginTop: '2px',
                        display: 'flex',
                        flexWrap: 'wrap',
                        gap: '8px',
                        alignItems: 'center'
                      }}
                    >
                      <span>{Math.abs(data.change).toFixed(1)} point {data.change > 0 ? 'increase' : 'decrease'}</span>
                      <span style={{ color: isDaytime ? '#CCCCCC' : '#666666' }}>•</span>
                      <span style={{ 
                        color: themeColors.text,
                        fontSize: '12px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px'
                      }}>
                        <span>Persona:</span>
                        <span style={{ fontWeight: 500 }}>{getTonePersona(tone)}</span>
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Rhythm state indicator */}
        <div 
          style={{
            padding: '16px',
            backgroundColor: `${getStateColor(weeklyData.rhythmState)}15`, // 15% opacity
            borderRadius: '10px',
            marginBottom: '20px',
            border: `1px solid ${getStateColor(weeklyData.rhythmState)}30`, // 30% opacity
            display: 'flex',
            alignItems: 'flex-start',
            gap: '14px'
          }}
        >
          <div 
            style={{ 
              width: '36px',
              height: '36px',
              borderRadius: '50%',
              backgroundColor: getStateColor(weeklyData.rhythmState),
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '18px'
            }}
          >
            {weeklyData.rhythmState === 'collapsed' ? '🌊' : 
             weeklyData.rhythmState === 'wavy' ? '〰️' : 
             weeklyData.rhythmState === 'stable' ? '⚡' : '🔥'}
          </div>
          <div>
            <div 
              style={{ 
                fontSize: '15px',
                fontWeight: 600,
                color: themeColors.text,
                marginBottom: '4px',
                textTransform: 'capitalize'
              }}
            >
              Predominantly {weeklyData.rhythmState} Rhythm
            </div>
            <div 
              style={{ 
                fontSize: '14px',
                color: themeColors.text
              }}
            >
              {weeklyData.rhythmState === 'collapsed' ? 
                'Your rhythms have been predominantly calming this week. Focus on gradual recovery and rebuilding energy.' : 
               weeklyData.rhythmState === 'wavy' ? 
                'Your rhythms have been fluctuating this week. Balance periods of activity with adequate rest.' : 
               weeklyData.rhythmState === 'stable' ? 
                'Your rhythms have been mostly stable and grounded this week. This is excellent for sustained focus.' : 
                'Your rhythms have been energetic and activating this week. Great for creative work and new initiatives.'}
            </div>
          </div>
        </div>
        
        {/* Weekly recommendations */}
        <div>
          <h4 
            style={{ 
              fontSize: '16px', 
              fontWeight: 600, 
              margin: '0 0 12px 0',
              color: themeColors.text,
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            <span role="img" aria-label="Recommendations">💡</span>
            <span>Weekly Recommendations</span>
          </h4>
          
          <ul 
            style={{
              backgroundColor: isDaytime ? 'rgba(245, 232, 199, 0.1)' : 'rgba(58, 58, 58, 0.6)',
              borderRadius: '8px',
              padding: '16px 16px 16px 36px',
              border: `1px solid ${themeColors.border}`,
              margin: 0,
              listStyleType: 'none',
              position: 'relative'
            }}
          >
            {suggestions.map((suggestion, index) => (
              <li 
                key={index}
                style={{ 
                  position: 'relative',
                  marginBottom: index < suggestions.length - 1 ? '12px' : 0,
                  paddingLeft: '8px',
                  fontSize: '14px',
                  color: themeColors.text,
                  lineHeight: 1.5
                }}
              >
                <span 
                  style={{
                    position: 'absolute',
                    left: '-20px',
                    top: '2px',
                    color: themeColors.accent,
                    fontSize: '14px'
                  }}
                >
                  •
                </span>
                {suggestion}
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      {/* Footer */}
      <div 
        style={{
          padding: '12px 20px',
          borderTop: `1px solid ${themeColors.border}`,
          backgroundColor: isDaytime ? 'rgba(245, 232, 199, 0.1)' : 'rgba(58, 58, 58, 0.5)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}
      >
        <div 
          style={{ 
            fontSize: '13px', 
            color: themeColors.textMuted
          }}
        >
          Based on data from the past 14 days
        </div>
        
        <a 
          href="/identity/insight"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            fontSize: '13px',
            color: isDaytime ? '#4B6587' : '#D8A7CA', // Caelum/Aurelia colors
            textDecoration: 'none',
            fontWeight: 500
          }}
        >
          <span>View detailed analysis</span>
          <span>→</span>
        </a>
      </div>
    </div>
  );
};

export default WeeklyProgressSummary;