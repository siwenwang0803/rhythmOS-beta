// ReplayRow.tsx

import React from 'react'

interface ReplayRowProps {
  cue: string
  persona: string
  tone: string
  score: number
  timestamp: number
}

const personaStyleMap: Record<string, { color: string; emoji: string }> = {
  rhea: { color: 'text-blue-500', emoji: '💙' },
  aurelia: { color: 'text-yellow-600', emoji: '💛' },
  lucis: { color: 'text-green-600', emoji: '💚' },
  niveus: { color: 'text-gray-600', emoji: '🧊' },
  caelum: { color: 'text-red-500', emoji: '❤️‍🔥' },
}

const ReplayRow: React.FC<ReplayRowProps> = ({
  cue,
  persona,
  tone,
  score,
  timestamp,
}) => {
  const style = personaStyleMap[persona] || {
    color: 'text-gray-500',
    emoji: '🤖',
  }

  return (
    <div className="border rounded-xl p-4 bg-white shadow-sm space-y-1">
      <div className="flex justify-between text-xs">
        <span className={`${style.color} font-semibold`}>
          {style.emoji} {persona.toUpperCase()}
        </span>
        <span className="text-gray-400 italic">
          {new Date(timestamp).toLocaleDateString()}
        </span>
      </div>
      <p className="text-sm text-gray-800 mt-1">“{cue}”</p>
      <div className="flex justify-between text-xs text-gray-500 mt-1">
        <span>Tone: {tone}</span>
        <span>Score: {score}</span>
      </div>
    </div>
  )
}

export default ReplayRow
