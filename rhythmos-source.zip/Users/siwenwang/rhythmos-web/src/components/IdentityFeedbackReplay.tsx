// IdentityFeedbackReplay.tsx

import React from 'react'
import ReplayRow from './ReplayRow'

interface FeedbackEntry {
  cue: string
  tone: string
  persona: string
  score: number
  timestamp: number
}

const IdentityFeedbackReplay: React.FC = () => {
  const raw = localStorage.getItem('rhythmSignatureLog')
  const logs: FeedbackEntry[] = raw ? JSON.parse(raw) : []

  if (logs.length === 0) {
    return (
      <p className="text-sm italic text-gray-400">
        No feedback records found yet. Start your training to generate rhythm memory.
      </p>
    )
  }

  const recent = logs.slice(-5).reverse()

  return (
    <div className="space-y-4">
      {recent.map((entry, i) => (
        <ReplayRow
          key={i}
          cue={entry.cue}
          tone={entry.tone}
          persona={entry.persona}
          score={entry.score}
          timestamp={entry.timestamp}
        />
      ))}
    </div>
  )
}

export default IdentityFeedbackReplay