import React from 'react';

export const BetaTestWelcomePanel: React.FC = () => {
  const sendFeedback = () => {
    const timestamp = new Date().toISOString();
    const log = JSON.parse(localStorage.getItem('betaFeedbackLog') || '[]');
    log.push({ timestamp, type: 'welcomePanelClick' });
    localStorage.setItem('betaFeedbackLog', JSON.stringify(log));
  };
  const url = new URLSearchParams(window.location.search);
  const forced = url.get('showBetaWelcome') === 'true';
  const dismissed = localStorage.getItem('betaWelcomeDismissed');
  if (!forced && dismissed === 'true') return null;

  const handleDismiss = () => {
    sendFeedback();
    const log = JSON.parse(localStorage.getItem('betaFeedbackLog') || '[]');
    log.push({ timestamp: new Date().toISOString(), type: 'enteredExperience', mood: '', expectation: '' });
    localStorage.setItem('betaFeedbackLog', JSON.stringify(log));
    localStorage.setItem('betaWelcomeDismissed', 'true');
    const el = document.getElementById('cre-start');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="mt-6 p-4 border border-indigo-300 bg-white rounded-xl shadow text-sm text-gray-800 space-y-2">
      <h3 className="text-md font-semibold text-indigo-700">🚀 Welcome to the RhythmOS Beta</h3>
      <p>
        This is a preview version of your rhythm insight system. You’ll explore how language,
        tone, and task behavior reflect and shape your identity in action.
      </p>
      <ul className="list-disc text-sm ml-5 space-y-1">
        <li>🎯 Follow your CRE cues daily</li>
        <li>📡 Try challenges based on your persona</li>
        <li>📈 Review your feedback and rhythm score trends</li>
        <li>🧠 Observe how your tone preferences evolve</li>
      </ul>
      <p className="text-xs text-gray-500">Your data is stored locally and can be exported on request.</p>
      <button
        onClick={handleDismiss}
        className="mt-2 px-3 py-1 bg-indigo-600 text-white rounded text-sm"
      >
        ✅ Enter Beta Experience
      </button>
    
    </div>
  );
};






