import React from 'react';
import { getCurrentTrend } from '../utils/trendScore';
import { getSignatureMap } from './SignatureSummaryBox';

export const TrendTonePersonaSuggestion: React.FC = () => {
  const trend = getCurrentTrend();
  const { dominantTone, dominantPersona } = getSignatureMap();

  const textMap: Record<string, string> = {
    collapsed: `Your rhythm is low. You often align with ${dominantTone} tone from ${dominantPersona}. Try something lighter today.`,
    rising: `You're rising. Your past feedback suggests ${dominantTone} tone helps. Double down on your momentum!`,
    stable: `You're stable. Your responses show consistency with ${dominantTone} tone. Stay centered.`,
    wavy: `You're in a mixed state. Past feedback shows ${dominantTone} works best — consider re-centering.`
  };

  return (
    <div className="mt-6 p-4 border rounded bg-blue-50 text-sm text-blue-800">
      <h4 className="font-semibold mb-1">🧭 Personalized Suggestion</h4>
      <p>{textMap[trend]}</p>
    </div>
  );
};
