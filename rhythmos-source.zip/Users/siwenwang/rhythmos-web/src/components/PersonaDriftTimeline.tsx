import React, { useState, useEffect } from 'react';

// Tone 到 Persona 的映射关系
const toneToPersonaMap: Record<string, string> = {
  gentle: 'rhea',
  directive: 'niveus', 
  visionary: 'lucis',
  rational: 'aurelia',
  motivated: 'caelum'
};

// 定义 persona 主题映射
const personaThemeMap: Record<string, any> = {
  rhea: {
    color: '#F5CFCF',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    icon: '💗',
    label: 'Rhea - Gentle'
  },
  caelum: {
    color: '#4B6587',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    icon: '💠',
    label: 'Caelum - Directive'
  },
  aurelia: {
    color: '#D8A7CA',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    icon: '🧠',
    label: 'Aurelia - Rational'
  },
  lucis: {
    color: '#C5D8A4',
    gradient: 'linear-gradient(135deg, #F5E8C7, #C5D8A4)',
    icon: '🌱',
    label: 'Lucis - Visionary'
  },
  niveus: {
    color: '#A2C4C9',
    gradient: 'linear-gradient(135deg, #F5E8C7, #A2C4C9)',
    icon: '📊',
    label: 'Niveus - Balanced'
  }
};

interface PersonaSwitch {
  fromPersona: string;
  toPersona: string;
  timestamp: string;
  dayOffset: number;
}

const PersonaSwitchTimeline: React.FC = () => {
  const [days, setDays] = useState(7);
  const [switches, setSwitches] = useState<PersonaSwitch[]>([]);
  const [currentPersona, setCurrentPersona] = useState('');
  const [loading, setLoading] = useState(true);

  // 从 localStorage 获取 persona 切换历史
  const getPersonaSwitches = (dayRange: number): PersonaSwitch[] => {
    try {
      const now = new Date();
      const cutoffTime = new Date(now.getTime() - dayRange * 24 * 60 * 60 * 1000);
      const switches: PersonaSwitch[] = [];

      // 检查是否有专门的 persona 切换日志
      const personaSwitchLog = localStorage.getItem('personaSwitchLog');
      if (personaSwitchLog) {
        try {
          const parsedLog = JSON.parse(personaSwitchLog);
          parsedLog.forEach((entry: any) => {
            const entryTime = new Date(entry.timestamp);
            if (entryTime >= cutoffTime) {
              const daysAgo = Math.floor((now.getTime() - entryTime.getTime()) / (24 * 60 * 60 * 1000));
              switches.push({
                fromPersona: entry.fromPersona || 'unknown',
                toPersona: entry.toPersona || 'unknown',
                timestamp: entry.timestamp,
                dayOffset: daysAgo
              });
            }
          });
        } catch (e) {
          console.warn('Failed to parse personaSwitchLog:', e);
        }
      }

      // 如果没有专门的切换日志，从其他活动中推断 persona 使用情况
      if (switches.length === 0) {
        const activities: Array<{persona: string, timestamp: string}> = [];

        // 从 cueFeedbackLog 获取
        const cueFeedbackRaw = localStorage.getItem('cueFeedbackLog');
        if (cueFeedbackRaw) {
          try {
            const cueFeedbacks = JSON.parse(cueFeedbackRaw);
            cueFeedbacks.forEach((entry: any) => {
              if (entry.persona && entry.timestamp) {
                activities.push({
                  persona: entry.persona,
                  timestamp: entry.timestamp
                });
              }
            });
          } catch (e) {
            console.warn('Failed to parse cueFeedbackLog:', e);
          }
        }

        // 从 challengeLog 获取
        const challengeLogRaw = localStorage.getItem('challengeLog');
        if (challengeLogRaw) {
          try {
            const challengeLogs = JSON.parse(challengeLogRaw);
            challengeLogs.forEach((entry: any) => {
              if (entry.persona && (entry.time || entry.timestamp)) {
                activities.push({
                  persona: entry.persona,
                  timestamp: entry.time || entry.timestamp
                });
              }
            });
          } catch (e) {
            console.warn('Failed to parse challengeLog:', e);
          }
        }

        // 按时间排序活动
        activities.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

        // 检测 persona 切换
        let lastPersona = '';
        activities.forEach((activity) => {
          const entryTime = new Date(activity.timestamp);
          if (entryTime >= cutoffTime && activity.persona !== lastPersona) {
            const daysAgo = Math.floor((now.getTime() - entryTime.getTime()) / (24 * 60 * 60 * 1000));
            switches.push({
              fromPersona: lastPersona || 'initial',
              toPersona: activity.persona,
              timestamp: activity.timestamp,
              dayOffset: daysAgo
            });
            lastPersona = activity.persona;
          }
        });
      }

      return switches.sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );

    } catch (error) {
      console.error('Error getting persona switches:', error);
      return [];
    }
  };

  useEffect(() => {
    setLoading(true);
    
    // 从 preferredTone 映射到对应的 persona
    const preferredTone = localStorage.getItem('preferredTone') || 'gentle';
    const current = toneToPersonaMap[preferredTone] || 'rhea';
    setCurrentPersona(current);
    
    // 获取切换历史
    const fetchData = async () => {
      try {
        console.log(`Fetching persona switches for last ${days} days...`);
        const data = getPersonaSwitches(days);
        console.log('Persona switches:', data);
        setSwitches(data);
      } catch (error) {
        console.error("Error fetching persona switches:", error);
        setSwitches([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    // 监听 tone 变化事件
    const handleToneChange = () => {
      console.log('Tone change detected, refreshing timeline...');
      const newTone = localStorage.getItem('preferredTone') || 'gentle';
      const newPersona = toneToPersonaMap[newTone] || 'rhea';
      setCurrentPersona(newPersona);
      fetchData();
    };

    window.addEventListener('tone-changed', handleToneChange);
    window.addEventListener('preferred-tone-updated', handleToneChange);
    window.addEventListener('storage', handleToneChange);

    // 定期检查是否有新的 tone 变化
    const intervalId = setInterval(() => {
      const newTone = localStorage.getItem('preferredTone') || 'gentle';
      const newPersona = toneToPersonaMap[newTone] || 'rhea';
      if (newPersona !== currentPersona) {
        setCurrentPersona(newPersona);
        fetchData();
      }
    }, 5000);

    return () => {
      window.removeEventListener('tone-changed', handleToneChange);
      window.removeEventListener('preferred-tone-updated', handleToneChange);
      window.removeEventListener('storage', handleToneChange);
      clearInterval(intervalId);
    };
  }, [days, currentPersona]);

  const generateTimeMarkers = () => {
    const markers = [];
    if (days >= 30) markers.push({ label: '30d ago', value: 30 });
    if (days >= 14) markers.push({ label: '14d ago', value: 14 });
    if (days >= 7) markers.push({ label: '7d ago', value: 7 });
    markers.push({ label: 'Now', value: 0 });
    return markers;
  };

  const timeMarkers = generateTimeMarkers();

  // 获取 persona 使用统计
  const getPersonaStats = () => {
    const stats = {};
    switches.forEach(s => {
      stats[s.toPersona] = (stats[s.toPersona] || 0) + 1;
    });
    return stats;
  };

  const personaStats = getPersonaStats();

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="inline-block w-5 h-5">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
            </svg>
          </span>
          <h3 className="text-base font-semibold">Persona Switch Timeline</h3>
        </div>
        <div className="relative">
          <select
            className="appearance-none rounded-full px-4 py-1.5 pr-8 border border-gray-300 bg-white/90 hover:bg-white transition-colors text-sm focus:outline-none focus:ring-2 focus:ring-blue-300"
            value={days}
            onChange={(e) => setDays(Number(e.target.value))}
            aria-label="Select timeframe"
          >
            <option value={7}>Last 7 days</option>
            <option value={14}>Last 14 days</option>
            <option value={30}>Last 30 days</option>
          </select>
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500">
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </div>
        </div>
      </div>

      {/* 当前 Persona 显示 - 基于 preferredTone */}
      <div className="flex items-center gap-3 p-4 rounded-lg border bg-white shadow-sm mb-6">
        <div 
          className="w-12 h-12 rounded-full flex items-center justify-center"
          style={{ 
            background: personaThemeMap[currentPersona]?.gradient || personaThemeMap.rhea.gradient
          }}
        >
          <span className="text-xl">
            {personaThemeMap[currentPersona]?.icon || '👤'}
          </span>
        </div>
        <div>
          <p className="text-sm font-semibold">Currently Active</p>
          <p className="text-xs text-gray-600">
            {personaThemeMap[currentPersona]?.label || `${currentPersona} - Active Persona`}
          </p>
          <p className="text-xs text-gray-400 mt-1">
            Based on preferred tone: {localStorage.getItem('preferredTone') || 'gentle'}
          </p>
        </div>
      </div>

      {/* 时间线 - 修复排版 */}
      <div className="mb-12 relative px-4">
        {/* 主时间线 */}
        <div className="relative w-full h-2 my-10">
          {/* 背景线 */}
          <div 
            className="absolute inset-0 rounded-full"
            style={{
              background: 'linear-gradient(90deg, #f3f4f6 0%, #d1d5db 100%)',
            }}
          />
          
          {/* 切换点 */}
          {!loading && switches.map((switchItem, index) => {
            const toPersona = switchItem.toPersona.toLowerCase();
            const theme = personaThemeMap[toPersona] || { color: '#CCCCCC', icon: '👤' };
            const position = Math.max(2, Math.min(98, 100 - (switchItem.dayOffset / days) * 100));
            
            return (
              <div key={`switch-${index}`} className="absolute group" style={{ left: `${position}%`, top: '-8px', zIndex: 10 }}>
                {/* 切换点 */}
                <div 
                  className="relative w-6 h-6 rounded-full cursor-pointer hover:scale-110 transition-all duration-300 flex items-center justify-center"
                  style={{ 
                    background: theme.color,
                    border: '3px solid white',
                    boxShadow: '0 3px 10px rgba(0,0,0,0.2)',
                    transform: 'translateX(-50%)',
                  }}
                  title={`${switchItem.fromPersona} → ${switchItem.toPersona}`}
                >
                  <span className="text-sm font-medium">{theme.icon}</span>
                </div>
                
                {/* 悬停信息 */}
                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
                  <div className="bg-gray-900 text-white text-xs rounded-lg px-3 py-2 whitespace-nowrap shadow-lg">
                    <div className="font-semibold text-center mb-1">{switchItem.fromPersona} → {switchItem.toPersona}</div>
                    <div className="text-gray-300 text-center">
                      {new Date(switchItem.timestamp).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </div>
                    {/* 小箭头 */}
                    <div 
                      className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0"
                      style={{
                        borderLeft: '5px solid transparent',
                        borderRight: '5px solid transparent',
                        borderTop: '5px solid #1f2937'
                      }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
          
          {/* 当前位置 */}
          <div className="absolute right-0 top-1/2 transform translate-x-4 -translate-y-1/2" style={{ zIndex: 15 }}>
            <div className="flex items-center gap-2">
              <div 
                className="w-4 h-4 rounded-full animate-pulse border-2 border-white"
                style={{ 
                  background: personaThemeMap[currentPersona.toLowerCase()]?.color || '#CCCCCC',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                }}
              />
              <span className="text-sm font-semibold text-gray-700">NOW</span>
            </div>
          </div>
        </div>
        
        {loading ? (
          <div className="text-center py-8">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-gray-600"></div>
            <p className="text-sm text-gray-500 mt-3">Loading...</p>
          </div>
        ) : switches.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-3xl mb-3">🎭</div>
            <p className="text-base text-gray-600 mb-2">
              No persona switches in the last {days} days
            </p>
            <p className="text-sm text-gray-400">
              Switch personas to see activity here
            </p>
          </div>
        ) : (
          <div className="text-center py-3">
            <p className="text-base text-gray-700 font-medium">
              {switches.length} transition{switches.length !== 1 ? 's' : ''} in the last {days} days
            </p>
          </div>
        )}

        {/* 时间标记 */}
        <div className="flex justify-between mt-12 mb-8 px-2">
          {timeMarkers.map((marker, index) => (
            <div key={index} className="flex flex-col items-center">
              <div className="w-1 h-8 bg-gray-400 rounded-full mb-3" />
              <span className="text-sm font-medium text-gray-600">{marker.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="border-t border-gray-200 my-6"></div>

      {/* 切换历史 */}
      {!loading && switches.length > 0 && (
        <div className="mt-4">
          <h4 className="text-sm font-medium mb-3">Recent Persona Switches</h4>
          <div className="space-y-3">
            {switches.slice(0, 5).map((switchItem, index) => {
              const fromTheme = personaThemeMap[switchItem.fromPersona.toLowerCase()] || {
                color: '#CCCCCC',
                icon: '👤'
              };
              const toTheme = personaThemeMap[switchItem.toPersona.toLowerCase()] || {
                color: '#CCCCCC',
                icon: '👤'
              };

              return (
                <div key={index} className="flex items-center p-3 rounded-lg border bg-white/80 hover:bg-white transition-colors">
                  <div className="flex items-center gap-2 flex-grow">
                    {/* From Persona */}
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center opacity-60"
                      style={{ backgroundColor: fromTheme.color }}
                    >
                      <span className="text-sm">{fromTheme.icon}</span>
                    </div>
                    
                    {/* Arrow */}
                    <div className="text-gray-400">→</div>
                    
                    {/* To Persona */}
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: toTheme.color }}
                    >
                      <span className="text-sm">{toTheme.icon}</span>
                    </div>
                    
                    {/* Switch Info */}
                    <div className="flex-grow ml-3">
                      <p className="text-sm font-medium capitalize">
                        {switchItem.fromPersona === 'initial' ? 'Started as' : switchItem.fromPersona} → {switchItem.toPersona}
                      </p>
                      <p className="text-xs text-gray-500">
                        {new Date(switchItem.timestamp).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          {/* Persona 使用统计 */}
          {Object.keys(personaStats).length > 0 && (
            <div className="mt-4 p-3 rounded-lg bg-gray-50">
              <p className="text-sm font-medium mb-2">Persona Usage in Last {days} Days</p>
              <div className="flex flex-wrap gap-2">
                {Object.entries(personaStats).map(([persona, count]) => {
                  const theme = personaThemeMap[persona.toLowerCase()] || {
                    color: '#CCCCCC',
                    icon: '👤'
                  };
                  return (
                    <div 
                      key={persona}
                      className="flex items-center gap-1 text-xs px-2 py-1 rounded-full"
                      style={{ backgroundColor: `${theme.color}30` }}
                    >
                      <span>{theme.icon}</span>
                      <span className="capitalize">{persona}</span>
                      <span className="font-medium">×{count}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PersonaSwitchTimeline;