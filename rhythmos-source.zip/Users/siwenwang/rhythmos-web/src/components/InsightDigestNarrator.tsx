import React from 'react';
import { getDigestHint } from '../data/hintMap';
import { personaThemeMap } from '../utils/personaThemeMap'; // 请确认路径

interface InsightDigestNarratorProps {
  toneSummary: string;   // e.g., 'rational'
  trend?: 'rising' | 'stable' | 'wavy' | 'collapsed';
  unlockedTags?: string[];
  isDaytime?: boolean;
}

// 语气映射对应 persona key
const toneToPersonaMap: Record<string, keyof typeof personaThemeMap> = {
  gentle: 'rhea',
  directive: 'niveus',
  rational: 'aurelia',
  visionary: 'lucis',
  motivative: 'caelum'
};

const InsightDigestNarrator: React.FC<InsightDigestNarratorProps> = ({
  toneSummary,
  trend = 'stable',
  unlockedTags = [],
  isDaytime = true
}) => {
  const personaKey = toneToPersonaMap[toneSummary] || 'lucis';
  const persona = personaThemeMap[personaKey];
  const hint = getDigestHint(toneSummary, trend, unlockedTags);

  return (
    <div
      style={{
        padding: '16px',
        background: persona.gradient,
        borderRadius: '12px',
        border: `1px solid ${persona.baseColor}80`,
        boxShadow: `0 2px 8px rgba(0, 0, 0, 0.08)`,
        margin: '24px 0',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'flex-start',
          gap: '12px'
        }}
      >
        <div
          style={{
            width: '36px',
            height: '36px',
            borderRadius: '50%',
            backgroundColor: isDaytime ? 'white' : '#2C2C2C',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '20px',
            flexShrink: 0,
            boxShadow: `0 2px 4px rgba(0,0,0,0.08)`,
            color: persona.textColor
          }}
        >
          {persona.emoji}
        </div>

        <div>
          <h3
            style={{
              fontSize: '16px',
              fontWeight: 600,
              color: persona.textColor,
              margin: '0 0 8px 0'
            }}
          >
            {persona.label} says
          </h3>

          <p
            style={{
              fontSize: '15px',
              lineHeight: 1.6,
              color: persona.textColor,
              margin: 0
            }}
          >
            {hint}
          </p>
        </div>
      </div>
    </div>
  );
};

export default InsightDigestNarrator;

