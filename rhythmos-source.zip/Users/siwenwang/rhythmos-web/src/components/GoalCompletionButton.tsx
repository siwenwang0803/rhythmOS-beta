// /components/GoalCompletionButton.tsx

import React, { useState } from 'react';
import { writeRhythmScore } from '../utils/writeRhythmScore';
import { MAX_SINGLE_GOAL_SCORE } from '../utils/writeRhythmScore';
import { RhythmButton } from './rhythmUI'; // 假设这是您项目中的按钮组件

interface GoalCompletionButtonProps {
  goalId: string;
  onComplete: () => void;
  disabled?: boolean;
  className?: string;
  style?: React.CSSProperties;
}

// 分数动画组件
const ScoreAnimation = ({ isVisible, onAnimationEnd, points }: { isVisible: boolean, onAnimationEnd: () => void, points: number }) => {
  React.useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onAnimationEnd();
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onAnimationEnd]);

  if (!isVisible) return null;

  const keyframes = `
    @keyframes float-up {
      0% {
        opacity: 0;
        transform: translate(0, 0);
      }
      20% {
        opacity: 1;
      }
      100% {
        opacity: 0;
        transform: translate(0, -50px);
      }
    }
  `;

  return (
    <>
      <style>{keyframes}</style>
      <div 
        className="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 text-sm font-bold text-green-600"
        style={{
          animation: 'float-up 1.5s ease-out forwards',
          textShadow: '0 0 3px rgba(0,0,0,0.3), 0 0 5px rgba(0,0,0,0.2)',
          zIndex: 10,
        }}
      >
        +{points} Rhythm
      </div>
    </>
  );
};

const GoalCompletionButton: React.FC<GoalCompletionButtonProps> = ({
  goalId,
  onComplete,
  disabled = false,
  className = '',
  style = {}
}) => {
  const [showAnimation, setShowAnimation] = useState(false);
  const [actualScore, setActualScore] = useState(0);
  const buttonRef = React.useRef<HTMLDivElement>(null);

// /components/GoalCompletionButton.tsx - 修复片段 (只显示关键修改部分)

// 修改handleGoalComplete函数:

const handleGoalComplete = () => {
    if (disabled) return;
  
    // 获取此目标已有的分数
    const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
    const today = new Date().toISOString().slice(0, 10);
    
    const goalScore = rhythmScoreLog
      .filter((entry: any) => 
        entry.date === today && 
        entry.goalId === goalId &&
        (entry.actionType === 'subtask_complete' || entry.actionType === 'goal_complete')
      )
      .reduce((acc: number, entry: any) => acc + entry.value, 0);
    
    // 计算完成目标应得分数
    // 最多得到MAX_SINGLE_GOAL_SCORE (2分)，减去已经从子任务获得的分数
    const remainingScore = Math.max(0, MAX_SINGLE_GOAL_SCORE - goalScore);
    const [actualScore, setActualScore] = useState(0);
    console.log(`Goal ${goalId} completion. Current score: ${goalScore}, Adding: ${remainingScore}`);
    
    // 如果还有分数可以得到，进行记录
    if (remainingScore > 0) {
      // 修改为接收实际记录的分数
      const actualScore = writeRhythmScore(remainingScore, 'goal_complete', goalId);
      
      if (actualScore > 0) {
        // 更新状态并显示动画
        setActualScore(actualScore);
        setShowAnimation(true);
        
        // 触发更新事件
        window.dispatchEvent(new Event('rhythm-score-updated'));
      }
    }
    
    // 无论是否得分，都调用完成回调
    onComplete();
  };

  return (
    <div ref={buttonRef} className="relative">
      <RhythmButton
        onClick={handleGoalComplete}
        disabled={disabled}
        className={className}
        style={style}
      >
        <span className="flex items-center gap-2">
          <span>🎯</span>
          <span>Mark Goal Complete</span>
        </span>
      </RhythmButton>
      
      {buttonRef.current && showAnimation && (
        <ScoreAnimation
          isVisible={showAnimation}
          onAnimationEnd={() => setShowAnimation(false)}
          points={actualScore}
        />
      )}
    </div>
  );
};

export default GoalCompletionButton;