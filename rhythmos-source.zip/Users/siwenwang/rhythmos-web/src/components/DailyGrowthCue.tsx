import React, { useEffect, useState } from 'react'
import { personaPathMap } from '../personaPathMap'
import { writeCREGrowthLog } from '../creGrowthLog'
import { updateRhythmScore } from '../rhythmScore'
import { recordRhythmTrend } from '../trendPathTracker'
import { addMilestone } from '../milestoneTracker'
import MilestoneToast from './MilestoneToast'
import { RhythmCard, RhythmButton } from './rhythmUI'
import { GeneratedCRE } from '../types/cre'
import RhythmFeedbackHint from './RhythmFeedbackHint'
import ToneMigrationPrompt from './ToneMigrationPrompt'
import { detectToneMigration } from '../utils/detectToneMigration'

interface DailyGrowthCueProps {
  cre: GeneratedCRE
}

const DailyGrowthCue: React.FC<DailyGrowthCueProps> = ({ cre }) => {
  if (!cre || !cre.persona) return null

  const [taskType, setTaskType] = useState<string | null>(null)
  const [accepted, setAccepted] = useState(false)
  const [milestone, setMilestone] = useState<any | null>(null)
  const [currentTrend, setCurrentTrend] = useState<string>('training')
  const [showHint, setShowHint] = useState(false)
  const [showTonePrompt, setShowTonePrompt] = useState(false)
  const [suggestedPersona, setSuggestedPersona] = useState<string | null>(null)

  useEffect(() => {
    const model = personaPathMap.find((p) => p.persona === cre.persona)
    if (model) {
      const task = model.taskFocus[Math.floor(Math.random() * model.taskFocus.length)]
      setTaskType(task)
    }
  }, [cre.persona])

  useEffect(() => {
    const drift = detectToneMigration()
    if (drift.trigger) {
      setSuggestedPersona(drift.suggested)
      setShowTonePrompt(true)
    }
  }, [])

  const handleAccept = () => {
    if (!cre.cue || !taskType) return

    writeCREGrowthLog({
      creText: cre.cue,
      tone: cre.tone,
      variant: 'base',
      taskType,
      persona: cre.persona,
      trend: 'training',
      context: 'persona',
      accepted: true,
      score: undefined,
      timestamp: Date.now()
    })

    const { score, state } = updateRhythmScore('complete', 'system')
    recordRhythmTrend(score, state)
    setCurrentTrend(state)
    setShowHint(true)

    // ❗️模拟检测语气变化趋势，后续用 SignatureMap 替换
    if (cre.tone === 'directive' && cre.persona !== 'caelum') {
      setSuggestedPersona('caelum')
      setShowTonePrompt(true)
    }

    if (score >= 6) {
      const msg = "🎯 You've entered a rising rhythm!"
      addMilestone('trend_rising', msg)
      setMilestone({ type: 'trend_rising', message: msg, timestamp: Date.now() })
    }

    setAccepted(true)
  }

  if (!cre.cue || !taskType) return null

  return (
    <div className="mt-8 space-y-3">
      <h2 className="text-md font-semibold text-gray-800">🌱 Today's Identity Cue</h2>

      <RhythmCard>
        <p className="text-sm text-blue-700 italic">“{cre.cue}”</p>
        <p className="text-xs text-gray-500">
          Voice: <strong>{cre.persona}</strong> · Tone: <strong>{cre.tone}</strong>
        </p>
        <p className="text-xs text-gray-500">
          Task Focus: <strong>{taskType}</strong>
        </p>

        {!accepted ? (
          <RhythmButton onClick={handleAccept}>✅ Accept Today's Task</RhythmButton>
        ) : (
          <>
            <p className="text-xs text-green-600 italic">✅ Accepted. Rhythm logged!</p>
            <p className="text-xs text-gray-400 italic">📆 Come back tomorrow for a new cue.</p>
            <RhythmButton onClick={() => window.location.reload()} variant="secondary">
              🔁 Generate Another Cue
            </RhythmButton>

            {showHint && (
              <div className="mt-4">
                <RhythmFeedbackHint
                  trend={currentTrend}
                  tone={cre.tone}
                  persona={cre.persona}
                />
              </div>
            )}

            {showTonePrompt && suggestedPersona && (
              <div className="mt-6">
                <ToneMigrationPrompt
                  current={cre.persona}
                  suggested={suggestedPersona}
                  onAccept={(newPersona) => {
                    localStorage.setItem('creStyleOverride', newPersona)
                    window.location.reload()
                  }}
                  onReject={() => setShowTonePrompt(false)}
                />
              </div>
            )}
          </>
        )}
      </RhythmCard>

      {milestone && <MilestoneToast milestone={milestone} />}
    </div>
  )
}

export default DailyGrowthCue


