import React, { useState, useEffect } from 'react';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend, Tooltip } from 'recharts';

// 独立的组件，不依赖于现有的 getToneScoreMapByDays
const ToneOverviewPanel: React.FC = () => {
  const [toneData, setToneData] = useState<Record<string, number>>({});
  const [isLoading, setIsLoading] = useState(true);

  // 直接从 localStorage 读取并处理数据
  useEffect(() => {
    const loadAndProcessToneData = () => {
      setIsLoading(true);
      try {
        // 从 localStorage 直接读取原始数据
        const toneLogString = localStorage.getItem('toneLog');
        if (!toneLogString) {
          console.log('No toneLog found in localStorage');
          setToneData({});
          setIsLoading(false);
          return;
        }

        // 解析数据
        const toneLog = JSON.parse(toneLogString);
        console.log('ToneOverviewPanel - Raw toneLog data:', toneLog);

        // 过滤最近7天的数据
        const now = new Date();
        const cutoffDate = new Date(now);
        cutoffDate.setDate(now.getDate() - 7);

        // 计算唯一天的键值
        const processedKeys = new Set<string>();
        const scoreByTone: Record<string, number> = {};

        // 处理每条记录
        toneLog.forEach((entry: any) => {
          if (!entry || !entry.tone || !entry.timestamp) return;
          
          const entryDate = new Date(entry.timestamp);
          // 跳过超出时间范围的数据
          if (entryDate < cutoffDate) return;
          
          // 计算得分
          const score = typeof entry.score === 'number' ? 
            entry.score : (entry.feedback === 'aligned' ? 1 : entry.feedback === 'okay' ? 0.5 : 0);
          
          // 跳过零分数据
          if (score === 0) return;
          
          // 生成日期字符串: YYYY-MM-DD
          const dateStr = `${entryDate.getFullYear()}-${entryDate.getMonth()+1}-${entryDate.getDate()}`;
          
          // 生成唯一键
          const uniqueKey = `${entry.cueId || 'unknown'}_${entry.tone}_${dateStr}`;
          
          // 防止重复计算
          if (processedKeys.has(uniqueKey)) return;
          processedKeys.add(uniqueKey);
          
          // 累计分数
          scoreByTone[entry.tone] = (scoreByTone[entry.tone] || 0) + score;
        });

        console.log('ToneOverviewPanel - Processed score data:', scoreByTone);
        setToneData(scoreByTone);
      } catch (error) {
        console.error('Error processing tone data:', error);
        setToneData({});
      } finally {
        setIsLoading(false);
      }
    };

    // 初始加载
    loadAndProcessToneData();

    // 设置定期刷新
    const intervalId = setInterval(loadAndProcessToneData, 30000);

    // 添加事件监听
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'toneLog' || e.key === 'cueFeedbackLog') {
        console.log('Storage changed, refreshing tone data');
        loadAndProcessToneData();
      }
    };
    window.addEventListener('storage', handleStorageChange);

    // 自定义事件监听
    const handleFeedbackUpdate = () => {
      console.log('Feedback updated event received, refreshing tone data');
      loadAndProcessToneData();
    };
    window.addEventListener('cue-feedback-updated', handleFeedbackUpdate);
    window.addEventListener('tone-radar-update', handleFeedbackUpdate);

    // 清理函数
    return () => {
      clearInterval(intervalId);
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('cue-feedback-updated', handleFeedbackUpdate);
      window.removeEventListener('tone-radar-update', handleFeedbackUpdate);
    };
  }, []);

  // 获取 tone 颜色
  const getToneColor = (tone: string): string => {
    const colorMap: Record<string, string> = {
      'gentle': '#4F8A8B', 
      'motivated': '#E16036',
      'directive': '#5D5FEF',
      'rational': '#9333EA',  
      'visionary': '#F59E0B',
      'default': '#64748B'
    };
    return colorMap[tone] || colorMap.default;
  };

  // 获取 tone 显示名称
  const getToneDisplayName = (tone: string): string => {
    const toneNames: Record<string, string> = {
      'gentle': 'Gentle',
      'motivated': 'Motivated',
      'directive': 'Directive',
      'rational': 'Rational',
      'visionary': 'Visionary'
    };
    return toneNames[tone] || tone.charAt(0).toUpperCase() + tone.slice(1);
  };

  // 为雷达图准备数据
  const formatDataForRadar = () => {
    const tones = Object.keys(toneData);
    if (tones.length === 0) return [];

    // 创建雷达图所需的数据结构
    return [
      { subject: 'Impact', ...toneData },
      { subject: 'Clarity', ...toneData },
      { subject: 'Engagement', ...toneData },
      { subject: 'Relevance', ...toneData },
      { subject: 'Alignment', ...toneData }
    ];
  };

  // 如果正在加载或没有数据，显示加载状态
  if (isLoading) {
    return (
      <div className="py-4 text-center text-gray-500">
        <div className="inline-block w-5 h-5 border-2 border-t-blue-500 border-gray-200 rounded-full animate-spin mr-2"></div>
        Loading tone data...
      </div>
    );
  }

  if (Object.keys(toneData).length === 0) {
    return (
      <div className="py-4 text-center text-gray-500 italic">
        No tone feedback available yet
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border shadow-sm p-4">
      <h3 className="text-lg font-medium mb-2">Tone Distribution Overview</h3>
      <p className="text-sm text-gray-600 mb-4">
        Based on your feedback in the last 7 days. Aligned = 1.0, Okay = 0.5
      </p>

      {/* Tone Cards */}
      <div className="mb-5 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {Object.entries(toneData).map(([tone, score]) => (
          <div 
            key={tone}
            className="rounded-lg border p-3 transition hover:shadow-sm"
            style={{ borderLeftWidth: '4px', borderLeftColor: getToneColor(tone) }}
          >
            <div className="flex justify-between items-center mb-1">
              <span className="font-medium">{getToneDisplayName(tone)}</span>
              <span 
                className="px-2 py-0.5 rounded-full text-xs font-bold"
                style={{ backgroundColor: `${getToneColor(tone)}20`, color: getToneColor(tone) }}
              >
                {score.toFixed(1)}
              </span>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-2">
              <div 
                className="h-2 rounded-full"
                style={{ 
                  width: `${Math.min((score / 3) * 100, 100)}%`,
                  backgroundColor: getToneColor(tone)
                }}
              ></div>
            </div>
          </div>
        ))}
      </div>

      {/* Radar Chart */}
      <div className="mt-6">
        <h4 className="text-sm font-medium mb-3">Tone Distribution (Radar):</h4>
        <div style={{ width: '100%', height: 300 }}>
          <ResponsiveContainer>
            <RadarChart outerRadius="70%" data={formatDataForRadar()}>
              <PolarGrid stroke="#E5E7EB" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#6B7280', fontSize: 12 }} />
              <PolarRadiusAxis domain={[0, 3]} tick={{ fill: '#9CA3AF', fontSize: 10 }} />
              
              {Object.keys(toneData).map(tone => (
                <Radar
                  key={tone}
                  name={getToneDisplayName(tone)}
                  dataKey={tone}
                  stroke={getToneColor(tone)}
                  fill={getToneColor(tone)}
                  fillOpacity={0.4}
                />
              ))}
              
              <Legend />
              <Tooltip formatter={(value: number) => [value.toFixed(1), '']} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 总结 */}
      <div className="mt-4 pt-3 border-t text-sm text-gray-500">
        <p>
          Total score: {Object.values(toneData).reduce((sum, score) => sum + score, 0).toFixed(1)}
        </p>
        <p className="mt-1 text-xs">
          Score explanation: Aligned feedback = 1.0 points, Okay feedback = 0.5 points
        </p>
      </div>
    </div>
  );
};

export default ToneOverviewPanel;