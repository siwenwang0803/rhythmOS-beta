// components/ui/RhythmStudioPanel.tsx

import React from 'react'

interface RhythmStudioPanelProps {
  title: string
  subtitle?: string
  tone?: 'default' | 'blue' | 'green' | 'yellow' | 'gray' | 'purple'
  children: React.ReactNode
}

const toneMap: Record<string, string> = {
  default: 'bg-gray-50 border border-gray-200',
  blue: 'bg-blue-50 border border-blue-200',
  green: 'bg-green-50 border border-green-200',
  yellow: 'bg-yellow-50 border border-yellow-200',
  gray: 'bg-gray-100 border border-gray-300',
  purple: 'bg-purple-50 border border-purple-200'
}

const RhythmStudioPanel: React.FC<RhythmStudioPanelProps> = ({
  title,
  subtitle,
  tone = 'default',
  children
}) => {
  return (
    <div className={`rounded-2xl p-6 shadow-sm space-y-2 ${toneMap[tone]}`}>
      <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
      {subtitle && <p className="text-sm text-gray-500">{subtitle}</p>}
      <div className="pt-2">{children}</div>
    </div>
  )
}

export default RhythmStudioPanel

