// PageIntro.tsx

import React from 'react'

interface PageIntroProps {
  title: string
  subtitle: string
  tone?: 'default' | 'blue' | 'green' | 'yellow'
}

const toneStyles: Record<string, string> = {
  default: 'bg-gray-50 border-gray-200',
  blue: 'bg-blue-50 border-blue-200',
  green: 'bg-green-50 border-green-200',
  yellow: 'bg-yellow-50 border-yellow-200',
}

const PageIntro: React.FC<PageIntroProps> = ({ title, subtitle, tone = 'default' }) => {
  return (
    <div
      className={`p-4 rounded-xl border ${toneStyles[tone]} mb-6`}
    >
      <h2 className="text-lg font-semibold text-gray-800">{title}</h2>
      <p className="text-sm text-gray-500 mt-1">{subtitle}</p>
    </div>
  )
}

export default PageIntro
