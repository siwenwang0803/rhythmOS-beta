// src/components/ui/RhythmTooltip.tsx

import React from 'react';
import {
    Tooltip,
    TooltipContent,
    TooltipProvider,
    TooltipTrigger,
  } from "@/components/ui/tooltip";
const tooltipMap: Record<string, string> = {
  CRE: 'A short, resonant sentence crafted by the system based on your rhythm and persona to guide self-reflection or emotional alignment.',
  trend: 'Your recent rhythm movement — rising, stable, or collapsed — affects what kind of cues and tasks you receive.',
  persona: 'The tone style used to communicate with you — gentle (Rhea), rational (Aurelia), directive (Niveus).',
  tone: 'The emotional tone used in your CRE cues — soft, directive, neutral, etc.',
  Signature: 'Your personal feedback × rhythm × tone preference map. Tracks how you grow over time.',
  rhythmScore: 'A numerical measure of your current rhythm state. Higher scores mean more energy/stability.',
  feedback: "Your rating after reading a CRE. This helps the system adapt and personalize future cues.",
  subtaskSuggestion: "System-generated action steps based on your goal cue or writing.",
  goalIntent: "The interpreted motivation or training direction behind your goal — used to refine system suggestions.",
};

type RhythmTooltipProps = {
  term: keyof typeof tooltipMap;
};

const RhythmTooltip: React.FC<RhythmTooltipProps> = ({ term }) => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger className="font-semibold underline decoration-dotted cursor-help">
          {term}
        </TooltipTrigger>
        <TooltipContent className="max-w-sm text-sm text-gray-100 bg-gray-900 p-2 rounded-md shadow-md">
          {tooltipMap[term]}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default RhythmTooltip;
