import React, { useState } from 'react';

interface RhythmButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'muted' | 'danger';
  tone?: 'collapsed' | 'wavy' | 'stable' | 'rising';
  children: React.ReactNode;
  isDaytime?: boolean;
}

/**
 * Enhanced RhythmButton with improved visual design following RhythmOS design system
 * Supports day/night mode and provides subtle interactive feedback
 */
const RhythmButton: React.FC<RhythmButtonProps> = ({
  variant = 'primary',
  tone,
  children,
  className = '',
  isDaytime = true,
  style,
  ...props
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isPressed, setIsPressed] = useState(false);
  
  // RhythmOS color system
  const stateColors = {
    collapsed: '#AEC6CF', // Gentle calming blue
    wavy: '#C3B1E1',      // Transitional lavender
    stable: '#C5D8A4',    // Grounded light green
    rising: '#FFB347',    // Activating orange-yellow
  };
  
  // Custom color mapping using RhythmOS colors
  const getButtonStyles = () => {
    // Base styles apply to all variants
    const baseStyles = {
      padding: '10px 18px',
      borderRadius: '10px',
      fontSize: '14px',
      fontWeight: 500,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '8px',
      transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
      cursor: props.disabled ? 'not-allowed' : 'pointer',
      opacity: props.disabled ? 0.6 : 1,
      transform: isPressed ? 'translateY(1px)' : isHovered ? 'translateY(-1px)' : 'translateY(0)',
    };
    
    // If tone is provided, override the variant's default color
    let variantStyles = {};
    
    if (tone && stateColors[tone]) {
      variantStyles = {
        backgroundColor: stateColors[tone],
        color: tone === 'rising' ? '#FFFFFF' : '#333333',
        border: 'none',
        boxShadow: isPressed 
          ? '0 1px 3px rgba(0, 0, 0, 0.1)' 
          : isHovered 
            ? `0 4px 12px rgba(0, 0, 0, 0.15)` 
            : '0 2px 6px rgba(0, 0, 0, 0.1)',
      };
    } else {
      // Variant-specific styles when no tone is provided
      switch(variant) {
        case 'primary':
          variantStyles = {
            backgroundColor: stateColors.rising,
            color: '#FFFFFF',
            border: 'none',
            boxShadow: isPressed 
              ? '0 1px 3px rgba(0, 0, 0, 0.1)' 
              : isHovered 
                ? '0 4px 12px rgba(255, 179, 71, 0.3)' 
                : '0 2px 6px rgba(255, 179, 71, 0.2)',
          };
          break;
        case 'secondary':
          variantStyles = {
            backgroundColor: stateColors.stable,
            color: '#333333',
            border: 'none',
            boxShadow: isPressed 
              ? '0 1px 3px rgba(0, 0, 0, 0.1)' 
              : isHovered 
                ? '0 4px 12px rgba(197, 216, 164, 0.3)' 
                : '0 2px 6px rgba(197, 216, 164, 0.2)',
          };
          break;
        case 'muted':
          variantStyles = {
            backgroundColor: isDaytime 
              ? 'rgba(245, 232, 199, 0.3)' 
              : 'rgba(58, 58, 58, 0.7)',
            color: isDaytime ? '#333333' : '#E0E0E0',
            border: `1px solid ${isDaytime ? '#E6E6E6' : '#555555'}`,
            boxShadow: isPressed 
              ? 'none' 
              : isHovered 
                ? `0 2px 8px ${isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(0, 0, 0, 0.2)'}` 
                : 'none',
          };
          break;
        case 'danger':
          variantStyles = {
            backgroundColor: isDaytime 
              ? 'rgba(239, 68, 68, 0.1)' 
              : 'rgba(239, 68, 68, 0.15)',
            color: isDaytime ? '#EF4444' : '#F87171',
            border: `1px solid ${isDaytime ? 'rgba(239, 68, 68, 0.3)' : 'rgba(239, 68, 68, 0.2)'}`,
            boxShadow: isPressed 
              ? 'none' 
              : isHovered 
                ? '0 2px 8px rgba(239, 68, 68, 0.15)' 
                : 'none',
          };
          break;
      }
    }
    
    // Return combined styles
    return {
      ...baseStyles,
      ...variantStyles,
      ...style  // Apply any custom style properties passed to the component
    };
  };

  return (
    <button
      {...props}
      style={getButtonStyles()}
      className={className}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setIsPressed(false);
      }}
      onMouseDown={() => setIsPressed(true)}
      onMouseUp={() => setIsPressed(false)}
      onTouchStart={() => setIsPressed(true)}
      onTouchEnd={() => setIsPressed(false)}
    >
      {children}
    </button>
  );
};

export default RhythmButton;
