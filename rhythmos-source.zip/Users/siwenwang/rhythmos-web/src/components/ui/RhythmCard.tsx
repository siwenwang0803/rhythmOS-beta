// components/ui/RhythmCard.tsx

import React from 'react'

interface RhythmCardProps {
  children: React.ReactNode
  className?: string
}

const RhythmCard: React.FC<RhythmCardProps> = ({ children, className = '' }) => {
  return (
    <div className={`p-4 border rounded-xl bg-white shadow-sm ${className}`}>
      {children}
    </div>
  )
}

export default RhythmCard
