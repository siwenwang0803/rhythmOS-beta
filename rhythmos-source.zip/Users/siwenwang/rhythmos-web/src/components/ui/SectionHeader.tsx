// components/ui/SectionHeader.tsx

import React from 'react'

interface SectionHeaderProps {
  title: string
  subtitle?: string
}

const SectionHeader: React.FC<SectionHeaderProps> = ({ title, subtitle }) => {
  return (
    <div className="mb-4">
      <h2 className="text-md font-semibold text-gray-800 mb-1">{title}</h2>
      {subtitle && <p className="text-sm text-gray-500">{subtitle}</p>}
    </div>
  )
}

export default SectionHeader
