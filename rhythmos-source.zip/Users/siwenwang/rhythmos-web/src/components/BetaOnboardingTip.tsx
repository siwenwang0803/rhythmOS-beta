import React from 'react';

export const BetaOnboardingTip: React.FC = () => {
    const url = new URLSearchParams(window.location.search);
    const forced = url.get('showBetaFeedback') === 'true';
    const dismissed = localStorage.getItem('betaTipDismissed');
    
    if (!forced && dismissed === 'true') return null;

  const handleDismiss = () => {
    localStorage.setItem('betaTipDismissed', 'true');
  };

  return (
    <div className="mt-6 p-4 border border-yellow-300 bg-yellow-50 rounded text-sm text-yellow-800 shadow-sm">
      <p className="font-medium mb-1">🌱 Beta Feedback Reminder</p>
      <p>
        You're currently using a beta version of RhythmOS. We'd love your feedback about the tone,
        challenge suggestions, or overall experience.
      </p>

    </div>
  );
};
