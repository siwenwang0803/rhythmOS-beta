// 完整的修改过的 IdentityChallengeCard.tsx 文件

import React, { useState, useEffect, useRef } from 'react';
import { RhythmButton } from './rhythmUI';
import { signatureMap } from '../SignatureMap';
import { writeRhythmScore } from '../utils/writeRhythmScore';
import { addXp } from '../utils/xpEngine'; // Direct import for critical fix

interface IdentityChallengeCardProps {
  cue: string;
  paragraph: string;
  action: string;
  isCompleted?: boolean;
  feedback?: 'aligned' | 'okay' | 'not_me';
  onComplete?: () => void;
  onFeedback?: (value: 'aligned' | 'okay' | 'not_me') => void;
  onRefresh?: () => void; // 新增：刷新挑战的回调
  points?: number;
}

// XP animation component
const XpAnimation = ({ isVisible, onAnimationEnd, xpAmount = 6 }: { isVisible: boolean, onAnimationEnd: () => void, xpAmount?: number }) => {
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onAnimationEnd();
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onAnimationEnd]);

  if (!isVisible) return null;

  // Animation style definitions
  const keyframes = `
    @keyframes fade-up {
      0% {
        opacity: 0;
        transform: translateY(10px);
      }
      20% {
        opacity: 1;
      }
      100% {
        opacity: 0;
        transform: translateY(-20px);
      }
    }
  `;

  return (
    <>
      <style>{keyframes}</style>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-green-100 text-green-800 px-4 py-2 rounded-full text-lg font-bold"
        style={{ animation: 'fade-up 1.5s ease-out forwards' }}>
        +{xpAmount} XP
      </div>
    </>
  );
};

// Add rhythm score animation component
const ScoreAnimation = ({ isVisible, onAnimationEnd, points = 2 }: { isVisible: boolean, onAnimationEnd: () => void, points?: number }) => {
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onAnimationEnd();
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onAnimationEnd]);

  if (!isVisible) return null;

  // Animation style definitions
  const animationStyle = {
    animation: 'float-right 1.5s ease-out forwards',
    textShadow: '0 0 3px rgba(0,0,0,0.3), 0 0 5px rgba(0,0,0,0.2)',
    zIndex: 10,
    left: '50%',
  };

  const keyframes = `
    @keyframes float-right {
      0% {
        opacity: 0;
        transform: translate(0, -50%);
      }
      20% {
        opacity: 1;
      }
      100% {
        opacity: 0;
        transform: translate(50px, -50%);
      }
    }
  `;

  return (
    <>
      <style>{keyframes}</style>
      <div 
        className="absolute text-sm font-bold text-[#4CAF50]"
        style={animationStyle}
      >
        +{points} Rhythm
      </div>
    </>
  );
};

const IdentityChallengeCard: React.FC<IdentityChallengeCardProps> = ({
  cue,
  paragraph,
  action,
  isCompleted = false,
  feedback,
  onComplete,
  onFeedback,
  onRefresh, // 新增：接收刷新回调
  points = 3
}) => {
  const [showParagraph, setShowParagraph] = useState(false);
  const [localFeedback, setLocalFeedback] = useState<string | null>(feedback || null);
  const [done, setDone] = useState<boolean>(isCompleted);
  const [showXpAnimation, setShowXpAnimation] = useState(false);
  const [showScoreAnimation, setShowScoreAnimation] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false); // 新增：刷新状态
  const buttonRef = useRef<HTMLButtonElement>(null);

  // Sync completion state
  useEffect(() => {
    setDone(isCompleted);
  }, [isCompleted]);

  useEffect(() => {
    setLocalFeedback(feedback || null);
  }, [feedback]);

  const writeChallengeLog = (value: 'aligned' | 'okay' | 'not_me') => {
    // Prevent duplicate logs
    if (localFeedback) return;

    signatureMap.challengeLog = signatureMap.challengeLog || [];
    signatureMap.challengeLog.push({
      text: cue,
      persona: localStorage.getItem('initPersona') || 'rhea',
      feedback: value,
      time: Date.now()
    });
  };

  const handleFeedback = (value: 'aligned' | 'okay' | 'not_me') => {
    if (localFeedback) return; // Prevent multiple entries

    setLocalFeedback(value);
    writeChallengeLog(value);
    onFeedback?.(value);
  };

  // CRITICAL FIX: handleComplete function
  const handleComplete = () => {
    console.log("=== CHALLENGE COMPLETED ===");
    
    // Record challenge completion and write rhythm score (default 3 points)
    writeRhythmScore(points, 'challenge_complete');
    console.log(`Wrote rhythm score: ${points} points`);
    
    // CRITICAL FIX: Directly add XP here
    // This ensures XP is added immediately when the challenge is completed
    const activePersona = localStorage.getItem('initPersona') || 'rhea';
    console.log(`Adding 6 XP directly to ${activePersona}`);
    
    // Call addXp directly to ensure XP is added
    addXp(activePersona, 6);
    
    // Update state and show animations
    setDone(true);
    setShowXpAnimation(true);
    setShowScoreAnimation(true);
    
    // Trigger the parent's onComplete callback (which calls logChallengeXp)
    console.log("Calling onComplete callback");
    onComplete?.();
    
    // Force update events
    window.dispatchEvent(new Event('xp-updated'));
    
    // Verify XP addition
    setTimeout(() => {
      try {
        const xpLogRaw = localStorage.getItem('personaXpLog');
        if (xpLogRaw) {
          const xpData = JSON.parse(xpLogRaw);
          console.log(`Verification - ${activePersona}'s XP: ${xpData[activePersona]?.xp}`);
        }
      } catch (e) {
        console.error('Error verifying XP:', e);
      }
    }, 100);
  };

  // 新增：处理刷新挑战
  const handleRefresh = async () => {
    if (!onRefresh) return;
    
    setIsRefreshing(true);
    console.log("Refreshing challenge...");
    
    try {
      // 调用父组件的刷新函数
      await onRefresh();
      
      // 显示刷新成功反馈
      console.log("Challenge refreshed successfully");
    } catch (error) {
      console.error("Error refreshing challenge:", error);
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <div
      className="border rounded-xl relative overflow-hidden shadow-sm"
      style={{
        borderColor: '#D5C8BB',
        backgroundColor: '#F7F3EF'
      }}
    >
      {/* Left Accent Bar */}
      <div className="absolute left-0 top-0 bottom-0 w-1.5" style={{ backgroundColor: '#BFAE9B' }} />

      <div className="px-5 py-5 space-y-4 ml-1.5" style={{ color: '#3B322B' }}>
        {/* Header */}
        <div
          className="flex items-center justify-between gap-2.5 px-4 py-2 rounded-lg shadow-sm"
          style={{ backgroundColor: '#E9E0D4' }}
        >
          <div className="flex items-center gap-2">
            <span className="text-base" style={{ color: '#BFAE9B' }}>🎯</span>
            <p className="text-sm font-semibold tracking-tight" style={{ color: '#3B322B' }}>
              Today's Challenge
            </p>
          </div>
          
          {/* Show points */}
          <div className="text-xs font-medium px-2 py-1 rounded" style={{ backgroundColor: '#F2E9DE', color: '#7C6F65' }}>
            {points} points
          </div>
        </div>

        {/* Challenge Content */}
        <div className="px-4 py-4 rounded-lg" style={{ backgroundColor: '#F2E9DE' }}>
          <p className="text-lg font-semibold mb-2 leading-tight" style={{ color: '#3B322B' }}>
            {action}
          </p>
          <p className="text-sm italic leading-relaxed" style={{ color: '#7C6F65' }}>
            "{cue}"
          </p>

          {showParagraph && (
            <div className="mt-4 p-3 rounded-lg" style={{ backgroundColor: '#F7F3EF' }}>
              <p className="text-sm leading-relaxed" style={{ color: '#7C6F65' }}>{paragraph}</p>
            </div>
          )}

          {!showParagraph && (
            <button
              className="mt-3 text-xs underline"
              style={{ color: '#7C6F65' }}
              onClick={() => setShowParagraph(true)}
            >
              show more
            </button>
          )}
        </div>

        {/* Completion & Feedback */}
        <div className="px-4 space-y-4 relative">
          {!done ? (
            <button
              ref={buttonRef}
              className="px-4 py-2.5 rounded-lg text-sm font-medium border transition-all shadow-sm"
              style={{
                backgroundColor: '#DDD0C1',
                color: '#3B322B',
                borderColor: '#D5C8BB'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#CDBFAB';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#DDD0C1';
              }}
              onClick={handleComplete}
            >
              ✅ Mark this as done
            </button>
          ) : (
            // 修改：完成状态时显示Anchored和刷新按钮
            <div className="flex items-center gap-3">
              <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg shadow-sm"
                style={{ backgroundColor: '#D5EAD6' }}>
                <span className="text-sm font-medium" style={{ color: '#2E7D32' }}>✅ Anchored</span>
              </div>
              
              {/* 刷新按钮 */}
              {onRefresh && (
                <button
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border transition-all shadow-sm"
                  style={{
                    backgroundColor: isRefreshing ? '#E0E0E0' : '#F0F0F0',
                    color: '#666666',
                    borderColor: '#D0D0D0'
                  }}
                  disabled={isRefreshing}
                  onMouseEnter={(e) => {
                    if (!isRefreshing) {
                      e.currentTarget.style.backgroundColor = '#E8E8E8';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isRefreshing) {
                      e.currentTarget.style.backgroundColor = '#F0F0F0';
                    }
                  }}
                  onClick={handleRefresh}
                  title="Get a new challenge"
                >
                  {isRefreshing ? (
                    <>
                      <span className="animate-spin">⟳</span>
                      <span>Refreshing...</span>
                    </>
                  ) : (
                    <>
                      <span>🔄</span>
                      <span>New Challenge</span>
                    </>
                  )}
                </button>
              )}
            </div>
          )}

          {/* XP Animation */}
          {buttonRef.current && showXpAnimation && (
            <div style={{ 
              position: 'absolute', 
              left: `${buttonRef.current.offsetLeft + buttonRef.current.offsetWidth / 2}px`,
              top: buttonRef.current.offsetTop
            }}>
              <XpAnimation 
                isVisible={showXpAnimation} 
                onAnimationEnd={() => setShowXpAnimation(false)} 
                xpAmount={6}
              />
            </div>
          )}
          
          {/* Rhythm Score Animation */}
          {buttonRef.current && showScoreAnimation && (
            <div style={{ 
              position: 'absolute', 
              left: `${buttonRef.current.offsetLeft + buttonRef.current.offsetWidth / 2}px`,
              top: buttonRef.current.offsetTop + 30
            }}>
              <ScoreAnimation 
                isVisible={showScoreAnimation} 
                onAnimationEnd={() => setShowScoreAnimation(false)} 
                points={points}
              />
            </div>
          )}

          <div>
            <p className="text-xs mb-2" style={{ color: '#7C6F65' }}>How did this feel?</p>
            <div className="flex gap-2">
              {['aligned', 'okay', 'not_me'].map((type) => {
                const isSelected = localFeedback === type;
                const styles = {
                  aligned: {
                    bg: isSelected ? '#D5EAD6' : '#DDD0C1',
                    color: isSelected ? '#2E7D32' : '#3B322B'
                  },
                  okay: {
                    bg: isSelected ? '#FFF4D1' : '#DDD0C1',
                    color: isSelected ? '#AD6700' : '#3B322B'
                  },
                  not_me: {
                    bg: isSelected ? '#FDE6E7' : '#DDD0C1',
                    color: isSelected ? '#B71C1C' : '#3B322B'
                  }
                }[type as 'aligned' | 'okay' | 'not_me'];

                return (
                  <button
                    key={type}
                    disabled={!!localFeedback}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all shadow-sm ${
                      localFeedback ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                    style={{
                      backgroundColor: styles.bg,
                      color: styles.color,
                      borderColor: '#CABAA6',
                      borderWidth: '1px'
                    }}
                    onClick={() => handleFeedback(type as 'aligned' | 'okay' | 'not_me')}
                  >
                    {{
                      aligned: '✅ Aligned',
                      okay: '😐 Okay',
                      not_me: '❌ Not me'
                    }[type as 'aligned' | 'okay' | 'not_me']}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IdentityChallengeCard;







