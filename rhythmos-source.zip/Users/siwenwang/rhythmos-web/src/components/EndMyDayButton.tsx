// /components/EndMyDayButton.tsx

import React, { useState, useEffect } from 'react';
import { getFinalizedSummary, getTodayTotalScore, isTodayFinalized, markTodayFinalized, finalizeToday } from '../utils/rhythmDayEngine';
import { detectCurrentTrend } from '../utils/rhythmDayEngine';

// Define UI spec colors
const RHYTHM_COLORS = {
  collapsed: '#AEC6CF',
  wavy: '#C3B1E1',
  stable: '#C5D8A4',
  rising: '#FFB347'
};

const safeNumber = (input: any): number => {
  if (typeof input === 'number' && !isNaN(input)) return input;
  const parsed = parseFloat(String(input));
  return isNaN(parsed) ? 0 : parsed;
};

const EndMyDayButton: React.FC = () => {
  const [score, setScore] = useState<number>(0);
  const [confirmMode, setConfirmMode] = useState<boolean>(false);
  const [dayEnded, setDayEnded] = useState<boolean>(false);
  const [currentTrend, setCurrentTrend] = useState<string>('stable');
  const [isAnimating, setIsAnimating] = useState<boolean>(false);

  useEffect(() => {
    const fetchScore = () => {
      const finalized = isTodayFinalized();
      const raw = finalized ? getFinalizedSummary()?.score : getTodayTotalScore();
      setScore(safeNumber(raw));
      setDayEnded(finalized);
      
      // Get the current trend
      const trend = detectCurrentTrend();
      setCurrentTrend(trend);
    };

    fetchScore();

    const interval = setInterval(fetchScore, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleConfirm = () => {
    setIsAnimating(true);
    
    setTimeout(() => {
      const todayScore = getTodayTotalScore();
      const trend = detectCurrentTrend();

      finalizeToday(todayScore, trend);
      markTodayFinalized();

      setDayEnded(true);
      setConfirmMode(false);
      
      // Reset animation state
      setTimeout(() => {
        setIsAnimating(false);
      }, 500);
    }, 300);
  };

  // Get color for the current trend
  const trendColor = RHYTHM_COLORS[currentTrend as keyof typeof RHYTHM_COLORS] || RHYTHM_COLORS.stable;

  return (
    <div 
      className="rounded-xl overflow-hidden"
      style={{ 
        border: '1px solid rgba(0, 0, 0, 0.05)',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)'
      }}
    >
      {/* Top color bar */}
      <div 
        className="h-1.5 w-full"
        style={{ backgroundColor: trendColor }}
      />
      
      <div 
        className="p-6"
        style={{ 
          backgroundColor: 'rgba(255, 255, 255, 0.7)',
          backdropFilter: 'blur(8px)'
        }}
      >
        <div className="flex justify-between items-center mb-4">
          <h3 
            className="text-base font-medium" 
            style={{ color: '#333333' }}
          >
            Daily Completion
          </h3>
          
          <div 
            className="px-3 py-1.5 rounded-xl text-sm flex items-center gap-2"
            style={{ 
              backgroundColor: 'rgba(255, 255, 255, 0.8)',
              border: `1px solid ${trendColor}40`,
              boxShadow: '0 2px 4px rgba(0, 0, 0, 0.03)'
            }}
          >
            <div 
              className="w-2 h-2 rounded-full animate-pulse" 
              style={{ backgroundColor: trendColor }}
            />
            <span style={{ color: '#333333' }}>Score: <strong>{score.toFixed(1)} / 10</strong></span>
          </div>
        </div>

        {dayEnded ? (
          <div className="space-y-5">
            <div 
              className="p-4 rounded-xl border"
              style={{ 
                backgroundColor: 'rgba(255, 255, 255, 0.6)',
                borderColor: `${trendColor}40`,
                boxShadow: '0 2px 6px rgba(0, 0, 0, 0.03)'
              }}
            >
              <div className="flex items-center gap-3 mb-2">
                <div 
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ 
                    background: `linear-gradient(135deg, ${trendColor}80, ${trendColor})`,
                    boxShadow: `0 0 15px ${trendColor}40`
                  }}
                >
                  <span>✓</span>
                </div>
                <p 
                  className="text-base font-medium" 
                  style={{ color: '#333333' }}
                >
                  Day completed successfully!
                </p>
              </div>
              <p 
                className="text-sm ml-11" 
                style={{ color: '#666666' }}
              >
                Your rhythm patterns have been recorded and insights are ready.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
  <a
    href="/rhythm"
    className="px-4 py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all duration-200"
    style={{ 
      backgroundColor: '#F5E8C7', 
      color: '#333333',
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)',
      border: '1px solid rgba(0, 0, 0, 0.05)'
    }}
  >
    <span>🔄</span>
    <span>Next Day Check-in</span>
  </a>

  <a
    href="/digest"
    className="px-4 py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all duration-200"
    style={{ 
      background: `linear-gradient(135deg, #F5E8C7, ${trendColor}90)`,
      color: '#333333',
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)',
      border: '1px solid rgba(0, 0, 0, 0.05)'
    }}
  >
    <span>📊</span>
    <span>Weekly Insights</span>
  </a>
</div>

          </div>
        ) : confirmMode ? (
          <div className="space-y-5">
            <div 
              className="p-4 rounded-xl" 
              style={{ 
                backgroundColor: 'rgba(255, 255, 255, 0.6)',
                backdropFilter: 'blur(4px)',
                border: '1px solid rgba(0, 0, 0, 0.05)'
              }}
            >
              <p 
                className="text-sm" 
                style={{ color: '#333333' }}
              >
                This will:
              </p>
              <ul 
                className="text-sm mt-2 space-y-1 ml-5 list-disc" 
                style={{ color: '#666666' }}
              >
                <li>Save your daily rhythm score ({score.toFixed(1)} / 10)</li>
                <li>Record your feedback patterns</li>
                <li>Prepare tomorrow's training cues</li>
              </ul>
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={handleConfirm}
                className="flex-1 py-3 rounded-xl text-sm font-medium shadow-sm transition-all duration-200 flex items-center justify-center gap-2"
                style={{ 
                  background: `linear-gradient(135deg, #F5E8C7, ${trendColor})`,
                  color: '#333333',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.08)'
                }}
              >
                <span>✓</span>
                <span>Complete My Day</span>
              </button>
              
              <button
                onClick={() => setConfirmMode(false)}
                className="px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200"
                style={{ 
                  backgroundColor: 'rgba(0, 0, 0, 0.05)',
                  color: '#666666'
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <div className="text-center">
            <button
              onClick={() => setConfirmMode(true)}
              className="px-5 py-3 rounded-xl text-base font-medium shadow-sm transition-all duration-200 inline-flex items-center gap-2"
              style={{ 
                background: `linear-gradient(135deg, #F5E8C7, ${trendColor})`,
                color: '#333333',
                boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)'
              }}
            >
              <span>📝</span>
              <span>Complete Today's Journey</span>
            </button>
            
            <p 
              className="text-xs mt-3" 
              style={{ color: '#666666' }}
            >
              This will save your progress and prepare tomorrow's insights
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default EndMyDayButton;















