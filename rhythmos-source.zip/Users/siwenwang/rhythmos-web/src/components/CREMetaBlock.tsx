// ✅ 修复 CREMetaBlock 中 tone/persona 显示不一致的问题
import React, { useEffect, useState } from 'react';

// Type Definitions
export type RhythmTrend = 'collapsed' | 'wavy' | 'stable' | 'rising';
export type PersonaKey = 'rhea' | 'aurelia' | 'lucis' | 'niveus' | 'caelum';
export type ToneStyle = 'gentle' | 'directive' | 'rational' | 'visionary' | 'motivated';

// Color/Label Maps
const RHYTHM_COLORS: Record<RhythmTrend, string> = {
  collapsed: '#AEC6CF',
  wavy: '#C3B1E1',
  stable: '#C5D8A4',
  rising: '#FFB347'
};

const TREND_LABELS: Record<RhythmTrend, string> = {
  collapsed: '🧘‍♀️ Calm Reset',
  wavy: '🌊 Wavy Transitions',
  stable: '🌿 Stable Flow',
  rising: '🚀 Rising Momentum'
};

const TONE_TO_PERSONA: Record<ToneStyle, PersonaKey> = {
  gentle: 'rhea',
  directive: 'niveus',
  rational: 'aurelia',
  visionary: 'lucis',
  motivated: 'caelum'
};

const PERSONAS: Record<PersonaKey, {
  name: string;
  description: string;
  fontStyle: string;
  gradient: string;
  color: string;
  icon: string;
}> = {
  rhea: {
    name: 'Rhea', description: '温和、共情', fontStyle: 'Nunito, sans-serif',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)', color: '#F5CFCF', icon: '💗'
  },
  caelum: {
    name: 'Caelum', description: '指导性、自信', fontStyle: 'Inter, sans-serif',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)', color: '#4B6587', icon: '💠'
  },
  aurelia: {
    name: 'Aurelia', description: '理性、直觉', fontStyle: 'Inter, sans-serif',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)', color: '#D8A7CA', icon: '🧠'
  },
  niveus: {
    name: 'Niveus', description: '分析性、清晰', fontStyle: 'Inter, sans-serif',
    gradient: 'linear-gradient(135deg, #E8E8E8, #C7C7C7)', color: '#C7C7C7', icon: '📊'
  },
  lucis: {
    name: 'Lucis', description: '成长、平衡', fontStyle: 'Nunito, sans-serif',
    gradient: 'linear-gradient(135deg, #E8F5C7, #A4D8C5)', color: '#A4D8C5', icon: '🌱'
  }
};

// Guards
function isValidTrend(value: string): value is RhythmTrend {
  return ['collapsed', 'wavy', 'stable', 'rising'].includes(value);
}
function isValidPersona(value: string): value is PersonaKey {
  return ['rhea', 'aurelia', 'lucis', 'niveus', 'caelum'].includes(value);
}
function isValidTone(value: string): value is ToneStyle {
  return ['gentle', 'directive', 'rational', 'visionary', 'motivated'].includes(value);
}

// Props
interface CREMetaProps {
  cue?: string;
  paragraph?: string;
  persona?: string;
  tone?: string;
  rhythm?: string;
}

const CREMetaBlock: React.FC<CREMetaProps> = ({ cue = '', paragraph = '', persona, tone, rhythm }) => {
  const [preferredTone, setPreferredTone] = useState<ToneStyle>('gentle');

  useEffect(() => {
    const stored = localStorage.getItem('preferredTone');
    if (stored && isValidTone(stored)) {
      setPreferredTone(stored);
    }
  }, []);

  const usedTone: ToneStyle = tone && isValidTone(tone) ? tone : preferredTone;
  const derivedPersona = TONE_TO_PERSONA[usedTone];
  const finalPersona: PersonaKey = persona && isValidPersona(persona) ? persona : derivedPersona;

  const personaData = PERSONAS[finalPersona];
  const safeRhythm: RhythmTrend = rhythm && isValidTrend(rhythm) ? rhythm : 'wavy';
  const rhythmColor = RHYTHM_COLORS[safeRhythm];
  const trendLabel = TREND_LABELS[safeRhythm];

  return (
    <div className="rounded-xl overflow-hidden" style={{ border: '1px solid rgba(0,0,0,0.05)', boxShadow: '0 2px 10px rgba(0,0,0,0.03)' }}>
      <div className="h-1 w-full" style={{ backgroundColor: rhythmColor }} />
      <div className="p-6" style={{ backgroundColor: 'rgba(255,255,255,0.7)', backdropFilter: 'blur(8px)', fontFamily: personaData.fontStyle }}>
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center" style={{ background: personaData.gradient }}>
            <span>{personaData.icon}</span>
          </div>
          <div>
            <p className="text-lg font-medium mb-4" style={{ color: '#333' }}>
              " {cue}"
            </p>
            <p className="text-base mb-4" style={{ color: '#333' }}>{paragraph}</p>
            <div className="flex flex-wrap gap-2 mt-4">
              <div className="px-3 py-1 rounded-full text-xs inline-flex items-center gap-1" style={{ backgroundColor: rhythmColor, color: '#333', opacity: 0.8 }}>
                <span>{trendLabel.split(' ')[0]}</span>
                <span>{trendLabel.slice(2)}</span>
              </div>
              <div className="px-3 py-1 rounded-full text-xs" style={{ backgroundColor: 'rgba(0,0,0,0.05)', color: '#333' }}>{usedTone} tone</div>
              <div className="px-3 py-1 rounded-full text-xs" style={{ backgroundColor: personaData.color, color: '#333', opacity: 0.8 }}>{personaData.name}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CREMetaBlock;






