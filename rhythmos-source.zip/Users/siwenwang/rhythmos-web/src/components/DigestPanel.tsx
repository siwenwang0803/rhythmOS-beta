import React from 'react';
import GlobalOnboardingHint from './GlobalOnboardingHint';
import ToneDonutChart from './ToneDonutChart';
import DigestToneSummaryBlock from './DigestToneSummaryBlock';
import TagUnlockNotice from './TagUnlockNotice';
import DigestUnlockedTagsSummary from './DigestUnlockedTagsSummary';
import ReplayLastCueBlock from './ReplayLastCueBlock';
import WeeklyProgressSummary from './WeeklyProgressSummary';
import { getWeeklyUnlockedTags } from './TagUnlockNarrator';
import { getSignatureMap } from '../SignatureMap';
import { getDominantPersonaTone } from '../logic/getDominantPersonaTone';
import PersonaDriftTimeline from './PersonaDriftTimeline';
import PersonaBeliefTrendChart from '../components/PersonaBeliefTrendChart';
import DigestWeeklyHighlightBlock from './DigestWeeklyHighlightBlock';

interface DigestPanelProps {
  isDaytime?: boolean;
}

/**
 * DigestPanel - Enhanced Weekly Digest view
 * 
 * Provides a visually appealing weekly summary of the user's RhythmOS data,
 * including tone distribution, insights, and unlocked tags.
 */
const DigestPanel: React.FC<DigestPanelProps> = ({ isDaytime = true }) => {
  const unlocked = getWeeklyUnlockedTags();
  const signatureMap = getSignatureMap();
  const latestCue = signatureMap.cueFeedbackLog?.[signatureMap.cueFeedbackLog.length - 1];
  const dominant = getDominantPersonaTone();

  // RhythmOS theme colors based on UI spec and day/night mode
  const themeColors = {
    background: isDaytime ? '#F5E8C7' : '#2C2C2C', // Sand base / Dark mode bg
    panelBg: isDaytime ? '#FFFFFF' : '#3A3A3A',     // White / Dark panel bg
    text: isDaytime ? '#333333' : '#E0E0E0',        // Dark text / Light text
    textMuted: isDaytime ? '#777777' : '#AAAAAA',   // Muted text colors
    border: isDaytime ? '#E6E6E6' : '#555555',      // Light/dark borders
    shadow: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(0, 0, 0, 0.2)',
    cardBg: isDaytime ? 'rgba(245, 232, 199, 0.1)' : 'rgba(74, 85, 104, 0.1)',
  };

  // Get current date for header
  const now = new Date();
  const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const dateOptions: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric' };
  const dateRange = `${weekStart.toLocaleDateString('en-US', dateOptions)} - ${now.toLocaleDateString('en-US', dateOptions)}`;

  // Section divider component for consistent styling
  const SectionDivider = () => (
    <div 
      style={{ 
        height: '1px', 
        background: themeColors.border,
        margin: '24px 0'
      }}
    />
  );

  // Section header component for consistent styling
  const SectionHeader = ({ icon, title }: { icon: string, title: string }) => (
    <div 
      style={{ 
        display: 'flex', 
        alignItems: 'center', 
        gap: '8px',
        marginBottom: '16px'
      }}
    >
      <div style={{ 
        width: '32px', 
        height: '32px', 
        borderRadius: '50%', 
        backgroundColor: `${isDaytime ? '#F7DC6F30' : '#F7DC6F15'}`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}>
        <span style={{ fontSize: '18px' }}>{icon}</span>
      </div>
      <h2 
        style={{ 
          fontSize: '18px', 
          fontWeight: 600,
          color: themeColors.text,
          margin: 0
        }}
      >
        {title}
      </h2>
    </div>
  );

  // Card container component for consistent styling
  const CardContainer = ({ children }: { children: React.ReactNode }) => (
    <div 
      style={{
        backgroundColor: themeColors.cardBg,
        borderRadius: '12px',
        border: `1px solid ${themeColors.border}`,
        padding: '20px',
        marginBottom: '24px',
        boxShadow: `0 2px 8px ${themeColors.shadow}`
      }}
    >
      {children}
    </div>
  );

  return (
    <div style={{
      maxWidth: '900px',
      margin: '0 auto',
      padding: '0 16px'
    }}>
      <div 
        style={{
          backgroundColor: isDaytime ? '#fbf9f5' : '#242424',
          borderRadius: '12px',
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          overflow: 'hidden',
          boxShadow: `0 4px 16px ${themeColors.shadow}`,
          border: `1px solid ${themeColors.border}`,
          margin: '20px 0'
        }}
      >
        {/* Header with gradient background */}
        <div 
          style={{
            padding: '24px 32px',
            background: isDaytime ? 
              'linear-gradient(to right, #F5E8C7, #F5CFCF)' : // Sand to Rhea gradient
              'linear-gradient(to right, #2C2C2C, #3A3A3A)',   // Dark gradient
            position: 'relative',
            overflow: 'hidden'
          }}
        >
          {/* Decorative wave pattern */}
          <div 
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              opacity: 0.1,
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='20' viewBox='0 0 100 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M21.184 20c.357-.13.72-.264.888-.14 1.005-.174 1.837-.83 2.415-1.66.18-.456-1.67-.378-1.877-.072-.52.757-2.438 1.56-3.28 1.122-.42-.22 1.35-.635 1.255-1.104-.44-.204-1.686.212-2.42.862-.55.545-1.622.775-2.08 1.155-.45.33-.346.67-.077.946.268.386 1.622.54 1.87.176.304.057.62-.14.94-.215.887-.585 1.816-1.18 2.617-1.855 1.152-1.043 3.25-1.988 3.53-3.36.09-.21.21-.505.092-.677-.116-.167-1.336.358-1.478.372-.566-.058 1-.796.934-1.002-.1-.276-1.22-.168-1.364-.075-.443.382-1.37.886-1.997 1.33-.48.336-1.27.686-1.605 1.066-.243.273-.228.818.018 1.008.332.338 1.25.244 1.555-.218.14-.214.53-.98.55-1.067.3-.148.994-.6 1.17-.83.234-.304-.17-.588-.536-.45-1.013.383-1.835 1.204-2.63 1.868-.22.152-.587.306-.594.518-.21.255.323.402.553.382.118-.03.235-.066.36-.082.353-.044.675-.22.92-.518.214-.28.264-.673.5-.922.347-.286.71-.628 1.095-.875.13-.07.245-.235.218-.374-.35-.185-.877.06-1.076.17-.8.493-1.626.95-2.39 1.482-.56.394-1.064.948-1.644 1.284-.183.107-.385.18-.51.332-.262.327.15.667.506.612.404-.064.845-.536 1.26-.616.135-.01.256.105.308.212.08.173.038.41-.094.532-.066.062-.172.096-.233.177-.09.12-.027.287.063.348.353.193.788-.092 1.08-.332.343-.293.573-.678.85-1.016.606-.775 1.37-1.355 2.214-1.896.275-.18.618-.266.76-.566.022-.352-.683-.313-.913-.186-.565.318-1.142.627-1.623 1.057-.375.338-.82.636-1.163 1.022-.193.233-.308.53-.225.787.095.29.446.37.713.33.242-.194.505-.42.602-.7.16-.422.533-.92.703-1.163.214-.307.43-.57.7-.842.8-.81 1.678-1.525 2.62-2.156.583-.408 1.19-.787 1.854-1.053.254-.1.542-.145.76-.293.28-.202.297-.578.017-.796-.278-.195-.655-.055-.931.082-.286.157-.591.225-.85.403-.574.394-1.12.816-1.685 1.215-.755.535-1.53 1.043-2.354 1.482-.218.117-.42.124-.492.444l.001-.2c.017.142-.034.257.025.377.149.3.555.177.83.097.4-.12.846-.306 1.24-.506.538-.27 1.044-.594 1.562-.893.65-.378 1.348-.79 1.748-1.417.23-.36-.295-.591-.562-.406-.87.607-1.854 1.05-2.833 1.48-.13.055-.266.095-.394.153-.152.066-.307.176-.316.35.069.215.307.22.494.163.268-.083.54-.223.775-.368.473-.294.932-.638 1.366-.975.346-.278.83-.642.906-1.09.034-.21-.294-.293-.442-.18-.48.368-1.037.684-1.553 1.026-.318.21-.517.523-.75.796-.34.398-.72.765-1.145 1.082-.155.115-.282.314-.277.498.026.24.337.333.546.29.388-.09.655-.456 1.032-.565.125-.02.292.038.347.165.072.167-.083.35-.124.526.167.277.535.147.765.035.407-.201.813-.416 1.188-.656.408-.26.708-.678 1.083-.98l.012-.008z' fill='%23000000' fill-opacity='0.15' fill-rule='evenodd'/%3E%3C/svg%3E")`
            }}
          />

          <div style={{ position: 'relative', zIndex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h1 
                style={{ 
                  fontSize: '28px', 
                  fontWeight: 700, 
                  margin: 0, 
                  color: themeColors.text,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px'
                }}
              >
                <span>📘</span> Weekly Digest
              </h1>
              <div 
                style={{ 
                  fontSize: '14px', 
                  color: themeColors.textMuted,
                  backgroundColor: isDaytime ? 'rgba(255, 255, 255, 0.5)' : 'rgba(0, 0, 0, 0.2)',
                  padding: '4px 12px',
                  borderRadius: '16px'
                }}
              >
                {dateRange}
              </div>
            </div>
            <p 
              style={{ 
                fontSize: '16px', 
                color: themeColors.textMuted,
                margin: '8px 0 0 0'
              }}
            >
              Your tone trends, unlocked tags, and growth insights
            </p>
          </div>
        </div>

        {/* Main content */}
<div className="grid grid-cols-1 gap-6 md:grid-cols-[2fr_3fr]">
  {/* Tone Chart Section */}
  <CardContainer>
    <SectionHeader icon="🎯" title="Tone Distribution" />
    <div style={{ 
      display: 'flex', 
      flexDirection: 'column', 
      alignItems: 'center',
      marginBottom: '24px'
    }}>
      <div style={{ width: '100%', maxWidth: '240px', margin: '0 auto 16px' }}>
        <ToneDonutChart isDaytime={isDaytime} />
      </div>
      <DigestToneSummaryBlock isDaytime={isDaytime} />
    </div>
  </CardContainer>

  {/* Weekly Highlight Section */}
  <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
    <CardContainer>
      <SectionHeader icon="🗓️" title="Weekly Timeline" />
      <PersonaDriftTimeline />
    </CardContainer>

    <CardContainer>
      <SectionHeader icon="✨" title="This Week's Highlight" />
      <DigestWeeklyHighlightBlock />
    </CardContainer>
  </div>
</div>

<SectionDivider />

{/* Second Section: Trends & Insights */}


{/* Third Section: Progress Summary */}
<div>
  <CardContainer>
    <SectionHeader icon="📈" title="Weekly Progress" />
    <WeeklyProgressSummary isDaytime={isDaytime} />
  </CardContainer>
</div>

{/* Fourth Section: Latest Challenge */}
{latestCue && dominant && (
  <>
    <SectionDivider />
    <div>
      <CardContainer>
        <SectionHeader icon="🧩" title="Latest Identity Challenge" />
        <ReplayLastCueBlock
          cue={latestCue}
          persona={dominant.persona}
          feedback={latestCue.feedback}
          isDaytime={isDaytime}
        />
      </CardContainer>
    </div>
  </>
)}

{/* Fifth Section: Unlocked Tags */}
{unlocked.length > 0 && (
  <>
    <SectionDivider />
    <div>
      <CardContainer>
        <SectionHeader icon="🏷️" title="Tags You Unlocked" />
        <div style={{ marginBottom: '16px' }}>
          {unlocked.map(tagId => (
            <div key={tagId} style={{ marginBottom: '12px' }}>
              <TagUnlockNotice tagId={tagId} isDaytime={isDaytime} />
            </div>
          ))}
        </div>
        <DigestUnlockedTagsSummary tags={unlocked} isDaytime={isDaytime} />
      </CardContainer>
    </div>
  </>
)}

{/* Footer */}
<div 
  style={{
    padding: '16px 32px',
    borderTop: `1px solid ${themeColors.border}`,
    backgroundColor: isDaytime ? 'rgba(245, 232, 199, 0.1)' : 'rgba(58, 58, 58, 0.5)',
    textAlign: 'center'
  }}
>
  <p 
    style={{ 
      fontSize: '13px', 
      color: themeColors.textMuted,
      margin: 0
    }}
  >
    Your weekly digest is updated every Monday • RhythmOS (v2.2)
  </p>
</div>

      </div>
    </div>
  );
};

export default DigestPanel;

