import React from 'react';
import { getCurrentTrend } from '../utils/trendScore';

export const RhythmTrendHint: React.FC = () => {
  const trend = getCurrentTrend();

  const textMap: Record<string, string> = {
    collapsed: "You're in a low rhythm zone. Take it slow and support yourself.",
    stable: "You're in a steady rhythm. Keep flowing!",
    rising: "Your rhythm is picking up. Great momentum!",
    wavy: "You're in a mixed rhythm. Choose consistency."
  };

  return (
    <div className="mt-4 border border-blue-100 bg-blue-50 rounded p-3 text-sm text-blue-700">
      <p>
        🌡️ <strong>Current rhythm trend:</strong> {trend}
      </p>
      <p className="text-xs text-blue-600 mt-1 italic">
        {textMap[trend] || 'Rhythm data unavailable.'}
      </p>
    </div>
  );
};