import React from 'react'
import { GeneratedCRE } from '../types/cre'

const IdentityCuePreview: React.FC<{ cre: GeneratedCRE }> = ({ cre }) => {
  return (
    <div className="space-y-3">
      <p className="text-xl text-gray-800 italic">“{cre.cue}”</p>
      <p className="text-xs text-gray-500">
        🎭 Voice: <strong>{cre.persona}</strong> · Tone: <strong>{cre.tone}</strong>
      </p>
    </div>
  )
}

export default IdentityCuePreview
