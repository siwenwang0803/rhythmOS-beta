import React, { useMemo } from 'react';
import {
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  Tooltip
} from 'recharts';

interface SubtaskIntentSummaryViewProps {
  isDaytime?: boolean;
}

/**
 * SubtaskIntentSummaryView - Visualizes the distribution of subtask intent types
 * 
 * This component displays a radar chart showing the frequency of each
 * subtask intent type (minimal, light, normal, challenge) from the system log.
 * Follows the RhythmOS design specification with day/night mode support.
 */
const SubtaskIntentSummaryView: React.FC<SubtaskIntentSummaryViewProps> = ({ isDaytime = true }) => {
  // RhythmOS theme colors based on UI spec and day/night mode
  const themeColors = {
    background: isDaytime ? '#F5E8C7' : '#2C2C2C', // Sand base / Dark mode bg
    panelBg: isDaytime ? '#FFFFFF' : '#3A3A3A',     // White / Dark panel bg
    text: isDaytime ? '#333333' : '#E0E0E0',        // Dark text / Light text
    textMuted: isDaytime ? '#777777' : '#AAAAAA',   // Muted text colors
    border: isDaytime ? '#E6E6E6' : '#555555',      // Light/dark borders
    gridLines: isDaytime ? '#EEEEEE' : '#444444',   // Grid line colors
    shadow: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(0, 0, 0, 0.2)',
  };
  
  // RhythmOS state colors for intent types (from UI spec)
  const intentColors = {
    minimal: '#AEC6CF',  // Collapsed - gentle calming blue
    light: '#C3B1E1',    // Wavy - transitional lavender
    normal: '#C5D8A4',   // Stable - grounded light green
    challenge: '#FFB347', // Rising - activating orange-yellow
  };

  // Main fill color based on UI spec (with opacity for fill vs stroke)
  const mainColor = isDaytime ? '#4B6587' : '#D8A7CA'; // Caelum/Aurelia colors

  // Process the data
  const data = useMemo(() => {
    const raw = localStorage.getItem('subtaskIntentLog');
    const log = raw ? JSON.parse(raw) : [];

    const counts: Record<string, number> = {};

    for (const entry of log) {
      const type = entry.type || 'unknown';
      counts[type] = (counts[type] || 0) + 1;
    }
    
    // Define the intent types in logical progression order
    const types = ['minimal', 'light', 'normal', 'challenge'];
    
    // Create the data array with counts and colors
    return types.map((type) => ({
      type: type.charAt(0).toUpperCase() + type.slice(1), // Capitalize first letter
      count: counts[type] || 0,
      fill: intentColors[type as keyof typeof intentColors]
    }));
  }, []);

  // Custom tooltip component
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const dataItem = payload[0].payload;
      
      return (
        <div style={{ 
          backgroundColor: isDaytime ? 'rgba(255, 255, 255, 0.95)' : 'rgba(50, 50, 50, 0.95)',
          border: `1px solid ${themeColors.border}`,
          borderRadius: '8px',
          padding: '8px 12px',
          boxShadow: `0 2px 8px ${themeColors.shadow}`,
          color: themeColors.text,
          fontSize: '12px'
        }}>
          <div style={{ 
            display: 'flex',
            alignItems: 'center',
            marginBottom: '4px'
          }}>
            <span style={{ 
              display: 'inline-block',
              width: '8px',
              height: '8px',
              backgroundColor: dataItem.fill,
              marginRight: '6px',
              borderRadius: '2px'
            }}></span>
            <span style={{ fontWeight: 600 }}>{dataItem.type}</span>
          </div>
          <div style={{ marginLeft: '14px' }}>
            <span>Count: <strong>{dataItem.count}</strong></span>
          </div>
        </div>
      );
    }
    return null;
  };

  // Don't render anything if no data
  if (data.length === 0 || data.every(d => d.count === 0)) {
    return (
      <div 
        className="mt-6 p-4 rounded-xl"
        style={{
          backgroundColor: themeColors.panelBg,
          border: `1px solid ${themeColors.border}`,
          boxShadow: `0 2px 8px ${themeColors.shadow}`,
          color: themeColors.textMuted,
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
        }}
      >
        <h3 
          className="text-md font-semibold mb-2"
          style={{ color: themeColors.text }}
        >
          📡 Subtask Strategy Radar
        </h3>
        <p>No subtask data available yet.</p>
      </div>
    );
  }

  // Calculate the maximum value for the radius axis
  const maxCount = Math.max(...data.map(d => d.count), 1);
  
  // We want tick values to be integers and have a reasonable number of them
  const tickCount = Math.min(maxCount, 5);
  const ticks = Array.from({ length: tickCount + 1 }, (_, i) => 
    Math.round(i * maxCount / tickCount)
  );

  // Render the chart
  return (
    <div 
      className="mt-6 p-4 rounded-xl"
      style={{
        backgroundColor: themeColors.panelBg,
        border: `1px solid ${themeColors.border}`,
        boxShadow: `0 2px 8px ${themeColors.shadow}`,
        color: themeColors.text,
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }}
    >
      <h3 className="text-md font-semibold mb-3">📡 Subtask Strategy Radar</h3>
      <div className="animate-pulse-in">
        <ResponsiveContainer width="100%" height={300}>
          <RadarChart 
            cx="50%" 
            cy="50%" 
            outerRadius={90} 
            data={data}
          >
            <PolarGrid 
              stroke={themeColors.gridLines}
            />
            <PolarAngleAxis 
              dataKey="type" 
              tick={{ fill: themeColors.text, fontSize: 12 }}
              stroke={themeColors.gridLines}
            />
            <PolarRadiusAxis 
              angle={30} 
              domain={[0, maxCount]} 
              tickCount={tickCount}
              ticks={ticks}
              tick={{ fill: themeColors.textMuted, fontSize: 10 }}
              stroke={themeColors.textMuted}
              axisLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Radar
              name="Completed"
              dataKey="count"
              stroke={mainColor}
              fill={mainColor}
              fillOpacity={0.3}
              isAnimationActive={true}
              animationDuration={800}
              animationEasing="ease-out"
            />
          </RadarChart>
        </ResponsiveContainer>
      </div>
      
      <div className="flex flex-wrap justify-center gap-3 mt-3">
        {data.map((entry, index) => (
          <div 
            key={`legend-${index}`} 
            className="flex items-center text-xs"
            style={{ color: themeColors.text }}
          >
            <span style={{ 
              display: 'inline-block',
              width: '8px',
              height: '8px',
              backgroundColor: entry.fill,
              marginRight: '4px',
              borderRadius: '2px'
            }}></span>
            <span>{entry.type}: <strong>{entry.count}</strong></span>
          </div>
        ))}
      </div>
      
      <p 
        className="text-xs mt-3 text-center"
        style={{ color: themeColors.textMuted }}
      >
        Distribution of subtask intent types over time
      </p>
      
      {/* Add animation keyframes with a style tag */}
      <style>{`
        @keyframes pulseIn {
          0% {
            opacity: 0;
            transform: scale(0.96);
          }
          70% {
            opacity: 1;
            transform: scale(1.01);
          }
          100% {
            opacity: 1;
            transform: scale(1);
          }
        }
        
        .animate-pulse-in {
          animation: pulseIn 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }
      `}</style>
    </div>
  );
};

export default SubtaskIntentSummaryView;

