import React, { useState } from 'react';

interface ExportRhythmDataProps {
  isDaytime?: boolean;
}

/**
 * ExportRhythmData - Component for exporting RhythmOS data
 * 
 * This component provides a button to export selected RhythmOS data from localStorage
 * as a JSON file. Styled according to the RhythmOS design specification with day/night mode support.
 */
export const ExportRhythmData: React.FC<ExportRhythmDataProps> = ({ isDaytime = true }) => {
  const [isExporting, setIsExporting] = useState(false);
  
  // RhythmOS theme colors based on UI spec and day/night mode
  const themeColors = {
    background: isDaytime ? '#F5E8C7' : '#2C2C2C',  // Sand base / Dark mode bg
    panelBg: isDaytime ? '#FFFFFF' : '#3A3A3A',     // White / Dark panel bg
    text: isDaytime ? '#333333' : '#E0E0E0',        // Dark text / Light text
    textMuted: isDaytime ? '#777777' : '#AAAAAA',   // Muted text colors
    border: isDaytime ? '#E6E6E6' : '#555555',      // Light/dark borders
    shadow: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(0, 0, 0, 0.2)',
  };
  
  // Persona colors from UI spec (for button styling)
  const personaColors = {
    primary: isDaytime ? '#4B6587' : '#D8A7CA',  // Caelum / Aurelia colors
    hover: isDaytime ? '#3A5376' : '#C796B9',    // Slightly darker variants for hover
    accent: '#F7DC6F',                           // Soft yellow accent from UI spec
  };

  // Keys to export from localStorage
  const keysToExport = [
    'signatureFeedbackLog',
    'challengeLog',
    'rhythmScoreLog',
    'betaFeedbackLog',
    'preferredTone',
    'initPersona',
    'toneLog',                 // Added from other components
    'subtaskIntentLog',        // Added from other components
    'cueFeedbackLog',          // Added from other components
    'speakReplayLog'           // Added from other components
  ];

  const handleExport = () => {
    setIsExporting(true);
    
    // Add a small delay to show the loading state
    setTimeout(() => {
      try {
        const data: Record<string, any> = {};

        // Collect data from localStorage
        keysToExport.forEach((key) => {
          const value = localStorage.getItem(key);
          try {
            data[key] = JSON.parse(value || 'null');
          } catch {
            data[key] = value;
          }
        });

        // Add export metadata
        data._exportMeta = {
          timestamp: new Date().toISOString(),
          version: '1.0',
          platformInfo: navigator.userAgent
        };

        // Create and download the file
        const blob = new Blob([JSON.stringify(data, null, 2)], {
          type: 'application/json'
        });
        const url = URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = `rhythmOS_export_${new Date().toISOString().slice(0, 10)}.json`;
        a.click();
        URL.revokeObjectURL(url);
        
        setIsExporting(false);
      } catch (error) {
        console.error('Export failed:', error);
        setIsExporting(false);
      }
    }, 800); // Short delay for UI feedback
  };

  return (
    <div 
      className="mt-6 p-4 rounded-xl"
      style={{
        backgroundColor: themeColors.panelBg,
        border: `1px solid ${themeColors.border}`,
        boxShadow: `0 2px 8px ${themeColors.shadow}`,
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }}
    >
      

      
      
      <p 
        className="text-sm mb-3"
        style={{ color: themeColors.textMuted }}
      >
        Download a complete snapshot of your RhythmOS data, including feedback logs, challenge responses, 
        and personalization settings.
      </p>
      
      <button
        onClick={handleExport}
        disabled={isExporting}
        style={{
          backgroundColor: personaColors.primary,
          color: '#FFFFFF',
          border: 'none',
          borderRadius: '8px',
          padding: '10px 16px',
          fontSize: '14px',
          fontWeight: 500,
          cursor: isExporting ? 'default' : 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '8px',
          boxShadow: `0 2px 4px ${themeColors.shadow}`,
          transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
          transform: isExporting ? 'scale(0.98)' : 'scale(1)',
          opacity: isExporting ? 0.8 : 1,
          position: 'relative',
          overflow: 'hidden'
        }}
        onMouseEnter={(e) => {
          if (!isExporting) {
            e.currentTarget.style.backgroundColor = personaColors.hover;
          }
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = personaColors.primary;
        }}
      >
        {isExporting ? (
          <>
            <span className="loading-spinner"></span>
            <span>Preparing Export...</span>
          </>
        ) : (
          <>
            <span role="img" aria-label="Download">💾</span>
            <span>Download rhythmOS_export.json</span>
          </>
        )}
        
        {/* Add subtle glow effect when button is clicked */}
        {isExporting && (
          <div 
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: personaColors.accent,
              opacity: 0.1,
              animation: 'pulse 1.5s infinite'
            }}
          ></div>
        )}
      </button>
      
      <p 
        className="text-xs mt-3"
        style={{ color: themeColors.textMuted }}
      >
        This file contains your personal rhythm data and can be used for backup or analysis purposes.
      </p>
      
      {/* Add animation keyframes with a style tag */}
      <style>{`
        @keyframes pulse {
          0% {
            opacity: 0.1;
          }
          50% {
            opacity: 0.2;
          }
          100% {
            opacity: 0.1;
          }
        }
        
        .loading-spinner {
          display: inline-block;
          width: 16px;
          height: 16px;
          border: 2px solid rgba(255, 255, 255, 0.3);
          border-radius: 50%;
          border-top-color: white;
          animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }
      `}</style>
    </div>
  );
};

export default ExportRhythmData;
