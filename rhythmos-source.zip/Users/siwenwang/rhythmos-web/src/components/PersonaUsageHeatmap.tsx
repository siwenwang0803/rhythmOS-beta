import React, { useMemo, useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from 'recharts';

interface PersonaUsageHeatmapProps {
  isDaytime?: boolean; // Optional prop to control day/night mode
}

/**
 * 映射 tone → persona
 */
const toneToPersonaMap: Record<string, string> = {
  gentle: 'rhea',
  directive: 'niveus',
  motivated: 'caelum',
  rational: 'aurelia',
  visionary: 'lucis'
};

// Persona colors and gradients from the UI specification
const PERSONAS = {
  rhea: {
    color: '#F5CFCF',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #694647)',
    icon: '💗',
    title: 'Gentle, empathic'
  },
  aurelia: {
    color: '#D8A7CA',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #5A4555)',
    icon: '🧠',
    title: 'Rational, intuitive'
  },
  lucis: {
    color: '#A4D8C5',
    gradient: 'linear-gradient(135deg, #E8F5C7, #A4D8C5)',
    nightGradient: 'linear-gradient(135deg, #495D44, #456056)',
    icon: '🌱',
    title: 'Supportive, growth'
  },
  niveus: {
    color: '#C7C7C7',
    gradient: 'linear-gradient(135deg, #E8E8E8, #C7C7C7)',
    nightGradient: 'linear-gradient(135deg, #4A4A4A, #555555)',
    icon: '📊',
    title: 'Directive, balanced'
  },
  caelum: {
    color: '#4B6587',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    nightGradient: 'linear-gradient(135deg, #5D4E47, #2A3A4F)',
    icon: '💠',
    title: 'Directive, confident'
  }
};

/**
 * 判断是否在过去 N 天之内
 */
const isRecent = (timestamp: string, days = 7) => {
  const now = new Date();
  const ts = new Date(timestamp);
  return now.getTime() - ts.getTime() <= days * 24 * 60 * 60 * 1000;
};

// Enhanced tooltip component
const CustomTooltip = ({ active, payload, isDaytime }: any) => {
  if (active && payload && payload.length) {
    const persona = payload[0].payload.persona;
    const count = payload[0].value;
    const personaInfo = PERSONAS[persona as keyof typeof PERSONAS] || PERSONAS.niveus;
    
    return (
      <div 
        style={{ 
          backgroundColor: isDaytime ? 'rgba(255, 255, 255, 0.95)' : 'rgba(40, 38, 46, 0.95)',
          padding: '12px 16px',
          borderRadius: '12px',
          boxShadow: isDaytime 
            ? '0 4px 20px rgba(0, 0, 0, 0.1)'
            : '0 4px 20px rgba(0, 0, 0, 0.3)',
          border: `1px solid ${personaInfo.color}${isDaytime ? '40' : '60'}`,
          fontSize: '14px',
          color: isDaytime ? '#333' : '#e0e0e0'
        }}
      >
        <div style={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: '8px', 
          marginBottom: '8px',
          paddingBottom: '8px',
          borderBottom: isDaytime 
            ? '1px solid rgba(0, 0, 0, 0.05)'
            : '1px solid rgba(255, 255, 255, 0.1)'
        }}>
          <span style={{ fontSize: '18px' }}>{personaInfo.icon}</span>
          <span style={{ 
            fontWeight: 600, 
            color: isDaytime ? '#333' : '#fff',
            textTransform: 'capitalize'
          }}>{persona}</span>
        </div>
        
        <p style={{ 
          margin: 0, 
          fontSize: '13px', 
          color: isDaytime ? '#666' : '#aaa' 
        }}>
          {personaInfo.title}
        </p>
        
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginTop: '8px'
        }}>
          <span style={{ color: isDaytime ? '#666' : '#aaa' }}>Usage count:</span>
          <div style={{
            backgroundColor: isDaytime 
              ? `${personaInfo.color}20` 
              : 'rgba(255, 255, 255, 0.15)',
            padding: '3px 8px',
            borderRadius: '12px',
            fontWeight: 'bold',
            color: isDaytime ? '#333' : '#fff'
          }}>
            {count} {count === 1 ? 'time' : 'times'}
          </div>
        </div>
      </div>
    );
  }
  return null;
};

const PersonaUsageHeatmap: React.FC<PersonaUsageHeatmapProps> = ({ isDaytime = true }) => {
  const raw = localStorage.getItem('toneLog');
  const log = raw ? JSON.parse(raw) : [];
  const [hoveredBar, setHoveredBar] = useState<string | null>(null);
  const [isAnimated, setIsAnimated] = useState(false);
  
  // Animation effect
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsAnimated(true);
    }, 300);
    
    return () => clearTimeout(timer);
  }, []);
  
  // 根据日夜模式调整颜色
  const baseTextColor = isDaytime ? '#333333' : '#E0E0E0';
  const secondaryTextColor = isDaytime ? '#666666' : '#AAAAAA';
  const gridColor = isDaytime 
    ? 'rgba(103, 58, 183, 0.08)'
    : 'rgba(255, 255, 255, 0.08)';
  const axisColor = isDaytime 
    ? 'rgba(103, 58, 183, 0.2)'
    : 'rgba(255, 255, 255, 0.2)';
  const containerBg = isDaytime
    ? 'linear-gradient(135deg, rgba(245, 232, 199, 0.05), rgba(255, 255, 255, 0.9))'
    : 'linear-gradient(135deg, rgba(40, 38, 46, 0.9), rgba(50, 48, 58, 0.8))';
  const chartBg = isDaytime
    ? 'linear-gradient(135deg, rgba(245, 232, 199, 0.05), rgba(255, 255, 255, 0.7))'
    : 'linear-gradient(135deg, rgba(45, 43, 51, 0.7), rgba(60, 58, 68, 0.6))';

  const data = useMemo(() => {
    const countMap: Record<string, number> = {};

    const seen = new Set<string>();

    [...log].reverse().forEach((entry: any) => {
      if (!entry?.tone || !entry?.feedback || !entry?.timestamp) return;
      if (!['aligned', 'okay'].includes(entry.feedback)) return;
      if (!isRecent(entry.timestamp, 7)) return;

      const date = new Date(entry.timestamp);
      const key = `${entry.cueId}_${entry.tone}_${date.toISOString().slice(0, 10)}`;
      if (seen.has(key)) return;
      seen.add(key);

      const persona = toneToPersonaMap[entry.tone];
      if (!persona) return;

      countMap[persona] = (countMap[persona] || 0) + 1;
    });

    // Create data array with all possible personas
    const allPersonas = Object.keys(PERSONAS);
    const resultData = allPersonas.map(persona => ({
      persona,
      count: countMap[persona] || 0
    }));

    // Sort by usage count (descending)
    resultData.sort((a, b) => b.count - a.count);
    
    return resultData;
  }, [log]);

  // Generate gradients for bars
  const renderGradients = () => {
    return data.map((entry) => {
      const persona = entry.persona as keyof typeof PERSONAS;
      const personaInfo = PERSONAS[persona] || PERSONAS.niveus;
      
      return (
        <linearGradient 
          key={`gradient-${persona}`} 
          id={`gradient-${persona}`} 
          x1="0" 
          y1="0" 
          x2="0" 
          y2="1"
        >
          <stop 
            offset="0%" 
            stopColor={isDaytime ? personaInfo.color : personaInfo.color} 
            stopOpacity={isDaytime ? 0.9 : 0.8} 
          />
          <stop 
            offset="100%" 
            stopColor={isDaytime ? personaInfo.color : personaInfo.color} 
            stopOpacity={isDaytime ? 0.6 : 0.5} 
          />
        </linearGradient>
      );
    });
  };

  if (data.length === 0 || data.every(item => item.count === 0)) {
    return (
      <div 
        className="text-sm italic text-center py-16 rounded-xl border"
        style={{ 
          color: secondaryTextColor,
          borderColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)',
          backgroundColor: isDaytime ? 'rgba(255, 255, 255, 0.5)' : 'rgba(255, 255, 255, 0.03)',
          backdropFilter: 'blur(8px)'
        }}
      >
        <div className="flex flex-col items-center gap-3">
          <div 
            className="w-16 h-16 rounded-full flex items-center justify-center text-2xl"
            style={{ 
              background: isDaytime 
                ? 'linear-gradient(135deg, #f0f0f0, #e0e0e0)'
                : 'linear-gradient(135deg, #3a3a3a, #2a2a2a)',
              boxShadow: isDaytime
                ? '0 4px 15px rgba(0, 0, 0, 0.05)'
                : '0 4px 15px rgba(0, 0, 0, 0.2)'
            }}
          >
            📊
          </div>
          <p>No persona tone usage data yet.</p>
          <p className="text-xs opacity-75">Give feedback to see persona tone activity.</p>
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`mt-6 transform transition-all duration-700 ${
        isAnimated ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0'
      }`}
    >
      <div 
        style={{ 
          width: '100%', 
          borderRadius: '16px',
          overflow: 'hidden',
          background: containerBg,
          padding: '24px',
          boxShadow: isDaytime
            ? '0 8px 30px rgba(0, 0, 0, 0.07), inset 0 0 15px rgba(0, 0, 0, 0.02)'
            : '0 8px 30px rgba(0, 0, 0, 0.2), inset 0 0 15px rgba(255, 255, 255, 0.01)',
          border: isDaytime
            ? '1px solid rgba(0, 0, 0, 0.05)'
            : '1px solid rgba(255, 255, 255, 0.05)',
          backdropFilter: 'blur(10px)'
        }}
      >
        <div className="flex items-center gap-3 mb-5">
          <div 
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ 
              background: isDaytime
                ? 'rgba(0, 0, 0, 0.03)'
                : 'rgba(255, 255, 255, 0.05)'
            }}
          >
            <span className="text-lg">📊</span>
          </div>
          
          <div>
            <h3 
              className="text-lg font-medium"
              style={{ color: baseTextColor }}
            >
              Persona Tone Usage Heatmap
            </h3>
            <p 
              className="text-sm"
              style={{ color: secondaryTextColor }}
            >
              Based on aligned and okay feedback over the last 7 days
            </p>
          </div>
        </div>
        
        <div style={{ 
          background: chartBg,
          borderRadius: '12px',
          padding: '16px 5px',
          marginTop: '10px',
          border: isDaytime
            ? '1px solid rgba(0, 0, 0, 0.03)'
            : '1px solid rgba(255, 255, 255, 0.03)'
        }}>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart 
              data={data}
              margin={{ top: 20, right: 20, left: 10, bottom: 20 }}
              onMouseLeave={() => setHoveredBar(null)}
            >
              <defs>
                {renderGradients()}
              </defs>
              <CartesianGrid 
                strokeDasharray="3 3" 
                stroke={gridColor} 
                vertical={false} 
              />
              <XAxis 
                dataKey="persona" 
                tick={{ fontSize: 12, fill: secondaryTextColor }}
                tickLine={{ stroke: axisColor }}
                axisLine={{ stroke: axisColor, strokeWidth: 1 }}
              />
              <YAxis 
                tick={{ fontSize: 12, fill: secondaryTextColor }}
                tickLine={{ stroke: axisColor }}
                axisLine={{ stroke: axisColor, strokeWidth: 1 }}
                allowDecimals={false}
              />
              <Tooltip 
                content={(props) => <CustomTooltip {...props} isDaytime={isDaytime} />} 
                cursor={{ 
                  fill: isDaytime 
                    ? 'rgba(103, 58, 183, 0.05)' 
                    : 'rgba(255, 255, 255, 0.05)' 
                }} 
              />
              <Bar 
                dataKey="count" 
                radius={[6, 6, 0, 0]}
                onMouseEnter={(data) => setHoveredBar(data.persona)}
                animationDuration={1500}
                animationEasing="ease-in-out"
              >
                {data.map((entry, index) => {
                  const persona = entry.persona as keyof typeof PERSONAS;
                  const isHovered = hoveredBar === persona;
                  
                  return (
                    <Cell 
                      key={`cell-${index}`}
                      fill={`url(#gradient-${persona})`}
                      style={{
                        filter: isHovered 
                          ? isDaytime
                            ? 'brightness(1.1) drop-shadow(0 0 3px rgba(0,0,0,0.1))'
                            : 'brightness(1.2) drop-shadow(0 0 5px rgba(0,0,0,0.2))'
                          : 'none',
                        transition: 'filter 0.3s ease'
                      }}
                    />
                  );
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        {/* Usage insights - summary */}
        {data.some(d => d.count > 0) && (
          <div 
            className="mt-5 p-4 rounded-xl border"
            style={{
              borderColor: isDaytime 
                ? 'rgba(0, 0, 0, 0.05)' 
                : 'rgba(255, 255, 255, 0.05)',
              backgroundColor: isDaytime 
                ? 'rgba(255, 255, 255, 0.6)' 
                : 'rgba(255, 255, 255, 0.03)'
            }}
          >
            <p 
              className="text-sm"
              style={{ color: secondaryTextColor }}
            >
              <span className="font-medium" style={{ color: baseTextColor }}>Insight:</span> {' '}
              {data[0].count > 0 ? (
                <>Your dominant style is <b style={{ color: baseTextColor }}>{data[0].persona}</b> ({PERSONAS[data[0].persona as keyof typeof PERSONAS]?.title}).</>
              ) : (
                <>No dominant style detected yet. Continue providing feedback to develop your persona profile.</>
              )}
            </p>
          </div>
        )}
      </div>

      {/* Persona legend */}
      <div className="flex flex-wrap gap-3 justify-center mt-5" style={{ padding: '0 10px' }}>
        {Object.entries(PERSONAS).filter(([key]) => data.some(d => d.persona === key && d.count > 0)).map(([key, info]) => (
          <div 
            key={key}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs transition-all duration-200 hover:transform hover:scale-105"
            style={{ 
              backgroundColor: isDaytime
                ? `${info.color}30`
                : `${info.color}40`,
              color: baseTextColor,
              border: isDaytime
                ? `1px solid ${info.color}30`
                : `1px solid ${info.color}40`,
              cursor: 'pointer'
            }}
            onMouseEnter={() => setHoveredBar(key)}
            onMouseLeave={() => setHoveredBar(null)}
          >
            <span>{info.icon}</span>
            <span style={{ fontSize: '12px', textTransform: 'capitalize' }}>{key}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PersonaUsageHeatmap;