// 优化版 DigestWeeklyHighlightBlock
import React from 'react';
import { format, subDays } from 'date-fns';

interface CueEntry {
  cueId: string;
  cueText: string;
  tone: string;
  trend: 'collapsed' | 'wavy' | 'stable' | 'rising' | 'unknown';
  feedback: 'aligned' | 'okay' | 'notMe';
  timestamp: string;
  score?: number;
}

interface WeeklyHighlight {
  dateLabel: string;
  trend: string;
  cueText: string;
  score?: number;
  totalAligned: number;
  alignmentRate: number;
}

export const getWeeklyHighlight = (): WeeklyHighlight | null => {
  try {
    // 优先从 cueFeedbackLog 获取数据
    const raw = localStorage.getItem('cueFeedbackLog');
    if (!raw) return null;

    const log: CueEntry[] = JSON.parse(raw);
    const today = new Date();
    const sevenDaysAgo = subDays(today, 7);
    
    // 获取最近7天的所有反馈
    const recentEntries = log.filter(entry => {
      const time = new Date(entry.timestamp);
      return time >= sevenDaysAgo;
    });

    if (recentEntries.length === 0) return null;

    // 计算对齐率
    const alignedEntries = recentEntries.filter(entry => entry.feedback === 'aligned');
    const alignmentRate = Math.round((alignedEntries.length / recentEntries.length) * 100);

    if (alignedEntries.length === 0) return null;

    // 选择最佳高亮：
    // 1. 优先选择 collapsed/wavy 状态下的 aligned
    // 2. 其次选择评分最高的 aligned
    // 3. 最后选择最新的 aligned
    const bestHighlight = alignedEntries
      .sort((a, b) => {
        // 1. collapsed/wavy 状态优先
        const aIsSpecialState = a.trend === 'collapsed' || a.trend === 'wavy';
        const bIsSpecialState = b.trend === 'collapsed' || b.trend === 'wavy';
        if (aIsSpecialState && !bIsSpecialState) return -1;
        if (!aIsSpecialState && bIsSpecialState) return 1;
        
        // 2. 评分高的优先
        if (a.score && b.score) {
          if (a.score !== b.score) return b.score - a.score;
        }
        
        // 3. 时间新的优先
        return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
      })[0];

    return {
      dateLabel: format(new Date(bestHighlight.timestamp), 'EEEE'),
      trend: bestHighlight.trend === 'unknown' ? 'stable' : bestHighlight.trend,
      cueText: bestHighlight.cueText,
      score: bestHighlight.score,
      totalAligned: alignedEntries.length,
      alignmentRate
    };
  } catch (e) {
    console.warn('[getWeeklyHighlight] Error:', e);
    return null;
  }
};

const DigestWeeklyHighlightBlock: React.FC = () => {
  const highlight = getWeeklyHighlight();
  
  if (!highlight) {
    return (
      <div style={{ 
        padding: '20px', 
        borderRadius: '12px',
        backgroundColor: '#f8f9fa',
        border: '1px dashed #dee2e6',
        textAlign: 'center'
      }}>
        <div style={{ 
          fontSize: '16px',
          fontWeight: 600,
          marginBottom: '8px',
          color: '#495057',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '8px'
        }}>
          ✨ This Week's Highlight
        </div>
        <p style={{ 
          margin: 0, 
          fontSize: '14px', 
          color: '#6c757d',
          fontStyle: 'italic'
        }}>
          Complete your first identity cue feedback to see highlights here.
        </p>
      </div>
    );
  }

  const { dateLabel, trend, cueText, score, totalAligned, alignmentRate } = highlight;

  const trendIcons: Record<string, string> = {
    collapsed: '🧘‍♀️',
    wavy: '🌊',
    stable: '⚖️',
    rising: '🚀'
  };

  const trendColors: Record<string, string> = {
    collapsed: '#AEC6CF',
    wavy: '#C3B1E1',
    stable: '#C5D8A4',
    rising: '#FFB347'
  };

  const trendLabels: Record<string, string> = {
    collapsed: 'calm',
    wavy: 'transitional',
    stable: 'balanced',
    rising: 'energetic'
  };

  // 根据对齐率选择励志消息
  const getEncouragementMessage = (rate: number) => {
    if (rate >= 80) return "Exceptional self-awareness! 🌟";
    if (rate >= 60) return "Strong alignment with your values! 💪";
    if (rate >= 40) return "Building good self-reflection habits! 📈";
    return "Every aligned moment counts! 🌱";
  };

  return (
    <div style={{
      backgroundColor: '#ffffff',
      borderRadius: '16px',
      padding: '24px',
      border: '1px solid #e9ecef',
      boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* 装饰性渐变背景 */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: '4px',
        background: `linear-gradient(90deg, ${trendColors[trend]}60, ${trendColors[trend]})`
      }} />
      
      <div style={{
        fontSize: '18px',
        fontWeight: 700,
        marginBottom: '16px',
        color: '#212529',
        display: 'flex',
        alignItems: 'center',
        gap: '8px'
      }}>
        ✨ This Week's Highlight
        <span style={{
          fontSize: '12px',
          fontWeight: 500,
          color: '#6c757d',
          marginLeft: 'auto'
        }}>
          {alignmentRate}% aligned this week
        </span>
      </div>
      
      <div style={{
        backgroundColor: `${trendColors[trend]}20`,
        borderRadius: '12px',
        padding: '16px',
        marginBottom: '16px',
        border: `1px solid ${trendColors[trend]}30`
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          marginBottom: '8px'
        }}>
          <span style={{ fontSize: '20px' }}>
            {trendIcons[trend]}
          </span>
          <span style={{ 
            fontSize: '15px',
            color: '#495057',
            fontWeight: 500
          }}>
            On <strong>{dateLabel}</strong>, you were in a <strong>{trendLabels[trend]}</strong> state
          </span>
        </div>
        
        <p style={{
          margin: 0,
          fontSize: '14px',
          color: '#6c757d'
        }}>
          and still recognized a cue that aligned with your values.
        </p>
      </div>
      
      <div style={{
        backgroundColor: '#f8f9fa',
        borderRadius: '8px',
        padding: '12px',
        borderLeft: `4px solid ${trendColors[trend]}`,
        marginBottom: '16px'
      }}>
        <p style={{
          margin: 0,
          fontStyle: 'italic',
          color: '#495057',
          fontSize: '14px',
          lineHeight: '1.5'
        }}>
          "{cueText}"
        </p>
        {score && (
          <div style={{
            marginTop: '8px',
            fontSize: '12px',
            color: '#6c757d'
          }}>
            Resonance: {score === 1 ? 'Perfect' : score >= 0.8 ? 'Strong' : 'Good'} match
          </div>
        )}
      </div>

      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingTop: '12px',
        borderTop: '1px solid #e9ecef'
      }}>
        <span style={{
          fontSize: '13px',
          color: trendColors[trend],
          fontWeight: 600
        }}>
          {getEncouragementMessage(alignmentRate)}
        </span>
        
        <span style={{
          fontSize: '12px',
          color: '#6c757d'
        }}>
          {totalAligned} aligned moment{totalAligned !== 1 ? 's' : ''} this week
        </span>
      </div>
    </div>
  );
};

export default DigestWeeklyHighlightBlock;
