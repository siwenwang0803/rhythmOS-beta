import React from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import { CREGrowthLogEntry } from '../creGrowthLog'

const CREGrowthView: React.FC = () => {
  const raw = localStorage.getItem('creGrowthLog')
  const log: CREGrowthLogEntry[] = raw ? JSON.parse(raw) : []

  const data = log
    .filter((e) => e.score !== undefined)
    .sort((a, b) => a.timestamp - b.timestamp)
    .map((e) => ({
      time: new Date(e.timestamp).toLocaleDateString(),
      score: e.score
    }))

  if (data.length === 0) return null

  return (
    <div className="mt-8">
      <h3 className="text-md font-semibold mb-2">📈 CRE Growth History</h3>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={data}>
          <XAxis dataKey="time" tick={{ fontSize: 10 }} />
          <YAxis domain={[0, 5]} tickCount={6} />
          <Tooltip />
          <Line type="monotone" dataKey="score" stroke="#10b981" strokeWidth={2} dot={{ r: 2 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

export default CREGrowthView