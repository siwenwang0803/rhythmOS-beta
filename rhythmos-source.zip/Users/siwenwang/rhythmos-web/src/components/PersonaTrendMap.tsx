import React from 'react'
import { CREGrowthLogEntry } from '../creGrowthLog'

const personaLabels: Record<string, string> = {
  caelum: 'Caelum',
  lucis: 'Lucis',
  aurelia: 'Aurelia',
  niveus: 'Niveus',
  rhea: 'Rhea',
  auto: 'Auto'
}

const personaPathSuggestions: Record<string, string> = {
  aurelia: 'caelum',
  niveus: 'lucis',
  rhea: 'caelum',
  lucis: 'caelum',
  caelum: 'lucis',
  auto: 'caelum'
}

const PersonaTrendMap: React.FC = () => {
  const raw = localStorage.getItem('creGrowthLog')
  const log: CREGrowthLogEntry[] = raw ? JSON.parse(raw) : []

  const counts: Record<string, number> = {}
  log.forEach((entry) => {
    if (entry.context === 'persona') {
      const p = entry.persona || 'auto'
      counts[p] = (counts[p] || 0) + 1
    }
  })

  const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1])
  const top = sorted[0]?.[0] || 'auto'
  const suggestion = personaPathSuggestions[top] || 'caelum'

  return (
    <div className="mt-10 space-y-2">
      <h3 className="text-md font-semibold text-gray-800">🧠 Your Current Persona Rhythm</h3>

      <p className="text-sm text-blue-700">
        🎯 Most Used Persona: <strong>{personaLabels[top] || top}</strong>
      </p>

      <p className="text-sm text-gray-700">
        🛤️ Suggested Shift: <strong>{personaLabels[suggestion]}</strong>{' '}
        (to expand your rhythm toward {suggestion === 'caelum' ? 'decisiveness and vision' : 'energy and execution'})
      </p>

      <div className="text-xs text-gray-400 italic">
        Based on your recent cue adoption and training behaviors.
      </div>
    </div>
  )
}

export default PersonaTrendMap