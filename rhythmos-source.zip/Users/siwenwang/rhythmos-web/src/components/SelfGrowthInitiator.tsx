import React, { useState } from 'react'

const SelfGrowthInitiator: React.FC<{ onNext: (vision: string) => void }> = ({ onNext }) => {
  const [vision, setVision] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = () => {
    if (!vision.trim()) return
    setSubmitted(true)
    onNext(vision.trim())
  }

  return (
    <div className="max-w-xl mx-auto mt-10 space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">🌱 Start Your Growth Journey</h1>
      <p className="text-sm text-gray-600">
        Tell the system: What kind of person do you want to become?
      </p>
      <input
        type="text"
        value={vision}
        onChange={(e) => setVision(e.target.value)}
        className="w-full px-4 py-2 border rounded shadow-sm"
        placeholder="e.g. I want to be more confident and calm"
      />
      <button
        onClick={handleSubmit}
        className="px-5 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm"
      >
        🚀 Begin RhythmOS Training
      </button>
      {submitted && (
        <p className="text-sm text-green-700 italic">
          ✅ Vision saved: “{vision}” — your daily rhythm path will be built from this.
        </p>
      )}
    </div>
  )
}

export default SelfGrowthInitiator