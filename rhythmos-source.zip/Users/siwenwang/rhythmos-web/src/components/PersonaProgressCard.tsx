// /components/PersonaProgressCard.tsx - 完整修复版本

import React, { useState, useEffect } from 'react';
import { getXpData, getCurrentTitle } from '../utils/xpEngine';
import { getXpTracker, getTodayDateKey } from '../utils/xpDailyTracker';

// 根据RhythmOS UI规范使用的渐变映射
const personaGradientMap: Record<string, { start: string, end: string }> = {
  rhea: { start: '#F5E8C7', end: '#F5CFCF' },
  caelum: { start: '#F5E8C7', end: '#4B6587' },
  aurelia: { start: '#F5E8C7', end: '#D8A7CA' },
  lucis: { start: '#F5E8C7', end: '#F8C1CC' },
  niveus: { start: '#F5E8C7', end: '#DDEBCF' }
};

const maxXp = 150;

interface XpLogEntry {
  amount: number;
  timestamp: string;
  newValue?: number;
  oldValue?: number;
  note?: string;
}

interface DetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  persona: string;
  xp: number;
  gradient: { start: string; end: string };
}

// XP详情模态框组件
const XpDetailModal: React.FC<DetailModalProps> = ({ isOpen, onClose, persona, xp, gradient }) => {
  const [xpHistory, setXpHistory] = useState<XpLogEntry[]>([]);
  const [todayXpSources, setTodayXpSources] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isOpen) {
      loadXpDetails();
    }
  }, [isOpen, persona]);

  const loadXpDetails = () => {
    setLoading(true);
    try {
      // 获取persona的XP历史记录
      const xpData = getXpData();
      const personaData = xpData[persona] || { xp: 0, history: [] };
      const history = personaData.history || [];
      
      // 获取最近的XP记录（最多显示10条）
      const recentHistory = history.slice(-10).reverse();
      setXpHistory(recentHistory);

      // 获取今天的XP来源
      const tracker = getXpTracker();
      const today = getTodayDateKey();
      const todayData = tracker[today];
      
      const todaySources = [];
      
      if (todayData) {
        // 挑战XP
        if (todayData.challengeCount > 0) {
          todaySources.push({
            type: 'Challenge Completion',
            count: todayData.challengeCount,
            xpPerAction: 6,
            totalXp: todayData.challengeCount * 6,
            icon: '🏆',
            description: `Completed ${todayData.challengeCount}/2 daily challenges`
          });
        }

        // 微任务XP
        if (todayData.microtaskCount > 0) {
          todaySources.push({
            type: 'Microtask Completion',
            count: todayData.microtaskCount,
            xpPerAction: 2,
            totalXp: todayData.microtaskCount * 2,
            icon: '📝',
            description: `Completed ${todayData.microtaskCount}/3 daily microtasks`
          });
        }

        // XP日志中的其他来源
        if (todayData.xpLogs && todayData.xpLogs.length > 0) {
          const todayDate = new Date().toDateString();
          const todayLogs = todayData.xpLogs.filter((log: any) => 
            log.persona === persona && 
            new Date(log.timestamp).toDateString() === todayDate
          );

          todayLogs.forEach((log: any) => {
            if (log.source !== 'challenge_complete' && log.source !== 'microtask_complete') {
              todaySources.push({
                type: log.source || 'Other Activity',
                count: 1,
                xpPerAction: log.amount,
                totalXp: log.amount,
                icon: '✨',
                description: `${log.source || 'Activity'} completion`,
                timestamp: log.timestamp
              });
            }
          });
        }
      }

      setTodayXpSources(todaySources);
    } catch (error) {
      console.error('Error loading XP details:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (timestamp: string) => {
    try {
      return new Date(timestamp).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return 'Unknown time';
    }
  };

  const getXpSourceInfo = (entry: XpLogEntry) => {
    // 从历史记录中推断 XP 来源类型
    const amount = entry.amount;
    const note = entry.note?.toLowerCase() || '';
    
    // 检查 note 中的关键词或根据数值推断
    if (note.includes('challenge') || amount === 6) {
      return {
        type: 'Challenge',
        icon: '🏆',
        color: 'text-amber-600',
        bgColor: '#fef3c7',
        borderColor: '#fbbf24'
      };
    } else if (note.includes('microtask') || amount === 2) {
      return {
        type: 'Microtask',
        icon: '📝',
        color: 'text-blue-600',
        bgColor: '#dbeafe',
        borderColor: '#3b82f6'
      };
    } else if (note.includes('cue') || note.includes('feedback')) {
      return {
        type: 'Identity Cue',
        icon: '🧩',
        color: 'text-purple-600',
        bgColor: '#f3e8ff',
        borderColor: '#a855f7'
      };
    } else if (note.includes('speak') || note.includes('language')) {
      return {
        type: 'Language Reflection',
        icon: '🗣️',
        color: 'text-indigo-600',
        bgColor: '#e0e7ff',
        borderColor: '#6366f1'
      };
    } else if (note.includes('manual') || note.includes('adjustment')) {
      return {
        type: 'Manual Adjustment',
        icon: '⚙️',
        color: 'text-gray-600',
        bgColor: '#f9fafb',
        borderColor: '#6b7280'
      };
    } else {
      // 默认为其他活动
      return {
        type: 'Other Activity',
        icon: '✨',
        color: 'text-green-600',
        bgColor: '#f0fdf4',
        borderColor: '#22c55e'
      };
    }
  };

  const getTodayTotalXp = () => {
    return todayXpSources.reduce((total, source) => total + source.totalXp, 0);
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.6)' }}
      onClick={onClose}
    >
      <div 
        className="w-full max-w-lg rounded-xl shadow-2xl max-h-[80vh] overflow-hidden"
        style={{ 
          background: `linear-gradient(to bottom, #ffffff, ${gradient.end}20)`,
          border: `2px solid ${gradient.end}50`
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* 头部 */}
        <div 
          className="p-4 text-white"
          style={{ background: `linear-gradient(135deg, ${gradient.start}, ${gradient.end})` }}
        >
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-semibold capitalize">{persona}</h2>
              <p className="text-sm opacity-90">XP Progress Details</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">{xp}</div>
              <div className="text-xs opacity-90">/ {maxXp} XP</div>
            </div>
          </div>
        </div>

        {/* 内容区域 */}
        <div className="p-4 overflow-y-auto max-h-96">
          {loading ? (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
              <p className="mt-2 text-gray-600">Loading XP details...</p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* 今日XP来源 */}
              <div>
                <h3 className="text-lg font-medium mb-3 flex items-center">
                  <span className="mr-2">📊</span>
                  Today's XP Sources
                </h3>
                
                {todayXpSources.length > 0 ? (
                  <div className="space-y-4">
                    {/* 按类型分组显示 */}
                    {(() => {
                      const challengeSources = todayXpSources.filter(s => s.type.includes('Challenge'));
                      const microtaskSources = todayXpSources.filter(s => s.type.includes('Microtask'));
                      const otherSources = todayXpSources.filter(s => !s.type.includes('Challenge') && !s.type.includes('Microtask'));
                      
                      return (
                        <>
                          {/* 挑战类别 */}
                          {challengeSources.length > 0 && (
                            <div className="mb-4">
                              <h4 className="text-md font-medium mb-2 flex items-center text-gray-700">
                                <span className="mr-2">🏆</span>
                                Challenges
                              </h4>
                              <div className="space-y-2">
                                {challengeSources.map((source, index) => (
                                  <div 
                                    key={`challenge-${index}`}
                                    className="flex justify-between items-center p-3 rounded-lg"
                                    style={{ backgroundColor: '#fef3c7', border: '1px solid #fbbf24' }}
                                  >
                                    <div className="flex items-center">
                                      <span className="text-lg mr-3">{source.icon}</span>
                                      <div>
                                        <div className="text-sm font-medium">{source.type}</div>
                                        <div className="text-xs text-gray-600">{source.description}</div>
                                      </div>
                                    </div>
                                    <div className="text-right">
                                      <div className="text-sm font-semibold text-amber-600">
                                        +{source.totalXp} XP
                                      </div>
                                      <div className="text-xs text-gray-500">
                                        {source.count} × {source.xpPerAction}
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* 微任务类别 */}
                          {microtaskSources.length > 0 && (
                            <div className="mb-4">
                              <h4 className="text-md font-medium mb-2 flex items-center text-gray-700">
                                <span className="mr-2">📝</span>
                                Microtasks
                              </h4>
                              <div className="space-y-2">
                                {microtaskSources.map((source, index) => (
                                  <div 
                                    key={`microtask-${index}`}
                                    className="flex justify-between items-center p-3 rounded-lg"
                                    style={{ backgroundColor: '#dbeafe', border: '1px solid #3b82f6' }}
                                  >
                                    <div className="flex items-center">
                                      <span className="text-lg mr-3">{source.icon}</span>
                                      <div>
                                        <div className="text-sm font-medium">{source.type}</div>
                                        <div className="text-xs text-gray-600">{source.description}</div>
                                      </div>
                                    </div>
                                    <div className="text-right">
                                      <div className="text-sm font-semibold text-blue-600">
                                        +{source.totalXp} XP
                                      </div>
                                      <div className="text-xs text-gray-500">
                                        {source.count} × {source.xpPerAction}
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* 其他活动类别 */}
                          {otherSources.length > 0 && (
                            <div className="mb-4">
                              <h4 className="text-md font-medium mb-2 flex items-center text-gray-700">
                                <span className="mr-2">✨</span>
                                Other Activities
                              </h4>
                              <div className="space-y-2">
                                {otherSources.map((source, index) => (
                                  <div 
                                    key={`other-${index}`}
                                    className="flex justify-between items-center p-3 rounded-lg"
                                    style={{ backgroundColor: '#f0fdf4', border: '1px solid #22c55e' }}
                                  >
                                    <div className="flex items-center">
                                      <span className="text-lg mr-3">{source.icon}</span>
                                      <div>
                                        <div className="text-sm font-medium">{source.type}</div>
                                        <div className="text-xs text-gray-600">{source.description}</div>
                                        {source.timestamp && (
                                          <div className="text-xs text-gray-500 mt-1">
                                            {formatDate(source.timestamp)}
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                    <div className="text-right">
                                      <div className="text-sm font-semibold text-green-600">
                                        +{source.totalXp} XP
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </>
                      );
                    })()}
                    
                    {/* 今日总计 */}
                    <div 
                      className="p-3 rounded-lg mt-4 text-center border-2"
                      style={{ 
                        backgroundColor: `${gradient.end}20`, 
                        borderColor: `${gradient.end}50`
                      }}
                    >
                      <span className="text-lg font-semibold">
                        🎯 Today's Total: <span style={{ color: gradient.end }}>+{getTodayTotalXp()} XP</span>
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    <span className="text-3xl block mb-2">🌱</span>
                    <p className="text-sm">No XP earned today yet</p>
                    <p className="text-xs mt-1">Complete challenges and activities to earn XP!</p>
                  </div>
                )}
              </div>

              {/* XP历史记录 */}
              <div className="border-t pt-4">
                <h3 className="text-lg font-medium mb-3 flex items-center">
                  <span className="mr-2">📈</span>
                  Recent XP History
                </h3>
                
                {xpHistory.length > 0 ? (
                  <div className="space-y-2">
                    {xpHistory.map((entry, index) => {
                      const sourceInfo = getXpSourceInfo(entry);
                      return (
                        <div 
                          key={index}
                          className="flex justify-between items-center p-3 rounded-lg border"
                          style={{ 
                            backgroundColor: entry.amount > 0 ? sourceInfo.bgColor : '#fef2f2',
                            borderColor: entry.amount > 0 ? sourceInfo.borderColor : '#ef4444'
                          }}
                        >
                          <div className="flex items-start gap-3">
                            <div className="flex items-center gap-2">
                              <span className="text-lg">{entry.amount > 0 ? sourceInfo.icon : '📉'}</span>
                              {entry.amount > 0 && (
                                <span className={`text-xs px-2 py-1 rounded-full ${sourceInfo.color} font-medium`}
                                      style={{ backgroundColor: 'rgba(255, 255, 255, 0.7)' }}>
                                  {sourceInfo.type}
                                </span>
                              )}
                            </div>
                            <div>
                              <div className="text-sm flex items-center">
                                <span className={entry.amount > 0 ? sourceInfo.color + ' font-semibold' : 'text-red-600 font-semibold'}>
                                  {entry.amount > 0 ? '+' : ''}{entry.amount} XP
                                </span>
                              </div>
                              <div className="text-xs text-gray-500 mt-1">
                                {formatDate(entry.timestamp)}
                              </div>
                              {entry.note && (
                                <div className="text-xs text-gray-600 mt-1 font-medium">
                                  {entry.note}
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm text-gray-700 font-semibold">
                              {entry.newValue || 0} XP
                            </div>
                            <div className="text-xs text-gray-500">Total</div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-4 text-gray-500">
                    <p className="text-sm">No XP history available</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* 底部关闭按钮 */}
        <div className="p-4 border-t" style={{ backgroundColor: '#ffffff' }}>
          <button
            onClick={onClose}
            className="w-full py-3 px-4 rounded-lg font-medium transition-all duration-200"
            style={{ 
              backgroundColor: `${gradient.end}20`,
              color: gradient.end,
              border: `2px solid ${gradient.end}40`
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = `${gradient.end}30`;
              e.currentTarget.style.transform = 'translateY(-1px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = `${gradient.end}20`;
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

// 主组件
const PersonaProgressCard: React.FC<{ persona: string }> = ({ persona }) => {
  const [xp, setXp] = useState(0);
  const [title, setTitle] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [showDetail, setShowDetail] = useState(false);

  const updateXpData = () => {
    setIsLoading(true);
    try {
      const xpData = getXpData();
      const currentXp = xpData?.[persona]?.xp || 0;
      setXp(currentXp);
      setTitle(getCurrentTitle(persona, currentXp));
    } catch (error) {
      console.error('获取XP数据时出错:', error);
      setXp(0);
      setTitle(getCurrentTitle(persona, 0));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    updateXpData();

    const handleXpUpdate = () => {
      updateXpData();
    };

    window.addEventListener('xp-updated', handleXpUpdate);
    const refreshInterval = setInterval(updateXpData, 30000);

    return () => {
      window.removeEventListener('xp-updated', handleXpUpdate);
      clearInterval(refreshInterval);
    };
  }, [persona]);

  const percent = Math.min(100, (xp / maxXp) * 100);
  const gradient = personaGradientMap[persona] || { start: '#F5E8C7', end: '#CCCCCC' };

  const activePersona = localStorage.getItem('initPersona') || 'rhea';
  const isActive = persona === activePersona;

  const getCardStyle = () => {
    return isActive
      ? {
          background: `linear-gradient(to bottom right, white 80%, ${gradient.end}15)`,
          borderLeft: `4px solid ${gradient.end}`,
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.07)'
        }
      : {
          background: 'white',
          borderLeft: xp > 0 ? `4px solid ${gradient.end}` : '4px solid transparent'
        };
  };

  const getProgressBarColor = () => {
    return `linear-gradient(to right, ${gradient.start}${xp === 0 ? '40' : ''}, ${gradient.end}${xp === 0 ? '40' : ''})`;
  };

  const handleManualRefresh = () => {
    updateXpData();
  };

  return (
    <>
      <div className="rounded-lg shadow-sm transition-all duration-300 hover:shadow p-4" style={getCardStyle()}>
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="text-lg font-medium text-[#333333] capitalize">{persona}</h3>
            <div className="text-sm text-[#333333]/70 mt-1">{title}</div>
          </div>

          <div className="flex items-center gap-2">
            {isActive && (
              <div className="bg-[#F7DC6F]/20 text-xs px-2 py-1 rounded-full text-[#333333]/80">Active</div>
            )}
            
            {/* 详情按钮 */}
            <button
              onClick={() => setShowDetail(true)}
              className="text-xs px-3 py-1 rounded-lg font-medium transition-all duration-200 flex items-center gap-1"
              style={{
                backgroundColor: `${gradient.end}15`,
                color: gradient.end,
                border: `1px solid ${gradient.end}30`
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = `${gradient.end}25`;
                e.currentTarget.style.transform = 'translateY(-1px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = `${gradient.end}15`;
                e.currentTarget.style.transform = 'translateY(0)';
              }}
              title="View XP details and earning history"
            >
              <span>📊</span>
              <span>Details</span>
            </button>
          </div>
        </div>

        <div className="mt-4">
          <div className="relative w-full h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="absolute top-0 left-0 h-full rounded-full transition-all duration-700 ease-out"
              style={{
                width: xp === 0 ? '100%' : `${percent}%`,
                background: getProgressBarColor(),
                opacity: xp === 0 ? 0.3 : 1
              }}
            />

            {percent > 0 && (
              <div
                className="absolute top-0 left-0 h-1/2 rounded-full opacity-30 bg-white"
                style={{ width: `${percent}%` }}
              />
            )}
          </div>

          <div className="flex justify-between mt-1">
            <div
              className="text-xs text-blue-500 cursor-pointer hover:underline flex items-center"
              onClick={handleManualRefresh}
              title="点击刷新XP数据"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path
                  fillRule="evenodd"
                  d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z"
                  clipRule="evenodd"
                />
              </svg>
              {isLoading && <span className="animate-pulse">•</span>}
            </div>
            <div className="text-xs text-[#333333]/70">{xp} XP / {maxXp}</div>
          </div>
        </div>
      </div>

      {/* XP详情模态框 */}
      <XpDetailModal
        isOpen={showDetail}
        onClose={() => setShowDetail(false)}
        persona={persona}
        xp={xp}
        gradient={gradient}
      />
    </>
  );
};

export default PersonaProgressCard;

