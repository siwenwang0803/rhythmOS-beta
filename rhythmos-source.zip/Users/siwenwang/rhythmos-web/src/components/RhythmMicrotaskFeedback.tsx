import React, { useState, useEffect } from 'react';
import RhythmButton from './ui/RhythmButton';
import { writeRhythmScore } from '../utils/rhythmscoreEngine';
import { updateMicrotaskLog } from '../utils/updateMicrotaskLog';
import { signatureMap } from '../SignatureMap';
import { addXp } from '../utils/xpEngine';
import { getXpTracker, saveXpTracker, getTodayDateKey } from '../utils/xpDailyTracker';
import { microtaskInsightToneMap } from '../data/microtaskInsightToneMap';

type RhythmTrend = 'collapsed' | 'wavy' | 'stable' | 'rising';

interface Props {
  currentTrend: RhythmTrend | null;
}

const rhythmColors = {
  sand: '#F5E8C7',
  collapsed: '#AEC6CF',
  wavy: '#C3B1E1',
  stable: '#C5D8A4',
  rising: '#FFB347',
  accent: '#F7DC6F'
};

const trendIcons = {
  collapsed: '🫥',
  wavy: '🌊',
  stable: '⚖️',
  rising: '🔥'
};

const microtasks: Record<RhythmTrend, string[]> = {
  collapsed: [
    'Write one line about how you feel right now.',
    'Put your phone away for 5 minutes.',
    'Do a 30-second breath reset.',
    'Walk to another room and back.',
    'List one thing you survived today.',
    'Sit still for 1 minute, nothing else.',
    'Say to yourself: "I\'m not behind. I\'m beginning."'
  ],
  wavy: [
    'Set a 10-minute timer and focus on anything.',
    'Write one sentence you\'ve been avoiding.',
    'Clean a small corner of your desk.',
    'Reply to one message that\'s on your mind.',
    'Do one "medium energy" thing, no perfection.',
    'Step outside, even for 30 seconds.',
    'Choose one tab to close and actually close it.'
  ],
  stable: [
    'Start a 15–25 minute task block.',
    'Sort one thing in your workspace.',
    'Create a short checklist for today.',
    'Do one task exactly as planned.',
    'Declutter 3 items from your phone/files.',
    'Review your week rhythm briefly.',
    'Identify one goal you\'re steadily progressing.'
  ],
  rising: [
    'Commit to a 30-minute power block.',
    'Send one bold message or proposal.',
    'Sketch out a plan for a bigger goal.',
    'Batch 3 similar tasks and execute.',
    'Record a voice memo of your current vision.',
    'Move without hesitation — start the task.',
    'Take action on something you\'ve been "thinking about."'
  ]
};

export const RhythmMicrotaskFeedback: React.FC<Props> = ({ currentTrend }) => {
  const [completed, setCompleted] = useState(false);
  const [selectedTask, setSelectedTask] = useState<string>('');
  const [isAnimating, setIsAnimating] = useState(false);
  const [showAllTasks, setShowAllTasks] = useState(false);
  const [xpAwarded, setXpAwarded] = useState(false);
  const [insightText, setInsightText] = useState('');

  const getTasks = () => {
    if (!currentTrend) return microtasks.wavy;
    return microtasks[currentTrend];
  };

  useEffect(() => {
    if (currentTrend) {
      const tasks = microtasks[currentTrend];
      const randomIndex = Math.floor(Math.random() * tasks.length);
      setSelectedTask(tasks[randomIndex]);
      setCompleted(false);
      setXpAwarded(false);
      setInsightText('');
    }
  }, [currentTrend]);

  const handleComplete = () => {
    const today = getTodayDateKey();
    const tracker = getXpTracker();
    if (!tracker[today]) tracker[today] = {};
    const count = tracker[today].microtaskCount || 0;

    if (count >= 4) {
      alert('🟡 You’ve already completed 4 microtasks today. Great job!');
      return;
    }

    setIsAnimating(true);
    setTimeout(() => {
      writeRhythmScore(0.5, 'microtask');
      updateMicrotaskLog('microtask');
      tracker[today].microtaskCount = count + 1;
      saveXpTracker(tracker);

      const persona = localStorage.getItem('initPersona') || 'rhea';
      addXp(persona, 2);
      setCompleted(true);
      setXpAwarded(true);
      setIsAnimating(false);

      const tone = localStorage.getItem('preferredTone') || 'balanced';
      const trend = currentTrend || 'wavy';
      const key = `${trend}_${tone}`;
      const insight = microtaskInsightToneMap[key] || 'This small action is building your rhythm.';
      setInsightText(insight);
    }, 600);
  };

  const handleSelectTask = (task: string) => {
    setSelectedTask(task);
    setShowAllTasks(false);
    setCompleted(false);
    setXpAwarded(false);
    setInsightText('');
  };

  const getTrendColor = () => {
    if (!currentTrend) return rhythmColors.sand;
    return rhythmColors[currentTrend];
  };

  return (
    <div className="flex flex-col gap-3">
      <div 
        className="p-4 rounded-lg border transition-all duration-300"
        style={{ 
          borderColor: getTrendColor(),
          backgroundColor: `${getTrendColor()}15`,
          borderLeftWidth: '4px',
          transform: isAnimating ? 'scale(1.02)' : 'scale(1)',
        }}
      >
        <div className="flex items-start gap-3">
          <div 
            className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center mt-0.5"
            style={{ backgroundColor: getTrendColor() }}
          >
            <span className="text-sm">{currentTrend ? trendIcons[currentTrend] : '🎯'}</span>
          </div>
          <div className="flex-1">
            <p className="text-base text-gray-800 font-medium mb-2">{selectedTask}</p>
            <div className="flex justify-between items-center flex-wrap gap-2">
              {!completed ? (
                <RhythmButton 
                  onClick={handleComplete} 
                  variant="primary"
                  tone={currentTrend as any}
                  style={{ padding: '8px 16px', fontSize: '14px' }}
                >
                  <span className="flex items-center gap-1.5">
                    <span>✅</span>
                    <span>I did this</span>
                  </span>
                </RhythmButton>
              ) : (
                <div 
                  className="flex items-center gap-2 px-3 py-1.5 rounded-md"
                  style={{ backgroundColor: `${rhythmColors.stable}30`, color: '#333333' }}
                >
                  <span className="text-base">✅</span>
                  <span className="text-sm font-medium">Completed</span>
                </div>
              )}
              <button
                onClick={() => setShowAllTasks(!showAllTasks)}
                className="text-sm px-3 py-1.5 rounded-md transition-colors duration-200"
                style={{ backgroundColor: 'rgba(0, 0, 0, 0.05)', color: '#666666' }}
              >
                <span className="flex items-center gap-1.5">
                  <span>{showAllTasks ? '▲' : '▼'}</span>
                  <span>{showAllTasks ? 'Hide options' : 'More options'}</span>
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {showAllTasks && (
        <div className="mt-1 bg-white bg-opacity-95 rounded-lg border border-gray-100 p-3 overflow-hidden transition-all duration-300"
             style={{ maxHeight: showAllTasks ? '300px' : '0', opacity: showAllTasks ? 1 : 0 }}>
          <p className="text-xs text-gray-500 mb-2">Choose another microtask that feels right for you:</p>
          <div className="space-y-2 mt-3">
            {getTasks().map((task, index) => (
              task !== selectedTask && (
                <button
                  key={index}
                  onClick={() => handleSelectTask(task)}
                  className="text-left w-full px-3 py-2 rounded-md text-sm hover:bg-gray-50 transition-colors duration-200 flex items-start gap-2"
                >
                  <span className="text-xs mt-0.5 text-gray-400">→</span>
                  <span className="text-gray-700">{task}</span>
                </button>
              )
            ))}
          </div>
        </div>
      )}

      {xpAwarded && (
        <div className="mt-1 text-sm text-gray-600 flex items-center gap-2 animate-fadeIn"
             style={{ animation: 'fadeIn 0.5s ease-out' }}>
          <style>
            {`@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }`}
          </style>
          <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded">+2 XP</span>
          <span>{insightText}</span>
        </div>
      )}
    </div>
  );
};

export default RhythmMicrotaskFeedback;





