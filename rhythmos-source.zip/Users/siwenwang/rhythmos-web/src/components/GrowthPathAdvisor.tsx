// 修改的 GrowthPathAdvisor.tsx - 添加单个挑战刷新功能

import React, { useEffect, useState } from 'react';
import { getTodayDate, hasTodayStarted, detectCurrentTrend } from '../utils/rhythmDayEngine';
import { writeRhythmScore } from '../utils/writeRhythmScore';
import { identityAnchoringChallenges, IdentityAnchoringChallenge } from '../data/identityAnchoringChallenges_v2';
import IdentityChallengeCard from './IdentityChallengeCard';
import { useSignatureLogger } from '../hooks/useSignatureLogger';
import { canLogChallenge, logChallengeXp, checkAndRepairTracker } from '../utils/xpDailyTracker';
import { addXp, getXpData, getCurrentTitle, forceRefreshAllXpData } from '../utils/xpEngine';

interface GrowthPathAdvisorProps {
  currentTrend?: 'collapsed' | 'wavy' | 'stable' | 'rising';
}

const GrowthPathAdvisor: React.FC<GrowthPathAdvisorProps> = ({ currentTrend }) => {
  const today = getTodayDate();
  
  const [activePersona, setActivePersona] = useState(localStorage.getItem('initPersona') || 'rhea');
  
  const { logChallengeEntry } = useSignatureLogger();
  const [personaXp, setPersonaXp] = useState(0);
  const [personaTitle, setPersonaTitle] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // 挑战列表基于 activePersona
  const fullList = identityAnchoringChallenges[activePersona.toLowerCase()] || identityAnchoringChallenges['rhea'];

  const [challenges, setChallenges] = useState<IdentityAnchoringChallenge[]>([]);
  const [completed, setCompleted] = useState<string[]>([]);
  const [feedbacks, setFeedbacks] = useState<Record<string, string>>({});
  const [challengeCount, setChallengeCount] = useState<number>(0);
  
  // 组件初始化时检查和修复数据
  useEffect(() => {
    forceRefreshAllXpData();
    checkAndRepairTracker();
    
    console.log(`GrowthPathAdvisor初始化: activePersona=${activePersona}`);
    
    // 确保 SignatureMap 初始化
    if (typeof window !== 'undefined' && !window.signatureMap) {
      console.log('初始化 SignatureMap...');
      try {
        window.signatureMap = {
          cueSeenCount: {},
          toneLog: [],
          cueFeedbackLog: [],
          trendHistory: [],
          challengeLog: [],
          personaAnchor: activePersona,
          microtaskCount: 0,
          microtaskLog: [],
          meta: {
            createdAt: new Date().toISOString(),
            lastUpdated: new Date().toISOString(),
            sessions: 0,
            speakReplayLog: [],
          },
        };
        console.log('SignatureMap 初始化完成');
      } catch (error) {
        console.error('SignatureMap 初始化失败:', error);
      }
    }
  }, []);
    
  // 监听身份变化
  useEffect(() => {
    const handlePersonaChange = () => {
      const newPersona = localStorage.getItem('initPersona') || 'rhea';
      if (newPersona !== activePersona) {
        console.log('GrowthPathAdvisor - 检测到activePersona变化:', newPersona);
        setActivePersona(newPersona);
      }
    };
        
    handlePersonaChange();
    window.addEventListener('persona-changed', handlePersonaChange);
    return () => {
      window.removeEventListener('persona-changed', handlePersonaChange);
    };
  }, [activePersona]);
    
  // 监听XP更新
  useEffect(() => {
    const updateXpData = () => {
      setIsLoading(true);
      try {
        const rawData = localStorage.getItem('personaXpLog');
        const xpData = rawData ? JSON.parse(rawData) : {};
        const xp = xpData[activePersona]?.xp || 0;
        console.log(`GrowthPathAdvisor - ${activePersona}的XP值:`, xp);
        setPersonaXp(xp);
        setPersonaTitle(getCurrentTitle(activePersona, xp));
      } catch (error) {
        console.error('获取XP数据时出错:', error);
      } finally {
        setIsLoading(false);
      }
    };
        
    updateXpData();
    window.addEventListener('xp-updated', updateXpData);
    return () => {
      window.removeEventListener('xp-updated', updateXpData);
    };
  }, [activePersona]);

  // 检查挑战限制情况
  useEffect(() => {
    const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
    const today = getTodayDate();
    const count = rhythmScoreLog.filter(
      (entry: any) => entry.date === today && entry.actionType === 'challenge_complete'
    ).length;
    console.log(`GrowthPathAdvisor - 今天完成的挑战数:`, count);
    setChallengeCount(count);
  }, [completed, today]);

  // 生成每日唯一挑战
  const generateDailyChallenges = () => {
    console.log(`生成${activePersona}的每日挑战...`);
    
    const stored = JSON.parse(localStorage.getItem('dailyChallenge') || '{}');
    const isOldFormat = Array.isArray(stored?.challenges) && typeof stored.challenges[0] === 'string';

    // 获取历史已完成的挑战
    const log = JSON.parse(localStorage.getItem('challengeLog') || '[]');
    const recentChallenges = log
      .filter((e: any) => e.today || e.date)
      .map((e: any) => e.text);

    // 创建可用挑战列表（排除最近使用的）
    const availableChallenges = fullList.filter(challenge => 
      !recentChallenges.includes(challenge.cue)
    );

    if (!hasTodayStarted() || stored.date !== today || isOldFormat) {
      let selectedChallenges;
      
      if (availableChallenges.length >= 2) {
        selectedChallenges = availableChallenges
          .sort(() => 0.5 - Math.random())
          .slice(0, 2);
      } else {
        selectedChallenges = fullList
          .sort(() => 0.5 - Math.random())
          .slice(0, 2);
      }

      console.log('生成新的每日挑战:', selectedChallenges);
      const challengeObj = { date: today, challenges: selectedChallenges };
      localStorage.setItem('dailyChallenge', JSON.stringify(challengeObj));
      return selectedChallenges;
    } else if (stored.challenges && stored.challenges.length > 0) {
      console.log('使用已存储的挑战:', stored.challenges);
      return stored.challenges;
    } else {
      console.log('未找到挑战，生成新的');
      const selectedChallenges = fullList.sort(() => 0.5 - Math.random()).slice(0, 2);
      localStorage.setItem('dailyChallenge', JSON.stringify({ date: today, challenges: selectedChallenges }));
      return selectedChallenges;
    }
  };

  // 新增：刷新单个挑战
  const refreshSingleChallenge = async (challengeIndex: number) => {
    console.log(`刷新挑战 ${challengeIndex}...`);
    
    try {
      // 获取当前挑战列表
      const currentChallenges = [...challenges];
      
      // 获取历史已完成的挑战（包括当前显示的挑战）
      const log = JSON.parse(localStorage.getItem('challengeLog') || '[]');
      const recentChallenges = log
        .filter((e: any) => e.today || e.date)
        .map((e: any) => e.text);
      
      // 添加当前显示的挑战到排除列表
      const excludeChallenges = [...recentChallenges, ...currentChallenges.map(c => c.cue)];
      
      // 找到可用的替代挑战
      const availableReplacements = fullList.filter(challenge => 
        !excludeChallenges.includes(challenge.cue)
      );
      
      if (availableReplacements.length === 0) {
        // 如果没有更多挑战，从所有挑战中随机选一个不是当前的
        const allOthers = fullList.filter(challenge => 
          challenge.cue !== currentChallenges[challengeIndex].cue
        );
        if (allOthers.length > 0) {
          currentChallenges[challengeIndex] = allOthers[Math.floor(Math.random() * allOthers.length)];
        } else {
          throw new Error('No alternative challenges available');
        }
      } else {
        // 随机选择一个可用的替代挑战
        const newChallenge = availableReplacements[Math.floor(Math.random() * availableReplacements.length)];
        currentChallenges[challengeIndex] = newChallenge;
      }
      
      // 更新挑战列表
      setChallenges(currentChallenges);
      
      // 更新 localStorage
      const stored = JSON.parse(localStorage.getItem('dailyChallenge') || '{}');
      const updatedStored = {
        ...stored,
        challenges: currentChallenges,
        lastRefreshed: new Date().toISOString(),
        refreshedIndex: challengeIndex
      };
      localStorage.setItem('dailyChallenge', JSON.stringify(updatedStored));
      
      // 清除该挑战的完成状态和反馈
      const newCompleted = completed.filter(cue => cue !== challenges[challengeIndex].cue);
      const newFeedbacks = { ...feedbacks };
      delete newFeedbacks[challenges[challengeIndex].cue];
      
      setCompleted(newCompleted);
      setFeedbacks(newFeedbacks);
      
      console.log('挑战刷新成功:', currentChallenges[challengeIndex]);
      
      // 触发成功通知
      window.dispatchEvent(new CustomEvent('challenge-refreshed', { 
        detail: { 
          index: challengeIndex, 
          newChallenge: currentChallenges[challengeIndex] 
        }
      }));
      
    } catch (error) {
      console.error('刷新挑战失败:', error);
      // 可以显示用户友好的错误消息
      alert('Unable to refresh challenge. You may have completed all available challenges for your persona.');
      throw error;
    }
  };

  // 挑战设置响应 activePersona 变化
  useEffect(() => {
    console.log(`GrowthPathAdvisor - 设置${activePersona}的挑战...`);
    const dailyChallenges = generateDailyChallenges();
    setChallenges(dailyChallenges);

    // 检查完成状态
    const log = JSON.parse(localStorage.getItem('challengeLog') || '[]');
    const todayLog = log.filter((e: any) => {
      if (e.today === today || e.date === today) return true;
      return false;
    });
    
    const completedCues = todayLog.map((e: any) => e.text);
    const feedbackMap: Record<string, string> = {};
    todayLog.forEach((e: any) => {
      if (e.feedback) feedbackMap[e.text] = e.feedback;
    });
    
    setCompleted(completedCues);
    setFeedbacks(feedbackMap);
    
    // 获取当前完成的挑战数量
    const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
    const count = rhythmScoreLog.filter(
      (entry: any) => entry.date === today && entry.actionType === 'challenge_complete'
    ).length;
    setChallengeCount(count);
  }, [activePersona, today, fullList]);

  const handleComplete = (cue: string) => {
    console.log(`开始处理挑战完成: ${cue}`);
    console.log(`当前active persona: ${activePersona}`);
    
    // 检查是否已达到挑战上限
    const MAX_CHALLENGE_COUNT = 2;
    if (challengeCount >= MAX_CHALLENGE_COUNT) {
      alert(`You've already completed the maximum of ${MAX_CHALLENGE_COUNT} challenges today.`);
      return;
    }
    
    // 1. 保存到 challengeLog
    const log = JSON.parse(localStorage.getItem('challengeLog') || '[]');
    const challengeEntry = {
      persona: activePersona,
      text: cue,
      time: Date.now(),
      today: today,
      date: today,
      completed: true,
      feedback: undefined
    };
    
    log.push(challengeEntry);
    localStorage.setItem('challengeLog', JSON.stringify(log));
    console.log('保存挑战记录:', challengeEntry);
    
    // 2. 保存到 SignatureMap
    try {
      const signatureMapLog = {
        challengeId: `daily-${today}-${Date.now()}`,
        persona: activePersona,
        text: cue,
        completed: true,
        skipped: false,
        trend: currentTrend || detectCurrentTrend(),
        timestamp: new Date().toISOString(),
      };
      
      if (typeof window !== 'undefined') {
        if (!window.signatureMap) {
          console.warn('SignatureMap 不存在，初始化基本结构...');
          window.signatureMap = {
            cueSeenCount: {},
            toneLog: [],
            cueFeedbackLog: [],
            trendHistory: [],
            challengeLog: [],
            personaAnchor: activePersona,
            microtaskCount: 0,
            microtaskLog: [],
            meta: {
              createdAt: new Date().toISOString(),
              lastUpdated: new Date().toISOString(),
              sessions: 0,
              speakReplayLog: [],
            },
          };
        }
        
        if (!window.signatureMap.challengeLog) {
          window.signatureMap.challengeLog = [];
        }
        window.signatureMap.challengeLog.push(signatureMapLog);
        console.log('保存到 SignatureMap:', signatureMapLog);
      }
    } catch (signatureMapError) {
      console.error('保存到 SignatureMap 失败:', signatureMapError);
    }
    
    // 3. 记录节奏分数
    writeRhythmScore(3, 'challenge_complete');
    console.log('记录挑战完成节奏分数');
    
    // 4. 更新本地状态
    setCompleted([...completed, cue]);
    setChallengeCount(prev => prev + 1);
    
    // 5. 添加XP
    if (canLogChallenge()) {
      console.log(`挑战完成，为${activePersona}添加6 XP`);
      const newXpValue = addXp(activePersona, 6);
      console.log(`添加XP后，${activePersona}的新XP值为: ${newXpValue}`);
      
      logChallengeXp();
      window.dispatchEvent(new Event('xp-updated'));
      
      setTimeout(() => {
        forceRefreshAllXpData();
      }, 300);
    }
    
    // 6. 触发更新事件
    window.dispatchEvent(new CustomEvent('challenge-completed', { 
      detail: { challenge: cue, persona: activePersona }
    }));
    window.dispatchEvent(new Event('storage'));
    
    console.log('挑战完成处理结束');
  };

  // 定义颜色和样式
  const RHYTHM_COLORS = {
    collapsed: '#AEC6CF',
    wavy: '#C3B1E1',
    stable: '#C5D8A4',
    rising: '#FFB347'
  };

  const PERSONAS = {
    rhea: {
      color: '#F5CFCF',
      gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
      icon: '💗',
      label: 'Rhea'
    },
    caelum: {
      color: '#4B6587',
      gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
      icon: '💠',
      label: 'Caelum'
    },
    aurelia: {
      color: '#D8A7CA',
      gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
      icon: '🧠',
      label: 'Aurelia'
    },
    lucis: {
      color: '#F8C1CC',
      gradient: 'linear-gradient(135deg, #F5E8C7, #F8C1CC)',
      icon: '🌱',
      label: 'Lucis'
    },
    niveus: {
      color: '#DDEBCF',
      gradient: 'linear-gradient(135deg, #F5E8C7, #DDEBCF)',
      icon: '📊',
      label: 'Niveus'
    }
  };

  const activePersonaStyle = PERSONAS[activePersona] || PERSONAS.rhea;
  const trendColor = RHYTHM_COLORS[currentTrend] || RHYTHM_COLORS.wavy;
  
  const trendLabel = {
    collapsed: '🧘‍♀️ Calm Reset',
    wavy: '🌊 Wavy Transitions',
    stable: '🌿 Stable Flow',
    rising: '🚀 Rising Momentum'
  };
  
  const currentTrendLabel = trendLabel[currentTrend] || '🌀 Mixed Flow';

  return (
    <div className="space-y-6">
      {/* 节奏状态信息面板 */}
      <div 
        className="rounded-xl overflow-hidden"
        style={{ 
          backgroundColor: 'rgba(255, 255, 255, 0.8)',
          backdropFilter: 'blur(8px)',
          border: '1px solid rgba(0, 0, 0, 0.03)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)'
        }}
      >
        {/* 顶部彩条 */}
        <div className="h-2 w-full" style={{ background: activePersonaStyle.gradient }} />
        
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div 
                className="w-12 h-12 rounded-full flex items-center justify-center transition-transform duration-300 hover:scale-105"
                style={{ 
                  background: activePersonaStyle.gradient,
                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)' 
                }}
              >
                <span className="text-xl">🎯</span>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h3 
                    className="text-lg font-medium"
                    style={{ color: '#333333' }}
                  >
                    Growth Challenges
                  </h3>
                  <span
                    className="text-xs text-gray-500 cursor-pointer w-5 h-5 rounded-full border border-gray-200 inline-flex items-center justify-center hover:bg-gray-100"
                    onClick={() => alert(`🎯 Growth Challenges are small identity-aligned actions.\nThey help you align your behavior with the person you aspire to be.`)}
                    title="Click for explanation"
                  >
                    ⓘ
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Align your actions with who you want to become
                </p>
              </div>
            </div>
            
            {/* 右侧适度大小的Persona显示 */}
            <div 
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg"
              style={{ 
                background: activePersonaStyle.gradient,
                boxShadow: '0 2px 4px rgba(0, 0, 0, 0.08)',
                border: '1px solid rgba(255, 255, 255, 0.3)'
              }}
            >
              <span className="text-lg">{activePersonaStyle.icon}</span>
              <span className="text-sm font-medium" style={{ color: '#333333' }}>
                {activePersonaStyle.label}
              </span>
            </div>
          </div>
          
          {/* 趋势状态和挑战计数器 */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div 
                className="w-2 h-2 rounded-full animate-pulse" 
                style={{ backgroundColor: trendColor }}
              />
              <span 
                className="text-xs px-2 py-0.5 rounded-full"
                style={{ 
                  backgroundColor: trendColor + '30',
                  color: '#333333'
                }}
              >
                {currentTrendLabel}
              </span>
            </div>
            
            {/* Challenge Limit Counter */}
            <div 
              className="text-xs px-2 py-1 rounded-lg"
              style={{ 
                backgroundColor: 'rgba(0, 0, 0, 0.05)',
                color: '#666666'
              }}
            >
              Challenges: {challengeCount}/2
            </div>
          </div>
          
          {/* XP进度显示 */}
          <div className="mb-4">
            <div className="flex justify-between items-center">
              <span className="text-xs text-gray-500">Experience</span>
              <div className="flex items-center">
                {isLoading ? (
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-1.5 animate-pulse"></span>
                ) : null}
                <span className="text-xs font-medium">{personaXp} XP</span>
              </div>
            </div>
            <div className="w-full h-2 bg-gray-100 rounded-full mt-1 overflow-hidden">
              <div 
                style={{ 
                  width: `${Math.min(100, (personaXp / 150) * 100)}%`,
                  background: activePersonaStyle.gradient
                }}
                className="h-full rounded-full transition-all duration-500"
              ></div>
            </div>
            
            <p className="text-xs text-gray-500 mt-2 italic">
              {personaTitle} - Completing challenges will develop {activePersonaStyle.label.toLowerCase()} qualities
            </p>
          </div>
        </div>
      </div>

      {/* 挑战卡片 */}
      <div className="grid gap-4">
      // 替换为（添加 onRefresh prop）：
{challenges.map((c, i) => (
  <IdentityChallengeCard
    key={`${today}-${i}`}
    cue={c.cue}
    paragraph={c.paragraph}
    action={c.action}
    points={3}
    isCompleted={completed.includes(c.cue)}
    feedback={feedbacks[c.cue]}
    onComplete={() => handleComplete(c.cue)}
    onRefresh={() => {
      // 简单的刷新逻辑
      console.log('Refreshing challenge:', i);
      
      // 获取所有可用挑战
      const availableChallenges = fullList.filter(challenge => 
        challenge.cue !== c.cue && !completed.includes(challenge.cue)
      );
      
      if (availableChallenges.length > 0) {
        // 随机选择一个新挑战
        const newChallenge = availableChallenges[Math.floor(Math.random() * availableChallenges.length)];
        
        // 更新挑战列表
        const newChallenges = [...challenges];
        newChallenges[i] = newChallenge;
        setChallenges(newChallenges);
        
        // 更新存储
        const stored = { date: today, challenges: newChallenges };
        localStorage.setItem('dailyChallenge', JSON.stringify(stored));
        
        // 清除该挑战的完成状态
        const newCompleted = completed.filter(cue => cue !== c.cue);
        setCompleted(newCompleted);
        
        // 清除反馈
        const newFeedbacks = { ...feedbacks };
        delete newFeedbacks[c.cue];
        setFeedbacks(newFeedbacks);
        
        console.log('Challenge refreshed successfully');
      } else {
        alert('No more challenges available!');
      }
    }}
    onFeedback={(value) => {
      // ... existing feedback handling code
    }}
  />
))}
              
              // 更新 localStorage challengeLog 中的反馈
              const log = JSON.parse(localStorage.getItem('challengeLog') || '[]');
              
              let updated = false;
              for (let j = log.length - 1; j >= 0; j--) {
                if (log[j].text === c.cue && 
                    (log[j].today === today || log[j].date === today) && 
                    log[j].persona === activePersona) {
                  log[j].feedback = value;
                  log[j].time = Date.now();
                  updated = true;
                  console.log('更新 challengeLog 中的反馈:', log[j]);
                  break;
                }
              }
              
              if (!updated) {
                const feedbackEntry = {
                  persona: activePersona,
                  text: c.cue,
                  time: Date.now(),
                  today: today,
                  date: today,
                  completed: true,
                  feedback: value
                };
                log.push(feedbackEntry);
                console.log('创建新的反馈记录:', feedbackEntry);
              }
              
              localStorage.setItem('challengeLog', JSON.stringify(log));
              
              // 更新 SignatureMap
              try {
                if (window.signatureMap && window.signatureMap.challengeLog) {
                  const signatureEntry = window.signatureMap.challengeLog.find(
                    (entry: any) => entry.text === c.cue && 
                    entry.persona === activePersona &&
                    entry.timestamp && entry.timestamp.startsWith(today)
                  );
                  
                  if (signatureEntry) {
                    signatureEntry.feedback = value;
                    console.log('更新 SignatureMap 中的反馈:', signatureEntry);
                  } else {
                    const newSignatureEntry = {
                      challengeId: `feedback-${today}-${Date.now()}`,
                      persona: activePersona,
                      text: c.cue,
                      completed: true,
                      feedback: value,
                      trend: currentTrend || detectCurrentTrend(),
                      timestamp: new Date().toISOString(),
                    };
                    window.signatureMap.challengeLog.push(newSignatureEntry);
                    console.log('在 SignatureMap 中创建新反馈记录:', newSignatureEntry);
                  }
                }
              } catch (signatureMapError) {
                console.error('更新 SignatureMap 反馈失败:', signatureMapError);
              }
              
              // 更新本地状态
              setFeedbacks({ ...feedbacks, [c.cue]: value });
              
              // 使用 SignatureLogger 记录
              logChallengeEntry({
                challengeId: `daily-${today}-${i}`,
                persona: activePersona,
                text: c.cue,
                completed: true,
                trend: currentTrend || detectCurrentTrend(),
                feedback: value,
                timestamp: new Date().toISOString(),
              });
              
              // 触发更新事件
              window.dispatchEvent(new CustomEvent('challenge-feedback-updated', { 
                detail: { challenge: c.cue, persona: activePersona, feedback: value }
              }));
              window.dispatchEvent(new Event('storage'));
              
              console.log('反馈处理完成');
            }}
          />
        ))}
      </div>

      {/* 挑战限制提示 */}
      {challengeCount >= 2 && (
        <div 
          className="p-4 rounded-lg text-center"
          style={{ 
            backgroundColor: 'rgba(255, 255, 255, 0.7)',
            border: '1px dashed rgba(0, 0, 0, 0.1)'
          }}
        >
          <p className="text-sm" style={{ color: '#666666' }}>
            You've completed your daily challenges! Come back tomorrow for more.
          </p>
        </div>
      )}

      {/* 底部文字 */}
      <p 
        className="text-xs italic text-center mt-4" 
        style={{ color: '#666666' }}
      >
        Refreshed daily. Based on your current identity path.
      </p>
    </div>
  );
};

export default GrowthPathAdvisor;