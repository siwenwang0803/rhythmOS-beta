import React, { useState } from 'react';

// RhythmOS colors from the UI spec
const rhythmColors = {
  sand: '#F5E8C7',     // Sand base: warmth and psychological safety
  collapsed: '#AEC6CF', // Gentle calming blue
  wavy: '#C3B1E1',     // Transitional lavender
  stable: '#C5D8A4',   // Grounded light green
  rising: '#FFB347',   // Activating orange-yellow
  accent: '#F7DC6F'    // Soft yellow for CTA/completion
};

// Persona gradients from UI spec
const personaGradients = {
  rhea: `linear-gradient(135deg, ${rhythmColors.sand} 0%, #F5CFCF 100%)`,    // Gentle, empathic
  caelum: `linear-gradient(135deg, ${rhythmColors.sand} 0%, #4B6587 100%)`,  // Directive, confident
  aurelia: `linear-gradient(135deg, ${rhythmColors.sand} 0%, #D8A7CA 100%)`, // Rational, intuitive
};

interface PostGoalReflectionCardProps {
  cue: string;
  paragraph: string;
  action?: string;
  onDismiss?: () => void;
}

const PostGoalReflectionCard: React.FC<PostGoalReflectionCardProps> = ({
  cue,
  paragraph,
  action,
  onDismiss
}) => {
  const [dismissed, setDismissed] = useState(false);
  const [isExpanded, setIsExpanded] = useState(true);

  if (dismissed) return null;

  // Handle dismiss with animation
  const handleDismiss = () => {
    setIsExpanded(false);
    setTimeout(() => {
      setDismissed(true);
      onDismiss?.();
    }, 300);
  };

  return (
    <div 
      className="rounded-lg overflow-hidden shadow-md transition-all duration-300 ease-in-out"
      style={{ 
        background: personaGradients.rhea,
        transform: isExpanded ? 'scale(1)' : 'scale(0.98)',
        opacity: isExpanded ? 1 : 0.7,
        maxHeight: isExpanded ? '1000px' : '0',
        borderLeft: `4px solid #F5CFCF`,
      }}
    >
      {/* Card Content */}
      <div className="p-5 space-y-3">
        {/* Header with persona gradient border */}
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xl">🎯</span>
          <h3 className="text-base font-semibold text-gray-800">
            Post-Goal Reflection
          </h3>
        </div>
        
        {/* Main content with persona styling */}
        <div 
          className="p-4 rounded-lg" 
          style={{ 
            backgroundColor: 'rgba(255, 255, 255, 0.85)',
            boxShadow: '0 2px 6px rgba(0, 0, 0, 0.05)',
            fontFamily: 'Nunito, sans-serif', // Rhea persona font from UI spec
          }}
        >
          <p 
            className="text-lg font-medium mb-3 leading-tight"
            style={{ color: '#333333' }}
          >
            {cue}
          </p>
          
          <p 
            className="text-base mb-4"
            style={{ color: '#555555', lineHeight: '1.5' }}
          >
            {paragraph}
          </p>
          
          {action && (
            <div 
              className="p-3 rounded-lg mt-3"
              style={{ 
                backgroundColor: `${rhythmColors.stable}30`,
                borderLeft: `3px solid ${rhythmColors.stable}`,
              }}
            >
              <p className="text-sm flex items-start">
                <span className="mr-2 mt-0.5">👉</span>
                <span style={{ color: '#333333' }}>{action}</span>
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Footer buttons */}
      <div 
        className="flex justify-end gap-3 px-5 py-4 border-t"
        style={{ borderColor: 'rgba(0, 0, 0, 0.05)' }}
      >
        <button
          onClick={handleDismiss}
          className="text-sm px-5 py-2.5 rounded-md transition-all duration-200 flex items-center gap-1.5 shadow-sm hover:shadow font-medium"
          style={{ 
            backgroundColor: rhythmColors.stable,
            color: '#333333',
            transform: 'translateY(0)',
            transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
          }}
          onMouseDown={(e) => e.currentTarget.style.transform = 'translateY(1px)'}
          onMouseUp={(e) => e.currentTarget.style.transform = 'translateY(0)'}
          onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
        >
          <span>✅</span>
          <span>Acknowledge</span>
        </button>
        
        <button
          onClick={handleDismiss}
          className="text-sm px-5 py-2.5 rounded-md transition-all duration-200 flex items-center gap-1.5 hover:bg-gray-50"
          style={{ 
            backgroundColor: 'rgba(255, 255, 255, 0.7)',
            color: '#666666',
            border: '1px solid rgba(0, 0, 0, 0.1)',
            transform: 'translateY(0)',
            transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
          }}
          onMouseDown={(e) => e.currentTarget.style.transform = 'translateY(1px)'}
          onMouseUp={(e) => e.currentTarget.style.transform = 'translateY(0)'}
          onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
        >
          <span>❌</span>
          <span>Skip</span>
        </button>
      </div>
    </div>
  );
};

export default PostGoalReflectionCard;
