import React from 'react'
import {
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
} from 'recharts'

import { CREGrowthLogEntry } from '../creGrowthLog'

const TONES = ['gentle', 'supportive', 'balanced', 'directive', 'reflective']

const TONE_COLORS: Record<string, string> = {
  gentle: '#60a5fa',      // blue-400
  supportive: '#34d399',  // green-400
  balanced: '#facc15',    // yellow-400
  directive: '#f87171',   // red-400
  reflective: '#a78bfa',  // purple-400
}

const CRECueEffectivenessRadar: React.FC = () => {
  const raw = localStorage.getItem('creGrowthLog')
  const log: CREGrowthLogEntry[] = raw ? JSON.parse(raw) : []

  const toneScores: Record<string, { total: number; count: number }> = {}

  log.forEach((entry) => {
    const tone = entry.tone || 'neutral'
    if (!toneScores[tone]) toneScores[tone] = { total: 0, count: 0 }

    if (entry.score !== undefined) {
      toneScores[tone].total += entry.score
      toneScores[tone].count += 1
    }
  })

  const data = TONES.map((tone) => {
    const d = toneScores[tone]
    const avg = d && d.count > 0 ? d.total / d.count : 0
    return {
      tone,
      avg: parseFloat(avg.toFixed(2)),
      color: TONE_COLORS[tone],
    }
  })

  const dominant = data.reduce((a, b) => (a.avg > b.avg ? a : b), data[0])

  if (data.every((d) => d.avg === 0)) return null

  return (
    <div className="mt-10">
      <h3 className="text-md font-semibold text-gray-800">
        🎯 CRE Tone Effectiveness Radar
      </h3>
      <p className="text-xs text-gray-500 mb-2">
        Based on your past feedback scores, this chart shows which tone styles
        were most effective for you.
      </p>

      <ResponsiveContainer width="100%" height={300}>
        <RadarChart data={data}>
          <PolarGrid />
          <PolarAngleAxis dataKey="tone" tick={{ fill: '#4b5563', fontSize: 12 }} />
          <PolarRadiusAxis domain={[0, 5]} />
          <Radar
            name="Average Score"
            dataKey="avg"
            stroke={TONE_COLORS[dominant.tone]}
            fill={TONE_COLORS[dominant.tone]}
            fillOpacity={0.5}
          />
        </RadarChart>
      </ResponsiveContainer>

      <p className="text-xs text-gray-600 mt-2">
        🌟 Your most effective tone: <span className="font-semibold text-blue-600">{dominant.tone.toUpperCase()}</span>{' '}
        with an average score of <strong>{dominant.avg}</strong>
      </p>
    </div>
  )
}

export default CRECueEffectivenessRadar
