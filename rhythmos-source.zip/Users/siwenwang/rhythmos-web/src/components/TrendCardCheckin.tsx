import React, { useState, useEffect } from 'react';
import { handleTrendCheckin } from '../utils/checkinTrendScore';

const TREND_OPTIONS = [
  { label: '🫥 Collapsed', value: 0 },
  { label: '🌊 Wavy', value: 1 },
  { label: '⚖️ Stable', value: 2 },
  { label: '🔥 Rising', value: 3 }
];

const TrendCardCheckin: React.FC = () => {
  const [selected, setSelected] = useState<number | null>(null);
  const [locked, setLocked] = useState(false);

  useEffect(() => {
    const today = new Date().toISOString().slice(0, 10);
    const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
    const alreadyCheckedIn = rhythmScoreLog.some(
      (entry: any) => entry.date === today && entry.actionType === 'daily_checkin'
    );
    if (alreadyCheckedIn) setLocked(true);
  }, []);

  const handleClick = (trend: number) => {
    if (locked) return;
    handleTrendCheckin(trend);
    setSelected(trend);
    setLocked(true);
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-800">🌡️ How’s your rhythm today?</h3>
      <p className="text-sm text-gray-500 mb-2">Select a state to check in:</p>

      <div className="grid grid-cols-2 gap-3">
        {TREND_OPTIONS.map(({ label, value }) => (
          <button
            key={value}
            onClick={() => handleClick(value)}
            className={`w-full px-4 py-2 rounded text-sm border shadow-sm
              ${selected === value ? 'bg-blue-600 text-white' : 'bg-white text-gray-800'}
              ${locked && selected !== value ? 'opacity-50 cursor-not-allowed' : ''}
            `}
            disabled={locked}
          >
            {label}
          </button>
        ))}
      </div>

      {locked && selected !== null && (
        <p className="text-sm text-green-600 mt-4">
          ✅ Checked in with: <strong>{TREND_OPTIONS[selected].label}</strong>
        </p>
      )}
    </div>
  );
};

export default TrendCardCheckin;

