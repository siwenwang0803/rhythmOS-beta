import React, { useState, useEffect } from 'react';

export const RhythmOnboardingGuide: React.FC = () => {
  const [dismissed, setDismissed] = useState<boolean>(false);

  useEffect(() => {
    const stored = localStorage.getItem('rhythmOnboardingDismissed');
    if (stored === 'true') {
      setDismissed(true);
    }
  }, []);

  const handleDismiss = () => {
    localStorage.setItem('rhythmOnboardingDismissed', 'true');
    setDismissed(true); // ✅ 触发重新渲染（组件隐藏）
  };

  if (dismissed) return null;

  return (
    <div className="mt-6 border border-indigo-300 bg-indigo-50 rounded p-4 text-sm text-indigo-800 shadow-sm">
      <p className="font-medium mb-1">🎓 Welcome to Your Rhythm Insight</p>
      <p>
        This page shows your rhythm trend, tone feedback, and identity growth map. Use it to understand
        how you respond to different tones and build a stronger training flow.
      </p>
      <ul className="list-disc ml-5 mt-2 space-y-1">
        <li><strong>Rhythm Score:</strong> shows your recent behavioral momentum</li>
        <li><strong>Signature Style:</strong> your dominant tone × persona pairing</li>
        <li><strong>Challenges:</strong> identity tasks based on your current training target</li>
        <li><strong>Trend Suggestion:</strong> how to stabilize or shift rhythm</li>
      </ul>
      <button
        onClick={handleDismiss}
        className="mt-3 px-3 py-1 rounded bg-indigo-600 text-white text-sm"
      >
        ✅ Hide onboarding guide
      </button>
    </div>
  );
};

