import React from 'react'

const TASK_EXAMPLES: Record<string, Record<string, string[]>> = {
  caelum: {
    reflect: [
      'Write about a moment you avoided leading today. What would Caelum have done?',
      'List 3 fears that blocked your decisions. Reframe them from a visionary mindset.',
      'Journal how you handled tension. Could you have responded with more clarity?'
    ],
    plan: [
      'Outline your next week with priorities in order.',
      'Write a 3-step path to one bold outcome you want.',
      'Design a small personal ritual to anchor your focus.'
    ]
  },
  lucis: {
    execute: [
      'Pick one thing you’ve been avoiding and do it in 10 minutes.',
      'Break one goal into 3 immediate tasks and start now.',
      'Schedule a hard decision and commit to follow-through.'
    ],
    write: [
      'Freewrite your current resistance. Then flip each into action.',
      'Describe a time when momentum changed your day.',
      'Draft a letter to your “weaker self” and explain why action matters.'
    ]
  },
  niveus: {
    clarify: [
      'List all open questions you’ve avoided this week.',
      'Break down a current dilemma into logical forks.',
      'Make a decision matrix with tradeoffs.'
    ],
    organize: [
      'Sort one chaotic folder, file, or notebook.',
      'Define a clean workspace rule to follow daily.',
      'Write a checklist for your next focused session.'
    ]
  },
  aurelia: {
    reflect: [
      'Write to your present self with kindness.',
      'Describe a heavy emotion from today, without judgment.',
      'Freewrite your unmet needs.'
    ],
    calm: [
      'Light a candle, sit in silence, and journal what arises.',
      'Create a short mantra for self-soothing.',
      'Write 3 things you forgave yourself for.'
    ]
  },
  rhea: {
    connect: [
      'Send a genuine message to someone you care about.',
      'Write how someone supported you recently.',
      'Reflect on what kind of presence you bring to others.'
    ],
    reflect: [
      'List 3 moments of empathy you showed this week.',
      'Journal about a conflict, from both sides.',
      'Write a kindness letter you’ve never sent.'
    ]
  }
}

const PersonaTaskExamples: React.FC<{ persona: string; taskType: string }> = ({ persona, taskType }) => {
  const examples = TASK_EXAMPLES[persona]?.[taskType] || []

  if (examples.length === 0) return null

  return (
    <div className="mt-6 space-y-2">
      <h4 className="text-sm font-semibold text-gray-700">📝 Suggested Actions for Today</h4>
      <ul className="list-disc text-sm ml-5 text-gray-700 space-y-1">
        {examples.map((ex, i) => (
          <li key={i}>{ex}</li>
        ))}
      </ul>
    </div>
  )
}

export default PersonaTaskExamples