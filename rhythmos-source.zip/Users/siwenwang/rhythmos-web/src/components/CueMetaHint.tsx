// CueMetaHint.tsx

import React, { useEffect, useState } from 'react'

interface CueMetaHintProps {
  persona: string
  tone: string
}

const toneInfo: Record<
  string,
  { label: string; color: string; description: string; emoji: string }
> = {
  gentle: {
    label: 'Gentle tone',
    color: 'text-blue-500 border-blue-300',
    description: 'Soft and nurturing. Best for emotional grounding.',
    emoji: '💙',
  },
  supportive: {
    label: 'Supportive tone',
    color: 'text-green-600 border-green-300',
    description: 'Warm and encouraging. Here to remind you you’re not alone.',
    emoji: '💚',
  },
  balanced: {
    label: 'Balanced tone',
    color: 'text-yellow-600 border-yellow-300',
    description: 'Clear and composed. Helps you stay centered.',
    emoji: '💛',
  },
  directive: {
    label: 'Directive tone',
    color: 'text-red-600 border-red-300',
    description: 'Sharp and focused. Pushes you to move forward.',
    emoji: '🔥',
  },
  reflective: {
    label: 'Reflective tone',
    color: 'text-purple-600 border-purple-300',
    description: 'Slower, deeper. Helps you pause and think clearly.',
    emoji: '🪞',
  },
}

const CueMetaHint: React.FC<CueMetaHintProps> = ({ persona, tone }) => {
  const toneData = toneInfo[tone] || {
    label: tone,
    color: 'text-gray-500 border-gray-300',
    description: '',
    emoji: '🤖',
  }

  const [hasShown, setHasShown] = useState(false)

  useEffect(() => {
    const key = `tone-hint-shown-${tone}`
    const seen = localStorage.getItem(key)
    if (!seen) {
      localStorage.setItem(key, 'true')
      setHasShown(false) // show description
    } else {
      setHasShown(true) // hide description
    }
  }, [tone])

  return (
    <div
      className={`rounded-xl border px-4 py-2 inline-block text-sm ${toneData.color} bg-white shadow-sm`}
    >
      <p className="font-medium">
        {toneData.emoji} {toneData.label} from{' '}
        <span className="underline">
          {persona.charAt(0).toUpperCase() + persona.slice(1)}
        </span>
      </p>
      {!hasShown && (
        <p className="text-xs text-gray-500 mt-1">{toneData.description}</p>
      )}
    </div>
  )
}

export default CueMetaHint


