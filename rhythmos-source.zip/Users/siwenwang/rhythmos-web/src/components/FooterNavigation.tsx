// src/components/FooterNavigation.tsx
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

// UI规范中定义的颜色和样式
const NAVIGATION_ITEMS = [
  {
    path: '/identity/train',
    icon: '🌱',
    label: 'Training',
    description: 'Daily rhythm practice'
  },
  {
    path: '/identity/insight',
    icon: '📊',
    label: 'Insights',
    description: 'Your rhythm patterns'
  },
  {
    path: '/digest',
    icon: '📘',
    label: 'Digest',
    description: 'Weekly progress summary'
  },
  {
    path: '/goals',
    icon: '🎯',
    label: 'Goals',
    description: 'Long-term progress'
  },
  {
    path: '/identity/growth',
    icon: '🌟',
    label: 'Growth',
    description: 'Persona XP & milestones'
  }
];

const FooterNavigation: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);

  const isOn = (path: string) => location.pathname.startsWith(path);

  return (
    <div className="relative pt-10 pb-6">
      {/* 背景装饰 */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-5"
        style={{ 
          backgroundImage: 'radial-gradient(circle at 20px 20px, #333 1px, transparent 0)',
          backgroundSize: '40px 40px'
        }}
      />
      
      {/* 上部分割线 */}
      <div className="mb-8 flex items-center justify-center">
        <div 
          className="w-16 h-[1px]"
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.1)' }}
        />
        <div 
          className="mx-3 text-xs uppercase tracking-widest"
          style={{ color: '#666666' }}
        >
          Navigation
        </div>
        <div 
          className="w-16 h-[1px]"
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.1)' }}
        />
      </div>
      
      {/* 导航卡片 */}
      <div className="flex flex-wrap justify-center gap-4">
        {NAVIGATION_ITEMS.map(item => {
          const active = isOn(item.path);
          if (active) return null;
          
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="group relative transition-all duration-300"
              onMouseEnter={() => setHoveredItem(item.path)}
              onMouseLeave={() => setHoveredItem(null)}
              style={{
                transform: hoveredItem === item.path ? 'translateY(-3px)' : 'translateY(0)'
              }}
            >
              <div 
                className="absolute inset-0 rounded-xl transition-all duration-300"
                style={{ 
                  backgroundColor: 'rgba(0, 0, 0, 0.03)',
                  transform: hoveredItem === item.path ? 'scale(1.05)' : 'scale(1)',
                  opacity: hoveredItem === item.path ? 0.7 : 0
                }}
              />
              
              <div 
                className="relative rounded-xl border overflow-hidden transition-all duration-300 p-0.5"
                style={{ 
                  borderColor: 'rgba(0, 0, 0, 0.05)',
                  backgroundColor: 'rgba(255, 255, 255, 0.5)',
                  backdropFilter: 'blur(8px)',
                  boxShadow: hoveredItem === item.path 
                    ? '0 8px 20px rgba(0, 0, 0, 0.08)' 
                    : '0 4px 10px rgba(0, 0, 0, 0.05)'
                }}
              >
                <div 
                  className="h-1 w-full transition-all duration-300"
                  style={{ 
                    background: 'linear-gradient(90deg, #F5E8C7, #4B6587)',
                    opacity: hoveredItem === item.path ? 1 : 0.5
                  }}
                />
                
                <div className="px-6 py-3 flex items-center gap-3">
                  <div 
                    className="w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300"
                    style={{ 
                      backgroundColor: hoveredItem === item.path ? 'rgba(245, 232, 199, 0.8)' : 'rgba(0, 0, 0, 0.05)'
                    }}
                  >
                    <span className="text-lg transition-all duration-300">{item.icon}</span>
                  </div>
                  
                  <div className="text-left">
                    <div 
                      className="font-medium transition-all duration-300"
                      style={{ 
                        color: '#333333',
                        transform: 'translateY(0)'
                      }}
                    >
                      {item.label}
                    </div>
                    
                    <div 
                      className="text-xs transition-all duration-300"
                      style={{ 
                        color: '#666666',
                        opacity: hoveredItem === item.path ? 1 : 0.8,
                        maxHeight: hoveredItem === item.path ? '20px' : '0',
                        overflow: 'hidden'
                      }}
                    >
                      {item.description}
                    </div>
                  </div>
                </div>
              </div>
            </button>
          );
        })}
      </div>
      
      {/* 返回主页按钮 */}
      {!isOn('/') && (
        <div className="mt-6 flex justify-center">
          <button
            onClick={() => navigate('/')}
            className="text-xs px-3 py-1.5 rounded-full transition-all duration-200"
            style={{ 
              backgroundColor: 'rgba(0, 0, 0, 0.05)',
              color: '#666666'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(0, 0, 0, 0.08)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(0, 0, 0, 0.05)';
            }}
          >
            ← Back to Home
          </button>
        </div>
      )}
    </div>
  );
};

export default FooterNavigation;

