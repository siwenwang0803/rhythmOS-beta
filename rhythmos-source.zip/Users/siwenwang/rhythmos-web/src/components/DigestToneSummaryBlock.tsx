import React, { useState, useEffect } from 'react';
import { getToneScoreMapByDays } from '../utils/writeToneLog';

// 扩展的语气描述和情绪映射
const toneData = {
  gentle: {
    message: "You're in a gentle space—keep listening to your inner voice.",
    icon: "🌿",
    color: "#84cc16",
    gradient: "linear-gradient(135deg, #84cc16, #65a30d)",
    trait: "reflective"
  },
  supportive: {
    message: "You're anchoring others. Let yourself rest, too.",
    icon: "🤲",
    color: "#f97316",
    gradient: "linear-gradient(135deg, #f97316, #ea580c)",
    trait: "nurturing"
  },
  balanced: {
    message: "Your clarity is growing. Keep pruning distractions.",
    icon: "⚖️",
    color: "#0ea5e9",
    gradient: "linear-gradient(135deg, #0ea5e9, #0284c7)",
    trait: "focused"
  },
  motivated: {
    message: "You're on the edge of movement—one push and it flows.",
    icon: "💫",
    color: "#8b5cf6",
    gradient: "linear-gradient(135deg, #8b5cf6, #7c3aed)",
    trait: "driven"
  },
  directive: {
    message: "You're stepping forward boldly. Stay grounded.",
    icon: "🏹",
    color: "#ec4899",
    gradient: "linear-gradient(135deg, #ec4899, #db2777)",
    trait: "commanding"
  },
  rational: {
    message: "You've been logical and clear—don't forget to feel.",
    icon: "🧠",
    color: "#14b8a6",
    gradient: "linear-gradient(135deg, #14b8a6, #0d9488)",
    trait: "analytical"
  },
  visionary: {
    message: "Your ideas are flowing—just don't lose the moment.",
    icon: "✨",
    color: "#f59e0b",
    gradient: "linear-gradient(135deg, #f59e0b, #d97706)",
    trait: "innovative"
  },
};

/**
 * DigestToneSummaryBlock - Enhanced tone insights component
 * 
 * Displays personalized insights based on user's recent tone patterns
 * with improved visual design and interactive elements.
 */
const DigestToneSummaryBlock: React.FC<{ isDaytime?: boolean }> = ({ 
  isDaytime = true 
}) => {
  const [timeframe, setTimeframe] = useState(3);
  const [isExpanded, setIsExpanded] = useState(false);
  const [animateIn, setAnimateIn] = useState(false);
  
  // Get tone scores based on selected timeframe
  const scoreMap = getToneScoreMapByDays(timeframe);
  const sorted = Object.entries(scoreMap).sort((a, b) => b[1] - a[1]);
  
  // Handle empty data state
  if (sorted.length === 0) {
    return (
      <div 
        className={`rounded-xl border p-4 shadow-sm ${isDaytime ? 'bg-white/90' : 'bg-gray-800/70'} 
        transition-all duration-300 backdrop-blur-sm`}
      >
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className={`text-sm font-semibold ${isDaytime ? 'text-gray-800' : 'text-gray-100'} mb-0.5`}>
              Insight Digest
            </h3>
            <p className={`text-xs ${isDaytime ? 'text-gray-500' : 'text-gray-400'}`}>
              No recent tone data
            </p>
          </div>
        </div>
        <p className={`text-sm ${isDaytime ? 'text-gray-600' : 'text-gray-300'} italic`}>
          Start interacting with daily prompts to build your tone profile.
        </p>
      </div>
    );
  }

  // Extract top tones (primary and secondary if available)
  const [primaryTone] = sorted[0];
  const secondaryTone = sorted.length > 1 ? sorted[1][0] : null;
  const primaryToneData = toneData[primaryTone as keyof typeof toneData] || {
    message: "Keep aligning with your true rhythm.",
    icon: "🔮",
    color: "#94a3b8",
    gradient: "linear-gradient(135deg, #94a3b8, #64748b)",
    trait: "intuitive"
  };
  
  // Calculate percentage for primary tone
  const totalScore = Object.values(scoreMap).reduce((sum, score) => sum + score, 0);
  const primaryPercentage = Math.round((scoreMap[primaryTone] / totalScore) * 100);
  
  // Effect to animate insights
  useEffect(() => {
    setAnimateIn(false);
    const timer = setTimeout(() => setAnimateIn(true), 100);
    return () => clearTimeout(timer);
  }, [timeframe]);

  return (
    <div 
      className={`rounded-xl border shadow-sm transition-all duration-300 overflow-hidden
      ${isDaytime ? 'bg-white/90 border-gray-200' : 'bg-gray-800/80 border-gray-700'} 
      backdrop-blur-sm`}
    >
      {/* Header with gradient accent based on primary tone */}
      <div 
        className="h-1.5"
        style={{ 
          background: primaryToneData.gradient,
          boxShadow: `0 0 8px ${primaryToneData.color}40`
        }}
      />
      
      <div className="p-4">
        {/* Title area with timeframe selector */}
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className={`text-sm font-semibold ${isDaytime ? 'text-gray-800' : 'text-gray-100'} 
              flex items-center gap-1.5 mb-0.5`}
            >
              <span>{primaryToneData.icon}</span>
              <span>Insight Digest</span>
            </h3>
            <p className={`text-xs ${isDaytime ? 'text-gray-500' : 'text-gray-400'}`}>
              Last {timeframe} days
            </p>
          </div>
          
          <div className="flex gap-1">
            {[3, 7, 14].map((days) => (
              <button
                key={days}
                onClick={() => setTimeframe(days)}
                className={`px-2 py-0.5 text-xs rounded-full transition-all
                ${timeframe === days 
                  ? isDaytime 
                    ? 'bg-gray-800 text-white' 
                    : 'bg-white text-gray-800'
                  : isDaytime
                    ? 'text-gray-700 hover:bg-gray-100'
                    : 'text-gray-300 hover:bg-gray-700'
                }`}
                aria-label={`View last ${days} days`}
              >
                {days}d
              </button>
            ))}
          </div>
        </div>
        
        {/* Main insight content with animation */}
        <div 
          className={`transition-all duration-300 transform
          ${animateIn ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}
        >
          {/* Primary insight message */}
          <div className={`flex items-start gap-3 mb-2 `}>
            <div 
              className="mt-0.5 w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ 
                background: primaryToneData.gradient,
                boxShadow: `0 2px 8px ${primaryToneData.color}50`
              }}
            >
              <span className="text-white text-lg" aria-hidden="true">
                {primaryToneData.icon}
              </span>
            </div>
            
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h4 className={`font-medium text-sm ${isDaytime ? 'text-gray-800' : 'text-gray-100'}`}>
                  {primaryTone.charAt(0).toUpperCase() + primaryTone.slice(1)}
                </h4>
                <span 
                  className={`text-xs px-1.5 py-0.5 rounded-full
                  ${isDaytime ? 'bg-gray-100 text-gray-700' : 'bg-gray-700 text-gray-300'}`}
                >
                  {primaryPercentage}%
                </span>
              </div>
              <p className={`text-sm ${isDaytime ? 'text-gray-700' : 'text-gray-300'} italic`}>
                {primaryToneData.message}
              </p>
            </div>
          </div>
          
          {/* Toggle for expanded view with secondary tones */}
          {secondaryTone && (
            <>
              <div className="flex justify-center my-2">
                <button
                  onClick={() => setIsExpanded(!isExpanded)}
                  className={`text-xs flex items-center gap-1 px-3 py-1 rounded-full transition-colors
                  ${isDaytime 
                    ? 'text-gray-500 hover:bg-gray-100' 
                    : 'text-gray-400 hover:bg-gray-700'
                  }`}
                  aria-expanded={isExpanded}
                >
                  <span>{isExpanded ? 'Show less' : 'Show more'}</span>
                  <svg 
                    width="12" 
                    height="12" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2"
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                    style={{ 
                      transform: isExpanded ? 'rotate(180deg)' : 'rotate(0)',
                      transition: 'transform 0.2s ease-in-out' 
                    }}
                  >
                    <polyline points="6 9 12 15 18 9"></polyline>
                  </svg>
                </button>
              </div>
              
              {/* Expanded view with secondary tones */}
              {isExpanded && (
                <div className={`mt-3 pt-3 border-t 
                  ${isDaytime ? 'border-gray-100' : 'border-gray-700'}
                  transition-all duration-300 animate-fadeIn`}
                >
                  <h5 className={`text-xs font-medium mb-2
                    ${isDaytime ? 'text-gray-600' : 'text-gray-400'}`}>
                    Secondary Patterns
                  </h5>
                  
                  {/* Show all secondary tones */}
                  <div className="space-y-2">
                    {sorted.slice(1, 3).map(([tone, score]) => {
                      const toneInfo = toneData[tone as keyof typeof toneData];
                      const percentage = Math.round((score / totalScore) * 100);
                      if (!toneInfo) return null;
                      
                      return (
                        <div key={tone} className="flex items-center gap-2">
                          <div 
                            className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0"
                            style={{ 
                              background: toneInfo.gradient,
                              opacity: 0.8
                            }}
                          >
                            <span className="text-white text-sm">{toneInfo.icon}</span>
                          </div>
                          <span className={`text-xs font-medium
                            ${isDaytime ? 'text-gray-700' : 'text-gray-300'}`}>
                            {tone.charAt(0).toUpperCase() + tone.slice(1)}
                          </span>
                          <span className={`text-xs
                            ${isDaytime ? 'text-gray-500' : 'text-gray-400'}`}>
                            {percentage}%
                          </span>
                        </div>
                      );
                    })}
                  </div>
                  
                  {/* Blend insight - what the combination means */}
                  <p className={`text-xs mt-3 
                    ${isDaytime ? 'text-gray-600' : 'text-gray-400'} italic`}>
                    Your blend of <span className="font-medium">{primaryTone}</span> and 
                    <span className="font-medium"> {secondaryTone}</span> tones suggests 
                    a balance between {primaryToneData.trait} and 
                    {toneData[secondaryTone as keyof typeof toneData]?.trait || 'adaptable'} 
                    tendencies in your approach.
                  </p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default DigestToneSummaryBlock;
