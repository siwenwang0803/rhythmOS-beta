// useSignatureLogger.ts — React hook to log feedback into SignatureMap

import {
    logToneFeedback,
    logCueFeedback,
    logTrend,
    logChallenge,
  } from '../FeedbackLogWriter';
  import {
    ToneEntry,
    CueEntry,
    TrendEntry,
    ChallengeEntry,
  } from '../SignatureMap';
  
  export function useSignatureLogger() {
    const logTone = (entry: ToneEntry) => {
      console.log('📥 useSignatureLogger.logTone called with:', entry);
      logToneFeedback(entry);
      console.log('✅ logToneFeedback completed');
    };
  
    const logCue = (entry: CueEntry) => {
      logCueFeedback(entry);
    };
  
    const logTrendEntry = (entry: TrendEntry) => {
      logTrend(entry);
    };
  
    const logChallengeEntry = (entry: ChallengeEntry) => {
      logChallenge(entry);
    };
  
    return {
      logTone,
      logCue,
      logTrendEntry,
      logChallengeEntry,
    };
  }