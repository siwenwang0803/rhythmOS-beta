// /hooks/useDailyRhythm.ts

import { useEffect } from 'react';
import { forceAutoFinalizeYesterday, startNewRhythmDay } from '../utils/rhythmDayEngine';

/**
 * 标准日节奏初始化 Hook
 * 页面加载时自动封结昨天、初始化今天
 */
export const useDailyRhythm = () => {
  useEffect(() => {
    forceAutoFinalizeYesterday();
    startNewRhythmDay();
  }, []);
};
