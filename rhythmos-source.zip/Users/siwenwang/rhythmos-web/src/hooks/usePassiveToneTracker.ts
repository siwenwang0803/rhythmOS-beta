// hooks/usePassiveToneTracker.ts

import { useEffect } from 'react'
import { triggerToneFromText } from '../rhea-echo/toneTrigger'
import { mapEmotionToTone } from '../rhea-echo/toneSwitchEngine'
import { writePassiveToneLog } from '../rhea-echo/signaturePassiveWriter'

export const usePassiveToneTracker = (text: string) => {
  useEffect(() => {
    if (!text || text.trim().length < 3) return

    const emotion = triggerToneFromText(text)
    const tone = mapEmotionToTone(emotion)
    writePassiveToneLog({ emotion, tone, timestamp: Date.now() })
  }, [text])
}
