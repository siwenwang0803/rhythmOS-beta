// creGenerator.ts（从 creTemplateRegistry.ts 获取 CRE）

import { creTemplates, CREVariant } from './creTemplateRegistry'
import { getCREStylePreference } from './creStylePreference'
import { getBestVariantByTask } from './creStrategySort'
import { RhythmSignatureMap } from './rhythmSignature'

export function generateCRE({
  trend,
  stage,
  taskType,
  signature,
  override,
  variant
}: {
  trend: string
  stage: string
  taskType: 'minimal' | 'light' | 'normal' | 'challenge'
  signature: RhythmSignatureMap
  override?: string
  variant?: CREVariant
}): string {
  const userOverride = localStorage.getItem('creStyleOverride')

  const finalTone =
    (userOverride && userOverride !== 'skip' ? userOverride : undefined) ||
    override ||
    getCREStylePreference(signature).tone

  const bestVariants = getBestVariantByTask()
  const variantUsed = variant || bestVariants[taskType] || 'base'

  const match = creTemplates.find(
    (t) =>
      t.tone === finalTone &&
      t.stage === stage &&
      t.taskType === taskType &&
      t.variant === variantUsed
  )

  return match?.text || 'Let rhythm guide you.'
}