// SignatureLogPage.tsx

import React from 'react'
import Section from '../components/ui/Section'
import CREUsageBarChart from '../components/CREUsageBarChart'

interface LogEntry {
  cue: string
  trend: string
  persona: string
  feedbackType: 'complete' | 'tried' | 'skipped'
  score: number
  timestamp: number
}

// Persona style map (emoji + tone color)
const personaStyleMap: Record<
  string,
  { color: string; emoji: string }
> = {
  rhea: { color: 'text-blue-500', emoji: '💙' },
  aurelia: { color: 'text-yellow-600', emoji: '💛' },
  lucis: { color: 'text-green-600', emoji: '💚' },
  niveus: { color: 'text-gray-600', emoji: '🧊' },
  caelum: { color: 'text-red-500', emoji: '❤️‍🔥' },
}

const SignatureLogPage: React.FC = () => {
  const raw = localStorage.getItem('rhythmSignatureLog')
  const logs: LogEntry[] = raw ? JSON.parse(raw) : []

  const sorted = logs.sort((a, b) => b.timestamp - a.timestamp)

  return (
    <div className="min-h-screen px-6 py-10 max-w-2xl mx-auto space-y-8">
      <h1 className="text-2xl font-bold text-gray-800">🧾 Signature Feedback Log</h1>
      <p className="text-sm text-gray-500">
        All your behavior feedback records are listed here.
      </p>

      <aside className="ml-6 w-1/4">
        <h3 className="text-md font-semibold mb-2">CRE Usage by Persona</h3>
        <CREUsageBarChart />
      </aside>

      {sorted.length === 0 ? (
        <p className="text-sm italic text-gray-500">No signature entries yet.</p>
      ) : (
        <div className="space-y-4">
          {sorted.map((entry, i) => {
            const personaStyle = personaStyleMap[entry.persona] || {
              color: 'text-gray-500',
              emoji: '🤖',
            }

            return (
              <Section
                key={i}
                title={`📍 ${entry.trend.toUpperCase()} · ${personaStyle.emoji}`}
                description={
                  <span className={`${personaStyle.color}`}>
                    {entry.persona.toUpperCase()} · {entry.feedbackType.toUpperCase()}
                  </span>
                }
              >
                <p className="text-sm text-gray-700 mb-1">
                  Cue: “{entry.cue}”
                </p>
                <p className="text-sm text-gray-600 mb-1">
                  Score: {entry.score}
                </p>
                <p className="text-xs text-gray-400">
                  Logged on: {new Date(entry.timestamp).toLocaleString()}
                </p>
              </Section>
            )
          })}
        </div>
      )}
    </div>
  )
}

export default SignatureLogPage

