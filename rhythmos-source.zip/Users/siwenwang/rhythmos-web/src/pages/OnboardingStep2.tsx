import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// 波浪背景组件 - 动态版
const WaveBackground = () => (
  <div className="absolute top-0 left-0 w-full overflow-hidden z-0 opacity-30">
    <div className="wave wave1"></div>
    <div className="wave wave2"></div>
  </div>
);

// 语调气泡组件
const ToneBubbles = ({ tone }) => {
  // 不同语调对应不同的气泡颜色和行为
  const toneConfig = {
    gentle: { colors: ['#bbf7d0', '#86efac', '#4ade80'], count: 6, speed: 'slow' },
    directive: { colors: ['#e0e7ff', '#c7d2fe', '#a5b4fc'], count: 5, speed: 'medium' },
    visionary: { colors: ['#fef3c7', '#fde68a', '#fcd34d'], count: 8, speed: 'medium' },
    rational: { colors: ['#fee2e2', '#fecaca', '#fca5a5'], count: 4, speed: 'medium' },
    motivated: { colors: ['#dbeafe', '#93c5fd', '#60a5fa'], count: 10, speed: 'fast' },
    default: { colors: ['#e5e7eb', '#d1d5db', '#9ca3af'], count: 4, speed: 'medium' }
  };
  
  const config = toneConfig[tone] || toneConfig.default;
  const bubbles = Array.from({ length: config.count }, (_, i) => ({
    color: config.colors[Math.floor(Math.random() * config.colors.length)],
    size: 5 + Math.random() * 15,
    left: 5 + Math.random() * 90,
    delay: Math.random() * 5,
    duration: config.speed === 'slow' ? 15 + Math.random() * 10 : 
              config.speed === 'medium' ? 8 + Math.random() * 7 :
              5 + Math.random() * 5
  }));
  
  return (
    <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
      {tone && bubbles.map((bubble, i) => (
        <div 
          key={i}
          className="absolute rounded-full animate-float"
          style={{
            width: `${bubble.size}px`,
            height: `${bubble.size}px`,
            backgroundColor: bubble.color,
            left: `${bubble.left}%`,
            bottom: '-20px',
            opacity: 0.7,
            animationDelay: `${bubble.delay}s`,
            animationDuration: `${bubble.duration}s`
          }}
        ></div>
      ))}
    </div>
  );
};

// 语调特征装饰组件
const ToneDecoration = ({ tone }) => {
  const patterns = {
    gentle: (
      <svg className="absolute inset-0 w-full h-full opacity-5" width="100%" height="100%">
        <pattern id="gentle-pattern" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M20 0 A20 20 0 0 1 20 40 A20 20 0 0 1 20 0" fill="none" stroke="currentColor" strokeWidth="1" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#gentle-pattern)" />
      </svg>
    ),
    directive: (
      <svg className="absolute inset-0 w-full h-full opacity-5" width="100%" height="100%">
        <pattern id="directive-pattern" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M0 20 L40 20 M20 0 L20 40" stroke="currentColor" strokeWidth="1" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#directive-pattern)" />
      </svg>
    ),
    visionary: (
      <svg className="absolute inset-0 w-full h-full opacity-5" width="100%" height="100%">
        <pattern id="visionary-pattern" width="60" height="60" patternUnits="userSpaceOnUse">
          <path d="M30 10 L50 30 L30 50 L10 30 Z" fill="none" stroke="currentColor" strokeWidth="1" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#visionary-pattern)" />
      </svg>
    ),
    rational: (
      <svg className="absolute inset-0 w-full h-full opacity-5" width="100%" height="100%">
        <pattern id="rational-pattern" width="40" height="40" patternUnits="userSpaceOnUse">
          <rect x="10" y="10" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#rational-pattern)" />
      </svg>
    ),
    motivated: (
      <svg className="absolute inset-0 w-full h-full opacity-5" width="100%" height="100%">
        <pattern id="motivated-pattern" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M0 0 L40 40 M40 0 L0 40" stroke="currentColor" strokeWidth="1" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#motivated-pattern)" />
      </svg>
    )
  };
  
  return patterns[tone] || null;
};

const cues = [
  { 
    text: "Take one step, even if you're unsure.", 
    tone: 'gentle',
    persona: 'rhea',
    icon: '🍃',
    description: "A calm, nurturing voice that encourages gentle progress.",
    bgGradient: "from-green-50 to-emerald-50",
    activeGradient: "from-green-100 to-emerald-100",
    borderColor: "border-green-200",
    personaDescription: "Rhea provides gentle encouragement and patient guidance."
  },
  { 
    text: "Focus. You know what matters.", 
    tone: 'directive',
    persona: 'niveus',
    icon: '🧭',
    description: "A clear, decisive voice that cuts through confusion.",
    bgGradient: "from-indigo-50 to-violet-50",
    activeGradient: "from-indigo-100 to-violet-100",
    borderColor: "border-indigo-200",
    personaDescription: "Niveus offers direct, clear guidance with a focus on priorities."
  },
  { 
    text: "You're here, and that's enough to start.", 
    tone: 'visionary',
    persona: 'lucis',
    icon: '✨',
    description: "A forward-looking voice that inspires possibility.",
    bgGradient: "from-yellow-50 to-amber-50",
    activeGradient: "from-yellow-100 to-amber-100",
    borderColor: "border-yellow-200",
    personaDescription: "Lucis inspires with a perspective that sees future potential."
  },
  { 
    text: "Let clarity lead the next move.", 
    tone: 'rational',
    persona: 'aurelia',
    icon: '⚖️',
    description: "A measured, thoughtful voice that values reasoning.",
    bgGradient: "from-red-50 to-rose-50",
    activeGradient: "from-red-100 to-rose-100", 
    borderColor: "border-red-200",
    personaDescription: "Aurelia approaches challenges with logic and structured thinking."
  },
  { 
    text: "Reflect, decide, and surge forward stronger.", 
    tone: 'motivated',
    persona: 'caelum',
    icon: '🌊', 
    description: "An energetic, affirming voice that builds momentum.",
    bgGradient: "from-blue-50 to-sky-50",
    activeGradient: "from-blue-100 to-sky-100",
    borderColor: "border-blue-200",
    personaDescription: "Caelum energizes with a focus on building momentum and enthusiasm."
  }
];

const toneToPersonaMap: Record<string, string> = {
  gentle: 'rhea',
  directive: 'niveus',
  visionary: 'lucis',
  rational: 'aurelia',
  motivated: 'caelum'
};

const OnboardingStep2: React.FC = () => {
  const navigate = useNavigate();
  const [selectedTone, setSelectedTone] = useState<string | null>(null);
  const [hoveredTone, setHoveredTone] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  // 在组件挂载后触发加载动画
  useEffect(() => {
    setTimeout(() => {
      setLoaded(true);
    }, 100);
  }, []);

  const handleSelect = (tone: string) => {
    setSelectedTone(tone);
    setShowDetails(true);
    
    localStorage.setItem('preferredTone', tone);
    
    // 添加短暂延迟，让用户体验选中状态的视觉反馈
    setTimeout(() => {
      navigate('/identity/mbti');
    }, 1500);
  };

  // 自定义CSS样式，包含动画和过渡效果
  const customStyles = `
    .wave {
      position: absolute;
      width: 100%;
      height: 100px;
      background-size: 1600px 100px;
    }
    
    .wave1 {
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%23fce7f3' fill-opacity='0.6' d='M0,192L48,176C96,160,192,128,288,122.7C384,117,480,139,576,144C672,149,768,139,864,149.3C960,160,1056,192,1152,197.3C1248,203,1344,181,1392,170.7L1440,160L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z'%3E%3C/path%3E%3C/svg%3E");
      animation: wave 30s linear infinite;
    }
    
    .wave2 {
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%23ddd6fe' fill-opacity='0.3' d='M0,256L48,261.3C96,267,192,277,288,266.7C384,256,480,224,576,213.3C672,203,768,213,864,224C960,235,1056,245,1152,240C1248,235,1344,213,1392,202.7L1440,192L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z'%3E%3C/path%3E%3C/svg%3E");
      animation: wave 20s linear reverse infinite;
      top: 30px;
    }
    
    @keyframes wave {
      0% {
        background-position-x: 0;
      }
      100% {
        background-position-x: 1600px;
      }
    }
    
    @keyframes float {
      0%, 100% {
        transform: translateY(0);
      }
      50% {
        transform: translateY(-100px);
      }
    }
    
    .animate-float {
      animation: float ease-in-out infinite;
    }
    
    .cue-card {
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .cue-card:hover {
      transform: translateY(-5px);
    }
    
    .cue-card.selected {
      transform: scale(1.03);
    }
    
    .tone-description {
      max-height: 0;
      overflow: hidden;
      transition: all 0.3s ease-out;
    }
    
    .tone-description.visible {
      max-height: 80px;
    }
    
    .details-panel {
      transform: translateY(20px);
      opacity: 0;
      transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .details-panel.visible {
      transform: translateY(0);
      opacity: 1;
    }
    
    .persona-avatar {
      position: relative;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 64px;
      height: 64px;
      border-radius: 9999px;
    }
    
    .persona-avatar::before {
      content: '';
      position: absolute;
      inset: -4px;
      border-radius: 9999px;
      background: conic-gradient(
        from 0deg, 
        rgba(255,255,255,0), 
        currentColor, 
        rgba(255,255,255,0),
        rgba(255,255,255,0),
        rgba(255,255,255,0)
      );
      animation: spin 4s linear infinite;
    }
    
    @keyframes spin {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }
    
    .progress-dot {
      transition: all 0.4s ease-out;
    }
    
    .progress-dot.active {
      transform: scale(1.2);
    }
    
    .quote-mark {
      font-size: 3rem;
      line-height: 1;
      opacity: 0.15;
      font-family: serif;
    }
  `;

  return (
    <div className="relative min-h-screen bg-gradient-to-b from-white to-gray-50 pt-12 pb-20 overflow-hidden">
      {/* 注入自定义动画样式 */}
      <style>{customStyles}</style>
      
      {/* 背景元素 */}
      <WaveBackground />
      <ToneBubbles tone={hoveredTone || selectedTone} />
      
      <div className="relative z-10 max-w-xl mx-auto px-6 pt-8 pb-12 space-y-8">
        {/* 标题区域 */}
        <div 
          className={`text-center mb-8 transition-all duration-1000 ease-out ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform -translate-y-10'}`}
        >
          <div className="inline-block p-3 mb-6 bg-pink-50 bg-opacity-80 backdrop-blur-sm rounded-full shadow-md">
            <div className="w-20 h-20 flex items-center justify-center bg-gradient-to-br from-pink-500 to-purple-400 rounded-full shadow-lg">
              <span className="text-4xl transform transition-transform duration-700 ease-out hover:rotate-12">🎯</span>
            </div>
          </div>
          <h1 className="text-4xl font-serif font-bold text-gray-900 tracking-tight mb-3">
            Choose Your Starting Cue
          </h1>
          <p className="text-lg text-pink-600 font-medium max-w-md mx-auto mt-3">
            <span className="bg-pink-50 px-5 py-2 rounded-full shadow-sm backdrop-blur-sm">
              Which voice resonates with you?
            </span>
          </p>
        </div>

        {/* 说明文本 */}
        <div 
          className={`bg-white bg-opacity-80 backdrop-blur-sm rounded-xl p-6 shadow-md border border-gray-100 transition-all duration-1000 ease-out delay-300 ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
        >
          <p className="text-gray-700 text-center leading-relaxed">
            Select the statement that feels most aligned with how you'd like RhythmOS to communicate with you.
            This choice will shape your personalized system voice.
          </p>
        </div>

        {/* 语调选项区域 */}
        <div className="grid grid-cols-1 gap-5 mt-8">
          {cues.map((cue, i) => (
            <button
              key={i}
              onClick={() => handleSelect(cue.tone)}
              onMouseEnter={() => setHoveredTone(cue.tone)}
              onMouseLeave={() => setHoveredTone(null)}
              className={`relative cue-card text-left bg-white backdrop-blur-sm bg-opacity-90 border ${cue.borderColor} rounded-xl px-6 py-5 shadow-sm hover:shadow-md ${selectedTone === cue.tone ? 'selected ring-2 ring-offset-1 shadow-md' : ''} ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
              style={{ 
                transitionDelay: `${300 + i * 150}ms`,
              }}
            >
              {/* 语调装饰背景 */}
              <div className={`absolute inset-0 bg-gradient-to-r ${cue.bgGradient} rounded-xl opacity-40 transition-opacity duration-300 ${hoveredTone === cue.tone || selectedTone === cue.tone ? 'opacity-70' : ''}`}></div>
              {(hoveredTone === cue.tone || selectedTone === cue.tone) && (
                <ToneDecoration tone={cue.tone} />
              )}
              
              {/* 引号装饰 */}
              <div className="absolute top-2 left-3 quote-mark">"</div>
              <div className="absolute bottom-2 right-3 quote-mark">"</div>
              
              <div className="flex items-start gap-4 relative z-10 ml-3">
                <div className="flex-grow text-center py-2">
                  <p className="text-gray-800 font-medium text-lg">{cue.text}</p>
                  <div 
                    className={`tone-description ${hoveredTone === cue.tone || selectedTone === cue.tone ? 'visible' : ''}`}
                  >
                    <div className="flex items-center justify-center gap-2 mt-3">
                      <span className="text-xl">{cue.icon}</span>
                      <p className="text-gray-600 text-sm">{cue.description}</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* 选中标记 */}
              {selectedTone === cue.tone && (
                <div className="absolute right-4 top-1/2 transform -translate-y-1/2 flex items-center justify-center w-8 h-8 bg-pink-100 rounded-full">
                  <svg className="w-5 h-5 text-pink-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                  </svg>
                </div>
              )}
            </button>
          ))}
        </div>
        
        {/* 选中状态详细信息 */}
        <div 
          className={`details-panel bg-white bg-opacity-80 backdrop-blur-sm rounded-xl p-6 shadow-md border border-gray-200 ${showDetails ? 'visible' : ''}`}
          style={{
            borderColor: selectedTone !== null 
              ? cues.find(c => c.tone === selectedTone)?.borderColor?.replace('border-', '') || 'transparent'
              : 'transparent'
          }}
        >
          {selectedTone !== null && (
            <div className="text-center">
              <div className="mb-4">
                {(() => {
                  const selectedCue = cues.find(c => c.tone === selectedTone);
                  if (!selectedCue) return null;
                  
                  const avatarGradient = selectedCue.bgGradient.replace('from-', '').replace('to-', '').split(' ');
                  
                  return (
                    <div 
                      className="persona-avatar mx-auto" 
                      style={{ color: avatarGradient[1].replace('-50', '-400') }}
                    >
                      <div className={`w-full h-full rounded-full flex items-center justify-center text-2xl bg-gradient-to-br ${selectedCue.activeGradient}`}>
                        {selectedCue.icon}
                      </div>
                    </div>
                  );
                })()}
              </div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">
                You've selected {cues.find(c => c.tone === selectedTone)?.persona} as your guide
              </h3>
              <p className="text-gray-600 text-sm">
                {cues.find(c => c.tone === selectedTone)?.personaDescription}
                <br/>Taking you to the next step...
              </p>
            </div>
          )}
        </div>

        {/* 进度指示器 */}
        <div 
          className={`pt-6 flex justify-center space-x-3 transition-opacity duration-1000 delay-1000 ${loaded ? 'opacity-100' : 'opacity-0'}`}
        >
          {Array.from({ length: 3 }, (_, i) => (
            <div 
              key={i} 
              className={`progress-dot w-3 h-3 rounded-full ${i === 1 ? 'active bg-pink-500' : i < 1 ? 'bg-green-500' : 'bg-gray-200'}`}
            ></div>
          ))}
        </div>
        
        {/* 低调的返回按钮 */}
        <div className={`text-center transition-opacity duration-1000 ease-out delay-1200 ${loaded ? 'opacity-100' : 'opacity-0'}`}>
          <button 
            onClick={() => navigate(-1)}
            className="text-sm text-gray-500 hover:text-gray-700 transition-colors duration-300 flex items-center justify-center gap-1 mx-auto"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
            </svg>
            <span>Back to Previous Step</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default OnboardingStep2;




