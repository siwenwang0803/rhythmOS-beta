// /components/DevResetPage.tsx - 添加XP修复功能

import React from 'react';
import { getTodayDate } from '../utils/rhythmDayEngine';
import { getXpTracker, getTodayDateKey, resetTodayCounters } from '../utils/xpDailyTracker';
import { getXpData, forceRefreshAllXpData, setPersonaXp } from '../utils/xpEngine';



const DevResetPage: React.FC = () => {
  // 完全重置所有数据
  const handleReset = () => {
    localStorage.clear();
    location.reload();
  };
// 在 DevResetPage 组件中添加缺失的函数

// 清除挑战记录
const handleClearChallenges = () => {
  try {
    localStorage.removeItem('challengeLog');
    localStorage.removeItem('dailyChallenge');
    
    // 清理 SignatureMap 中的挑战记录
    if (window.signatureMap && window.signatureMap.challengeLog) {
      window.signatureMap.challengeLog = [];
    }
    
    // 清理 rhythmScoreLog 中的挑战完成记录
    const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
    const filteredRhythm = rhythmScoreLog.filter((entry: any) => 
      entry.actionType !== 'challenge_complete'
    );
    localStorage.setItem('rhythmScoreLog', JSON.stringify(filteredRhythm));
    
    // 触发更新事件
    window.dispatchEvent(new CustomEvent('challenge-completed'));
    window.dispatchEvent(new Event('storage'));
    
    alert('✅ Challenge logs and daily challenge cleared.');
  } catch (error) {
    console.error('清除挑战记录时出错:', error);
    alert('❌ 清除失败: ' + error.message);
  }
};

// 清除目标和子任务
const handleClearGoals = () => {
  try {
    localStorage.removeItem('rhythmGoals');
    localStorage.removeItem('rhythmSubtasks');
    
    // 触发更新事件
    window.dispatchEvent(new Event('storage'));
    
    alert('✅ All goals and subtasks have been cleared.');
  } catch (error) {
    console.error('清除目标时出错:', error);
    alert('❌ 清除失败: ' + error.message);
  }
};

// 重置所有XP数据
const handleResetAllXP = () => {
  try {
    const personaXpBase = {
      rhea: { xp: 0, history: [] },
      caelum: { xp: 0, history: [] },
      aurelia: { xp: 0, history: [] },
      lucis: { xp: 0, history: [] },
      niveus: { xp: 0, history: [] },
    };
    localStorage.setItem('personaXpLog', JSON.stringify(personaXpBase));
    
    // 清理每日XP追踪器
    localStorage.removeItem('xpDailyTracker');
    
    // 触发自定义事件通知组件更新
    window.dispatchEvent(new Event('xp-updated'));
    
    alert('✅ All persona XP has been reset to zero.');
  } catch (error) {
    console.error('重置XP时出错:', error);
    alert('❌ 重置失败: ' + error.message);
  }
};
// 修复的测试工具 - 同步清理所有数据源

// 修复的 DevResetPage 组件内部函数版本

// 将这些函数放在你的 DevResetPage 组件内部，替换原有的函数

// 在组件内部定义这些函数：

// 模拟新的一天 - 修复版本
const handleSimulateNewDay = () => {
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);

  const yesterdayString = yesterday.toISOString().slice(0, 10);
  const todayString = today.toISOString().slice(0, 10);

  console.log('🚀 开始模拟新的一天...');
  console.log('📅 昨天:', yesterdayString);
  console.log('📅 今天:', todayString);

  // ✅ 1. 写一条模拟昨天的dailySummaryLog记录
  const summaryLog = JSON.parse(localStorage.getItem('dailySummaryLog') || '[]');
  summaryLog.push({
    date: yesterdayString,
    score: Math.floor(Math.random() * 7) + 3,
    trend: ['collapsed', 'wavy', 'stable', 'rising'][Math.floor(Math.random() * 4)]
  });
  localStorage.setItem('dailySummaryLog', JSON.stringify(summaryLog));
  console.log('✅ 添加了昨天的 dailySummaryLog');

  // ✅ 2. 控制节奏时间
  localStorage.setItem('lastFinalizedDate', yesterdayString);
  localStorage.removeItem('rhythmTodayStarted');
  localStorage.removeItem('rhythmTodayFinalized');
  localStorage.removeItem('dailyChallenge');
  console.log('✅ 重置了节奏控制标志');

  // ✅ 3. 清理 rhythmScoreLog 当天的内容（保留历史）
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const filtered = rhythmScoreLog.filter((entry: any) => entry.date !== todayString);
  localStorage.setItem('rhythmScoreLog', JSON.stringify(filtered));
  console.log('✅ 清理了 rhythmScoreLog 今天的内容');

  // ✅ 4. 重置今天的 xpTracker 数据
  const xpTracker = JSON.parse(localStorage.getItem('xpTracker') || '{}');
  if (xpTracker[todayString]) {
    // 保存昨天的数据以备查看
    xpTracker[yesterdayString] = {...xpTracker[yesterdayString] || {}, archivedFromReset: true};
    // 删除今天的数据
    delete xpTracker[todayString];
    localStorage.setItem('xpTracker', JSON.stringify(xpTracker));
    console.log('✅ 重置了 xpTracker 今天的数据');
  }

  // ✅ 5. 清理 SignatureMap 今天的数据 - 这是关键！
  try {
    const signatureMap = (window as any).signatureMap;
    if (signatureMap) {
      // 保存原有的历史数据
      const originalMicrotaskLog = signatureMap.microtaskLog || [];
      
      // 过滤掉今天的 microtaskLog 条目
      const filteredMicrotaskLog = originalMicrotaskLog.filter((entry: any) => {
        if (entry.timestamp) {
          const entryDate = new Date(entry.timestamp).toISOString().slice(0, 10);
          return entryDate !== todayString;
        }
        return true; // 保留没有时间戳的条目
      });
      
      // 更新 SignatureMap
      signatureMap.microtaskLog = filteredMicrotaskLog;
      signatureMap.microtaskCount = filteredMicrotaskLog.length;
      
      // 更新 meta 信息
      signatureMap.meta.lastUpdated = new Date().toISOString();
      
      console.log('✅ 清理了 SignatureMap 今天的数据');
      console.log('📊 SignatureMap 更新后:', {
        microtaskCount: signatureMap.microtaskCount,
        logEntries: signatureMap.microtaskLog.length
      });
    }
  } catch (error) {
    console.error('❌ 清理 SignatureMap 时出错:', error);
  }

  // ✅ 6. 触发更新事件
  window.dispatchEvent(new CustomEvent('microtask-updated'));
  window.dispatchEvent(new CustomEvent('rhythm-score-updated'));
  window.dispatchEvent(new CustomEvent('storage'));
  
  console.log('✅ 触发了更新事件');

  alert(`✅ Simulated new rhythm day. Last finalized set to ${yesterdayString}. All data sources synchronized.`);
  location.reload();
};

// 重置今天的所有计数器 - 修复版本
const handleResetTodayTrackers = () => {
  const todayString = new Date().toISOString().slice(0, 10);
  console.log('🔄 重置今天的计数器:', todayString);
  
  let oldMicrotaskCount = 0;
  let oldChallengeCount = 0;
  
  try {
    // 1. 重置 xpTracker
    const xpTracker = JSON.parse(localStorage.getItem('xpTracker') || '{}');
    const todayData = xpTracker[todayString] || {};
    oldMicrotaskCount = todayData.microtaskCount || 0;
    oldChallengeCount = todayData.challengeCount || 0;
    
    delete xpTracker[todayString];
    localStorage.setItem('xpTracker', JSON.stringify(xpTracker));
    console.log('✅ 重置 xpTracker');
    
    // 2. 重置 SignatureMap
    const signatureMap = (window as any).signatureMap;
    if (signatureMap) {
      // 过滤掉今天的条目
      const filteredMicrotaskLog = (signatureMap.microtaskLog || []).filter((entry: any) => {
        if (entry.timestamp) {
          const entryDate = new Date(entry.timestamp).toISOString().slice(0, 10);
          return entryDate !== todayString;
        }
        return true;
      });
      
      signatureMap.microtaskLog = filteredMicrotaskLog;
      signatureMap.microtaskCount = filteredMicrotaskLog.length;
      signatureMap.meta.lastUpdated = new Date().toISOString();
      console.log('✅ 重置 SignatureMap');
    }
    
    // 3. 重置 rhythmScoreLog 今天的微任务条目
    const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
    const filteredRhythm = rhythmScoreLog.filter((entry: any) => 
      !(entry.date === todayString && entry.actionType === 'microtask_complete')
    );
    localStorage.setItem('rhythmScoreLog', JSON.stringify(filteredRhythm));
    console.log('✅ 重置 rhythmScoreLog');
    
    // 4. 触发更新事件
    window.dispatchEvent(new CustomEvent('microtask-updated'));
    window.dispatchEvent(new CustomEvent('rhythm-score-updated'));
    window.dispatchEvent(new CustomEvent('storage'));
    
    return { oldMicrotaskCount, oldChallengeCount };
    
  } catch (error) {
    console.error('❌ 重置计数器时出错:', error);
    return null;
  }
};

// 完全清理所有微任务数据 - 新增功能
const handleClearAllMicrotasks = () => {
  if (!confirm('⚠️ 这将清除所有微任务数据，包括历史记录。确定继续吗？')) {
    return;
  }
  
  try {
    // 1. 清理 xpTracker 中的所有微任务数据
    const xpTracker = JSON.parse(localStorage.getItem('xpTracker') || '{}');
    Object.keys(xpTracker).forEach(dateKey => {
      if (xpTracker[dateKey]) {
        delete xpTracker[dateKey].microtaskCount;
      }
    });
    localStorage.setItem('xpTracker', JSON.stringify(xpTracker));
    
    // 2. 清理 SignatureMap
    const signatureMap = (window as any).signatureMap;
    if (signatureMap) {
      signatureMap.microtaskLog = [];
      signatureMap.microtaskCount = 0;
      signatureMap.meta.lastUpdated = new Date().toISOString();
    }
    
    // 3. 清理 rhythmScoreLog 中的微任务条目
    const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
    const filteredRhythm = rhythmScoreLog.filter((entry: any) => 
      entry.actionType !== 'microtask_complete'
    );
    localStorage.setItem('rhythmScoreLog', JSON.stringify(filteredRhythm));
    
    // 4. 清理相关的解锁标签和成就
    localStorage.removeItem('unlockedBadges');
    localStorage.removeItem('unlockedMilestones');
    localStorage.removeItem('unlockedTags');
    
    // 5. 触发更新事件
    window.dispatchEvent(new CustomEvent('microtask-updated'));
    window.dispatchEvent(new CustomEvent('rhythm-score-updated'));
    window.dispatchEvent(new CustomEvent('storage'));
    window.dispatchEvent(new CustomEvent('achievement-unlocked'));
    
    alert('✅ 所有微任务数据已清除');
    location.reload();
    
  } catch (error) {
    console.error('❌ 清理微任务数据时出错:', error);
    alert('❌ 清理失败: ' + error.message);
  }
};

// 数据同步检查和修复功能
const handleSyncCheck = () => {
  const todayString = new Date().toISOString().slice(0, 10);
  
  console.log('🔍 开始数据同步检查...');
  
  // 检查各数据源的今天统计
  const checks = {
    signatureMap: 0,
    xpTracker: 0,
    rhythmScoreLog: 0
  };
  
  // SignatureMap 检查
  try {
    const signatureMap = (window as any).signatureMap;
    if (signatureMap) {
      checks.signatureMap = (signatureMap.microtaskLog || []).filter((entry: any) => {
        if (entry.timestamp) {
          const entryDate = new Date(entry.timestamp).toISOString().slice(0, 10);
          return entryDate === todayString;
        }
        return false;
      }).length;
    }
  } catch (e) {
    console.error('SignatureMap 检查失败:', e);
  }
  
  // XpTracker 检查
  try {
    const xpTracker = JSON.parse(localStorage.getItem('xpTracker') || '{}');
    checks.xpTracker = xpTracker[todayString]?.microtaskCount || 0;
  } catch (e) {
    console.error('XpTracker 检查失败:', e);
  }
  
  // RhythmScoreLog 检查
  try {
    const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
    checks.rhythmScoreLog = rhythmScoreLog.filter((entry: any) => 
      entry.date === todayString && entry.actionType === 'microtask_complete'
    ).length;
  } catch (e) {
    console.error('RhythmScoreLog 检查失败:', e);
  }
  
  console.log('📊 数据源检查结果:', checks);
  
  // 检查是否一致
  const allCounts = Object.values(checks);
  const isConsistent = allCounts.every(count => count === allCounts[0]);
  
  if (isConsistent) {
    alert(`✅ 数据同步正常\n今天的微任务数: ${allCounts[0]}`);
  } else {
    const message = `⚠️ 数据不同步\n` +
                   `SignatureMap: ${checks.signatureMap}\n` +
                   `XpTracker: ${checks.xpTracker}\n` +
                   `RhythmScoreLog: ${checks.rhythmScoreLog}\n\n` +
                   `建议使用"重置今天计数器"功能来同步数据`;
    alert(message);
  }
};


  // 设置特定角色的XP值
  const handleSetPersonaXP = () => {
    const persona = prompt('Enter persona name (rhea, caelum, aurelia, lucis, niveus):');
    if (!persona) return;
    
    const validPersonas = ['rhea', 'caelum', 'aurelia', 'lucis', 'niveus'];
    if (!validPersonas.includes(persona.toLowerCase())) {
      alert('❌ Invalid persona name. Please use one of: rhea, caelum, aurelia, lucis, niveus');
      return;
    }
    
    const xpValue = prompt(`Enter XP value for ${persona}:`, '0');
    if (xpValue === null) return;
    
    const xpNumber = parseInt(xpValue, 10);
    if (isNaN(xpNumber)) {
      alert('❌ Please enter a valid number for XP.');
      return;
    }
    
    // 设置XP
    setPersonaXp(persona.toLowerCase(), xpNumber);
    alert(`✅ Set ${persona}'s XP to ${xpNumber}.`);
  };

  // 显示当前所有角色XP
  const handleShowAllXP = () => {
    const xpData = getXpData();
    let message = "Current XP values:\n\n";
    
    ['rhea', 'caelum', 'aurelia', 'lucis', 'niveus'].forEach(persona => {
      const xp = xpData[persona]?.xp || 0;
      message += `${persona}: ${xp} XP\n`;
    });
    
    alert(message);
  };

  // 显示当前日常追踪器状态
  const handleShowDailyTrackers = () => {
    const xpTracker = getXpTracker();
    const today = getTodayDateKey();
    
    let message = "Current Daily Tracker Status:\n\n";
    message += `Today (${today}):\n`;
    message += `- Microtasks: ${xpTracker[today]?.microtaskCount || 0}/3\n`;
    message += `- Challenges: ${xpTracker[today]?.challengeCount || 0}/2\n\n`;
    
    // 显示最近几天的记录
    const dates = Object.keys(xpTracker).sort().reverse().slice(0, 5);
    if (dates.length > 1) {
      message += "Recent history:\n";
      dates.forEach(date => {
        if (date !== today) {
          message += `${date}:\n`;
          message += `- Microtasks: ${xpTracker[date]?.microtaskCount || 0}/3\n`;
          message += `- Challenges: ${xpTracker[date]?.challengeCount || 0}/2\n`;
        }
      });
    }
    
    alert(message);
  };

  // 检查和修复XP数据 - 新增
  const handleCheckAndFixXP = () => {
    try {
      // 读取当前XP数据
      const xpData = getXpData();
      console.log('当前XP数据:', xpData);
      
      // 检查挑战记录
      const challengeLog = JSON.parse(localStorage.getItem('challengeLog') || '[]');
      console.log('挑战记录:', challengeLog);
      
      // 统计每个persona完成的挑战数量
      const personaChallenges: Record<string, number> = {};
      challengeLog.forEach((entry: any) => {
        if (!entry.persona) return;
        
        const persona = entry.persona.toLowerCase();
        if (!personaChallenges[persona]) personaChallenges[persona] = 0;
        personaChallenges[persona]++;
      });
      
      console.log('每个persona完成的挑战数量:', personaChallenges);
      
      // 根据挑战记录修复XP
      let fixed = false;
      let message = "XP检查和修复结果:\n\n";
      
      Object.entries(personaChallenges).forEach(([persona, challengeCount]) => {
        // 每个挑战6 XP
        const expectedXp = challengeCount * 6;
        
        if (!xpData[persona]) {
          xpData[persona] = { xp: 0, history: [] };
        }
        
        const currentXp = xpData[persona].xp || 0;
        message += `${persona}: 当前${currentXp}XP, 完成${challengeCount}个挑战\n`;
        
        // 如果XP不符合预期，进行修复
        if (currentXp !== expectedXp) {
          xpData[persona].xp = expectedXp;
          xpData[persona].history.push({
            amount: expectedXp - currentXp,
            timestamp: new Date().toISOString(),
            note: 'Auto-repaired based on challenge count'
          });
          fixed = true;
          message += `  ⚠️ 修复: ${currentXp} → ${expectedXp} XP\n`;
        } else {
          message += `  ✓ XP值正确\n`;
        }
      });
      
      // 保存修复后的数据
      if (fixed) {
        localStorage.setItem('personaXpLog', JSON.stringify(xpData));
        console.log('已保存修复后的XP数据');
        message += "\n✅ XP数据已修复!";
        
        // 触发更新事件
        window.dispatchEvent(new Event('xp-updated'));
      } else {
        message += "\n✓ 所有XP数据正确!";
      }
      
      alert(message);
    } catch (error) {
      console.error('检查和修复XP数据时出错:', error);
      alert(`❌ 检查过程中出错: ${error instanceof Error ? error.message : String(error)}`);
    }
  };

  // 强制刷新XP数据
  const handleForceRefreshXP = () => {
    forceRefreshAllXpData();
    alert('✅ XP data has been force refreshed. Check the console for details.');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 py-12 text-center space-y-6">
      <h1 className="text-2xl font-bold text-red-600">🧨 Developer Reset Page</h1>
      <p className="text-sm text-gray-600 max-w-md">
        This will <strong>permanently clear</strong> all local data from RhythmOS Beta,
        including your onboarding status, CRE feedback, rhythm logs, tone preferences, and challenges.
      </p>

      <button
        onClick={handleReset}
        className="px-5 py-2 bg-red-600 text-white rounded shadow hover:bg-red-700 text-sm"
      >
        🔄 Reset All Local Data
      </button>

      <div className="w-full border-t border-gray-300 my-4"></div>

      <h2 className="text-xl font-bold text-indigo-600">🧪 Rhythm Day Simulation</h2>
      <p className="text-xs text-gray-500">
        This will simulate that yesterday was finalized, allowing you to start a new rhythm day immediately.
      </p>

      <button
        onClick={handleSimulateNewDay}
        className="px-5 py-2 bg-indigo-600 text-white rounded shadow hover:bg-indigo-700 text-sm"
      >
        🔄 Simulate New Rhythm Day
      </button>

      <div className="w-full border-t border-gray-300 my-4"></div>

      <h2 className="text-md font-semibold text-gray-700">🎯 Selective Clear Options</h2>

      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={handleClearChallenges}
          className="px-4 py-2 bg-yellow-500 text-white rounded shadow hover:bg-yellow-600 text-sm"
        >
          🧹 Clear Only Challenge Logs
        </button>

        <button
          onClick={handleClearGoals}
          className="px-4 py-2 bg-blue-500 text-white rounded shadow hover:bg-blue-600 text-sm"
        >
          🧹 Clear Only Goal + Subtasks
        </button>
      </div>

      <div className="w-full border-t border-gray-300 my-4"></div>

      <h2 className="text-md font-semibold text-gray-700">✨ XP Management</h2>
      
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={handleResetAllXP}
          className="px-4 py-2 bg-purple-500 text-white rounded shadow hover:bg-purple-600 text-sm"
        >
          🔄 Reset All Persona XP
        </button>
        
        <button
          onClick={handleSetPersonaXP}
          className="px-4 py-2 bg-green-500 text-white rounded shadow hover:bg-green-600 text-sm"
        >
          ✏️ Set Specific Persona XP
        </button>
        
        <button
          onClick={handleResetTodayTrackers}
          className="px-4 py-2 bg-orange-500 text-white rounded shadow hover:bg-orange-600 text-sm"
        >
          🔄 Reset Today's Counters
        </button>
        
        <button
          onClick={handleShowAllXP}
          className="px-4 py-2 bg-teal-500 text-white rounded shadow hover:bg-teal-600 text-sm"
        >
          👁️ Show All XP Values
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3 mt-2">
        <button
          onClick={handleCheckAndFixXP}
          className="px-4 py-2 bg-amber-500 text-white rounded shadow hover:bg-amber-600 text-sm"
        >
          🔧 Check & Fix XP Data
        </button>
        
        <button
          onClick={handleForceRefreshXP}
          className="px-4 py-2 bg-rose-500 text-white rounded shadow hover:bg-rose-600 text-sm"
        >
          🔄 Force Refresh XP
        </button>
      </div>
      
      <button
        onClick={handleShowDailyTrackers}
        className="px-4 py-2 bg-gray-500 text-white rounded shadow hover:bg-gray-600 text-sm"
      >
        📊 Show Daily Counter Status
      </button>

      <p className="text-xs text-gray-400 mt-4">For testing rhythm daily flow transitions and edge states.</p>
      
      <div className="text-xs text-left p-4 bg-gray-100 rounded w-full max-w-md mt-6">
  <p className="font-medium mb-2">XP Repair Guide:</p>
  <ul className="list-disc pl-5 space-y-1">
    <li>If you completed challenges but XP wasn't added, use "Check & Fix XP Data"</li>
    <li>This function will recalculate expected XP based on challenge records</li>
    <li>Each completed challenge should earn 6 XP</li>
    <li>If XP values are incorrect, it will automatically repair and save them</li>
    <li>If issues persist, use "Force Refresh XP" to force a refresh</li>
  </ul>
</div>
    </div>
  );
};

export default DevResetPage;


