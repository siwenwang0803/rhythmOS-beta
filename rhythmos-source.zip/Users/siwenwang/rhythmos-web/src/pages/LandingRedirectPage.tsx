import React from 'react';
import { Navigate } from 'react-router-dom';

const LandingRedirectPage: React.FC = () => {
  const hasPersona = localStorage.getItem('initPersona');

  if (!hasPersona) {
    // 未完成 onboarding，跳转到初始步骤
    return <Navigate to="/onboarding/step1" replace />;
  }

  // 已完成 onboarding，进入主流程
  return <Navigate to="/rhythm/checkin" replace />;
};

export default LandingRedirectPage;
