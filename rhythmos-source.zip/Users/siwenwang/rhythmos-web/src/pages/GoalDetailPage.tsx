import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getRhythmGoals, updateGoalStatus } from '../rhythmGoal';
import { updateSubtaskStatus, getSubtasksForGoal, saveSubtasks, generateInitialSubtasks } from '../rhythmSubtasks';
import { getRhythmTrend, getRecentRhythmLogs } from '../rhythmLog';
import { handleCompleteSubtask, handleCompleteGoal } from '../utils/handleRhythmCompletion';
import { writeSubtaskIntentLog } from '../utils/subtaskLog';
import TaskTimelineChart from '../components/TaskTimelineChart';
import { Goal } from '../rhythmGoal';
import RhythmStudioPanel from '../components/ui/RhythmStudioPanel';
import RhythmButton from '../components/ui/RhythmButton';
import FooterNavigation from '../components/FooterNavigation';
import { generateSubtaskSuggestions } from '../generateSubtaskSuggestions';
import { classifyGoalIntent } from '../goalIntentClassifier';
import SubtaskDebugTool from '../components/SubtaskDebugTool';

import { generatePostGoalReflection } from '../utils/generatePostGoalReflection';
import PostGoalReflectionCard from '../components/PostGoalReflectionCard';

// RhythmOS colors from the UI spec
const rhythmColors = {
  sand: '#F5E8C7',    // Sand base: warmth and psychological safety
  collapsed: '#AEC6CF', // Gentle calming blue
  wavy: '#C3B1E1',    // Transitional lavender
  stable: '#C5D8A4',  // Grounded light green
  rising: '#FFB347',  // Activating orange-yellow
  accent: '#F7DC6F'   // Soft yellow for CTA/completion
};

const GoalDetailPage: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [goalAbandoned, setGoalAbandoned] = useState(false);
  const [goalCompleted, setGoalCompleted] = useState(false);
  const [subtaskState, setSubtaskState] = useState<any[]>([]);
  const [reflection, setReflection] = useState<any | null>(null);
  const [showReflection, setShowReflection] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [showEmptyWarning, setShowEmptyWarning] = useState(false);
  // Add rhythm state tracking
  const [rhythmState, setRhythmState] = useState('collapsed');
  // Add completion transition state
  const [isCompleting, setIsCompleting] = useState(false);

  const goals: Goal[] = getRhythmGoals();
  const goal = goals.find((g) => g.id.toLowerCase() === id?.toLowerCase());

  // 早期返回处理
  if (!goal) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-red-50">
        <div className="p-6 rounded-lg shadow-sm border border-red-200 bg-white text-red-600 max-w-md text-center">
          <div className="text-3xl mb-2">❌</div>
          <h2 className="text-lg font-medium mb-2">Goal not found</h2>
          <p className="text-sm text-red-500 mb-4">Check the ID or create a new goal.</p>
          <RhythmButton variant="primary" onClick={() => navigate('/goals')}>
            Return to Goals
          </RhythmButton>
        </div>
      </div>
    );
  }

  const recent = getRecentRhythmLogs(5);
  const trend = getRhythmTrend(recent);

  // 日志辅助函数
  const logDebug = (message: string, data?: any) => {
    console.log(`[GoalDetail] ${message}`, data || '');
  };

  // 创建阅读特定的子任务
  const createReadingSubtasks = (goalId: string, goalTitle: string) => {
    const readingSubtasks = [
      {
        id: crypto.randomUUID(),
        goalId,
        parentGoalId: goalId,
        title: 'Choose which book to read first',
        text: 'Choose which book to read first',
        createdAt: new Date().toISOString(),
        status: 'pending',
        difficulty: 'minimal',
        cue: 'Small choices lead to big journeys.'
      },
      {
        id: crypto.randomUUID(),
        goalId,
        parentGoalId: goalId,
        title: 'Schedule dedicated reading time in your calendar',
        text: 'Schedule dedicated reading time in your calendar',
        createdAt: new Date().toISOString(),
        status: 'pending',
        difficulty: 'light',
        cue: 'Protected time creates meaningful space.'
      },
      {
        id: crypto.randomUUID(),
        goalId,
        parentGoalId: goalId,
        title: 'Read the first chapter and take notes',
        text: 'Read the first chapter and take notes',
        createdAt: new Date().toISOString(),
        status: 'pending',
        difficulty: 'normal',
        cue: 'The first step is often the most important.'
      }
    ];
    
    return readingSubtasks;
  };

  // 处理存储事件
  const handleStorageChange = () => {
    if (id) {
      const updatedSubtasks = getSubtasksForGoal(id);
      setSubtaskState(updatedSubtasks);
    }
  };

  useEffect(() => {
    if (!id) {
      setIsLoading(false);
      return;
    }

    // 添加存储事件监听器
    window.addEventListener('storage', handleStorageChange);
    
    // 从 localStorage 获取目标的子任务
    const existingSubtasks = getSubtasksForGoal(id);
    logDebug('Existing subtasks found:', existingSubtasks.length);
    
    // 如果没有子任务，则生成初始子任务
    if (existingSubtasks.length === 0 && goal) {
      logDebug('No existing subtasks found, generating initial subtasks');
      
      // 处理"阅读书籍"类型的目标
      if (goal.title.toLowerCase().includes('read') && goal.title.toLowerCase().includes('book')) {
        logDebug('Creating reading-specific subtasks');
        const readingSubtasks = createReadingSubtasks(id, goal.title);
        saveSubtasks(readingSubtasks);
        setSubtaskState(readingSubtasks);
      } else {
        // 1. 识别目标意图
        const intent = classifyGoalIntent(goal.title || '');
        logDebug('Classified goal intent:', intent);
        
        // 2. 根据目标生成建议的子任务
        const suggestions = generateSubtaskSuggestions(goal.title || '', trend);
        logDebug('Generated subtask suggestions:', suggestions);
        
        // 3. 将建议转换为子任务结构
        const newSubtasks = suggestions.map((suggestion, index) => ({
          id: crypto.randomUUID(),
          parentGoalId: id, 
          goalId: id,
          text: suggestion.text,
          title: suggestion.text,
          createdAt: new Date().toISOString(),
          status: 'pending',
          difficulty: ['minimal', 'light', 'normal', 'challenge'][index % 4],
          cue: suggestion.cue,
          tone: suggestion.tone,
          taskType: suggestion.taskType
        }));
        
        // 如果没有生成建议，使用通用子任务模板
        if (newSubtasks.length === 0) {
          logDebug('No suggestions generated, using fallback template');
          const fallbackSubtasks = generateInitialSubtasks(id, goal.title || '');
          
          saveSubtasks(fallbackSubtasks);
          setSubtaskState(fallbackSubtasks);
        } else {
          // 保存建议的子任务
          logDebug('Saving generated subtasks');
          saveSubtasks(newSubtasks);
          setSubtaskState(newSubtasks);
        }
      }
    } else {
      // 使用现有子任务
      logDebug('Using existing subtasks:', existingSubtasks);
      setSubtaskState(existingSubtasks);
      
      // 检查是否有文本内容
      const hasTextContent = existingSubtasks.some(
        sub => sub.text || sub.title
      );
      
      if (!hasTextContent) {
        setShowEmptyWarning(true);
      }
    }
    
    setIsLoading(false);
    
    // 清理函数
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [id, goal?.title, trend]);

  // Calculate progress and update rhythm state
  useEffect(() => {
    const completedCount = subtaskState.filter(t => t.status === 'completed').length;
    const totalCount = subtaskState.length;
    
    if (totalCount === 0) return;
    
    const progressPercent = Math.round((completedCount / totalCount) * 100);
    
    // Set rhythm state based on progress
    if (progressPercent === 0) {
      setRhythmState('collapsed');
    } else if (progressPercent < 33) {
      setRhythmState('wavy');
    } else if (progressPercent < 66) {
      setRhythmState('stable');
    } else {
      setRhythmState('rising');
    }
  }, [subtaskState]);

  // 检查目标是否已完成并设置相应状态
  useEffect(() => {
    if (goal && goal.status === 'completed') {
      setGoalCompleted(true);
    }
  }, [goal]);

  const completedCount = subtaskState.filter(t => t.status === 'completed').length;
  const totalCount = subtaskState.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const handleToggleSubtask = (subId: string, status: string) => {
    if (status === 'completed') return;
    if (!window.confirm('Mark this subtask as complete?')) return;

    updateSubtaskStatus(subId, 'completed');
    handleCompleteSubtask(subId);

    const matched = subtaskState.find((s) => s.id === subId);
    const taskType = matched?.difficulty || 'unknown';
    writeSubtaskIntentLog(subId, taskType);

    const updated = subtaskState.map(sub =>
      sub.id === subId ? { ...sub, status: 'completed' } : sub
    );
    setSubtaskState(updated);
  };

  const handleGoalComplete = () => {
    if (!window.confirm('Mark this goal as complete?')) return;

    // 设置状态为完成中，触发视觉反馈
    setIsCompleting(true);
    setRhythmState('rising');

    // 更新所有子任务状态为已完成
    subtaskState.forEach(sub => {
      if (sub.status !== 'completed') {
        updateSubtaskStatus(sub.id, 'completed');
      }
    });
    
    // 更新目标状态为已完成
    updateGoalStatus(goal.id, 'completed');

    // 处理目标完成的奖励逻辑
    const subtaskIds = subtaskState.map(sub => sub.id);
    handleCompleteGoal(goal.id, subtaskIds);

    // 生成反思
    const generated = generatePostGoalReflection(goal.title || goal.notes || '');
    setReflection(generated);
    
    // 设置状态标记为已完成
    setGoalCompleted(true);
    
    // 更新进度为100%
    const updatedSubtasks = subtaskState.map(sub => ({ ...sub, status: 'completed' }));
    setSubtaskState(updatedSubtasks);

    // 显示反思卡片
    setTimeout(() => {
      setShowReflection(true);
      setIsCompleting(false);
    }, 800);
  };

  // 处理反思卡片关闭后的导航
  const handleReflectionDismiss = () => {
    setShowReflection(false);
    // 给用户一点时间看到变化，然后导航回目标列表
    setTimeout(() => {
      navigate('/goals');
    }, 300);
  };

  const handleGoalAbandon = () => {
    const confirmed = window.confirm('Are you sure you want to abandon this goal?');
    if (!confirmed || !goal?.id) return;
    updateGoalStatus(goal.id, 'abandoned');
    alert('This goal has been marked as abandoned.');
    setGoalAbandoned(true);
    navigate('/goals');
  };

  // Map difficulty to colors based on rhythm colors
  const getDifficultyColor = (difficulty: string) => {
    switch(difficulty) {
      case 'minimal': return rhythmColors.collapsed;
      case 'light': return rhythmColors.wavy;
      case 'normal': return rhythmColors.stable;
      case 'challenge': return rhythmColors.rising;
      default: return rhythmColors.sand;
    }
  };

  // Get panel tone based on rhythm state
  const getPanelTone = () => {
    switch(rhythmState) {
      case 'collapsed': return 'blue';
      case 'wavy': return 'purple';
      case 'stable': return 'green';
      case 'rising': return 'yellow';
      default: return 'default';
    }
  };

  // 显示加载状态
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: `${rhythmColors.sand}20` }}>
        <div className="text-center p-8 rounded-lg shadow-sm bg-white">
          <div style={{ 
            width: "48px", 
            height: "48px", 
            border: `4px solid ${rhythmColors.sand}`, 
            borderTopColor: rhythmColors.rising,
            borderRadius: "50%",
            margin: "0 auto 16px",
            animation: "spin 1s linear infinite"
          }}></div>
          <style>
            {`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}
          </style>
          <p className="text-gray-600 font-medium">Loading goal details...</p>
        </div>
      </div>
    );
  }

  // 计算完成动画样式
  const getCompletingStyle = () => {
    if (!isCompleting) return {};

    return {
      animation: 'pulseComplete 1.5s ease-in-out',
    };
  };

  return (
    <div 
      className="min-h-screen px-6 py-10 max-w-3xl mx-auto space-y-10"
      style={{ 
        backgroundImage: `linear-gradient(to bottom, ${rhythmColors.sand}20 0%, #FFFFFF 100%)`,
        transition: 'background-image 0.5s ease'
      }}
    >
      <style>
        {`
          @keyframes pulseComplete {
            0% { transform: scale(1); }
            50% { transform: scale(1.02); }
            100% { transform: scale(1); }
          }
        `}
      </style>
      
      <RhythmStudioPanel
        title={`🎯 ${goal.title}`}
        subtitle={goal.createdAt ? `Created on ${new Date(goal.createdAt).toLocaleDateString()}` : ''}
        tone={getPanelTone()}
      >
        {goal.notes && (
          <p className="text-sm text-gray-600 mb-4 bg-white bg-opacity-70 p-3 rounded-lg">{goal.notes}</p>
        )}

        <div 
          className="mb-6 p-4 rounded-lg shadow-sm flex items-center"
          style={{ 
            backgroundColor: `${rhythmColors[rhythmState as keyof typeof rhythmColors]}20`,
            borderLeft: `4px solid ${rhythmColors[rhythmState as keyof typeof rhythmColors]}`,
            transition: 'all 0.3s ease',
            ...getCompletingStyle()
          }}
        >
          <div 
            className="w-12 h-12 rounded-full flex items-center justify-center mr-4 text-lg font-bold"
            style={{ 
              backgroundColor: isCompleting || goalCompleted 
                ? rhythmColors.accent 
                : rhythmColors[rhythmState as keyof typeof rhythmColors],
              color: '#333333',
              transition: 'all 0.3s ease'
            }}
          >
            {isCompleting || goalCompleted ? '100%' : `${progressPercent}%`}
          </div>
          <div>
            <div className="text-sm font-medium mb-1 text-gray-700">Progress</div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="h-2.5 rounded-full" 
                style={{ 
                  width: isCompleting || goalCompleted ? '100%' : `${progressPercent}%`,
                  backgroundColor: isCompleting || goalCompleted 
                    ? rhythmColors.accent 
                    : rhythmColors[rhythmState as keyof typeof rhythmColors],
                  transition: 'width 0.5s ease-out, background-color 0.3s ease'
                }}
              ></div>
            </div>
          </div>
        </div>

        {subtaskState.length === 0 ? (
          <div className="p-5 border border-yellow-300 bg-yellow-50 rounded-lg text-sm text-yellow-800 mb-6 shadow-sm">
            <p className="font-medium flex items-center">
              <span className="mr-2">⚠️</span>
              No subtasks found for this goal
            </p>
            <p className="mt-2 ml-6">This goal doesn't have any subtasks yet. Try refreshing the page or creating subtasks manually.</p>
          </div>
        ) : showEmptyWarning ? (
          <div className="p-5 border border-yellow-300 bg-yellow-50 rounded-lg text-sm text-yellow-800 mb-6 shadow-sm">
            <p className="font-medium flex items-center">
              <span className="mr-2">⚠️</span>
              Subtasks found but missing content
            </p>
            <p className="mt-2 ml-6">Found {subtaskState.length} subtasks, but they seem to be missing content. Use the debug tool below.</p>
          </div>
        ) : (
          <div className="space-y-4 mb-8">
            {subtaskState.map((sub) => (
              <div
                key={sub.id}
                className="border rounded-lg shadow-sm transition-all duration-300 overflow-hidden"
                style={{ 
                  borderColor: sub.status === 'completed' || isCompleting || goalCompleted
                    ? rhythmColors.stable 
                    : getDifficultyColor(sub.difficulty),
                  backgroundColor: sub.status === 'completed' || isCompleting || goalCompleted
                    ? `${rhythmColors.stable}15` 
                    : '#FFFFFF',
                  transform: sub.status === 'completed' || isCompleting || goalCompleted ? 'scale(0.99)' : 'scale(1)',
                }}
              >
                <div className="px-5 py-4 flex justify-between items-center">
                  <div className="flex-1">
                    <p 
                      className="text-sm font-medium text-gray-800"
                      style={{ 
                        textDecoration: sub.status === 'completed' || isCompleting || goalCompleted ? 'line-through' : 'none',
                        opacity: sub.status === 'completed' || isCompleting || goalCompleted ? 0.8 : 1
                      }}
                    >
                      {sub.text || sub.title || `Subtask ${sub.id.substring(0, 4)}`}
                    </p>
                    
                    <div className="flex items-center mt-1">
                      <span 
                        className="inline-block w-2 h-2 rounded-full mr-2"
                        style={{ backgroundColor: getDifficultyColor(sub.difficulty) }}
                      ></span>
                      <p className="text-xs text-gray-500">
                        {sub.difficulty.charAt(0).toUpperCase() + sub.difficulty.slice(1)}
                      </p>
                    </div>

                    {sub.cue && (
                      <div 
                        className="mt-2 text-xs italic px-3 py-2 rounded"
                        style={{ 
                          backgroundColor: `${getDifficultyColor(sub.difficulty)}15`,
                          color: '#333333',
                        }}
                      >
                        "{sub.cue}"
                      </div>
                    )}
                  </div>

                  {sub.status !== 'completed' && !isCompleting && !goalCompleted ? (
                    <RhythmButton
                      onClick={() => handleToggleSubtask(sub.id, sub.status)}
                      variant="primary"
                      tone={rhythmState as any}
                      style={{ padding: '6px 12px', fontSize: '13px' }}
                    >
                      <span className="flex items-center gap-1">
                        <span>✅</span>
                        <span>Complete</span>
                      </span>
                    </RhythmButton>
                  ) : (
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center"
                      style={{ 
                        backgroundColor: rhythmColors.stable,
                        color: '#FFFFFF',
                      }}
                    >
                      ✓
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-8 mb-6 bg-white bg-opacity-70 p-4 rounded-lg shadow-sm">
          <TaskTimelineChart />
        </div>

    

<div className="mt-8 flex flex-wrap gap-4">
  {/* 返回按钮 - 始终显示 */}
  <RhythmButton 
    onClick={() => navigate('/goals')}
    variant="secondary"
    style={{ 
      backgroundColor: rhythmColors.stable,
      padding: '10px 20px',
    }}
  >
    <span className="flex items-center gap-2">
      <span>←</span>
      <span>Return to Goals</span>
    </span>
  </RhythmButton>
  
  {/* 目标操作按钮 - 仅在目标未完成时显示 */}
  {!goalCompleted && !isCompleting && (
    <>
      <RhythmButton 
        onClick={handleGoalComplete} 
        variant="primary"
        style={{ 
          backgroundColor: rhythmColors.rising,
          padding: '10px 20px',
          boxShadow: '0 4px 12px rgba(255, 179, 71, 0.2)'
        }}
      >
        <span className="flex items-center gap-2">
          <span>🎯</span>
          <span>Mark Goal Complete</span>
        </span>
      </RhythmButton>
      
      <RhythmButton 
        onClick={handleGoalAbandon} 
        variant="danger"
      >
        <span className="flex items-center gap-2">
          <span>❌</span>
          <span>Abandon Goal</span>
        </span>
      </RhythmButton>
    </>
  )}
</div>

{/* Post Goal Reflection */}
{showReflection && reflection && (
  <div 
    className="mt-8 border-t border-gray-200 pt-6"
    style={{ 
      animation: 'fadeIn 0.5s ease-out'
    }}
  >
    <style>
      {`@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }`}
    </style>
    <PostGoalReflectionCard
      cue={reflection.cue}
      paragraph={reflection.paragraph}
      action={reflection.action}
      onDismiss={handleReflectionDismiss}
    />
  </div>
)}
        
        {/* 调试工具 */}
        {id && !goalCompleted && <SubtaskDebugTool goalId={id} />}
      </RhythmStudioPanel>

      <FooterNavigation />
    </div>
  );
};

export default GoalDetailPage;









