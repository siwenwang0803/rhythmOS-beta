import React from 'react';
import { useNavigate } from 'react-router-dom';

const steps = [
    {
      title: 'Step 0: Beta Welcome Page (Optional)',
      path: '/beta',
      emoji: '👋',
      desc: 'Intro to RhythmOS + guide to onboarding steps.'
    },
    {
      title: 'Step 1: Rhythm State Selection',
      path: '/onboarding/step1',
      emoji: '🌡️',
      desc: 'Choose your current rhythm trend. Only needed on first day.'
    },
    {
      title: 'Step 2: Tone Preference Setup',
      path: '/onboarding/step2',
      emoji: '🎙️',
      desc: 'Choose your preferred system speaking tone.'
    },
    {
      title: 'Step 3: MBTI → Persona Mapping',
      path: '/identity/mbti',
      emoji: '🧬',
      desc: 'Select your MBTI. Used to assign fallback persona.'
    },
    {
      title: 'Step 4: Identity Anchoring',
      path: '/identity/start',
      emoji: '🎯',
      desc: 'Set your transformation goal. Choose or confirm a training persona.'
    },
    {
      title: 'Daily Step 1: Rhythm Check-In',
      path: '/rhythm',
      emoji: '📆',
      desc: 'Your daily starting point. Choose rhythm + generate CRE cue.'
    },
    {
      title: 'Daily Step 2: Identity Cue × Feedback',
      path: '/identity/train',
      emoji: '📚',
      desc: 'Train with CRE cue, give feedback, and reflect with tone insight.'
    },
    {
      title: 'Daily Step 3: Subgoal Progress',
      path: '/goals',
      emoji: '🎯',
      desc: 'Select a challenge task. Track subtask completion aligned with persona.'
    },
    {
      title: 'Daily Step 4: Feedback Insight Review',
      path: '/identity/insight',
      emoji: '🧠',
      desc: 'Review your tone alignment, persona usage, and rhythm trajectory.'
    }
  ];
  

const OnboardingFlowPreview: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="max-w-4xl mx-auto px-6 py-12 space-y-10 text-gray-800">
      <h1 className="text-2xl font-bold text-indigo-700 text-center">🧭 RhythmOS Flow Preview</h1>
      <p className="text-sm text-gray-600 text-center">
        This is the full experience flow from onboarding to rhythm tracking and feedback insight.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {steps.map((step, i) => (
          <div
            key={i}
            className="border border-indigo-200 rounded-lg p-4 shadow-sm hover:shadow transition bg-white"
          >
            <div className="text-lg font-semibold flex items-center gap-2 text-indigo-700">
              <span>{step.emoji}</span> {step.title}
            </div>
            <p className="text-sm text-gray-600 mt-2">{step.desc}</p>
            <button
              onClick={() => navigate(step.path)}
              className="mt-3 text-xs text-blue-600 underline hover:text-blue-800"
            >
              Go to → {step.path}
            </button>
          </div>
        ))}
      </div>
      <div className="text-center pt-8">
  <a
    href="/"
    className="inline-block px-4 py-2 text-sm font-medium bg-gray-100 text-gray-800 rounded-md shadow hover:bg-gray-200 transition"
  >
    🔙 Return to Beta Welcome Page
  </a>
</div>

      <p className="text-center text-xs text-gray-400 pt-6">RhythmOS Beta v0.91 · Flow Debug Mode</p>
    </div>
  );
};

export default OnboardingFlowPreview;
