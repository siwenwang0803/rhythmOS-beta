// /pages/IdentityGrowthPage.tsx

import React, { useState } from 'react';
import PersonaProgressCard from '../components/PersonaProgressCard';
import BadgeGallery from '../components/BadgeGallery';
import MilestoneTracker from '../components/MilestoneTracker';
import EndMyDayButton from '../components/EndMyDayButton';
import FooterNavigation from '../components/FooterNavigation';
import { BetaOnboardingTip } from '../components/BetaOnboardingTip';
import HowXpWorks from '../components/HowXpWorks';
import PersonaIdentityPathSelector from '../components/PersonaIdentityPathSelector';
const IDENTITY_PERSONAS = ['rhea', 'caelum', 'aurelia', 'lucis', 'niveus'];

const IdentityGrowthPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('progress');
  
  return (
    <div className="min-h-screen bg-[#F5E8C7] pb-20">
      {/* 标题区域 */}
      <div className="px-6 pt-10 pb-4 bg-gradient-to-b from-[#F5E8C7] to-[#F5E8C7]/80">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-[#333333] flex items-center">
            <span className="mr-2">🌱</span> Your Identity Growth Room
          </h1>
          <p className="text-[#333333]/80 mt-2">
            Explore your growth across personas, achievements, and milestones.
          </p>
        </div>

        {/* 标签导航 */}
        <div className="flex space-x-1 mt-6 border-b border-[#333333]/10">
          <button 
            onClick={() => setActiveTab('progress')}
            className={`px-4 py-2 text-sm font-medium rounded-t-lg transition-colors ${
              activeTab === 'progress' 
                ? 'bg-[#F7DC6F]/30 text-[#333333]' 
                : 'text-[#333333]/70 hover:text-[#333333]'
            }`}
          >
            Personas
          </button>
          <button 
            onClick={() => setActiveTab('badges')}
            className={`px-4 py-2 text-sm font-medium rounded-t-lg transition-colors ${
              activeTab === 'badges' 
                ? 'bg-[#F7DC6F]/30 text-[#333333]' 
                : 'text-[#333333]/70 hover:text-[#333333]'
            }`}
          >
            Badges
          </button>
          <button 
            onClick={() => setActiveTab('milestones')}
            className={`px-4 py-2 text-sm font-medium rounded-t-lg transition-colors ${
              activeTab === 'milestones' 
                ? 'bg-[#F7DC6F]/30 text-[#333333]' 
                : 'text-[#333333]/70 hover:text-[#333333]'
            }`}
          >
            Journey
          </button>
        </div>
      </div>

      <div className="px-6 max-w-4xl mx-auto">
        {/* Persona Progress 标签 */}
        {activeTab === 'progress' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-2 mt-4">
              <h2 className="text-lg font-semibold text-[#333333] flex items-center">
                <span className="mr-2">🎯</span> Persona Progress
              </h2>
              <div className="text-sm text-[#333333]/70">5/5 Active</div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {IDENTITY_PERSONAS.map(p => (
                <PersonaProgressCard key={p} persona={p} />
              ))}
            </div>
            
            {/* 替换为导入的HowXpWorks组件 */}
            <HowXpWorks />
          </div>
        )}

        {/* Badges 标签 */}
        {activeTab === 'badges' && (
          <div className="space-y-4 mt-4">
            <h2 className="text-lg font-semibold text-[#333333] flex items-center">
              <span className="mr-2">🏆</span> Unlocked Badges
            </h2>
            <BadgeGallery />
            
            <div className="bg-gradient-to-r from-[#F5E8C7] to-[#F7DC6F]/30 rounded-lg p-4 mt-6 shadow-sm">
              <h3 className="text-md font-medium text-[#333333] mb-2">Next Goal</h3>
              <p className="text-sm text-[#333333]/80">
                Keep interacting with Rhea persona to unlock the "Rhea ×5" badge. Just 3 more interactions needed!
              </p>
            </div>
          </div>
        )}

        {/* Milestones 标签 */}
        {activeTab === 'milestones' && (
          <div className="space-y-4 mt-4">
            <h2 className="text-lg font-semibold text-[#333333] flex items-center">
              <span className="mr-2">📈</span> Growth Milestones
            </h2>
            <MilestoneTracker />
            
            
            <div className="bg-white rounded-lg p-4 mt-6 shadow-sm border-l-4 border-[#FFB347]">
              <div className="flex items-start">
                <div className="text-2xl mr-3">💫</div>
                <div>
                  <h3 className="text-md font-medium text-[#333333]">System Insight</h3>
                  <p className="text-sm text-[#333333]/80 mt-1">
                    You've completed 40% of your initial growth journey. Focus on maintaining a daily streak to unlock more powerful persona features.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
        <PersonaIdentityPathSelector />
        <BetaOnboardingTip />
        
        {/* End My Day 按钮 */}
        <div className="mt-8 mb-16">
          <EndMyDayButton className="w-full bg-gradient-to-r from-[#F5E8C7] to-[#F7DC6F] hover:from-[#F7DC6F] hover:to-[#F7DC6F] text-[#333333] font-medium py-3 px-4 rounded-lg shadow-sm transition-all duration-300 hover:shadow-md flex justify-center items-center">
            <span className="mr-2">🌙</span> End My Day
          </EndMyDayButton>
        </div>
      </div>
      
      <FooterNavigation />
    </div>
  );
};

export default IdentityGrowthPage;
