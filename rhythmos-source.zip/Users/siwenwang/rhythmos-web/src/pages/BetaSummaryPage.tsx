import React from "react";
import BetaBuildBanner from '../components/BetaBuildBanner';

const BetaSummaryPage: React.FC = () => {
  const buildDate = new Date().toISOString();
  

  return (
    <div className="max-w-3xl mx-auto px-6 py-12 space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">📦 RhythmOS Beta Release Summary</h1>

      <div className="text-sm text-gray-700 space-y-4">
        <p><strong>Version:</strong> v0.9-beta</p>
        <p><strong>Build Date:</strong> {buildDate}</p>

        <div>
          <h2 className="text-lg font-semibold mt-4">✅ Included Modules</h2>
          <ul className="list-disc ml-6">
            <li>Onboarding flow (trend, tone, persona)</li>
            <li>Daily check-in + CRE cue generation</li>
            <li>Identity Challenge (cue + action + feedback)</li>
            <li>SignatureMap and Tone Feedback tracking</li>
            <li>Goal setting + Subtask suggestion system</li>
            <li>Daily rhythm scoring system</li>
            <li>Insight dashboard (trend chart + radar map)</li>
            <li>Guide page for user concepts</li>
            <li>DevResetPage (reset, simulate new day)</li>
          </ul>
        </div>

        <div>
          <h2 className="text-lg font-semibold mt-6">🧪 Known Issues / Limitations</h2>
          <ul className="list-disc ml-6">
            <li>CRE cues, task suggestions, and identity challenges are currently pre-authored only — dynamic generation via GPT or LLMs is not yet integrated</li>
            <li>Mobile responsiveness still being optimized</li>
          </ul>
        </div>

        <div>
          <h2 className="text-lg font-semibold mt-6">📬 Beta Tester Instructions</h2>
          <p className="mt-2">To test:</p>
          <ol className="list-decimal ml-6 space-y-1">
            <li>Visit onboarding (/onboarding/step1 → step2 → MBTI)</li>
            <li>Start daily flow at /identity/train</li>
            <li>Complete CRE feedback and at least one challenge</li>
            <li>Check /identity/insight and observe rhythm growth</li>
            <li>Try goal → subtask → complete → radar</li>
            <li>Optionally reset via /dev/reset and test again</li>
          </ol>
          <p className="text-xs text-gray-500 mt-2 italic">Please report any issues via feedback form or direct message.</p>
        </div>
      </div>
      <div className="text-center pt-8">
  <a
    href="/"
    className="inline-block px-4 py-2 text-sm font-medium bg-gray-100 text-gray-800 rounded-md shadow hover:bg-gray-200 transition"
  >
    🔙 Return to Beta Welcome Page
  </a>
</div>
    </div>
  );
};
<BetaBuildBanner />
export default BetaSummaryPage;
