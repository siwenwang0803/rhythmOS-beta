import React from "react";

const cueStyles = [
  {
    tone: "gentle",
    persona: "Rhea",
    example: "You don’t have to rush. Your pace is still progress.",
    description: "Soft, calming, nurturing tone. Expresses emotional permission and reassurance."
  },
  {
    tone: "directive",
    persona: "Niveus",
    example: "Finish the task before noon. You’ll feel the shift.",
    description: "Clear, action-oriented tone with a built-in nudge. Structured and confident."
  },
  {
    tone: "visionary",
    persona: "Lucis",
    example: "What you build today shapes the world you’ll see tomorrow.",
    description: "Abstract, poetic, and future-focused tone. Often reflective or idealistic."
  },
  {
    tone: "motivated",
    persona: "Caelum",
    example: "You’ve already started. Now drive it forward.",
    description: "Upbeat, assertive, motivational tone with kinetic energy."
  },
  {
    tone: "rational",
    persona: "Aurelia",
    example: "Break it down step by step. Consistency beats intensity.",
    description: "Structured, reasoned, logical tone. Low emotion, high clarity. Helps with decision-making."
  }
];

const CueStyleDeck: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {cueStyles.map((style) => (
        <div
          key={style.tone}
          className="border rounded-xl p-4 shadow-sm bg-white hover:shadow-md transition"
        >
          <h3 className="text-lg font-semibold text-blue-700 mb-1 capitalize">
            {style.tone} <span className="text-sm text-gray-500">({style.persona})</span>
          </h3>
          <p className="text-sm text-gray-600 italic">“{style.example}”</p>
          <p className="text-xs text-gray-500 mt-2">{style.description}</p>
        </div>
      ))}
    </div>
  );
};

export default CueStyleDeck;

