import React from 'react'
import RhythmTrendView from '../components/RhythmTrendView'
import SubtaskIntentSummaryView from '../components/SubtaskIntentSummaryView'
import PersonaUsageHeatmap from '../components/PersonaUsageHeatmap'
import CRECueEffectivenessRadar from '../components/CRECueEffectivenessRadar'
import IdentityFeedbackReplay from '../components/IdentityFeedbackReplay'
import GrowthBeliefTracker from '../components/GrowthBeliefTracker'
import RhythmStudioPanel from '../components/ui/RhythmStudioPanel'
import RhythmTooltip from '@/components/ui/RhythmTooltip'

const IdentityProfilePage: React.FC = () => {
  const persona = localStorage.getItem('initPersona') || 'lucis'

  return (
    <div className="max-w-4xl mx-auto px-6 py-12 space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">📘 Your RhythmOS Identity Profile</h1>
      <p className="text-sm text-gray-500">
        This is your personalized rhythm growth map. See how your actions, language, and identity have evolved.
      </p>

      <div className="text-sm text-gray-600 space-y-2">
        <p>
          Your <RhythmTooltip term="Signature" /> reflects your long-term evolution across <RhythmTooltip term="tone" /> preferences, <RhythmTooltip term="trend" /> shifts, and <RhythmTooltip term="persona" /> usage.
        </p>
        <p>
          Each feedback you give helps shape the future cues you receive and tunes your growth path.
        </p>
      </div>

      <RhythmStudioPanel 
        icon="📈"
        title="Rhythm Score Trend"
        subtitle="Your rhythm pattern for the past 7 days"
        tone="default"
      >
        <RhythmTrendView />
      </RhythmStudioPanel >

      <RhythmStudioPanel 
        icon="📡"
        title="Persona Usage"
        subtitle="How often you’ve expressed each persona style"
        tone="default"
      >
        <PersonaUsageHeatmap />
      </RhythmStudioPanel >

      <RhythmStudioPanel 
        icon="🎯"
        title="Cue Tone Effectiveness"
        subtitle="Average feedback score per tone style"
        tone="default"
      >
        <CRECueEffectivenessRadar />
      </RhythmStudioPanel >

      <RhythmStudioPanel 
        icon="📑"
        title="Replay History"
        subtitle="Your feedback log of all CRE interactions"
        tone="default"
      >
        <IdentityFeedbackReplay />
      </RhythmStudioPanel >
    </div>
  )
}

export default IdentityProfilePage
