// /pages/IdentityTrainPage.tsx

import React, { useEffect, useState, useRef } from 'react';
import { matchCREBlock } from '../logic/matchCREBlock';
import ConfidentialNotice from '../components/ConfidentialNotice';
import { useDailyRhythm } from '../hooks/useDailyRhythm';
import  CREMetaBlock  from '../components/CREMetaBlock';
import CREFeedbackBox from '../components/CREFeedbackBox';
import UserTextInput from '../components/UserTextInput';
import GrowthPathAdvisor from '../components/GrowthPathAdvisor';
import GrowthBeliefTracker from '../components/GrowthBeliefTracker';
import RhythmScoreSummaryCard from '../components/RhythmScoreSummaryCard';
import EndMyDayButton from '../components/EndMyDayButton';
import FooterNavigation from '../components/FooterNavigation';
import GlobalOnboardingHint from '../components/GlobalOnboardingHint';
import PageIntro from '../components/ui/PageIntro';
import RhythmPanel from '../components/RhythmPanel';
import { BetaTestWelcomePanel } from '../components/BetaTestWelcomePanel';
import { getTodayDate } from '../utils/rhythmDayEngine';
import PersonaSelector from '../components/PersonaSelector';
import { useSignatureLogger } from "../hooks/useSignatureLogger";
import { getFeedbackScore } from '../utils/getFeedbackScore';
import { checkToneFatigueSuggestion } from '../logic/ToneFatigueTrigger';
import ToneNudgeHint from '../components/ToneNudgeHint';
import { generateCRECueFromSignaturePrompt } from '../logic/gpt/generateCRECueFromSignaturePrompt';
import { generateCRECue, generateCRECueAsync } from '../cre/generateCRECue';
import TodayPersonaChallenge from '../components/TodayPersonaChallenge';
import PersonaChallengePanel from '../components/PersonaChallengePanel';

// Define type unions to enforce type safety
type RhythmTrend = 'collapsed' | 'wavy' | 'stable' | 'rising';
type ToneStyle = 'gentle' | 'directive' | 'rational' | 'visionary' | 'motivated';
type PersonaKey = 'rhea' | 'aurelia' | 'lucis' | 'niveus' | 'caelum';

// Type guards for safe type narrowing
function isValidTrend(value: string | null): value is RhythmTrend {
  return value === 'collapsed' || value === 'wavy' || value === 'stable' || value === 'rising';
}

function isValidTone(value: string | null): value is ToneStyle {
  return value === 'gentle' || value === 'directive' || value === 'rational' || 
         value === 'visionary' || value === 'motivated';
}

function isValidPersona(value: string | null): value is PersonaKey {
  return value === 'rhea' || value === 'aurelia' || value === 'lucis' || 
         value === 'niveus' || value === 'caelum';
}

// Utility functions for safe localStorage access
function getStoredTrend(): RhythmTrend {
  const storedValue = localStorage.getItem('lastTrend');
  return isValidTrend(storedValue) ? storedValue : 'wavy';
}

function getStoredTone(): ToneStyle {
  const storedValue = localStorage.getItem('preferredTone');
  return isValidTone(storedValue) ? storedValue : 'gentle';
}

function getStoredPersona(): PersonaKey {
  const storedValue = localStorage.getItem('initPersona');
  return isValidPersona(storedValue) ? storedValue : 'rhea';
}

// Update utility functions to ensure type safety
function getPreferredTone(): ToneStyle {
  return getStoredTone();
}

function getCurrentTrend(): RhythmTrend {
  return getStoredTrend();
}

function updateCueSeenCount(cueId: string): void {
  const signatureMap = JSON.parse(localStorage.getItem('signatureMap') || '{"cueSeenCount":{}}');
  if (!signatureMap.cueSeenCount) {
    signatureMap.cueSeenCount = {};
  }
  
  signatureMap.cueSeenCount[cueId] = (signatureMap.cueSeenCount[cueId] || 0) + 1;
  localStorage.setItem('signatureMap', JSON.stringify(signatureMap));
}

// Helper function for detecting passive tone (placeholder implementation)
function detectPassiveTone(text: string): number {
  // Implementation would go here
  return 0;
}

// Helper function for writing passive tone log (placeholder implementation)
function writePassiveToneLog(text: string, score: number): void {
  // Implementation would go here
}

// Enhanced GeneratedCRE interface with strong typing
interface GeneratedCRE {
  id?: string;
  cue: string;
  paragraph: string;
  tone: ToneStyle;
  persona: PersonaKey;
  rhythm: RhythmTrend;
  source?: string;
  stage?: string;
}

// Type definitions for UI constants
interface PersonaStyle {
  color: string;
  gradient: string;
  icon: string;
}

// UI constants with proper typing
const RHYTHM_COLORS: Record<RhythmTrend, string> = {
  collapsed: '#AEC6CF', // 平静的蓝色
  wavy: '#C3B1E1',     // 过渡的薰衣草色
  stable: '#C5D8A4',    // 稳定的绿色
  rising: '#FFB347'     // 激活的橙黄色
} as const;

const PERSONAS: Record<PersonaKey, PersonaStyle> = {
  rhea: {
    color: '#F5CFCF',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    icon: '💗'
  },
  aurelia: {
    color: '#D8A7CA',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    icon: '🧠'
  },
  lucis: {
    color: '#A4D8C5',
    gradient: 'linear-gradient(135deg, #E8F5C7, #A4D8C5)',
    icon: '🌱'
  },
  niveus: {
    color: '#C7C7C7',
    gradient: 'linear-gradient(135deg, #E8E8E8, #C7C7C7)',
    icon: '📊'
  },
  caelum: {
    color: '#4B6587',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    icon: '💠'
  }
} as const;

const TREND_LABELS: Record<RhythmTrend, string> = {
  collapsed: '🧘‍♀️ Calm Reset',
  wavy: '🌊 Wavy Transitions',
  stable: '🌿 Stable Flow',
  rising: '🚀 Rising Momentum'
} as const;

const IdentityTrainPage: React.FC = () => {
  useDailyRhythm();

  const { logTone, logCue, logChallengeEntry } = useSignatureLogger();
  const creStartRef = useRef<HTMLDivElement>(null);
  const lastTrend = getStoredTrend();

  const handleCueRefresh = async () => {
    try {
      const preferredTone = getPreferredTone();
      const initPersona = getStoredPersona();
      const trend = getCurrentTrend();
      const useGPTCueEngine = localStorage.getItem('useGPTCueEngine') === 'true';
  
      const newCue = useGPTCueEngine
        ? await generateCRECueAsync({
            preferredTone,
            initPersona,
            trend,
            currentCueId: creCue.id
          })
        : generateCRECue({
            preferredTone,
            initPersona,
            trend,
            currentCueId: creCue.id
          });
  
      setCreCue({
        cue: newCue.cue,
        paragraph: newCue.paragraph,
        tone: newCue.tone as ToneStyle,
        persona: newCue.persona as PersonaKey,
        rhythm: newCue.rhythm as RhythmTrend,
        id: newCue.id,
        source: newCue.source,
        stage: newCue.stage
      });
  
      updateCueSeenCount(newCue.id || newCue.cue);
      console.log('🔄 Cue refreshed:', newCue);
    } catch (err) {
      console.warn('❌ Failed to refresh cue:', err);
    }
  };

  const [creCue, setCreCue] = useState<GeneratedCRE>({
    cue: '',
    paragraph: '',
    tone: getPreferredTone(),
    persona: getStoredPersona(),
    rhythm: lastTrend,
  });

  const [identityPersona, setIdentityPersona] = useState<PersonaKey>(getStoredPersona());
  const [showTonePrompt, setShowTonePrompt] = useState(false);
  const [suggestedPersona, setSuggestedPersona] = useState<PersonaKey | null>(null);
  const [refreshingCue, setRefreshingCue] = useState(false);
  const [scrolledPastHeader, setScrolledPastHeader] = useState(false);
  const [animatedElements, setAnimatedElements] = useState({
    header: false,
    intro: false,
    cre: false,
    challenges: false
  });

  const trend = getCurrentTrend();
  const suggestion = checkToneFatigueSuggestion(14);
  const useGPTCueEngine = localStorage.getItem('useGPTCueEngine') === 'true';
  
  // Get trend color and persona style - now type-safe
  const trendColor = RHYTHM_COLORS[lastTrend];
  const personaStyle = PERSONAS[creCue.persona];
  
  // Access signatureMap for cue seen count
  const signatureMap = JSON.parse(localStorage.getItem('signatureMap') || '{"cueSeenCount":{}}');

  // Scroll animation handler
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      
      // Update header state based on scroll position
      setScrolledPastHeader(scrollPosition > 200);
      
      // Trigger animations based on scroll position
      if (scrollPosition > 50 && !animatedElements.header) {
        setAnimatedElements(prev => ({ ...prev, header: true }));
      }
      
      if (scrollPosition > 250 && !animatedElements.intro) {
        setAnimatedElements(prev => ({ ...prev, intro: true }));
      }
      
      if (scrollPosition > 450 && !animatedElements.cre) {
        setAnimatedElements(prev => ({ ...prev, cre: true }));
      }
      
      if (scrollPosition > 750 && !animatedElements.challenges) {
        setAnimatedElements(prev => ({ ...prev, challenges: true }));
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [animatedElements]);

  useEffect(() => {
    if (useGPTCueEngine) {
      const cre = generateCRECueFromSignaturePrompt();
      setCreCue({
        cue: cre.cue,
        paragraph: cre.paragraph,
        tone: cre.tone as ToneStyle,
        persona: cre.persona as PersonaKey,
        rhythm: getCurrentTrend(),
        source: 'gpt'
      });
    }
  }, [useGPTCueEngine]);
  

  useEffect(() => {
    const init = async () => {
      // 首先检查是否有保存的 CRE
      const savedCue = localStorage.getItem('cre_cue');
      const savedParagraph = localStorage.getItem('cre_paragraph');
      const savedTone = localStorage.getItem('cre_tone');
      const savedPersona = localStorage.getItem('cre_persona');
      const savedSource = localStorage.getItem('cre_source');
      
      console.log('[IdentityTrainPage] Checking for saved CRE:', {
        hasCue: !!savedCue,
        source: savedSource
      });
      
      // 如果有保存的 CRE，使用它
      if (savedCue && savedParagraph && savedTone && savedPersona) {
        console.log('[IdentityTrainPage] Using saved CRE from localStorage');
        
        setCreCue({
          cue: savedCue,
          paragraph: savedParagraph,
          tone: isValidTone(savedTone) ? savedTone : 'gentle',
          persona: isValidPersona(savedPersona) ? savedPersona : 'rhea',
          rhythm: getCurrentTrend(),
          source: savedSource || 'static'
        });
        
        // 更新查看计数
        const cueId = savedCue;
        updateCueSeenCount(cueId);
        
        // 清除保存的 CRE（如果你想要每次都重新生成，取消注释下面的代码）
        // localStorage.removeItem('cre_cue');
        // localStorage.removeItem('cre_paragraph');
        // localStorage.removeItem('cre_tone');
        // localStorage.removeItem('cre_persona');
        // localStorage.removeItem('cre_source');
        
      } else {
        // 如果没有保存的 CRE，生成新的
        console.log('[IdentityTrainPage] No saved CRE, generating new one');
        
        const preferredTone = getPreferredTone();
        const initPersona = getStoredPersona();
        const trend = getCurrentTrend();
        
        try {
          const cre = await generateCRECueAsync({
            preferredTone,
            initPersona,
            trend
          });
  
          setCreCue({
            cue: cre.cue,
            paragraph: cre.paragraph,
            tone: cre.tone as ToneStyle,
            persona: cre.persona as PersonaKey,
            rhythm: cre.rhythm as RhythmTrend,
            id: cre.id,
            source: cre.source,
            stage: cre.stage
          });
  
          const cueId = cre.id || cre.cue;
          updateCueSeenCount(cueId);
  
          console.log('✅ New CRE generated:', cre);
        } catch (err) {
          console.warn('⚠️ Fallback to local CRE due to error:', err);
        }
      }
    };
  
    init();
  
    // 开始动画初始化
    setTimeout(() => {
      setAnimatedElements(prev => ({ ...prev, header: true }));
      setTimeout(() => {
        setAnimatedElements(prev => ({ ...prev, intro: true }));
        setTimeout(() => {
          setAnimatedElements(prev => ({ ...prev, cre: true }));
          setTimeout(() => {
            setAnimatedElements(prev => ({ ...prev, challenges: true }));
          }, 300);
        }, 300);
      }, 300);
    }, 300);
  }, []);
  
  // Feedback handling logic
  const handleCREFeedback = (feedback: 'aligned' | 'okay' | 'wrong') => {
    const today = getTodayDate();
  
    const feedbackLog = JSON.parse(localStorage.getItem('signatureFeedbackLog') || '[]');
    feedbackLog.push({
      feedback,
      timestamp: new Date().toISOString(),
      today: today,
    });
    localStorage.setItem('signatureFeedbackLog', JSON.stringify(feedbackLog));
  
    const interpretedFeedback = feedback === 'wrong' ? 'notMe' : feedback;
    const score = getFeedbackScore(interpretedFeedback);
  
    logTone({
      cueId: 'cre-beta-001',
      tone: creCue.tone,
      feedback: interpretedFeedback,
      score,
      trendAtFeedback: trend,
      timestamp: new Date().toISOString(),
    });
  
    logCue({
      cueId: 'cre-beta-001',
      cueText: creCue.cue,
      tone: creCue.tone,
      trend: trend,
      feedback: interpretedFeedback,
      timestamp: new Date().toISOString(),
    });
  
    logChallengeEntry({
      challengeId: 'chal-beta-001',
      persona: identityPersona,
      text: 'Reflect on a hard conversation you had.',
      completed: true,
      trend: trend,
      timestamp: new Date().toISOString(),
    });
  };

  const handleTextSubmit = (text: string) => {
    const score = detectPassiveTone(text);
    if (score > 0) {
      writePassiveToneLog(text, score);
    }
  };

  // UI rendering
  return (
    <div 
      className="min-h-screen relative overflow-hidden"
      style={{ 
        backgroundColor: '#FAFAFA', // 更轻微的背景色以提高对比度
        color: '#333333',
        backgroundImage: 'radial-gradient(circle at 30px 30px, #F2E9DE 1.5px, transparent 0)', // 更精细的点状图案
        backgroundSize: '40px 40px' // 更密集的背景
      }}
    >
      {/* 气氛背景元素 - 更有层次感和沉浸感 */}
      <div 
        className="fixed inset-0 z-0 pointer-events-none"
        style={{ 
          background: `
            radial-gradient(circle at 10% 20%, ${trendColor}20 0%, transparent 50%),
            radial-gradient(circle at 90% 80%, ${personaStyle.color}20 0%, transparent 50%)
          `,
          backdropFilter: 'blur(80px)'
        }}
      />
      
      {/* 更自然的浮动形状，增强空间感 */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div 
          className="absolute -top-[300px] -right-[300px] w-[600px] h-[600px] rounded-full opacity-8 animate-pulse"
          style={{ 
            background: trendColor,
            filter: 'blur(150px)',
            animation: 'pulse 8s infinite ease-in-out'
          }}
        />
        <div 
          className="absolute -bottom-[200px] -left-[200px] w-[400px] h-[400px] rounded-full opacity-8"
          style={{ 
            background: personaStyle.color,
            filter: 'blur(120px)',
            animation: 'pulse 10s infinite ease-in-out' 
          }}
        />
      </div>

      {/* 改良的黏性头部 - 更平滑的过渡和更清晰的信息层次 */}
      <div 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolledPastHeader ? 'translate-y-0 opacity-100' : 'translate-y-[-100%] opacity-0'
        }`}
        style={{ 
          backdropFilter: 'blur(12px)',
          background: 'rgba(255, 255, 255, 0.85)',
          borderBottom: '1px solid rgba(0, 0, 0, 0.05)',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.05)'
        }}
      >
        <div className="max-w-3xl mx-auto px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div 
                className="w-9 h-9 rounded-xl flex items-center justify-center transition-transform duration-300 hover:scale-105"
                style={{ 
                  background: 'linear-gradient(135deg, #F5E8C7, #A4D8C5)',
                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
                }}
              >
                <span className="text-sm">🌱</span>
              </div>
              <div>
                <h3 className="text-base font-medium" style={{ color: '#333333' }}>Identity Rhythm Training</h3>
              </div>
            </div>
            
            <div 
              className="px-3 py-1.5 rounded-full text-xs flex items-center gap-1.5 transition-all duration-300 hover:shadow-sm"
              style={{ 
                backgroundColor: trendColor + '30',
                color: '#333333'
              }}
            >
              <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: trendColor }} />
              <span>{TREND_LABELS[lastTrend]}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="relative z-10 max-w-3xl mx-auto px-5 py-12 space-y-8">
        <GlobalOnboardingHint />
        
        {/* 头部区域 - 改进的视觉层次和动画效果 */}
        <div 
          className={`transform transition-all duration-700 ${
            animatedElements.header ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
          }`}
        >
          <div className="flex items-center gap-4 mb-6">
            <div 
              className="w-16 h-16 rounded-xl flex items-center justify-center transform transition-all duration-500 hover:scale-105"
              style={{ 
                background: 'linear-gradient(135deg, #F5E8C7, #A4D8C5)',
                boxShadow: '0 4px 15px rgba(0, 0, 0, 0.1)'
              }}
            >
              <span className="text-2xl">🌱</span>
            </div>
            <div>
              <h1 
                className="text-3xl font-bold"
                style={{ color: '#333333' }}
              >
                Identity Rhythm Training
              </h1>
              <p 
                className="text-sm mt-1"
                style={{ color: '#666666' }}
              >
                Align with your ideal self
              </p>
            </div>
          </div>

          {/* 改进的节奏指示器 - 更清晰的视觉层次和动画效果 */}
          <div className="flex items-center gap-3 mb-8">
            <div 
              className="w-3 h-3 rounded-full animate-pulse" 
              style={{ backgroundColor: trendColor }}
            />
            <span className="text-sm font-medium" style={{ color: '#444444' }}>Current rhythm:</span>
            <div 
              className="px-4 py-1.5 rounded-full text-sm font-medium shadow-sm transition-all duration-300 hover:shadow"
              style={{ 
                backgroundColor: trendColor + '30',
                color: '#333333'
              }}
            >
              {TREND_LABELS[lastTrend]}
            </div>
          </div>
        </div>

        {/* 介绍部分 - 更现代的卡片设计和过渡效果 */}
        <div 
          className={`transform transition-all duration-700 ${
            animatedElements.intro ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
          }`}
        >
          <div 
            className="rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg"
            style={{ 
              boxShadow: '0 4px 20px rgba(0, 0, 0, 0.08)'
            }}
          >
            {/* 顶部彩条 */}
            <div 
              className="h-2 w-full"
              style={{ backgroundColor: trendColor }}
            />
            
            <div 
              className="p-6"
              style={{ 
                backgroundColor: '#E8F1F5',
                backgroundImage: 'linear-gradient(to right, #E1F0F5, #EBF3F7)'
              }}
            >
              <div className="flex items-start gap-4">
                <div 
                  className="w-12 h-12 rounded-full flex items-center justify-center mt-1"
                  style={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.6)',
                    boxShadow: '0 2px 8px rgba(255, 80, 80, 0.15)'
                  }}
                >
                  <span className="text-xl">🎯</span>
                </div>
                <div>
                  <h2 
                    className="text-xl font-medium mb-2"
                    style={{ color: '#333333' }}
                  >
                    This is your current rhythm execution space.
                  </h2>
                  <p 
                    className="text-base"
                    style={{ color: '#444444' }}
                  >
                    Use today's CRE cue to take action. Your feedback updates the system in real time.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <BetaTestWelcomePanel scrollTargetRef={creStartRef} />

        <p 
          className="text-center text-sm italic my-5 transform transition-all duration-500"
          style={{ color: '#666666' }}
        >
          Align your daily actions, feedback, and reflection with who you want to become.
        </p>

        {/* CRE面板 - 改进的卡片设计，动画和交互效果 */}
        <div 
          ref={creStartRef} 
          id="cre-start"
          className={`transform transition-all duration-700 ${
            animatedElements.cre ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
          } ${refreshingCue ? 'scale-[0.98] opacity-90' : 'scale-100 opacity-100'}`}
        >
          <div 
            className="rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg"
            style={{ 
              border: '1px solid rgba(0, 0, 0, 0.05)',
              boxShadow: '0 4px 20px rgba(0, 0, 0, 0.08)'
            }}
          >
            {/* 顶部彩条 */}
            <div className="h-2 w-full" style={{ background: personaStyle.gradient }} />
            
            {/* 头部区域 - 改进布局和对比度 */}
            <div 
              className="p-5 border-b flex justify-between items-center"
              style={{ 
                borderColor: 'rgba(0, 0, 0, 0.07)',
                backgroundColor: 'rgba(255, 255, 255, 0.8)',
                backdropFilter: 'blur(8px)'
              }}
            >
              <div className="flex items-center gap-3">
                <div 
                  className="w-12 h-12 rounded-full flex items-center justify-center transition-transform duration-300 hover:scale-105"
                  style={{ 
                    background: personaStyle.gradient,
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)' 
                  }}
                >
                  <span className="text-xl">{personaStyle.icon}</span>
                </div>
                <div>
                  <h3 
                    className="text-lg font-medium"
                    style={{ color: '#333333' }}
                  >
                    Today's Identity Cue
                  </h3>
                  <p 
                    className="text-xs"
                    style={{ color: '#666666' }}
                  >
                    Tuned to your rhythm state
                  </p>
                </div>
              </div>
              
              <div className="flex gap-2">
                <div 
                  className="px-3 py-1.5 rounded-lg text-xs shadow-sm"
                  style={{ 
                    backgroundColor: 'rgba(0, 0, 0, 0.05)',
                    color: '#555555'
                  }}
                >
                  {creCue.tone} tone
                </div>
                <div 
                  className="px-3 py-1.5 rounded-lg text-xs shadow-sm"
                  style={{ 
                    backgroundColor: personaStyle.color + '40',
                    color: '#333333'
                  }}
                >
                  {creCue.persona}
                </div>
              </div>
            </div>
            
            {/* 主要内容 - 改进的间距和视觉层次 */}
            <div 
              className="p-6 border-b"
              style={{ 
                backgroundColor: 'white',
                borderColor: 'rgba(0, 0, 0, 0.05)'
              }}
            >
              {/* 使用原有的CREMetaBlock但添加额外样式 */}
              <div className="mb-6">
                <CREMetaBlock
                  cue={creCue.cue}
                  paragraph={creCue.paragraph}
                  tone={creCue.tone}
                  persona={creCue.persona}
                  rhythm={creCue.rhythm}
                />
                
                {/* 提示计数提示 */}
                {signatureMap.cueSeenCount?.[creCue.cue] > 1 && (
                  <p 
                    className="text-xs italic mt-3 ml-3 px-3 py-1.5 rounded-lg inline-block"
                    style={{ 
                      color: '#666666',
                      backgroundColor: 'rgba(0,0,0,0.03)' 
                    }}
                  >
                    You've seen this cue <strong>{signatureMap.cueSeenCount[creCue.cue]}</strong> times.
                  </p>
                )}
              </div>

              {/* 使用原有CREFeedbackBox但添加额外样式 */}
              <div className="mb-6 p-4 rounded-lg" style={{ backgroundColor: 'rgba(0,0,0,0.02)' }}>
                <CREFeedbackBox
                  key={creCue.cue}
                  cueId={creCue.id || creCue.cue}
                  cue={creCue.cue}
                  paragraph={creCue.paragraph}
                  tone={creCue.tone}
                  persona={creCue.persona}
                  trend={trend}
                  onFeedbackSubmit={handleCREFeedback}
                />
              </div>
              
              {/* 更吸引人的刷新按钮 */}
              <div className="mt-6 flex justify-end">
                <button
                  onClick={handleCueRefresh}
                  className="px-5 py-2.5 rounded-xl text-sm inline-flex items-center gap-2 transition-all duration-300"
                  style={{ 
                    background: personaStyle.gradient,
                    color: '#333333',
                    boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-3px)';
                    e.currentTarget.style.boxShadow = '0 6px 12px rgba(0, 0, 0, 0.15)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = '0 2px 6px rgba(0, 0, 0, 0.1)';
                  }}
                >
                  <span>🔄</span>
                  <span>Try Another Identity Cue</span>
                </button>
              </div>
              
              {/* 保留原有的提示逻辑，但改进样式 */}
              {suggestion && (
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <ToneNudgeHint dominant={suggestion.dominant} suggested={suggestion.suggested} />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* 文本输入面板 - 更现代的卡片设计 */}
        <div className="h-1.5 w-full" style={{ backgroundColor: trendColor }} />
          
<div className="p-6">
  <div className="flex items-center gap-3 mb-4">
    <div className="w-10 h-10 rounded-full flex items-center justify-center" 
      style={{ 
        backgroundColor: `${trendColor}30`,
        boxShadow: '0 2px 6px rgba(0, 0, 0, 0.05)'
      }}>
      <span className="text-lg">💬</span>
    </div>
    <div>
      <h3 className="text-lg font-medium text-gray-800">Express Yourself</h3>
      <p className="text-sm text-gray-600">Share your thoughts and receive personalized reflection</p>
    </div>
  </div>
          <UserTextInput onSubmit={handleTextSubmit} />
        </div>

        {/* 挑战面板 - 改进的视觉设计和动画 */}
        <div 
          className={`transform transition-all duration-700 ${
            animatedElements.challenges ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
          }`}
        >
          <div 
            className="rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg"
            style={{ 
              border: '1px solid rgba(0, 0, 0, 0.05)',
              boxShadow: '0 4px 14px rgba(0, 0, 0, 0.07)'
            }}
          >
            {/* 顶部彩条 */}
            <div className="h-2 w-full" style={{ background: personaStyle.gradient }} />
            
            <div className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div 
                  className="w-12 h-12 rounded-full flex items-center justify-center transition-transform duration-300 hover:scale-105"
                  style={{ 
                    background: personaStyle.gradient,
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)' 
                  }}
                >
                  <span className="text-xl">🎯</span>
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h3 
                      className="text-lg font-medium"
                      style={{ color: '#333333' }}
                    >
                      Next Growth Challenges
                    </h3>
                    <span
                      className="text-xs text-gray-500 cursor-pointer w-5 h-5 rounded-full border border-gray-200 inline-flex items-center justify-center hover:bg-gray-100"
                      onClick={() => alert(`🎯 Growth Challenges are small identity-aligned actions.\nThey help you align your behavior with the person you aspire to be.`)}
                      title="Click for explanation"
                    >
                      ⓘ
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Align your actions with who you want to become
                  </p>
                </div>
              </div>
              <PersonaChallengePanel
                personaStyle={personaStyle}
                animated={animatedElements.challenges}
              />
            </div>
          </div>
        </div>

        {/* 信念追踪面板 - 添加悬停效果 */}
        <div 
          className="transform transition-all duration-500 hover:translate-y-[-3px] hover:shadow-lg rounded-xl overflow-hidden"
          style={{ 
            transition: 'transform 0.3s ease, box-shadow 0.3s ease',
            boxShadow: '0 4px 14px rgba(0, 0, 0, 0.05)'
          }}
        >
          <div className="h-1.5 w-full" style={{ backgroundColor: trendColor }} />
          <GrowthBeliefTracker persona={creCue.persona} />
        </div>

        {/* 角色选择器 - 添加过渡和卡片效果 */}
        <div className="transform transition-all duration-500 rounded-xl overflow-hidden hover:shadow-lg"
             style={{ boxShadow: '0 4px 14px rgba(0, 0, 0, 0.05)' }}>
          <div className="h-1.5 w-full" style={{ background: personaStyle.gradient }} />
          <PersonaSelector />
        </div>
        
        {/* 分数摘要 - 添加过渡和卡片效果 */}
        <div className="transform transition-all duration-500 rounded-xl overflow-hidden hover:shadow-lg"
             style={{ boxShadow: '0 4px 14px rgba(0, 0, 0, 0.05)' }}>
          <div className="h-1.5 w-full" style={{ backgroundColor: trendColor }} />
          <RhythmScoreSummaryCard />
        </div>

        {/* 保留原始代码的音调提示逻辑 */}
        {showTonePrompt && (
          <div 
            className="rounded-xl overflow-hidden transform transition-all duration-500 animate-fade-in-up shadow-lg"
            style={{ 
              border: '1px solid rgba(0, 0, 0, 0.05)',
              boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
              background: 'linear-gradient(135deg, #FFF8E6, #FFF4D1)'
            }}
          >
            <div className="p-6">
              <div className="flex items-start gap-4">
                <div 
                  className="w-12 h-12 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: 'rgba(255, 255, 255, 0.6)' }}
                >
                  <span className="text-lg">🌀</span>
                </div>
                <div className="flex-1">
                  <p 
                    className="mb-4"
                    style={{ color: '#333333' }}
                  >
                    Based on your recent feedback, the system suggests switching to a gentler tone.
                  </p>
                  <button
                    onClick={() => {
                      localStorage.setItem('preferredTone', 'gentle');
                      setShowTonePrompt(false);
                      setTimeout(() => window.location.reload(), 50);
                    }}
                    className="px-4 py-2.5 rounded-xl text-sm font-medium inline-flex items-center gap-2 transition-all duration-300"
                    style={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.6)',
                      color: '#333333',
                      boxShadow: '0 2px 6px rgba(0, 0, 0, 0.05)'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = 'translateY(-2px)';
                      e.currentTarget.style.boxShadow = '0 4px 10px rgba(0, 0, 0, 0.1)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.boxShadow = '0 2px 6px rgba(0, 0, 0, 0.05)';
                    }}
                  >
                    <span>✓</span>
                    <span>Switch to gentle</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 改进的结束日按钮样式 */}
        <div className="mt-8 flex justify-center">
          <EndMyDayButton />
        </div>
        
        {/* 底部导航和保密声明 */}
        <div className="border-t border-gray-200 pt-6 mt-6">
          <FooterNavigation />
          <button
            onClick={() => {
              const current = localStorage.getItem('useGPTCueEngine') === 'true';
              localStorage.setItem('useGPTCueEngine', (!current).toString());
              alert(`CRE Source switched to ${!current ? 'GPT' : 'Local'} mode. Refresh to apply.`);
            }}
            className="text-xs text-blue-600 underline mt-2"
          >
            Toggle CRE source
          </button>
          <ConfidentialNotice />
        </div>
      </div>
    </div>
  );
};

export default IdentityTrainPage;












