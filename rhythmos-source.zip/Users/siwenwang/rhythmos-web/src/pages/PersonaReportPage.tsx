import React, { useState } from 'react'
import Section from '../components/ui/Section'
import RhythmTaskProgressChart from '../components/RhythmTaskProgressChart'
import CREStyleGrowthMap from '../components/CREStyleGrowthMap'
import BehaviorRadarChart from '../components/BehaviorRadarChart'
import { generatePersonaSummary } from '../logic/generatePersonaSummary'
import { recommendNextRhythmStep } from '../logic/recommendNextRhythmStep'
import CREStyleTrendChart from '../components/CREStyleTrendChart'
import SignatureLogLink from '../components/SignatureLogLink'
import CREStyleMigrationHint from '../components/CREStyleMigrationHint'
import { getStyleMigrationTrend } from '../creStyleUsage'
import PersonaArchivePage from './PersonaArchivePage'

const PersonaReportPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'current' | 'archive'>('current')

  const persona = generatePersonaSummary()
  const nextStep = recommendNextRhythmStep()
  const raw = localStorage.getItem('creSampleRatings')
  const signature = JSON.parse(localStorage.getItem('rhythmSignature') || '{}')
  const migration = getStyleMigrationTrend(signature)
  const ratings = raw ? JSON.parse(raw) : []

  return (
    <div className="min-h-screen px-6 py-10 max-w-4xl mx-auto space-y-12">
      <h1 className="text-2xl font-bold text-gray-800">🧬 Your Rhythm Persona</h1>
      <p className="text-sm text-gray-500">
        This is a profile built from your past task patterns, CRE feedback, and tone style behaviors.
      </p>

      <Section title="🎯 Rhythm Pattern Overview">
        <RhythmTaskProgressChart />
      </Section>

      <Section title="🎨 CRE Style Usage Over Time">
        <CREStyleGrowthMap />
      </Section>

      <Section title="🧭 Task Behavior Radar">
        <BehaviorRadarChart />
      </Section>

      <Section title="💬 Rhythm Language Summary">
        <p className="text-sm text-gray-600 mb-2">{persona.summary}</p>
        <blockquote className="text-blue-600 italic text-sm">“{persona.quote}”</blockquote>
      </Section>

      {/* Tabs block replacement */}
      <div className="border-t pt-6">
        <div className="flex gap-4 mb-4">
          <button
            className={`text-sm px-3 py-1 rounded ${
              activeTab === 'current' ? 'bg-blue-600 text-white' : 'bg-gray-200'
            }`}
            onClick={() => setActiveTab('current')}
          >
            Current Insight
          </button>
          <button
            className={`text-sm px-3 py-1 rounded ${
              activeTab === 'archive' ? 'bg-blue-600 text-white' : 'bg-gray-200'
            }`}
            onClick={() => setActiveTab('archive')}
          >
            Archive
          </button>
        </div>

        {activeTab === 'current' && (
          <Section title="📌 System Recommendation">
            <p className="text-sm text-gray-700 mb-2">
              Based on your recent rhythm pattern, the system recommends:
            </p>
            <p className="text-base font-semibold text-blue-700">{nextStep.suggestion}</p>
            <p className="text-xs text-gray-500 mt-2 italic">
              Suggested tone: <strong>{nextStep.tone}</strong> | task type:{' '}
              <strong>{nextStep.taskType}</strong>
            </p>

            <CREStyleTrendChart data={ratings} />
            <CREStyleMigrationHint migration={migration} />
          </Section>
        )}

        {activeTab === 'archive' && (
          <Section title="🗂️ Archive Overview">
            <PersonaArchivePage />
          </Section>
        )}
      </div>

      <div className="pt-8 text-xs text-gray-400 italic text-center">
        <SignatureLogLink />
        You don’t need to do everything today.
        <br />
        You just need to enter the rhythm.
        <br />
        <br />
        RhythmOS doesn’t want your performance.  
        <br />
        It wants your presence.
      </div>
    </div>
  )
}

export default PersonaReportPage

