import React, { useState, useEffect } from 'react';

// SVG波浪背景组件
const WaveBackground = () => (
  <div className="absolute top-0 left-0 w-full overflow-hidden z-0 opacity-40">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" preserveAspectRatio="none" className="w-full h-auto">
      <path 
        fill="#FEE2E2" 
        fillOpacity="0.6" 
        d="M0,192L48,176C96,160,192,128,288,122.7C384,117,480,139,576,144C672,149,768,139,864,149.3C960,160,1056,192,1152,197.3C1248,203,1344,181,1392,170.7L1440,160L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z">
      </path>
    </svg>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" preserveAspectRatio="none" className="w-full h-auto -mt-5">
      <path 
        fill="#DBEAFE" 
        fillOpacity="0.3" 
        d="M0,256L48,261.3C96,267,192,277,288,266.7C384,256,480,224,576,213.3C672,203,768,213,864,224C960,235,1056,245,1152,240C1248,235,1344,213,1392,202.7L1440,192L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z">
      </path>
    </svg>
  </div>
);

// 装饰形状组件
const DecorativeShapes = () => (
  <>
    <div className="absolute top-40 left-10 w-24 h-24 rounded-full bg-orange-100 opacity-20 z-0 blur-xl"></div>
    <div className="absolute top-60 right-10 w-32 h-32 rounded-full bg-blue-100 opacity-30 z-0 blur-xl"></div>
    <div className="absolute bottom-40 left-1/4 w-40 h-40 rounded-full bg-rose-100 opacity-20 z-0 blur-xl"></div>
    <div className="absolute top-1/3 right-1/4 w-16 h-16 rounded-full bg-yellow-100 opacity-30 z-0 blur-md"></div>
  </>
);

const RhythmOSBetaWelcome: React.FC = () => {
  const [loaded, setLoaded] = useState(false);
  
  // 在组件挂载后触发加载动画
  useEffect(() => {
    setLoaded(true);
  }, []);

  return (
    <div className="relative min-h-screen bg-gradient-to-b from-white to-gray-50 pt-12 pb-20 overflow-hidden">
      {/* 背景元素 */}
      <WaveBackground />
      <DecorativeShapes />
      
      <div className="relative z-10 max-w-3xl mx-auto px-8 space-y-10">
        {/* 优雅的标题区域 - 带淡入效果 */}
        <div 
          className={`text-center mb-16 transition-opacity duration-1000 ease-out ${loaded ? 'opacity-100' : 'opacity-0'}`}
        >
          <div className="inline-block p-3 mb-6 bg-rose-50 bg-opacity-80 backdrop-blur-sm rounded-full shadow-xl">
            <div className="w-20 h-20 flex items-center justify-center bg-gradient-to-br from-rose-500 to-orange-400 rounded-full shadow-lg">
              <span className="text-4xl transform transition-transform duration-700 ease-out hover:rotate-12">🎯</span>
            </div>
          </div>
          <h1 className="text-5xl font-serif font-bold text-gray-900 tracking-tight mb-3">
            Welcome to RhythmOS
          </h1>
          <p className="text-lg text-rose-600 font-medium">
            <span className="bg-rose-50 px-4 py-1 rounded-full shadow-sm backdrop-blur-sm">Beta Experience</span>
          </p>
        </div>

        {/* 柔和的介绍文案 - 带玻璃拟态效果 */}
        <div 
          className={`bg-white bg-opacity-70 backdrop-blur-md rounded-2xl p-8 shadow-lg border border-gray-100 transition-all duration-1000 ease-out delay-300 ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
        >
          <p className="text-gray-700 text-lg leading-relaxed font-light">
            RhythmOS is a new kind of self-guidance system — one that reflects your rhythm, your emotional trends,
            and the tones that resonate with you. In this beta, you'll train with identity cues, track your growth,
            and shape your system persona through tone × feedback × action.
          </p>
        </div>

        {/* 精致的功能介绍 - 交错淡入 */}
        <div className="grid gap-5 md:grid-cols-2">
          {[
            {
              icon: "🌿",
              bgColor: "bg-green-50",
              bgGradient: "from-green-200 to-green-50",
              title: "Daily CRE Cue",
              description: "Receive contextual reflective echoes that resonate with your current state"
            },
            {
              icon: "🧠",
              bgColor: "bg-rose-50",
              bgGradient: "from-rose-200 to-rose-50",
              title: "Train Your Tone",
              description: "Provide feedback to shape your personal rhythm signature"
            },
            {
              icon: "🎯",
              bgColor: "bg-orange-50",
              bgGradient: "from-orange-200 to-orange-50",
              title: "Personal Challenges",
              description: "Engage with activities aligned to your current persona"
            },
            {
              icon: "📈",
              bgColor: "bg-blue-50",
              bgGradient: "from-blue-200 to-blue-50",
              title: "Track Progress",
              description: "Monitor behavior scores and emotional trend shifts over time"
            }
          ].map((feature, index) => (
            <div 
              key={index}
              className={`bg-white bg-opacity-80 backdrop-blur-sm p-5 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 border border-gray-100 flex items-start space-x-4 transform hover:-translate-y-1 ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
              style={{ transitionDelay: `${400 + index * 150}ms` }}
            >
              <div className={`bg-gradient-to-br ${feature.bgGradient} p-3 rounded-lg text-xl shadow-sm`}>{feature.icon}</div>
              <div>
                <h3 className="font-medium text-gray-900 mb-1">{feature.title}</h3>
                <p className="text-gray-600 text-sm">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* 柔和的注意事项提示 - 向上淡入 */}
        <div 
          className={`bg-gradient-to-r from-amber-50 to-yellow-50 bg-opacity-90 backdrop-blur-sm rounded-xl p-6 border border-yellow-100 shadow-md transition-all duration-1000 ease-out ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
          style={{ transitionDelay: '1000ms' }}
        >
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0 text-amber-500 text-xl">⚠️</div>
            <div>
              <p className="font-medium text-amber-800 mb-2">Beta Scope Note</p>
              <p className="text-amber-700 text-sm leading-relaxed">
                This version of RhythmOS does not yet include large language model (LLM) integration.
                In future updates, CRE cues, tasks, and challenges will be generated dynamically via GPT, 
                and the system will support real-time multi-turn dialogue.
              </p>
            </div>
          </div>
        </div>

        {/* 探索选项 - 轻微弹跳淡入 */}
        <div 
          className={`bg-indigo-50 bg-opacity-80 backdrop-blur-sm rounded-xl p-8 text-center space-y-5 transition-all duration-1000 ease-out shadow-md border border-indigo-100 ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
          style={{ transitionDelay: '1200ms' }}
        >
          <h3 className="text-indigo-900 font-medium">Explore the system before starting</h3>
          
          <a 
            href="/onboarding/flow-preview" 
            className="inline-block px-6 py-3 bg-white bg-opacity-90 backdrop-blur-sm text-indigo-600 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 font-medium text-sm"
          >
            🚀 View Full Flow Preview
          </a>
          
          <div className="flex justify-center gap-8 text-sm">
            {[
              { icon: "🧭", text: "Guide", href: "/guide" },
              { icon: "📘", text: "Glossary", href: "/glossary" },
              { icon: "🎥", text: "Beta Summary", href: "/beta/summary" }
            ].map((link, index) => (
              <a 
                key={index}
                href={link.href} 
                className="text-indigo-600 hover:text-indigo-800 flex items-center gap-1 transition-all duration-300 hover:-translate-y-1 group"
              >
                <span className="group-hover:scale-110 transition-transform duration-300">{link.icon}</span> 
                <span className="group-hover:underline">{link.text}</span>
              </a>
            ))}
          </div>
        </div>

        {/* 行动按钮区域 - 脉动效果 */}
        <div 
          className={`text-center space-y-6 pt-8 transition-all duration-1000 ease-out ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
          style={{ transitionDelay: '1400ms' }}
        >
          <a
            href="/onboarding/step1"
            className="inline-block px-12 py-5 bg-gradient-to-r from-rose-500 to-orange-500 text-white rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 font-medium text-lg relative group"
          >
            <span className="relative z-10 flex items-center justify-center">
              Begin Your Rhythm Journey
              <svg className="w-5 h-5 ml-2 transform group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
              </svg>
            </span>
            <span className="absolute inset-0 bg-gradient-to-r from-rose-600 to-orange-600 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
          </a>
          
          <a
            href="/rhythm"
            className="block text-gray-500 hover:text-gray-700 transition-colors duration-300 mt-6 group"
          >
            Not your first time? <span className="text-rose-500 font-medium group-hover:underline transition-all duration-300">Go to Daily Check-in <span className="inline-block transform group-hover:translate-x-1">→</span></span>
          </a>
        </div>

        {/* 优雅的底部信息 - 最后淡入 */}
        <div 
          className={`pt-12 mt-12 border-t border-gray-200 text-center transition-opacity duration-1000 ease-out ${loaded ? 'opacity-70' : 'opacity-0'}`}
          style={{ transitionDelay: '1600ms' }}
        >
          <div className="bg-white bg-opacity-50 backdrop-blur-sm rounded-lg py-3 px-6 inline-block">
            <p className="text-xs text-gray-500 font-medium uppercase tracking-wider mb-2">Confidential Prototype</p>
            <p className="text-xs text-gray-500 max-w-md mx-auto">
              This is a private identity rhythm experience prototype. 
              Please do not share system content or screenshots outside the approved test group.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RhythmOSBetaWelcome;