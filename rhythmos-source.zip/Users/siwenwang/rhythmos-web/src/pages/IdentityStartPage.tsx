import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { mbtiToPersonaMap } from '../utils/mbtiToPersonaMap';

// 波浪背景组件 - 动态版
const WaveBackground = () => (
  <div className="absolute top-0 left-0 w-full overflow-hidden z-0 opacity-30">
    <div className="wave wave1"></div>
    <div className="wave wave2"></div>
  </div>
);

// 动态灵感气泡
const InspirationBubbles = ({ activePersona }) => {
  // 不同角色对应不同的气泡颜色和行为
  const personaConfig = {
    caelum: { colors: ['#fed7aa', '#fdba74', '#fb923c'], count: 5, speed: 'fast' },
    rhea: { colors: ['#bfdbfe', '#93c5fd', '#60a5fa'], count: 8, speed: 'slow' },
    aurelia: { colors: ['#fef08a', '#fde047', '#facc15'], count: 6, speed: 'medium' },
    niveus: { colors: ['#c7d2fe', '#a5b4fc', '#818cf8'], count: 7, speed: 'medium' },
    lucis: { colors: ['#bbf7d0', '#86efac', '#4ade80'], count: 6, speed: 'medium' },
    default: { colors: ['#fed7aa', '#fef08a', '#bbf7d0'], count: 5, speed: 'medium' }
  };
  
  const config = personaConfig[activePersona] || personaConfig.default;
  const bubbles = Array.from({ length: config.count }, (_, i) => ({
    color: config.colors[Math.floor(Math.random() * config.colors.length)],
    size: 5 + Math.random() * 15,
    left: 5 + Math.random() * 90,
    delay: Math.random() * 5,
    duration: config.speed === 'slow' ? 15 + Math.random() * 10 : 
              config.speed === 'medium' ? 8 + Math.random() * 7 :
              5 + Math.random() * 5
  }));
  
  return (
    <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
      {activePersona && bubbles.map((bubble, i) => (
        <div 
          key={i}
          className="absolute rounded-full animate-float"
          style={{
            width: `${bubble.size}px`,
            height: `${bubble.size}px`,
            backgroundColor: bubble.color,
            left: `${bubble.left}%`,
            bottom: '-20px',
            opacity: 0.6,
            animationDelay: `${bubble.delay}s`,
            animationDuration: `${bubble.duration}s`
          }}
        ></div>
      ))}
    </div>
  );
};

// 光效灯泡 - 表示灵感
const LightbulbEffect = ({ pulsing }) => (
  <div className={`absolute top-60 left-12 opacity-40 z-0 hidden lg:block ${pulsing ? 'pulsing-glow' : ''}`}>
    <div className="lightbulb-rays"></div>
  </div>
);

// 增强版的角色数据
const personaMap = {
  caelum: {
    label: 'Bold & Decisive',
    emoji: '🔥',
    tone: 'motivated',
    quote: 'We ignite action from within.',
    description:'Motivated and forward-driving, helping you break inertia and move with purpose.',
    gradient: 'from-orange-50 to-amber-50',
    hoverGradient: 'from-orange-100 to-amber-100',
    activeGradient: 'from-orange-200 to-amber-200',
    borderColor: 'border-orange-200',
    textColor: 'text-orange-600',
    bgColor: 'bg-orange-50',
    iconBg: 'bg-gradient-to-br from-orange-400 to-amber-300',
    traits: ['Energetic', 'Ambitious', 'Driven', 'Progress-focused'],
    animation: 'animate-bounce-gentle',
    symbolPath: "M12 22l4.01-5.06L12 14.25l-4.01 2.69L12 22zm0-19.94L4 6.06l2.67 1.69L12 4l5.33 3.75L20 6.06L12 2.06z M10.94 8l-2.67 1.69 2.67 1.69 2.67-1.69L10.94 8z M15.08 12l-2.69-1.69v-3.38L9.7 8.62v3.38L7.01 12"
  },
  rhea: {
    label: 'Gentle & Supportive',
    emoji: '💙',
    tone: 'gentle',
    quote: 'We speak gently, so you can begin again.',
    description: 'Nurturing and compassionate, creating a safe space for exploration.',
    gradient: 'from-blue-50 to-sky-50',
    hoverGradient: 'from-blue-100 to-sky-100',
    activeGradient: 'from-blue-200 to-sky-200',
    borderColor: 'border-blue-200',
    textColor: 'text-blue-600',
    bgColor: 'bg-blue-50',
    iconBg: 'bg-gradient-to-br from-blue-400 to-sky-300',
    traits: ['Compassionate', 'Patient', 'Supportive', 'Understanding'],
    animation: 'animate-pulse-slow',
    symbolPath: "M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
  },
  aurelia: {
    label: 'Clear & Rational',
    emoji: '💛',
    tone: 'rational',
    quote: 'We offer clarity in complexity.',
    description: 'Analytical and clear-minded, helping you think logically and objectively.',
    gradient: 'from-yellow-50 to-amber-50',
    hoverGradient: 'from-yellow-100 to-amber-100',
    activeGradient: 'from-yellow-200 to-amber-200',
    borderColor: 'border-yellow-200',
    textColor: 'text-yellow-600',
    bgColor: 'bg-yellow-50',
    iconBg: 'bg-gradient-to-br from-yellow-400 to-amber-300',
    traits: ['Analytical', 'Objective', 'Thoughtful', 'Balanced'],
    animation: 'animate-spin-slow',
    symbolPath: "M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7zm2.85 11.1l-.85.6V16h-4v-2.3l-.85-.6A4.997 4.997 0 017 9c0-2.76 2.24-5 5-5s5 2.24 5 5c0 1.63-.8 3.16-2.15 4.1z"
  },
  niveus: {
    label: 'Precise & Logical',
    emoji: '🧊',
    tone: 'directive',
    quote: 'We guide with quiet precision.',
    description: 'Exacting and methodical, helping you create structure and clarity.',
    gradient: 'from-indigo-50 to-purple-50',
    hoverGradient: 'from-indigo-100 to-purple-100',
    activeGradient: 'from-indigo-200 to-purple-200',
    borderColor: 'border-indigo-200',
    textColor: 'text-indigo-600',
    bgColor: 'bg-indigo-50',
    iconBg: 'bg-gradient-to-br from-indigo-400 to-purple-300',
    traits: ['Precise', 'Systematic', 'Logical', 'Structured'],
    animation: 'animate-ping-slow',
    symbolPath: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 2h1.5v3l2-3h1.7l-2 3 2 3h-1.7l-2-3v3H12V5zM7 7.25h2.5V6.5H7V5h4v3.75H8.5v.75H11V11H7V7.25zM19 13l-6 6 -4-4 -4 4v-2.5l4-4 4 4 6-6V13z"
  },
  lucis: {
    label: 'Steady & Grounded',
    emoji: '💚',
    tone: 'visionary',
    quote: 'We ground you so your future can grow.',
    description: 'Visionary and deeply rooted, helping you trust the long path and build lasting strength.',
    gradient: 'from-green-50 to-emerald-50',
    hoverGradient: 'from-green-100 to-emerald-100',
    activeGradient: 'from-green-200 to-emerald-200',
    borderColor: 'border-green-200',
    textColor: 'text-green-600',
    bgColor: 'bg-green-50',
    iconBg: 'bg-gradient-to-br from-green-400 to-emerald-300',
    traits: ['Grounded', 'Enduring', 'Strategic', 'Growth-minded'],
    animation: 'animate-pulse-gentle',
    symbolPath: "M12 22l-6.16-6.16a7 7 0 1112.32 0L12 22zm0-12c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"
  }
};

// 更新的关键词映射集，增加更多关键词以提高匹配精度
const personaKeywordsMap = {
  caelum: [
    // 行动和决断关键词
    'bold', 'decisive', 'strong', 'momentum', 'action', 'assertive', 'confident',
    'fast', 'quick', 'progress', 'lead', 'direct', 'energetic', 'powerful',
    'ambitious', 'drive', 'determination', 'courage', 'challenge', 'achieve',
    // 额外的情感/意图关键词
    'take charge', 'make decisions', 'get things done', 'move forward', 'accomplish',
    'succeed', 'win', 'compete', 'advance', 'efficient', 'effective'
  ],
  
  rhea: [
    // 温和和支持关键词
    'gentle', 'safe', 'soft', 'soothe', 'kind', 'supportive', 'compassionate',
    'care', 'nurture', 'help', 'empathy', 'comfort', 'warm', 'tender',
    'loving', 'patient', 'understanding', 'sensitive', 'friendly', 'accepting',
    // 额外的情感/意图关键词
    'connect', 'relate', 'listen', 'support others', 'be there', 'emotionally',
    'heart', 'feelings', 'harmony', 'peaceful', 'trust', 'openness'
  ],
  
  aurelia: [
    // 清晰和理性关键词
    'clear', 'logic', 'focus', 'rational', 'analytical', 'objective', 'balanced',
    'think', 'understand', 'clarity', 'insight', 'intelligent', 'smart', 'wise',
    'mind', 'reason', 'perspective', 'thoughtful', 'ideas', 'concepts',
    // 额外的情感/意图关键词
    'analyze', 'problem solve', 'strategize', 'comprehend', 'figure out', 'learn',
    'knowledge', 'curious', 'intellectual', 'mental clarity', 'insight'
  ],
  
  lucis: [
    // 稳定和坚定关键词
    'stable', 'grounded', 'calm', 'consistency', 'steady', 'reliable', 'practical',
    'solid', 'balanced', 'foundation', 'centered', 'rooted', 'peaceful', 'quiet',
    'deliberate', 'mindful', 'present', 'focused', 'careful', 'patient',
    // 额外的情感/意图关键词
    'sustained', 'long-term', 'enduring', 'dependable', 'trustworthy', 'consistent',
    'balance', 'harmony', 'peace', 'tranquil', 'serene', 'even', 'moderate'
  ],
  
  niveus: [
    // 精确和结构关键词
    'precise', 'sharp', 'structured', 'accurate', 'methodical', 'systematic', 'logical',
    'exact', 'organize', 'order', 'detail', 'thorough', 'meticulous', 'careful',
    'disciplined', 'rigorous', 'efficient', 'planned', 'accurate', 'correct',
    // 额外的情感/意图关键词
    'plan', 'structure', 'organize', 'control', 'manage', 'arrange', 'coordinate',
    'perfectionist', 'excellence', 'high standards', 'quality', 'refinement'
  ]
};

// 意图关键词 - 用于识别用户的基本意图
const intentKeywords = {
  want: ['want', 'wish', 'desire', 'hope', 'aspire', 'aim', 'intend', 'like to', 'would like'],
  become: ['become', 'be', 'grow into', 'transform into', 'develop into', 'evolve into', 'turn into'],
  improve: ['improve', 'better', 'enhance', 'develop', 'grow', 'advance', 'progress', 'strengthen']
};

const IdentityStartPage: React.FC = () => {
  const navigate = useNavigate();
  const [selected, setSelected] = useState<string | null>(null);
  const [custom, setCustom] = useState('');
  const [recommended, setRecommended] = useState<string | null>(null);
  const [fallbackPersona, setFallbackPersona] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [hoveredPersona, setHoveredPersona] = useState<string | null>(null);
  const [inputFocused, setInputFocused] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [typingEffect, setTypingEffect] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [userHasTyped, setUserHasTyped] = useState(false); // 新增状态：用户是否已经输入过
  const typingRef = useRef<NodeJS.Timeout | null>(null);
  const textInputRef = useRef<HTMLInputElement>(null);
  
  // 页面加载动画
  useEffect(() => {
    setTimeout(() => {
      setLoaded(true);
    }, 100);
    
    // 启动打字效果
    startTypingEffect();
    
    return () => {
      if (typingRef.current) {
        clearTimeout(typingRef.current);
      }
    };
  }, []);

  // 获取MBTI推荐
  useEffect(() => {
    const mbti = localStorage.getItem('mbtiType')?.toLowerCase();
    const storedPersona = localStorage.getItem('initPersona');
    const fallback = storedPersona || (mbti && mbtiToPersonaMap[mbti]) || 'caelum';
    console.log('[DEBUG] fallbackPersona from MBTI:', fallback);
    setFallbackPersona(fallback);
  }, []);
  
  // 打字效果 - 在输入框中自动显示建议（但不自动分析）
  const startTypingEffect = () => {
    const suggestedTexts = [
      "I want to be more confident and decisive.",
      "I need support to begin my journey gently.",
      "I want clarity and objectivity in my thinking.",
      "I need structure and precision in my approach.",
      "I want to build steady and reliable habits."
    ];
    
    const selectedText = suggestedTexts[Math.floor(Math.random() * suggestedTexts.length)];
    let currentIndex = 0;
    setIsTyping(true);
    
    const typeNextChar = () => {
      if (currentIndex < selectedText.length) {
        setTypingEffect(selectedText.substring(0, currentIndex + 1));
        currentIndex++;
        typingRef.current = setTimeout(typeNextChar, 70 + Math.random() * 50);
      } else {
        setIsTyping(false);
        // 移除自动分析 - 不再在这里调用 analyzeText
      }
    };
    
    typingRef.current = setTimeout(typeNextChar, 1500);
  };
  
  // 增强的文本分析函数
  const analyzeText = (text) => {
    // 如果文本为空或只包含空格，不进行分析并清除推荐
    if (!text || text.trim() === '') {
      setRecommended(null);
      return;
    }
    
    const lowercaseText = text.toLowerCase().trim();
    
    // 检查是否有强烈的意图表达
    const hasIntent = Object.values(intentKeywords).some(wordList => 
      wordList.some(word => lowercaseText.includes(word))
    );
    
    // 如果文本太短且没有明确意图，不做推荐
    if (lowercaseText.length < 5 && !hasIntent) {
      setRecommended(null);
      return;
    }
    
    // 使用分数系统，根据匹配的关键词数给每个角色打分
    const personaScores = Object.entries(personaKeywordsMap).reduce((scores, [persona, keywords]) => {
      const matchScore = keywords.reduce((score, keyword) => {
        // 完整单词匹配得3分
        if (lowercaseText.includes(` ${keyword} `) || 
            lowercaseText.startsWith(`${keyword} `) || 
            lowercaseText.endsWith(` ${keyword}`)) {
          return score + 3;
        } 
        // 部分匹配得1分
        else if (lowercaseText.includes(keyword)) {
          return score + 1;
        }
        return score;
      }, 0);
      
      scores[persona] = matchScore;
      return scores;
    }, {});
    
    // 找出得分最高的角色
    let highestScore = 0;
    let bestMatch = null;
    
    Object.entries(personaScores).forEach(([persona, score]) => {
      if (score > highestScore) {
        highestScore = score as number;
        bestMatch = persona;
      }
    });
    
    // 只有当分数足够高时才设置推荐
    const MIN_SCORE_THRESHOLD = 3; // 需要至少一个完整匹配或多个部分匹配
    
    // 如果有匹配且分数足够高，设置为推荐
    if (bestMatch && highestScore >= MIN_SCORE_THRESHOLD) {
      setRecommended(bestMatch);
      return;
    }
    
    // 如果没有足够高分的匹配但有意图表达，尝试根据语义分析
    if (hasIntent && lowercaseText.length > 5) {
      // 查找与 "calm" 相关的关键词 (lucis)
      if (/\b(calm|peace|tranquil|serene|quiet|steady|stable|relax|patient|mindful|focus)\b/i.test(lowercaseText)) {
        setRecommended('lucis');
        return;
      }
      
      // 查找与 "confident" 相关的关键词 (caelum)
      if (/\b(confident|strong|powerful|bold|decisive|assertive|leader|achieve|succeed|win|ambitious)\b/i.test(lowercaseText)) {
        setRecommended('caelum');
        return;
      }
      
      // 查找与 "kind" 相关的关键词 (rhea)
      if (/\b(kind|gentle|caring|compassionate|empathy|supportive|nurturing|loving|tender|friendly|warm)\b/i.test(lowercaseText)) {
        setRecommended('rhea');
        return;
      }
      
      // 查找与 "clear" 相关的关键词 (aurelia)
      if (/\b(clear|rational|logical|intelligent|smart|analytical|insightful|objective|understand|think|focused)\b/i.test(lowercaseText)) {
        setRecommended('aurelia');
        return;
      }
      
      // 查找与 "organized" 相关的关键词 (niveus)
      if (/\b(organized|precise|structured|methodical|systematic|detailed|thorough|exact|disciplined|efficient|plan)\b/i.test(lowercaseText)) {
        setRecommended('niveus');
        return;
      }
    }
    
    // 如果没有匹配，不推荐任何 persona
    setRecommended(null);
  };

  // 处理自定义输入
  const handleCustomInput = () => {
    // 只有用户真正输入过内容时才分析
    if (!custom || !userHasTyped) {
      setRecommended(null);
      return;
    }
    analyzeText(custom);
  };

  // 处理开始按钮
  const handleStart = (persona: string) => {
    setSubmitting(true);
    localStorage.setItem('creStyleOverride', persona);
    localStorage.setItem('initPersona', persona);
    localStorage.setItem('targetPersona', persona);
    
    console.log('[DEBUG] Saved growth target persona (creStyleOverride):', persona);
    
    // 显示视觉反馈后再导航
    setSelected(persona);
    setTimeout(() => {
      navigate('/identity/train');
    }, 1200);
  };
  
  // 处理输入框内容变化
  const handleInputChange = (e) => {
    // 如果正在进行自动打字效果，则停止
    if (isTyping) {
      setIsTyping(false);
      if (typingRef.current) {
        clearTimeout(typingRef.current);
      }
    }
    
    const newValue = e.target.value;
    setCustom(newValue);
    setUserHasTyped(true); // 标记用户已经输入过
    
    // 如果清空输入，也清空推荐
    if (!newValue.trim()) {
      setRecommended(null);
    } else {
      // 实时分析输入，提供即时推荐
      analyzeText(newValue);
    }
  };
  
  // 文本输入框获取焦点
  const handleInputFocus = () => {
    setInputFocused(true);
    
    // 如果正在进行自动打字效果，停止并采用已经输入的内容
    if (isTyping) {
      setIsTyping(false);
      if (typingRef.current) {
        clearTimeout(typingRef.current);
      }
      
      setCustom(typingEffect);
      setTypingEffect('');
      setUserHasTyped(true); // 标记用户已经输入过（通过点击采用示例文本）
      
      // 分析示例文本
      setTimeout(() => {
        analyzeText(typingEffect);
      }, 100);
    }
  };

  // 获取当前有效的角色
  const getEffectivePersona = () => {
    return selected || recommended || hoveredPersona || fallbackPersona;
  };

  // 自定义CSS样式，包含动画和过渡效果
  const customStyles = `
    .wave {
      position: absolute;
      width: 100%;
      height: 100px;
      background-size: 1600px 100px;
    }
    
    .wave1 {
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%23fef3c7' fill-opacity='0.6' d='M0,192L48,176C96,160,192,128,288,122.7C384,117,480,139,576,144C672,149,768,139,864,149.3C960,160,1056,192,1152,197.3C1248,203,1344,181,1392,170.7L1440,160L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z'%3E%3C/path%3E%3C/svg%3E");
      animation: wave 30s linear infinite;
    }
    
    .wave2 {
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%23fef9c3' fill-opacity='0.3' d='M0,256L48,261.3C96,267,192,277,288,266.7C384,256,480,224,576,213.3C672,203,768,213,864,224C960,235,1056,245,1152,240C1248,235,1344,213,1392,202.7L1440,192L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z'%3E%3C/path%3E%3C/svg%3E");
      animation: wave 20s linear reverse infinite;
      top: 30px;
    }
    
    @keyframes wave {
      0% {
        background-position-x: 0;
      }
      100% {
        background-position-x: 1600px;
      }
    }
    
    .lightbulb-rays {
      width: 80px;
      height: 80px;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1zm0 18v2c0 .55.45 1 1 1s1-.45 1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1zM5.99 4.58c-.39-.39-1.03-.39-1.41 0-.39.39-.39 1.03 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0s.39-1.03 0-1.41L5.99 4.58zm12.37 12.37c-.39-.39-1.03-.39-1.41 0-.39.39-.39 1.03 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0 .39-.39.39-1.03 0-1.41l-1.06-1.06zm1.06-10.96c.39-.39.39-1.03 0-1.41-.39-.39-1.03-.39-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06zM7.05 18.36c.39-.39.39-1.03 0-1.41-.39-.39-1.03-.39-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06z' fill='%23FBBF24'/%3E%3C/svg%3E");
      opacity: 0;
      animation: rays-fade 8s ease-in-out infinite;
    }
    
    @keyframes rays-fade {
      0%, 100% {
        opacity: 0;
        transform: scale(0.8);
      }
      50% {
        opacity: 0.6;
        transform: scale(1.1);
      }
    }
    
    .pulsing-glow {
      animation: pulsing 2s ease-in-out infinite;
    }
    
    @keyframes pulsing {
      0%, 100% {
        filter: drop-shadow(0 0 5px rgba(251, 191, 36, 0.4));
      }
      50% {
        filter: drop-shadow(0 0 20px rgba(251, 191, 36, 0.8));
      }
    }
    
    .animate-float {
      animation: float ease-in-out infinite;
    }
    
    @keyframes float {
      0%, 100% {
        transform: translateY(0);
      }
      50% {
        transform: translateY(-100px);
      }
    }
    
    .animate-pulse-slow {
      animation: pulse 6s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
    
    @keyframes pulse {
      0%, 100% {
        opacity: 0.2;
      }
      50% {
        opacity: 0.5;
      }
    }
    
    .animate-spin-slow {
      animation: spin 8s linear infinite;
    }
    
    @keyframes spin {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }
    
    .animate-bounce-gentle {
      animation: bounce-gentle 2s ease infinite;
    }
    
    @keyframes bounce-gentle {
      0%, 100% {
        transform: translateY(0);
      }
      50% {
        transform: translateY(-10px);
      }
    }
    
    .animate-ping-slow {
      animation: ping-slow 4s cubic-bezier(0, 0, 0.2, 1) infinite;
    }
    
    @keyframes ping-slow {
      0% {
        transform: scale(1);
      }
      50% {
        transform: scale(1.1);
      }
      100% {
        transform: scale(1);
      }
    }
    
    .animate-pulse-gentle {
      animation: pulse-gentle 4s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
    
    @keyframes pulse-gentle {
      0%, 100% {
        opacity: 1;
      }
      50% {
        opacity: 0.8;
      }
    }
    
    .persona-card {
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
      overflow: hidden;
    }
    
    .persona-card:hover {
      transform: translateY(-5px);
    }
    
    .persona-card.selected {
      transform: scale(1.03);
    }
    
    .persona-symbol {
      transition: all 0.5s ease;
    }
    
    .persona-card:hover .persona-symbol {
      transform: scale(1.1) rotate(5deg);
    }
    
    .persona-traits {
      max-height: 0;
      overflow: hidden;
      transition: all 0.3s ease-out;
    }
    
    .persona-traits.visible {
      max-height: 80px;
      margin-top: 0.5rem;
    }
    
    .custom-input {
      transition: all 0.3s ease;
    }
    
    .custom-input:focus {
      box-shadow: 0 0 0 3px rgba(251, 191, 36, 0.2);
    }
    
    .start-button {
      position: relative;
      overflow: hidden;
    }
    
    .start-button::after {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
      transition: all 0.5s ease;
    }
    
    .start-button:hover::after {
      left: 100%;
    }
    
    .persona-card::before {
      content: '';
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: radial-gradient(circle, rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 60%);
      opacity: 0;
      transform: scale(0.5);
      transition: transform 0.6s ease, opacity 0.6s ease;
      z-index: 1;
      pointer-events: none;
    }
    
    .persona-card.selected::before {
      opacity: 0.3;
      transform: scale(1);
      animation: pulse-out 2s ease-out;
    }
    
    @keyframes pulse-out {
      0% {
        opacity: 0.5;
        transform: scale(0.5);
      }
      100% {
        opacity: 0;
        transform: scale(2);
      }
    }
    
    .cursor-blink {
      border-right: 2px solid #f59e0b;
      animation: blink 1s step-end infinite;
    }
    
    @keyframes blink {
      from, to { border-color: transparent }
      50% { border-color: #f59e0b }
    }
    
    .recommendation-appear {
      animation: appear-fade 0.5s ease-out forwards;
    }
    
    @keyframes appear-fade {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  `;
  
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-white to-gray-50 pt-12 pb-20 overflow-hidden">
      {/* 注入自定义动画样式 */}
      <style>{customStyles}</style>
      
      {/* 背景元素 */}
      <WaveBackground />
      <InspirationBubbles activePersona={getEffectivePersona()} />
      <LightbulbEffect pulsing={inputFocused || typingEffect.length > 0} />
      
      <div className="relative z-10 max-w-xl mx-auto px-6 pt-6 pb-12 space-y-8">
        {/* 标题区域 */}
        <div 
          className={`text-center mb-8 transition-all duration-1000 ease-out ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform -translate-y-10'}`}
        >
          <div className="inline-block p-3 mb-6 bg-yellow-50 bg-opacity-80 backdrop-blur-sm rounded-full shadow-md">
            <div className="w-16 h-16 flex items-center justify-center bg-gradient-to-br from-yellow-400 to-amber-300 rounded-full shadow-lg">
              <span className="text-3xl transform transition-transform duration-700 ease-out hover:rotate-12">💡</span>
            </div>
          </div>
          <h1 className="text-3xl font-serif font-bold text-gray-900 tracking-tight mb-3">
            Who do you want to become?
          </h1>
          <p className="text-lg text-amber-600 font-medium max-w-md mx-auto mt-3">
            <span className="bg-yellow-50 px-4 py-1 rounded-full shadow-sm backdrop-blur-sm">
              Choose the voice that will guide you
            </span>
          </p>
        </div>

        {/* MBTI推荐提示 */}
        {fallbackPersona && personaMap[fallbackPersona] && (
          <div 
            className={`bg-white bg-opacity-80 backdrop-blur-sm rounded-xl p-5 border border-yellow-100 shadow-sm transition-all duration-1000 ease-out delay-300 ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
          >
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0 text-yellow-500 text-xl">✨</div>
              <p className="text-gray-700">
                Based on your MBTI, we suggest starting with{' '}
                <span className={`font-medium ${personaMap[fallbackPersona].textColor}`}>
                  {personaMap[fallbackPersona].emoji} {personaMap[fallbackPersona].label}
                </span>
              </p>
            </div>
          </div>
        )}

        {/* 角色选择区域 */}
        <div className="grid grid-cols-1 gap-4 mt-2">
          {Object.entries(personaMap).map(([key, persona], i) => (
            <button
              key={key}
              onClick={() => setSelected(key)}
              onMouseEnter={() => setHoveredPersona(key)}
              onMouseLeave={() => setHoveredPersona(null)}
              className={`relative persona-card text-left bg-white backdrop-blur-sm bg-opacity-90 border ${persona.borderColor} rounded-xl p-5 shadow-sm hover:shadow-md transition-all duration-300 ${selected === key ? 'selected ring-2 ring-offset-1 ring-yellow-300 shadow-md' : ''} ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
              style={{ 
                transitionDelay: `${400 + i * 100}ms`,
              }}
              disabled={submitting}
            >
              {/* 背景渐变 */}
              <div className={`absolute inset-0 bg-gradient-to-r ${hoveredPersona === key || selected === key ? persona.hoverGradient : persona.gradient} rounded-xl opacity-40 transition-opacity duration-300 ${hoveredPersona === key || selected === key ? 'opacity-70' : ''}`}></div>
              
              <div className="relative z-10 flex items-start gap-4">
                {/* 图标/符号 */}
                <div className="flex-shrink-0">
                  <div className={`w-10 h-10 ${persona.iconBg} rounded-full flex items-center justify-center shadow-sm persona-symbol ${persona.animation}`}>
                    <span className="text-xl">{persona.emoji}</span>
                  </div>
                </div>
                
                <div className="flex-grow">
                  {/* 标题和引用 */}
                  <h3 className={`text-lg font-semibold ${persona.textColor}`}>
                    {persona.label}
                  </h3>
                  <p className="text-gray-600 text-sm italic mt-1">"{persona.quote}"</p>
                  
                  {/* 描述 */}
                  <p className="text-gray-700 text-sm mt-2">
                    {persona.description}
                  </p>
                  
                  {/* 特质标签 - 悬停时显示 */}
                  <div className={`flex flex-wrap gap-2 persona-traits ${hoveredPersona === key || selected === key ? 'visible' : ''}`}>
                    {persona.traits.map((trait, j) => (
                      <span 
                        key={j} 
                        className={`inline-block px-2 py-0.5 rounded-full text-xs ${persona.textColor} ${persona.bgColor}`}
                      >
                        {trait}
                      </span>
                    ))}
                  </div>
                </div>
                
                {/* 选择指示器 */}
                {selected === key && (
                  <div className="absolute right-4 top-1/2 transform -translate-y-1/2 flex items-center justify-center w-8 h-8 bg-yellow-100 rounded-full">
                    <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  </div>
                )}
              </div>
            </button>
          ))}
        </div>

        {/* 自定义输入区域 */}
        <div 
          className={`space-y-3 pt-6 transition-all duration-1000 ease-out delay-800 ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
        >
          <div className="flex items-center gap-2">
            <span className="text-amber-500 text-sm">✏️</span>
            <p className="text-gray-700">Or write one sentence about who you want to become:</p>
          </div>
          
          <div className={`relative rounded-lg transition-all duration-300 ${inputFocused ? 'shadow-md' : ''}`}>
            <input
              ref={textInputRef}
              type="text"
              value={custom}
              onChange={handleInputChange}
              onFocus={handleInputFocus}
              onBlur={() => {
                setInputFocused(false);
                handleCustomInput();
              }}
              placeholder="e.g. I want to be calm and focused."
              className={`w-full border border-amber-200 px-4 py-3 rounded-lg bg-white bg-opacity-90 backdrop-blur-sm text-gray-700 placeholder-gray-400 custom-input ${submitting ? 'opacity-50' : ''}`}
              disabled={submitting || isTyping}
            />
            
            {/* 自动打字效果 */}
            {isTyping && typingEffect && (
              <div 
                className="absolute inset-0 px-4 py-3 text-gray-700 flex items-center cursor-text"
                onClick={() => {
                  setIsTyping(false);
                  if (typingRef.current) clearTimeout(typingRef.current);
                  setCustom(typingEffect);
                  setTypingEffect('');
                  setUserHasTyped(true);
                  if (textInputRef.current) textInputRef.current.focus();
                  // 分析采用的示例文本
                  setTimeout(() => {
                    analyzeText(typingEffect);
                  }, 100);
                }}
              >
                {typingEffect}<span className="cursor-blink">&nbsp;</span>
              </div>
            )}
            
            {/* 输入时的动态光效 */}
            <div className={`absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-yellow-300 to-amber-500 rounded-full transition-all duration-300 ${inputFocused ? 'w-full opacity-100' : 'w-0 opacity-0'}`}></div>
          </div>
          
          {/* 基于输入的推荐 - 只在有输入且有推荐且用户已经输入过时显示 */}
          {recommended && personaMap[recommended] && custom.trim().length > 0 && userHasTyped && (
            <div className="bg-yellow-50 border border-yellow-100 rounded-lg p-4 recommendation-appear">
              <div className="flex gap-3">
                <div className={`w-10 h-10 ${personaMap[recommended].iconBg} rounded-full flex items-center justify-center shadow-sm ${personaMap[recommended].animation}`}>
                  <span className="text-xl">{personaMap[recommended].emoji}</span>
                </div>
                <div>
                  <p className="text-gray-700 text-sm">
                    Based on your input, we recommend:
                  </p>
                  <p className={`font-medium text-lg ${personaMap[recommended].textColor}`}>
                    {personaMap[recommended].label}
                  </p>
                  <p className="text-gray-600 text-xs italic mt-1">
                    "{personaMap[recommended].quote}"
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 开始按钮区域 */}
        <div 
          className={`pt-6 transition-all duration-1000 ease-out delay-1000 ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
        >
          {(selected || (recommended && userHasTyped && (custom.trim() || typingEffect))) && !submitting && (
            <button
              className="w-full bg-gradient-to-r from-amber-500 to-yellow-500 text-white font-medium px-6 py-3 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 start-button"
              onClick={() => handleStart(selected || recommended || '')}
            >
              <div className="flex items-center justify-center gap-2">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                </svg>
                <span>
                  Start with {selected || recommended ? personaMap[selected || recommended || ''].emoji : ''} {selected || recommended ? personaMap[selected || recommended || ''].label : ''}
                </span>
              </div>
            </button>
          )}
          
          {/* 提交状态 */}
          {submitting && (
            <div className="w-full bg-gradient-to-r from-amber-500 to-yellow-500 text-white font-medium px-6 py-3 rounded-lg shadow-md flex items-center justify-center gap-3">
              <svg className="w-5 h-5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
              </svg>
              Setting up your journey...
            </div>
          )}
          
          {!selected && !recommended && !submitting && (
            <div className="bg-red-50 border border-red-100 rounded-lg p-4 text-center">
              <p className="text-red-600 text-sm">
                Please select a style above or enter a sentence that describes your identity goal.
              </p>
            </div>
          )}
          
          {/* 返回按钮 */}
          <div className="text-center mt-6">
            <button 
              onClick={() => navigate(-1)}
              className={`text-sm text-gray-500 hover:text-gray-700 transition-colors duration-300 flex items-center justify-center gap-1 mx-auto ${submitting ? 'opacity-50 pointer-events-none' : ''}`}
              disabled={submitting}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
              </svg>
              <span>Back to Previous Step</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IdentityStartPage;






