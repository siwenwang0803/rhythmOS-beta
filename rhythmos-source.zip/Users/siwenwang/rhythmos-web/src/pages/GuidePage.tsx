import React from "react";
import RhythmTooltip from "@/components/ui/RhythmTooltip";

const GuidePage: React.FC = () => {
  const sections = [
    {
      title: "What is Rhythm?",
      content: (
        <>
          <RhythmTooltip term="rhythm" /> is the natural emotional and behavioral flow that emerges throughout your day. RhythmOS helps you become more aware of that rhythm — not to control it, but to grow with it.
          By aligning your inner state with outer action, rhythm becomes your personal tempo of growth.
        </>
      ),
    },
    {
      title: "What is RhythmOS?",
      content: (
        <>
          RhythmOS is a rhythm-based growth system that helps align your emotions, intentions, and daily actions through personalized language feedback.
          It works by observing your emotional rhythm, offering resonant cues (<RhythmTooltip term="CRE" />), and letting you grow through reflection, <RhythmTooltip term="feedback" />, and daily rhythm tracking.
        </>
      ),
    },
    {
      title: "What is a CRE cue?",
      content: (
        <>
          A <RhythmTooltip term="CRE" /> (Contextual Resonant Echo) is a crafted phrase that resonates with your current emotional rhythm.
          It encourages introspection, realignment, or activation — based on your selected trend and system-detected rhythm.
        </>
      ),
    },
    {
      title: "What is your Daily Rhythm?",
      content: (
        <>
          Your <RhythmTooltip term="dailyRhythm" /> represents your system-evaluated rhythm based on today's task performance.
          Higher task engagement leads to steadier daily rhythm states like Steady or Peak Momentum.
        </>
      ),
    },
    {
      title: "What is your Rhythm Trend?",
      content: (
        <>
          Your <RhythmTooltip term="trend" /> reflects your self-reported energy state: collapsed, wavy, stable, or rising.
          It guides the tone and structure of your daily cues and microtask suggestions.
        </>
      ),
    },
    {
      title: "What is your Persona?",
      content: (
        <>
          Your <RhythmTooltip term="persona" /> defines the tone style of the system’s interaction with you.
          You might choose encouragement (Rhea), clarity (Aurelia), precision (Niveus), or energy (Caelum) — adapting to your growth journey.
        </>
      ),
    },
    {
      title: "What is the Signature Map?",
      content: (
        <>
          The <RhythmTooltip term="Signature" /> records your cumulative tone feedback and persona alignment over time.
          It's your personalized growth fingerprint, showing how your rhythm style evolves.
        </>
      ),
    },
    {
      title: "How does Feedback work?",
      content: (
        <>
          After reading a <RhythmTooltip term="CRE" />, you rate how aligned it felt.
          This <RhythmTooltip term="feedback" /> tunes future cue generation, persona matching, and shapes your Signature Map.
        </>
      ),
    },
    {
      title: "How to grow with RhythmOS?",
      content: (
        <>
          Each day: check-in → receive your <RhythmTooltip term="CRE" /> → act on suggestions → reflect → rate → update your daily rhythm and signature.
          Growth here follows natural emotional rhythm — not external performance pressure.
        </>
      ),
    },
  ];

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">RhythmOS Guide</h1>
      {sections.map((section, index) => (
        <details key={index} className="mb-4 border rounded-lg p-4">
          <summary className="text-lg font-semibold cursor-pointer">{section.title}</summary>
          <div className="mt-2 text-base text-gray-700">{section.content}</div>
        </details>
      ))}
      <div className="text-center pt-8">
  <a
    href="/"
    className="inline-block px-4 py-2 text-sm font-medium bg-gray-100 text-gray-800 rounded-md shadow hover:bg-gray-200 transition"
  >
    🔙 Return to Beta Welcome Page
  </a>
</div>
    </div>
  );
};

export default GuidePage;



