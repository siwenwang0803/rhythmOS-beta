// /pages/IdentityInsightPage.tsx

import React, { useState, useEffect } from 'react';
import RhythmTrendView from '../components/RhythmTrendView';
import ConfidentialNotice from '../components/ConfidentialNotice';
import PersonaUsageHeatmap from '../components/PersonaUsageHeatmap';
import CREFeedbackSignatureMap from '../components/CREFeedbackSignatureMap';
import RhythmStudioPanel from '../components/ui/RhythmStudioPanel';
import SpeakReplayView from '../components/SpeakReplayView';
import UserTextInput from '../components/UserTextInput';
import { getDominantPersonaTone } from '../logic/getDominantPersonaTone';
import { generateIdentityTags } from '../logic/generateIdentityTags';
import FooterNavigation from '../components/FooterNavigation';
import SignatureSummaryBox from '../components/SignatureSummaryBox';
import { ChallengeStatsView } from '../components/ChallengeStatsView';
import { SignatureFeedbackReplay } from '../components/SignatureFeedbackReplay';
import { ToneFeedbackHeatmap } from '../components/ToneFeedbackHeatmap';
import { RhythmStatusSuggestionBox } from '../components/RhythmStatusSuggestionBox';
import { BetaOnboardingTip } from '../components/BetaOnboardingTip';
import { RhythmOnboardingGuide } from '../components/RhythmOnboardingGuide';
import { ExportRhythmData } from '../components/ExportRhythmData';
import GlobalOnboardingHint from '../components/GlobalOnboardingHint';
import EndMyDayButton from '../components/EndMyDayButton';
import { useDailyRhythm } from '../hooks/useDailyRhythm';
import RhythmScoreSummaryCard from '../components/RhythmScoreSummaryCard';
import SubtaskIntentSummaryView from '../components/SubtaskIntentSummaryView';
import SignatureReplayPanel from '../components/SignatureReplayPanel';
import { signatureMap } from '../SignatureMap';
import FeedbackLogCollapse from '../components/FeedbackLogCollapse';
import RhythmInteractionReplayPanel from '../components/RhythmInteractionReplayPanel';
import ChallengeReplayPanel from '../components/ChallengeReplayPanel';
import IdentityGPTSummaryCard from '../components/IdentityGPTSummaryCard';
import IdentityNarrativeCard from '../components/IdentityNarrativeCard';
import MicrotaskStreakHint from '../components/MicrotaskStreakHint';
import { checkPassiveTagUnlock } from '../logic/checkPassiveTagUnlock';
import TagUnlockNotice from '../components/TagUnlockNotice';
import DigestUnlockedTagsSummary from '../components/DigestUnlockedTagsSummary';
import { getCurrentTrend } from '../utils/rhythmTrend';
import { checkToneFatigueSuggestion } from '../logic/ToneFatigueTrigger';
import ToneOverviewPanel from '../components/ToneOverviewPanel';
import ToneNudgeHint from '../components/ToneNudgeHint';
import DigestToneSummaryBlock from '../components/DigestToneSummaryBlock';
import ToneDonutChart from '../components/ToneDonutChart';
import { getWeeklyUnlockedTags } from '../components/TagUnlockNarrator';
import { getSignatureMap } from '../SignatureMap';
import ToneScorePanel from '../components/ToneScorePanel';
import { ToneFeedbackChart } from '../components/ToneFeedbackChart';
import { getToneScoreMapByDays } from '../utils/writeToneLog';
import { identityTagInfo } from '../utils/identityTagInfo';
// UI规范中的颜色和样式
const RHYTHM_COLORS = {
  collapsed: '#AEC6CF', // 平静的蓝色
  wavy: '#C3B1E1',     // 过渡的薰衣草色
  stable: '#C5D8A4',    // 稳定的绿色
  rising: '#FFB347'     // 激活的橙黄色
};

const PERSONAS = {
  rhea: {
    color: '#F5CFCF',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    icon: '💗'
  },
  aurelia: {
    color: '#D8A7CA',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    icon: '🧠'
  },
  lucis: {
    color: '#A4D8C5',
    gradient: 'linear-gradient(135deg, #E8F5C7, #A4D8C5)',
    icon: '🌱'
  },
  niveus: {
    color: '#C7C7C7',
    gradient: 'linear-gradient(135deg, #E8E8E8, #C7C7C7)',
    icon: '📊'
  },
  caelum: {
    color: '#4B6587',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    icon: '💠'
  }
};

// Trend label mapping
const TREND_LABELS = {
  collapsed: '🧘‍♀️ Calm Reset',
  wavy: '🌊 Dynamic Waves',
  stable: '🌿 Stable Flow',
  rising: '🚀 Rising Momentum'
};

const IdentityInsightPage: React.FC = () => {
  useDailyRhythm();

  const [showDetails, setShowDetails] = useState(false);
  const [unlockedTags, setUnlockedTags] = useState<string[]>([]);
  const [scrolledPastHeader, setScrolledPastHeader] = useState(false);
  const [animatedElements, setAnimatedElements] = useState({
    header: false,
    summary: false,
    narrative: false,
    details: false
  });
  const [expandedSections, setExpandedSections] = useState<string[]>([]);
  const [isDaytime, setIsDaytime] = useState(true);

  // 滚动动画处理
  useEffect(() => {
    const handleScroll = () => {
      
      const scrollPosition = window.scrollY;
      
      // 更新header状态基于滚动位置
      setScrolledPastHeader(scrollPosition > 200);
      
      // 触发动画基于滚动位置
      if (scrollPosition > 50 && !animatedElements.header) {
        setAnimatedElements(prev => ({ ...prev, header: true }));
      }
      
      if (scrollPosition > 150 && !animatedElements.summary) {
        setAnimatedElements(prev => ({ ...prev, summary: true }));
      }
      
      if (scrollPosition > 300 && !animatedElements.narrative) {
        setAnimatedElements(prev => ({ ...prev, narrative: true }));
      }
      
      if (scrollPosition > 450 && !animatedElements.details) {
        setAnimatedElements(prev => ({ ...prev, details: true }));
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [animatedElements]);

  // 调试数据和解锁标签
  useEffect(() => {
    const signatureMap = getSignatureMap();
    console.log('✅ [DIGEST DEBUG START]');
    console.log('🎯 toneLog =', signatureMap.toneLog);
    console.log('🎯 cueFeedbackLog =', signatureMap.cueFeedbackLog);
    console.log('🎯 tagLog =', signatureMap.tagLog);

    const scoreMap = getToneScoreMapByDays(3);
    console.log('📊 Final tone score map (3d) =', scoreMap);

    const unlocked = getWeeklyUnlockedTags();
    console.log('🏷️ Weekly unlocked tags =', unlocked);
    console.log('✅ [DIGEST DEBUG END]');

    // 开始动画序列
    setTimeout(() => {
      setAnimatedElements(prev => ({ ...prev, header: true }));
      setTimeout(() => {
        setAnimatedElements(prev => ({ ...prev, summary: true }));
        setTimeout(() => {
          setAnimatedElements(prev => ({ ...prev, narrative: true }));
          setTimeout(() => {
            setAnimatedElements(prev => ({ ...prev, details: true }));
          }, 300);
        }, 300);
      }, 300);
    }, 300);
  }, []);

  // 初始化调试数据和检查解锁标签
  useEffect(() => {
    if (signatureMap.cueFeedbackLog.length === 0) {
      signatureMap.cueFeedbackLog.push({
        cueId: 'debug-001',
        cueText: 'You deserve to pause.',
        tone: 'gentle',
        persona: 'rhea',
        trend: 'stable',
        feedback: 'aligned',
        timestamp: new Date().toISOString(),
      });
      console.log('[DEBUG] Injected test cueFeedback');
    }
    const newTags = checkPassiveTagUnlock();
    setUnlockedTags(newTags);
  }, []);

  const [expandAll, setExpandAll] = useState(false);

  // 添加一个同时处理所有技术部分展开/折叠的函数
  const handleExpandAll = () => {
    if (expandAll) {
      // 如果当前是展开全部状态，则折叠所有部分
      setExpandedSections([]);
      setExpandAll(false);
    } else {
      // 如果当前不是展开全部状态，则展开所有部分
      setExpandedSections([
        'rhythmScore', 
        'personaUsage', 
        'signatureMap', 
        'challengeTracking', 
        'toneDrift', 
        'toneHeatmap', 
        'subtaskStyle', 
        'interactionReplay'
      ]);
      setExpandAll(true);
    }
  };
  
  const latestCue = signatureMap.cueFeedbackLog?.[signatureMap.cueFeedbackLog.length - 1];
  const cueId = latestCue?.cueId || latestCue?.cueText;
  const seenCount = signatureMap.cueSeenCount?.[cueId] || 0;
  const tags = generateIdentityTags();
  const dominant = getDominantPersonaTone();
  
  
  const tagLabel = tags[0]; // ✅ 加在 render 上层

  
  let signatureLog: any[] = [];
let rawRhythmLog: any[] = [];

try {
  const raw1 = localStorage.getItem('signatureFeedbackLog');
  signatureLog = raw1 && raw1 !== 'undefined' ? JSON.parse(raw1) : [];
} catch (e) {
  console.warn('signatureFeedbackLog parse failed:', e);
  signatureLog = [];
}

try {
  const raw2 = localStorage.getItem('rhythmScoreLog');
  rawRhythmLog = raw2 && raw2 !== 'undefined' ? JSON.parse(raw2) : [];
} catch (e) {
  console.warn('rhythmScoreLog parse failed:', e);
  rawRhythmLog = [];
}

const validSignatureLog = signatureLog.filter((entry: any) => entry.persona && entry.tone);
const weeklyUnlockedTags = getWeeklyUnlockedTags(7);
const filteredRhythmLog = rawRhythmLog.filter((entry: any) => entry.source !== 'onboarding');

  const trend = getCurrentTrend();
  const trendColor = RHYTHM_COLORS[trend as keyof typeof RHYTHM_COLORS] || RHYTHM_COLORS.wavy;
  const personaStyle = dominant?.persona ? 
    (PERSONAS[dominant.persona as keyof typeof PERSONAS] || PERSONAS.rhea) : 
    PERSONAS.rhea;
  
  const showRecovery = (trend === 'collapsed' || trend === 'wavy') && validSignatureLog.length < 3;
  const suggestion = checkToneFatigueSuggestion(14);

  const toggleSection = (section: string) => {
    setExpandedSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section) 
        : [...prev, section]
    );
  };

  const isExpanded = (section: string) => expandedSections.includes(section);
  
  // 视觉指标数据
  const rhythmScore = 4.0; // 假设这是从某处获取的
  const rhythmLabel = TREND_LABELS[trend as keyof typeof TREND_LABELS] || '🌊 Dynamic Waves';
  const challengeCount = 4; // 假设这是从某处获取的
  
  // 根据日夜模式调整颜色
  const baseTextColor = isDaytime ? '#333333' : '#E0E0E0';
  const secondaryTextColor = isDaytime ? '#666666' : '#AAAAAA';
  const bgOpacity = isDaytime ? 0.7 : 0.6;

  return (
    <div 
      className="min-h-screen relative overflow-hidden"
      style={{ 
        backgroundColor: isDaytime ? '#F7F3EF' : '#24222A',
        color: baseTextColor,
        backgroundImage: isDaytime 
          ? 'radial-gradient(circle at 30px 30px, #F2E9DE 2px, transparent 0)'
          : 'radial-gradient(circle at 30px 30px, #33303A 2px, transparent 0)',
        backgroundSize: '60px 60px',
        transition: 'background-color 0.5s ease, color 0.5s ease'
      }}
    >
      {/* 环境背景元素 */}
      <div 
        className="fixed inset-0 z-0 pointer-events-none opacity-30"
        style={{ 
          background: `linear-gradient(135deg, ${trendColor}10, transparent 60%, ${personaStyle.color}10)`,
          backdropFilter: 'blur(150px)'
        }}
      />
      
      {/* 浮动形状创造视觉深度 */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div 
          className="absolute -top-[300px] -right-[300px] w-[600px] h-[600px] rounded-full opacity-10"
          style={{ 
            background: trendColor,
            filter: 'blur(150px)'
          }}
        />
        <div 
          className="absolute -bottom-[200px] -left-[200px] w-[400px] h-[400px] rounded-full opacity-10"
          style={{ 
            background: personaStyle.color,
            filter: 'blur(120px)'
          }}
        />
      </div>

      {/* 日夜模式切换按钮 - 置于右上方 */}
      <div className="fixed top-4 right-6 z-50">
        <button
          className="px-3 py-1.5 rounded-full flex items-center gap-2 transition-all duration-300"
          style={{ 
            backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.1)',
            color: secondaryTextColor,
            border: isDaytime ? '1px solid rgba(0, 0, 0, 0.05)' : '1px solid rgba(255, 255, 255, 0.1)',
            backdropFilter: 'blur(4px)'
          }}
          onClick={() => setIsDaytime(!isDaytime)}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-2px)';
            e.currentTarget.style.boxShadow = isDaytime 
              ? '0 4px 12px rgba(0, 0, 0, 0.1)' 
              : '0 4px 12px rgba(0, 0, 0, 0.3)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = 'none';
          }}
        >
          <span>{isDaytime ? '🌙' : '☀️'}</span>
          <span className="text-sm">{isDaytime ? 'Night' : 'Day'}</span>
        </button>
      </div>

      {/* 滚动时显示的固定标题 */}
      <div 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolledPastHeader ? 'translate-y-0 opacity-100' : 'translate-y-[-100%] opacity-0'
        }`}
        style={{ 
          backdropFilter: 'blur(10px)',
          background: isDaytime 
            ? 'rgba(255, 255, 255, 0.85)' 
            : 'rgba(36, 34, 42, 0.85)',
          borderBottom: isDaytime 
            ? '1px solid rgba(0, 0, 0, 0.05)'
            : '1px solid rgba(255, 255, 255, 0.05)',
          boxShadow: isDaytime
            ? '0 4px 20px rgba(0, 0, 0, 0.03)'
            : '0 4px 20px rgba(0, 0, 0, 0.2)'
        }}
      >
        <div className="max-w-4xl mx-auto px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div 
                className="w-8 h-8 rounded-xl flex items-center justify-center"
                style={{ 
                  background: `linear-gradient(135deg, ${trendColor}40, ${personaStyle.color}40)`
                }}
              >
                <span className="text-sm">🧬</span>
              </div>
              <div>
                <h3 className="text-base font-medium" style={{ color: baseTextColor }}>Your Rhythm Insight</h3>
              </div>
            </div>
            
            <div 
              className="px-3 py-1 rounded-full text-xs flex items-center gap-1.5"
              style={{ 
                backgroundColor: trendColor + '30',
                color: baseTextColor
              }}
            >
              <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: trendColor }} />
              <span>{rhythmLabel}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 py-12 space-y-10">
        <GlobalOnboardingHint />
        
        {/* 页面标题区域 */}
        <div 
          className={`transform transition-all duration-700 ${
            animatedElements.header ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
          }`}
        >
          <div className="flex items-center gap-4 mb-6">
            <div 
              className="w-14 h-14 rounded-xl flex items-center justify-center transform transition-all duration-500 hover:scale-105"
              style={{ 
                background: `linear-gradient(135deg, ${trendColor}40, ${personaStyle.color}40)`,
                boxShadow: '0 4px 15px rgba(0, 0, 0, 0.07)'
              }}
            >
              <span className="text-2xl">🧬</span>
            </div>
            <div>
              <h1 
                className="text-3xl font-bold"
                style={{ color: baseTextColor }}
              >
                Your Rhythm Insight
              </h1>
              <p 
                className="text-sm mt-1"
                style={{ color: secondaryTextColor }}
              >
                This page summarizes your current rhythm style, preference trends, and reflections.
              </p>
            </div>
          </div>
        </div>

        <RhythmOnboardingGuide />

        {/* Weekly Digest 按钮 */}
        <div 
          className={`transform transition-all duration-500 ${
            animatedElements.header ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
          }`}
        >
          <a
            href="/digest"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-200"
            style={{ 
              background: 'linear-gradient(135deg, #9C27B0, #673AB7)',
              color: 'white',
              boxShadow: '0 4px 10px rgba(103, 58, 183, 0.3)'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 6px 15px rgba(103, 58, 183, 0.4)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 4px 10px rgba(103, 58, 183, 0.3)';
            }}
          >
            <span>📘</span>
            <span>Weekly Digest</span>
          </a>
        </div>

        {/* 节奏摘要卡片 */}
        <div 
  className={`transform transition-all duration-700 ${
    animatedElements.summary ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
  }`}
>
  <RhythmScoreSummaryCard />
</div>

        {/* 身份叙事卡片 */}
        {(dominant || tags.length > 0 || validSignatureLog.length > 0) && (
          <div
            className={`transform transition-all duration-700 ${
              animatedElements.narrative ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
            }`}
          >
            <div 
              className="rounded-xl overflow-hidden"
              style={{ 
                border: isDaytime 
                  ? '1px solid rgba(0, 0, 0, 0.05)'
                  : '1px solid rgba(255, 255, 255, 0.05)',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.07)',
                backgroundColor: `rgba(255, 255, 255, ${bgOpacity})`,
                backdropFilter: 'blur(8px)'
              }}
            >
              <div className="h-1.5 w-full" style={{ background: personaStyle.gradient }} />
              
              <div className="p-6 space-y-6">
                {/* 标题和身份表达 */}
                <div className="flex items-start gap-4">
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ 
                      background: personaStyle.gradient,
                      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.07)'
                    }}
                  >
                    <span className="text-xl">🧠</span>
                  </div>
                  
                  <div>
                    <h2 
                      className="text-xl font-semibold mb-1"
                      style={{ color: baseTextColor }}
                    >
                      Your Identity Narrative
                    </h2>
                    
                    {/* 身份表达 */}
                    {tags.length > 0 && (
                      <p 
                        className="text-base"
                        style={{ color: secondaryTextColor }}
                      >
                        Your recent identity expression: 
                        {(() => {
  const label = 'Supportive Guardian';
  const info = identityTagInfo[label] || {};
  return (
    <span className="inline-flex items-center gap-1">
      <span 
        className="inline-block ml-2 px-3 py-1 rounded-full text-sm font-medium"
        style={{ 
          backgroundColor: personaStyle.color + '30',
          color: baseTextColor
        }}
      >
        {label}
      </span>
      {info.definition && (
        <span
          className="text-xs text-gray-500 cursor-help"
          title={`📖 ${info.definition}\n🧠 ${info.reason}`}
        >
          ⓘ
        </span>
      )}
    </span>
  );
})()}

                      </p>
                    )}
                  </div>
                </div>

                {/* 身份卡片 */}
                {tags.length > 0 && dominant && (
                  <IdentityNarrativeCard
                    tagId={tags[0]}
                    persona={dominant.persona}
                    tone={dominant.tone}
                    rhythmSummary={`Your rhythm has been ${dominant.trend}.`}
                  />
                )}

                {/* 微任务进度 */}
                <div 
                  className="pt-4 mt-2 border-t"
                  style={{ borderColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)' }}
                >
                  <MicrotaskStreakHint />
                </div>
                
                {/* 解锁标签通知 */}
                {weeklyUnlockedTags.map(tagId => (
                  <TagUnlockNotice key={tagId} tagId={tagId} />
                ))}
                
                <DigestUnlockedTagsSummary tags={weeklyUnlockedTags} />
              </div>
            </div>
          </div>
        )}

        {/* CUE 提示信息 */}
        {cueId && seenCount > 1 && (
          <p 
            className="text-sm italic text-center"
            style={{ color: secondaryTextColor }}
          >
            You've seen this cue <strong>{seenCount}</strong> times.
            {seenCount > 4 && ' Consider trying something new tomorrow.'}
          </p>
        )}

        {/* 技术详情按钮 */}
        <div 
          className={`text-center transform transition-all duration-700 ${
            animatedElements.details ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
          }`}
        >
          <button
            className="px-5 py-2.5 rounded-xl text-sm font-medium inline-flex items-center gap-2 transition-all duration-200"
            style={{ 
              backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.1)',
              color: secondaryTextColor,
              border: isDaytime ? '1px solid rgba(0, 0, 0, 0.05)' : '1px solid rgba(255, 255, 255, 0.05)'
            }}
            onClick={() => setShowDetails(!showDetails)}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = isDaytime ? 'rgba(0, 0, 0, 0.08)' : 'rgba(255, 255, 255, 0.15)';
              e.currentTarget.style.transform = 'translateY(-2px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.1)';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            <span>{showDetails ? '▲' : '▼'}</span>
            <span>{showDetails ? 'Hide technical details' : 'Show technical insight'}</span>
          </button>
        </div>

        {/* 技术详情部分 */}
        {showDetails && (
          <div 
            className="space-y-8 transform transition-all duration-500 animate-fade-in-up"
          >
            {/* 节奏分数历史 */}
            <div 
              className="rounded-xl overflow-hidden"
              style={{ 
                border: isDaytime 
                  ? '1px solid rgba(0, 0, 0, 0.05)'
                  : '1px solid rgba(255, 255, 255, 0.05)',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.07)',
                backgroundColor: `rgba(255, 255, 255, ${bgOpacity})`,
                backdropFilter: 'blur(8px)'
              }}
            >
              {/* 折叠/展开按钮 */}
              <div 
                className="flex items-center justify-between px-6 py-4 cursor-pointer border-b"
                style={{ borderColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)' }}
                onClick={() => toggleSection('rhythmScore')}
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ 
                      background: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)'
                    }}
                  >
                    <span className="text-lg">📈</span>
                  </div>
                  <div>
                    <h2 
                      className="text-lg font-semibold"
                      style={{ color: baseTextColor }}
                    >
                      Rhythm Score History
                    </h2>
                    <p 
                      className="text-sm"
                      style={{ color: secondaryTextColor }}
                    >
                      Your recent rhythmScore trend
                    </p>
                  </div>
                </div>
                
                <div 
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ 
                    backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)',
                    transition: 'transform 0.3s ease'
                  }}
                >
                  <span 
                    style={{ 
                      transform: isExpanded('rhythmScore') ? 'rotate(180deg)' : 'rotate(0deg)',
                      transition: 'transform 0.3s ease'
                    }}
                  >
                    ▼
                  </span>
                </div>
              </div>
              
              {/* 内容部分 */}
              <div 
                className="overflow-hidden transition-all duration-500"
                style={{ 
                  maxHeight: isExpanded('rhythmScore') ? '1000px' : '0',
                  opacity: isExpanded('rhythmScore') ? 1 : 0
                }}
              >
                <div className="p-6">
                  <RhythmTrendView />
                </div>
              </div>
            </div>

            {/* Persona使用热图 */}
            <div 
              className="rounded-xl overflow-hidden"
              style={{ 
                border: isDaytime 
                  ? '1px solid rgba(0, 0, 0, 0.05)'
                  : '1px solid rgba(255, 255, 255, 0.05)',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.07)',
                backgroundColor: `rgba(255, 255, 255, ${bgOpacity})`,
                backdropFilter: 'blur(8px)'
              }}
            >
              {/* 折叠/展开按钮 */}
              <div 
  className="flex items-center justify-between px-6 py-4 cursor-pointer border-b"
  style={{ borderColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)' }}
  onClick={() => toggleSection('personaUsage')}
>
  <div className="flex items-center gap-3">
    <div 
      className="w-10 h-10 rounded-xl flex items-center justify-center"
      style={{ 
        background: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)'
      }}
    >
      <span className="text-lg">📊</span>
    </div>
    <div>
      <h2 
        className="text-lg font-semibold"
        style={{ color: baseTextColor }}
      >
        Style Usage Patterns
      </h2>
      <p 
        className="text-sm"
        style={{ color: secondaryTextColor }}
      >
        How often you've used each persona-tone combination
      </p>
    </div>
  </div>
  
  <div 
    className="w-8 h-8 rounded-full flex items-center justify-center"
    style={{ 
      backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)',
      transition: 'transform 0.3s ease'
    }}
  >
    <span 
      style={{ 
        transform: isExpanded('personaUsage') ? 'rotate(180deg)' : 'rotate(0deg)',
        transition: 'transform 0.3s ease'
      }}
    >
      ▼
    </span>
  </div>
</div>

{/* 内容部分 */}
<div 
  className="overflow-hidden transition-all duration-500"
  style={{ 
    maxHeight: isExpanded('personaUsage') ? '1000px' : '0',
    opacity: isExpanded('personaUsage') ? 1 : 0
  }}
>
  <div className="p-6">
    <PersonaUsageHeatmap />
  </div>
</div>
            </div>

            {/* 类似地，为其他技术部分创建可折叠面板 */}
            {/* Signature Map */}
            <div 
              className="rounded-xl overflow-hidden"
              style={{ 
                border: isDaytime 
                  ? '1px solid rgba(0, 0, 0, 0.05)'
                  : '1px solid rgba(255, 255, 255, 0.05)',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.07)',
                backgroundColor: `rgba(255, 255, 255, ${bgOpacity})`,
                backdropFilter: 'blur(8px)'
              }}
            >
              <div 
                className="flex items-center justify-between px-6 py-4 cursor-pointer border-b"
                style={{ borderColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)' }}
                onClick={() => toggleSection('signatureMap')}
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)' }}
                  >
                    <span className="text-lg">🧩</span>
                  </div>
                  <div>
                    <h2 
                      className="text-lg font-semibold"
                      style={{ color: baseTextColor }}
                    >
                      Signature Map
                    </h2>
                    <p 
                      className="text-sm"
                      style={{ color: secondaryTextColor }}
                    >
                      Persona × tone alignment trend
                    </p>
                  </div>
                </div>
                
                <div 
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ 
                    backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)',
                    transition: 'transform 0.3s ease'
                  }}
                >
                  <span 
                    style={{ 
                      transform: isExpanded('signatureMap') ? 'rotate(180deg)' : 'rotate(0deg)',
                      transition: 'transform 0.3s ease'
                    }}
                  >
                    ▼
                  </span>
                </div>
              </div>
              
              <div 
                className="overflow-hidden transition-all duration-500"
                style={{ 
                  maxHeight: isExpanded('signatureMap') ? '2000px' : '0',
                  opacity: isExpanded('signatureMap') ? 1 : 0
                }}
              >
                <div className="p-6 space-y-6">
                  <CREFeedbackSignatureMap />
                  <SignatureSummaryBox />
                  <SignatureReplayPanel />
                  <RhythmStatusSuggestionBox />
                </div>
              </div>
            </div>

            {/* Challenge Tracking */}
            <div 
              className="rounded-xl overflow-hidden"
              style={{ 
                border: isDaytime 
                  ? '1px solid rgba(0, 0, 0, 0.05)'
                  : '1px solid rgba(255, 255, 255, 0.05)',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.07)',
                backgroundColor: `rgba(255, 255, 255, ${bgOpacity})`,
                backdropFilter: 'blur(8px)'
              }}
            >
              <div 
                className="flex items-center justify-between px-6 py-4 cursor-pointer border-b"
                style={{ borderColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)' }}
                onClick={() => toggleSection('challengeTracking')}
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)' }}
                  >
                    <span className="text-lg">🎯</span>
                  </div>
                  <div>
                    <h2 
                      className="text-lg font-semibold"
                      style={{ color: baseTextColor }}
                    >
                      Identity Challenge Tracking
                    </h2>
                  </div>
                </div>
                
                <div 
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ 
                    backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)',
                    transition: 'transform 0.3s ease'
                  }}
                >
                  <span 
                    style={{ 
                      transform: isExpanded('challengeTracking') ? 'rotate(180deg)' : 'rotate(0deg)',
                      transition: 'transform 0.3s ease'
                    }}
                  >
                    ▼
                  </span>
                </div>
              </div>
              
              <div 
                className="overflow-hidden transition-all duration-500"
                style={{ 
                  maxHeight: isExpanded('challengeTracking') ? '1500px' : '0',
                  opacity: isExpanded('challengeTracking') ? 1 : 0
                }}
              >
                <div className="p-6 space-y-6">
                  <ChallengeStatsView />
                  <ChallengeReplayPanel />
                </div>
              </div>
            </div>

            {/* Tone Drift */}
            <div 
              className="rounded-xl overflow-hidden"
              style={{ 
                border: isDaytime 
                  ? '1px solid rgba(0, 0, 0, 0.05)'
                  : '1px solid rgba(255, 255, 255, 0.05)',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.07)',
                backgroundColor: `rgba(255, 255, 255, ${bgOpacity})`,
                backdropFilter: 'blur(8px)'
              }}
            >
              <div 
                className="flex items-center justify-between px-6 py-4 cursor-pointer border-b"
                style={{ borderColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)' }}
                onClick={() => toggleSection('toneDrift')}
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)' }}
                  >
                    <span className="text-lg">📈</span>
                  </div>
                  <div>
                    <h2 
                      className="text-lg font-semibold"
                      style={{ color: baseTextColor }}
                    >
                      Tone Drift Over Time
                    </h2>
                    <p 
                      className="text-sm"
                      style={{ color: secondaryTextColor }}
                    >
                      Based on your aligned feedback
                    </p>
                  </div>
                </div>
                
                <div 
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ 
                    backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)',
                    transition: 'transform 0.3s ease'
                  }}
                >
                  <span 
                    style={{ 
                      transform: isExpanded('toneDrift') ? 'rotate(180deg)' : 'rotate(0deg)',
                      transition: 'transform 0.3s ease'
                    }}
                  >
                    ▼
                  </span>
                </div>
              </div>
              
              <div 
                className="overflow-hidden transition-all duration-500"
                style={{ 
                  maxHeight: isExpanded('toneDrift') ? '1000px' : '0',
                  opacity: isExpanded('toneDrift') ? 1 : 0
                }}
              >
                <div className="p-6">
                  <ToneFeedbackChart />
                  
                  {suggestion && (
                    <div className="mt-4">
                      <ToneNudgeHint dominant={suggestion.dominant} suggested={suggestion.suggested} />
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* 为剩余的技术部分创建类似的折叠面板 */}
            {/* Tone Feedback Heatmap */}
            <div 
              className="rounded-xl overflow-hidden"
              style={{ 
                border: isDaytime 
                  ? '1px solid rgba(0, 0, 0, 0.05)'
                  : '1px solid rgba(255, 255, 255, 0.05)',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.07)',
                backgroundColor: `rgba(255, 255, 255, ${bgOpacity})`,
                backdropFilter: 'blur(8px)'
              }}
            >
              <div 
                className="flex items-center justify-between px-6 py-4 cursor-pointer border-b"
                style={{ borderColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)' }}
                onClick={() => toggleSection('toneHeatmap')}
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)' }}
                  >
                    <span className="text-lg">🎨</span>
                  </div>
                  <div>
                    <h2 
                      className="text-lg font-semibold"
                      style={{ color: baseTextColor }}
                    >
                      Tone Feedback Heatmap
                    </h2>
                    <p 
                      className="text-sm"
                      style={{ color: secondaryTextColor }}
                    >
                      Distribution of feedback by tone
                    </p>
                  </div>
                </div>
                
                <div 
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ 
                    backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)',
                    transition: 'transform 0.3s ease'
                  }}
                >
                  <span 
                    style={{ 
                      transform: isExpanded('toneHeatmap') ? 'rotate(180deg)' : 'rotate(0deg)',
                      transition: 'transform 0.3s ease'
                    }}
                  >
                    ▼
                  </span>
                </div>
              </div>
              
              <div 
                className="overflow-hidden transition-all duration-500"
                style={{ 
                  maxHeight: isExpanded('toneHeatmap') ? '1000px' : '0',
                  opacity: isExpanded('toneHeatmap') ? 1 : 0
                }}
              >
                <div className="p-6">
                  <ToneFeedbackHeatmap />
                </div>
              </div>
            </div>

            {/* Subtask Style Radar */}
            <div 
              className="rounded-xl overflow-hidden"
              style={{ 
                border: isDaytime 
                  ? '1px solid rgba(0, 0, 0, 0.05)'
                  : '1px solid rgba(255, 255, 255, 0.05)',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.07)',
                backgroundColor: `rgba(255, 255, 255, ${bgOpacity})`,
                backdropFilter: 'blur(8px)'
              }}
            >
              <div 
                className="flex items-center justify-between px-6 py-4 cursor-pointer border-b"
                style={{ borderColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)' }}
                onClick={() => toggleSection('subtaskStyle')}
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)' }}
                  >
                    <span className="text-lg">📡</span>
                  </div>
                  <div>
                    <h2 
                      className="text-lg font-semibold"
                      style={{ color: baseTextColor }}
                    >
                      Subtask Style Radar
                    </h2>
                    <p 
                      className="text-sm"
                      style={{ color: secondaryTextColor }}
                    >
                      Visualize your rhythm strategy preference
                    </p>
                  </div>
                </div>
                
                <div 
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ 
                    backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)',
                    transition: 'transform 0.3s ease'
                  }}
                >
                  <span 
                    style={{ 
                      transform: isExpanded('subtaskStyle') ? 'rotate(180deg)' : 'rotate(0deg)',
                      transition: 'transform 0.3s ease'
                    }}
                  >
                    ▼
                  </span>
                </div>
              </div>
              
              <div 
                className="overflow-hidden transition-all duration-500"
                style={{ 
                  maxHeight: isExpanded('subtaskStyle') ? '1000px' : '0',
                  opacity: isExpanded('subtaskStyle') ? 1 : 0
                }}
              >
                <div className="p-6">
                  <SubtaskIntentSummaryView />
                </div>
              </div>
            </div>

            {/* Interaction Replay Panel */}
            <div 
              className="rounded-xl overflow-hidden"
              style={{ 
                border: isDaytime 
                  ? '1px solid rgba(0, 0, 0, 0.05)'
                  : '1px solid rgba(255, 255, 255, 0.05)',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.07)',
                backgroundColor: `rgba(255, 255, 255, ${bgOpacity})`,
                backdropFilter: 'blur(8px)'
              }}
            >
              <div 
                className="flex items-center justify-between px-6 py-4 cursor-pointer border-b"
                style={{ borderColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)' }}
                onClick={() => toggleSection('interactionReplay')}
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)' }}
                  >
                    <span className="text-lg">🗣️</span>
                  </div>
                  <div>
                    <h2 
                      className="text-lg font-semibold"
                      style={{ color: baseTextColor }}
                    >
                      Interaction Replay Panel
                    </h2>
                  </div>
                </div>
                
                <div 
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ 
                    backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)',
                    transition: 'transform 0.3s ease'
                  }}
                >
                  <span 
                    style={{ 
                      transform: isExpanded('interactionReplay') ? 'rotate(180deg)' : 'rotate(0deg)',
                      transition: 'transform 0.3s ease'
                    }}
                  >
                    ▼
                  </span>
                </div>
              </div>
              
              <div 
                className="overflow-hidden transition-all duration-500"
                style={{ 
                  maxHeight: isExpanded('interactionReplay') ? '1000px' : '0',
                  opacity: isExpanded('interactionReplay') ? 1 : 0
                }}
              >
                <div className="p-6 space-y-6">
                  <RhythmInteractionReplayPanel />
                  <UserTextInput />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 数据导出面板 */}
        <div 
          className="rounded-xl overflow-hidden"
          style={{ 
            border: isDaytime 
              ? '1px solid rgba(0, 0, 0, 0.05)'
              : '1px solid rgba(255, 255, 255, 0.05)',
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.07)',
            backgroundColor: `rgba(255, 255, 255, ${bgOpacity})`,
            backdropFilter: 'blur(8px)'
          }}
        >
          <div className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: isDaytime ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.05)' }}
              >
                <span className="text-lg">📤</span>
              </div>
              <div>
                <h2 
                  className="text-lg font-semibold"
                  style={{ color: baseTextColor }}
                >
                  Export My Rhythm Data
                </h2>
                <p 
                  className="text-sm"
                  style={{ color: secondaryTextColor }}
                >
                  Download a full snapshot of your feedback and progress
                </p>
              </div>
            </div>
            
            <ExportRhythmData />
          </div>
        </div>

        <BetaOnboardingTip />
        <EndMyDayButton />
        <FooterNavigation />

        {/* 移除底部的日夜模式切换按钮，现在已经移到页面顶部 */}

        {/* 反馈链接 */}
        <div className="text-center">
          <p 
            className="text-sm"
            style={{ color: secondaryTextColor }}
          >
            Want to help improve RhythmOS? 
            <a 
              href="https://docs.google.com/forms/d/e/1FAIpQLSdZVEcOa-Js3Z5BRZXOd23auPvQnCcvZmCpPL7prrqVEH7fYQ/viewform?usp=sharing" 
              target="_blank" 
              className="ml-1 inline-flex items-center gap-1 transition-all duration-200"
              style={{ 
                color: '#9C27B0',
                borderBottom: '1px dotted #9C27B080'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderBottom = '1px solid #9C27B0';
                e.currentTarget.style.color = '#7B1FA2';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderBottom = '1px dotted #9C27B080';
                e.currentTarget.style.color = '#9C27B0';
              }}
            >
              Leave feedback here <span>→</span>
            </a>
          </p>
        </div>
        
        <ConfidentialNotice />
      </div>
    </div>
  );
};

export default IdentityInsightPage;