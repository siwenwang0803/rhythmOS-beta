import React, { useState } from 'react';
import ConfidentialNotice from '../components/ConfidentialNotice';
import DigestPanel from '../components/DigestPanel';
import FooterNavigation from '../components/FooterNavigation';
import EndMyDayButton from '../components/EndMyDayButton';
import GlobalOnboardingHint from '../components/GlobalOnboardingHint';
import InsightDigestNarrator from '../components/InsightDigestNarrator';
import { getTopTone } from '../utils/toneLogStats';
import PersonaBeliefTrendChart from '../components/PersonaBeliefTrendChart';

// 修复后的获取当前趋势函数
const getCurrentTrend = (): 'rising' | 'stable' | 'wavy' | 'collapsed' => {
  try {
    // 从 localStorage 获取最近的 cue feedback 数据
    const raw = localStorage.getItem('cueFeedbackLog');
    if (!raw) {
      console.log('No cueFeedbackLog found, defaulting to stable');
      return 'stable';
    }
    
    const log = JSON.parse(raw);
    if (!Array.isArray(log) || log.length === 0) {
      console.log('Invalid or empty log data, defaulting to stable');
      return 'stable';
    }
    
    // 获取最近7天的数据
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const recentEntries = log
      .filter(entry => {
        if (!entry.timestamp || !entry.trend) return false;
        const entryDate = new Date(entry.timestamp);
        return entryDate >= oneWeekAgo;
      })
      .slice(-10); // 最近10条记录
    
    if (recentEntries.length === 0) {
      console.log('No recent entries found, defaulting to stable');
      return 'stable';
    }
    
    // 分析最近的趋势分布
    const trendCounts = recentEntries.reduce((acc: Record<string, number>, entry: any) => {
      const trend = entry.trend;
      if (['rising', 'stable', 'wavy', 'collapsed'].includes(trend)) {
        acc[trend] = (acc[trend] || 0) + 1;
      }
      return acc;
    }, {});
    
    // 如果没有有效的趋势数据
    if (Object.keys(trendCounts).length === 0) {
      console.log('No valid trend data found, defaulting to stable');
      return 'stable';
    }
    
    // 返回出现最多的趋势
    const dominantTrend = Object.keys(trendCounts).reduce((a, b) => 
      trendCounts[a] > trendCounts[b] ? a : b
    );
    
    console.log('Trend analysis:', { trendCounts, dominantTrend, recentEntries: recentEntries.length });
    return dominantTrend as 'rising' | 'stable' | 'wavy' | 'collapsed';
  } catch (error) {
    console.error('Error getting current trend:', error);
    return 'stable';
  }
};

// 获取解锁的标签
const getUnlockedTags = (): string[] => {
  try {
    const raw = localStorage.getItem('unlockedTags');
    return raw ? JSON.parse(raw) : [];
  } catch (error) {
    console.error('Error getting unlocked tags:', error);
    return [];
  }
};

// 根据 tone 和 trend 生成个性化成长建议
const getGrowthRecommendations = (tone: string, trend: string) => {
  const recommendations = [];
  
  // 基础建议（总是显示）
  recommendations.push({
    id: 'mindful-reflection',
    icon: '⚖️',
    title: 'Mindful Reflection',
    description: 'Schedule 5 minutes of structured reflection to better understand your patterns.'
  });
  
  // 基于 tone 的建议
  switch (tone) {
    case 'rational':
      recommendations.push({
        id: 'creative-thinking',
        icon: '🧠',
        title: 'Expand Creative Thinking',
        description: 'Your rational approach is strong. Try incorporating more intuitive and creative problem-solving methods.'
      });
      break;
    case 'gentle':
      recommendations.push({
        id: 'assertiveness',
        icon: '💗',
        title: 'Practice Assertiveness',
        description: 'Your gentle nature is valuable. Consider practicing firmer boundary-setting when needed.'
      });
      break;
    case 'motivated':
      recommendations.push({
        id: 'sustainable-energy',
        icon: '⚡',
        title: 'Sustainable Energy Management',
        description: 'Channel your motivation into sustainable habits that prevent burnout.'
      });
      break;
    case 'directive':
      recommendations.push({
        id: 'collaborative-leadership',
        icon: '🤝',
        title: 'Collaborative Leadership',
        description: 'Balance your directive approach with collaborative decision-making for better team dynamics.'
      });
      break;
    case 'visionary':
      recommendations.push({
        id: 'practical-steps',
        icon: '🎯',
        title: 'Bridge Vision to Action',
        description: 'Transform your visionary ideas into concrete, actionable steps for implementation.'
      });
      break;
  }
  
  // 基于 trend 的建议
  switch (trend) {
    case 'rising':
      recommendations.push({
        id: 'sustain-momentum',
        icon: '📈',
        title: 'Sustain Positive Momentum',
        description: 'You\'re on an upward trajectory. Focus on maintaining this growth sustainably without overextending.'
      });
      break;
    case 'wavy':
      recommendations.push({
        id: 'stabilize-patterns',
        icon: '🌊',
        title: 'Stabilize Your Patterns',
        description: 'Your fluctuating pattern suggests exploring grounding practices and consistent routines.'
      });
      break;
    case 'collapsed':
      recommendations.push({
        id: 'gentle-rebuilding',
        icon: '🌱',
        title: 'Gentle Rebuilding',
        description: 'Take small, manageable steps to rebuild your momentum. Focus on self-compassion during this phase.'
      });
      break;
    case 'stable':
      recommendations.push({
        id: 'growth-challenge',
        icon: '🚀',
        title: 'Embrace New Challenges',
        description: 'Your stability provides a solid foundation. Consider taking on new challenges for continued growth.'
      });
      break;
  }
  
  return recommendations.slice(0, 3); // 限制为3个建议
};

interface DigestPageProps {
  isDaytime?: boolean;
}

/**
 * DigestPage - Enhanced Page component for the Weekly Digest view
 * 
 * Features tabbed navigation to organize different types of insights,
 * improved layout structure, and visual organization.
 */
const DigestPage: React.FC<DigestPageProps> = ({ isDaytime = true }) => {
  // State for active tab (移除了 growth tab，合并到 insights)
  const [activeTab, setActiveTab] = useState<'weekly' | 'identity' | 'insights'>('weekly');
  
  // Get current tone, trend, and unlocked tags
  const topTone = getTopTone();
  const currentTrend = getCurrentTrend();
  const unlockedTags = getUnlockedTags();
  const growthRecommendations = getGrowthRecommendations(topTone || 'neutral', currentTrend);
  
  // RhythmOS theme colors based on UI spec and day/night mode
  const themeColors = {
    background: isDaytime ? '#F5E8C7' : '#2C2C2C', // Sand base / Dark mode bg
    text: isDaytime ? '#333333' : '#E0E0E0',        // Dark text / Light text
    textMuted: isDaytime ? '#777777' : '#AAAAAA',   // Muted text colors
    accent: '#F7DC6F',                              // Soft yellow accent from UI spec
    cardBg: isDaytime ? '#FFFFFF' : '#3A3A3A',      // Card background
    border: isDaytime ? '#E6E6E6' : '#555555',      // Border color
  };
  
  // Tab configuration (合并后只有3个tabs)
  const tabs = [
    { id: 'weekly', label: '📊 Weekly Summary', icon: '📊' },
    { id: 'identity', label: '🧩 Identity Journey', icon: '🧩' },
    { id: 'insights', label: '💡 Insights & Growth', icon: '💡' }, // 合并后的标签
  ];

  // Helper function to render the active tab content
  const renderTabContent = () => {
    switch (activeTab) {
      case 'weekly':
        return <DigestPanel isDaytime={isDaytime} />;
      case 'identity':
        return (
          <div style={{ 
            backgroundColor: themeColors.cardBg, 
            borderRadius: '12px', 
            padding: '24px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
            border: `1px solid ${themeColors.border}`
          }}>
            <h2 style={{ 
              fontSize: '24px', 
              fontWeight: 600, 
              color: themeColors.text,
              marginBottom: '24px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span style={{ 
                width: '36px', 
                height: '36px', 
                borderRadius: '50%', 
                backgroundColor: isDaytime ? 'rgba(245, 232, 199, 0.3)' : 'rgba(74, 85, 104, 0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>🧩</span>
              Identity Alignment Journey
            </h2>
            <PersonaBeliefTrendChart />
            <div style={{ 
              marginTop: '24px', 
              padding: '16px', 
              backgroundColor: isDaytime ? 'rgba(245, 232, 199, 0.2)' : 'rgba(74, 85, 104, 0.2)',
              borderRadius: '8px'
            }}>
              <p style={{ color: themeColors.text, fontSize: '15px' }}>
                Track how consistently you embody your chosen identity traits over time. The chart shows your alignment score across different personas.
              </p>
            </div>
          </div>
        );
      case 'insights':
        return (
          <div style={{ 
            backgroundColor: themeColors.cardBg, 
            borderRadius: '12px', 
            padding: '24px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
            border: `1px solid ${themeColors.border}`
          }}>
            {/* 标题 */}
            <h2 style={{ 
              fontSize: '24px', 
              fontWeight: 600, 
              color: themeColors.text,
              marginBottom: '24px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span style={{ 
                width: '36px', 
                height: '36px', 
                borderRadius: '50%', 
                backgroundColor: isDaytime ? 'rgba(245, 232, 199, 0.3)' : 'rgba(74, 85, 104, 0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>💡</span>
              Tone Insights & Growth Pathways
            </h2>
            
            {/* Debug 信息（可选，用于测试） */}
            <div style={{
              marginBottom: '20px',
              padding: '12px',
              backgroundColor: isDaytime ? '#f8f9fa' : '#444',
              borderRadius: '8px',
              fontSize: '14px',
              color: themeColors.textMuted
            }}>
              <strong>Current Analysis:</strong> Tone: {topTone || 'None'}, Trend: {currentTrend}, Tags: {unlockedTags.length}
            </div>
            
            {/* Persona 洞察部分 */}
            <div style={{ marginBottom: '32px' }}>
              <h3 style={{
                fontSize: '18px',
                fontWeight: 500,
                color: themeColors.text,
                marginBottom: '16px',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}>
                <span>🎭</span> Persona Insights
              </h3>
              
              <InsightDigestNarrator 
                toneSummary={topTone || 'neutral'} 
                trend={currentTrend}
                unlockedTags={unlockedTags}
                isDaytime={isDaytime} 
              />
              
              {/* 额外的模式分析 */}
              <div style={{
                marginTop: '16px',
                padding: '16px',
                backgroundColor: isDaytime ? 'rgba(245, 232, 199, 0.2)' : 'rgba(74, 85, 104, 0.2)',
                borderRadius: '8px'
              }}>
                <h4 style={{ 
                  fontSize: '16px', 
                  fontWeight: 500, 
                  color: themeColors.text, 
                  marginBottom: '12px' 
                }}>
                  Understanding Your Pattern
                </h4>
                <p style={{ color: themeColors.text, fontSize: '15px', marginBottom: '12px' }}>
                  Your dominant tone this week has been <strong style={{ color: '#4B6587' }}>{topTone || 'neutral'}</strong>, 
                  with a <strong style={{ color: '#D8A7CA' }}>{currentTrend}</strong> trend pattern.
                </p>
                {unlockedTags.length > 0 && (
                  <p style={{ color: themeColors.text, fontSize: '15px' }}>
                    You've unlocked <strong>{unlockedTags.length}</strong> new insights that reflect 
                    your evolving identity traits and behavioral patterns.
                  </p>
                )}
              </div>
            </div>

            {/* 分隔线 */}
            <div style={{
              height: '1px',
              backgroundColor: themeColors.border,
              margin: '32px 0'
            }} />

            {/* 成长路径部分 */}
            <div>
              <h3 style={{
                fontSize: '18px',
                fontWeight: 500,
                color: themeColors.text,
                marginBottom: '16px',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}>
                <span>🌱</span> Growth Pathways
              </h3>
              
              <div style={{ 
                padding: '16px', 
                backgroundColor: isDaytime ? 'rgba(245, 232, 199, 0.2)' : 'rgba(74, 85, 104, 0.2)',
                borderRadius: '8px',
                marginBottom: '24px'
              }}>
                <p style={{ color: themeColors.text, fontSize: '15px', marginBottom: '16px' }}>
                  Based on your <strong>{topTone || 'neutral'}</strong> tone pattern with a <strong>{currentTrend}</strong> trend, 
                  here are recommended focus areas for continued growth:
                </p>
              </div>
              
              {/* 成长建议卡片 */}
              <div style={{ 
                display: 'grid', 
                gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', 
                gap: '16px' 
              }}>
                {growthRecommendations.map((recommendation) => (
                  <div 
                    key={recommendation.id}
                    style={{ 
                      backgroundColor: themeColors.cardBg, 
                      padding: '20px', 
                      borderRadius: '12px',
                      border: `1px solid ${themeColors.border}`,
                      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)',
                      transition: 'all 0.2s ease'
                    }}
                  >
                    <div style={{ 
                      fontSize: '24px', 
                      marginBottom: '12px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px'
                    }}>
                      <span>{recommendation.icon}</span>
                      <span style={{ 
                        fontSize: '16px', 
                        fontWeight: '500',
                        color: themeColors.text
                      }}>
                        {recommendation.title}
                      </span>
                    </div>
                    <p style={{ 
                      color: themeColors.textMuted, 
                      fontSize: '14px',
                      lineHeight: '1.5',
                      margin: 0
                    }}>
                      {recommendation.description}
                    </p>
                  </div>
                ))}
              </div>

              {/* 行动提示 */}
              <div style={{
                marginTop: '24px',
                padding: '16px',
                backgroundColor: isDaytime ? 'rgba(71, 85, 105, 0.05)' : 'rgba(216, 167, 202, 0.1)',
                borderRadius: '8px',
                border: `1px solid ${isDaytime ? '#4B6587' : '#D8A7CA'}30`
              }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  marginBottom: '8px'
                }}>
                  <span style={{ fontSize: '16px' }}>💡</span>
                  <span style={{ 
                    fontSize: '14px', 
                    fontWeight: '500',
                    color: themeColors.text
                  }}>
                    Next Steps
                  </span>
                </div>
                <p style={{ 
                  color: themeColors.text, 
                  fontSize: '14px',
                  margin: 0,
                  lineHeight: '1.5'
                }}>
                  Choose one recommendation that resonates with you and commit to practicing it for the next week. 
                  Small, consistent steps lead to meaningful growth.
                </p>
              </div>
            </div>
          </div>
        );
      default:
        return <DigestPanel isDaytime={isDaytime} />;
    }
  };

  return (
    <div 
      style={{ 
        backgroundColor: isDaytime ? '#fbf9f5' : '#242424',
        transition: 'background-color 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      <div style={{ 
        maxWidth: '1000px', 
        margin: '0 auto', 
        width: '100%', 
        padding: '24px 16px',
        display: 'flex',
        flexDirection: 'column',
        flex: 1
      }}>
        <GlobalOnboardingHint />

        {/* Header area with navigation */}
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center', 
          marginBottom: '24px'
        }}>
          <div>
            <h1 style={{ 
              fontSize: '28px', 
              fontWeight: 700, 
              color: themeColors.text,
              margin: '0 0 4px 0',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span>📊</span> Weekly Digest
            </h1>
            <p style={{ color: themeColors.textMuted, margin: 0, fontSize: '15px' }}>
              Track your journey, review insights, and explore growth opportunities
            </p>
          </div>
          
          <a
            href="/identity/insight"
            style={{ 
              color: isDaytime ? '#4B6587' : '#D8A7CA',
              textDecoration: 'none',
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              fontSize: '14px',
              padding: '8px 12px',
              borderRadius: '6px',
              backgroundColor: isDaytime ? 'rgba(75, 101, 135, 0.1)' : 'rgba(216, 167, 202, 0.1)'
            }}
          >
            <span>←</span> Back to Insight
          </a>
        </div>

        {/* Tab navigation */}
        <div style={{ 
          display: 'flex', 
          borderBottom: `1px solid ${themeColors.border}`,
          marginBottom: '24px',
          overflowX: 'auto',
          WebkitOverflowScrolling: 'touch',
          scrollbarWidth: 'none', // Firefox
          msOverflowStyle: 'none' // IE/Edge
        }}>
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              style={{
                padding: '12px 16px',
                backgroundColor: 'transparent',
                border: 'none',
                borderBottom: `3px solid ${activeTab === tab.id ? themeColors.accent : 'transparent'}`,
                color: activeTab === tab.id ? themeColors.text : themeColors.textMuted,
                fontWeight: activeTab === tab.id ? 600 : 400,
                cursor: 'pointer',
                fontSize: '15px',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                transition: 'all 0.2s',
                whiteSpace: 'nowrap'
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div style={{ marginBottom: '32px', flex: 1 }}>
          {renderTabContent()}
        </div>

        {/* Action buttons */}
        <div style={{ marginBottom: '32px' }}>
          <EndMyDayButton isDaytime={isDaytime} />
        </div>

        {/* Footer area */}
        <div style={{ marginTop: 'auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '24px' }}>
            <p style={{ color: themeColors.textMuted, fontSize: '14px', margin: '0 0 8px 0' }}>
              Want to suggest improvements to the digest summary?
              <a
                href="https://forms.gle/YourFormLink"
                target="_blank"
                rel="noopener noreferrer"
                style={{ 
                  color: isDaytime ? '#4B6587' : '#D8A7CA',
                  textDecoration: 'underline',
                  marginLeft: '4px'
                }}
              >
                Leave feedback here →
              </a>
            </p>

            <ConfidentialNotice isDaytime={isDaytime} />
          </div>

          <FooterNavigation isDaytime={isDaytime} />
        </div>
      </div>
    </div>
  );
};

export default DigestPage;