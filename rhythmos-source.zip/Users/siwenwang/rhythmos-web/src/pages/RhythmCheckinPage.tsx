// /pages/RhythmCheckinPage.tsx - 沉浸式版本

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import RhythmButton from '../components/ui/RhythmButton';
import RhythmStudioPanel from '../components/ui/RhythmStudioPanel';
import RhythmMicrotaskFeedback from '../components/RhythmMicrotaskFeedback';
import UserTextInput from '../components/UserTextInput';
import { generateCRECueAsync } from '../cre/generateCRECue';
import { useDailyRhythm } from '../hooks/useDailyRhythm';
import { useSignatureLogger } from '../hooks/useSignatureLogger';
import { getCurrentTrend, RhythmTrend } from '../utils/rhythmTrend';
import { getSignatureMap } from '../SignatureMap';

// RhythmOS colors
const rhythmColors = {
  sand: '#F5E8C7',
  collapsed: '#AEC6CF',
  wavy: '#C3B1E1',
  stable: '#C5D8A4',
  rising: '#FFB347',
  accent: '#F7DC6F'
};

// 更温暖的情绪选项
const trendOptions = [
  { 
    label: 'Collapsed', 
    value: 'collapsed',
    greeting: "I feel heavy today...",
    description: 'Like carrying invisible weight',
    emoji: '🫥',
    color: rhythmColors.collapsed,
    companion: 'Rhea',
    message: "Rest is not giving up. Let me hold some of that weight with you."
  },
  { 
    label: 'Wavy', 
    value: 'wavy',
    greeting: "I'm up and down...",
    description: 'Riding emotional waves',
    emoji: '🌊',
    color: rhythmColors.wavy,
    companion: 'Aurelia',
    message: "The waves are real, and so is your strength to ride them."
  },
  { 
    label: 'Stable', 
    value: 'stable',
    greeting: "I'm steady today...",
    description: 'Flowing at my own pace',
    emoji: '⚖️',
    color: rhythmColors.stable,
    companion: 'Lucis',
    message: "Stability is power. From here, anything is possible."
  },
  { 
    label: 'Rising', 
    value: 'rising',
    greeting: "I'm energized...",
    description: 'Ready to accelerate',
    emoji: '🔥',
    color: rhythmColors.rising,
    companion: 'Caelum',
    message: "Your fire is beautiful. Let's channel it wisely together."
  }
];

const microEmotionsByTrend = {
  collapsed: ['Overwhelmed', 'Exhausted', 'Numb', 'Uncertain', 'Stuck', 'Foggy'],
  wavy: ['Anxious', 'Hopeful', 'Nostalgic', 'Sensitive', 'Emotional', 'Reflective'],
  stable: ['Calm', 'Centered', 'Content', 'Peaceful', 'Balanced', 'Mindful'],
  rising: ['Motivated', 'Inspired', 'Excited', 'Focused', 'Determined', 'Creative']
};

const RhythmCheckinPage: React.FC = () => {
  useDailyRhythm();
  const navigate = useNavigate();
  const { logTrendEntry } = useSignatureLogger();
  
  const [currentStep, setCurrentStep] = useState<'greeting' | 'mood' | 'emotion' | 'reflection' | 'ready'>('greeting');
  const [trend, setTrend] = useState<RhythmTrend | null>(null);
  const [microEmotion, setMicroEmotion] = useState<string | null>(null);
  const [inputText, setInputText] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [systemTrend, setSystemTrend] = useState<RhythmTrend>('wavy');
  const [showOptions, setShowOptions] = useState(false);

  useEffect(() => {
    const currentSystemTrend = getCurrentTrend();
    setSystemTrend(currentSystemTrend);
    
    const storedTrend = localStorage.getItem('lastTrend') as RhythmTrend | null;
    const storedEmotion = localStorage.getItem('microEmotion');
    const storedText = localStorage.getItem('resonance_input_text');
    
    if (storedTrend) setTrend(storedTrend);
    else setTrend(currentSystemTrend);
    
    if (storedEmotion) setMicroEmotion(storedEmotion);
    if (storedText) setInputText(storedText);

    // 延迟显示选项，创造呼吸感
    setTimeout(() => setShowOptions(true), 800);
  }, []);

  const handleSelectTrend = (selectedTrend: RhythmTrend) => {
    setTrend(selectedTrend);
    setMicroEmotion(null);
    
    // 平滑过渡到下一步
    setTimeout(() => {
      setCurrentStep('emotion');
    }, 600);
  };

  const handleSelectMicroEmotion = (emotion: string) => {
    setMicroEmotion(emotion);
    localStorage.setItem('microEmotion', emotion);
    
    setTimeout(() => {
      setCurrentStep('reflection');
    }, 400);
  };

  const handleTextSubmit = (text: string) => {
    setInputText(text);
    localStorage.setItem('resonance_input_text', text);
    
    // 记录到 SignatureMap
    try {
      const currentSignatureMap = getSignatureMap();
      if (!currentSignatureMap.interactionLog) {
        currentSignatureMap.interactionLog = [];
      }
      
      const languageReflectionEntry = {
        type: 'language-reflection',
        content: text,
        timestamp: new Date().toISOString(),
        source: 'rhythm-checkin-freetext',
        trend: trend || systemTrend,
        persona: localStorage.getItem('initPersona') || 'rhea',
        sessionId: Date.now().toString(),
        metadata: {
          checkinContext: true,
          selectedTrend: trend,
          systemTrend: systemTrend,
          microEmotion: microEmotion,
          page: 'rhythm-checkin'
        }
      };
      
      currentSignatureMap.interactionLog.push(languageReflectionEntry);
      localStorage.setItem('signatureMap', JSON.stringify(currentSignatureMap));
      
      // 更新语言反思存储
      let existingReflections = [];
      try {
        const stored = localStorage.getItem('languageReflections');
        existingReflections = stored ? JSON.parse(stored) : [];
      } catch (e) {
        existingReflections = [];
      }
      
      existingReflections.push(languageReflectionEntry);
      localStorage.setItem('languageReflections', JSON.stringify(existingReflections));
      
      // 触发事件
      window.dispatchEvent(new CustomEvent('language-reflection-added', {
        detail: { reflection: languageReflectionEntry }
      }));
      
    } catch (error) {
      console.error('Error recording reflection:', error);
    }
    
    setTimeout(() => {
      setCurrentStep('ready');
    }, 500);
  };

  const handleSubmit = async () => {
    if (!trend) return;
    
    setIsSubmitting(true);
    localStorage.setItem('lastTrend', trend);
    
    logTrendEntry({
      date: new Date().toISOString().slice(0, 10),
      trend,
    });
    
    try {
      const preferredTone = localStorage.getItem('preferredTone') || 'gentle';
      const initPersona = localStorage.getItem('initPersona') || 'rhea';
      
      const generatedCRE = await generateCRECueAsync({
        preferredTone,
        initPersona,
        trend,
        microEmotion,
        userContext: inputText,
        context: inputText
      });
      
      if (generatedCRE) {
        localStorage.setItem('cre_cue', generatedCRE.cue);
        localStorage.setItem('cre_paragraph', generatedCRE.paragraph);
        localStorage.setItem('cre_tone', generatedCRE.tone);
        localStorage.setItem('cre_persona', generatedCRE.persona);
        localStorage.setItem('cre_source', generatedCRE.source || 'static');
      }
      
      setTimeout(() => {
        navigate('/identity/train');
      }, 400);
    } catch (err) {
      setIsSubmitting(false);
      console.error('[CHECKIN ERROR]', err);
    }
  };

  return (
    <div className="min-h-screen overflow-hidden relative">
      {/* 动态背景 */}
      <div 
        className="absolute inset-0 transition-all duration-1000"
        style={{
          background: trend 
            ? `linear-gradient(135deg, ${trendOptions.find(t => t.value === trend)?.color}20 0%, ${rhythmColors.sand} 100%)`
            : `linear-gradient(135deg, ${rhythmColors.sand} 0%, #FFFFFF 100%)`
        }}
      />
      
      {/* 主内容区 */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6 py-12">
        <div className="w-full max-w-lg mx-auto">
          
          {/* Step 1: 温暖的问候 */}
          {currentStep === 'greeting' && (
            <div className="text-center animate-fadeIn">
              <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-white/80 flex items-center justify-center shadow-lg animate-breathe">
                <span className="text-2xl">💭</span>
              </div>
              <h1 className="text-3xl font-light text-gray-800 mb-3">
                Hey there...
              </h1>
              <p className="text-lg text-gray-600 mb-8">
                How's your inner rhythm today?
              </p>
              <button
                onClick={() => setCurrentStep('mood')}
                className="px-8 py-3 bg-white/90 text-gray-700 rounded-full shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105"
              >
                Let me check in
              </button>
            </div>
          )}
          
          {/* Step 2: 情绪选择 - 全屏沉浸式 */}
          {currentStep === 'mood' && (
            <div className="w-full">
              <div className="text-center mb-8 animate-fadeInDown">
                <h2 className="text-2xl font-light text-gray-800 mb-2">
                  Which of these feels most true?
                </h2>
                <p className="text-sm text-gray-500">
                  Take a moment to really feel it...
                </p>
              </div>
              
              <div className="space-y-4">
                {trendOptions.map((option, index) => (
                  <button
                    key={option.value}
                    onClick={() => handleSelectTrend(option.value as RhythmTrend)}
                    className={`
                      w-full p-6 rounded-2xl transition-all duration-500 transform
                      ${showOptions ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}
                      ${trend === option.value ? 'scale-105 shadow-lg' : 'hover:scale-102 shadow-md'}
                    `}
                    style={{
                      animationDelay: `${index * 150}ms`,
                      backgroundColor: trend === option.value ? `${option.color}30` : 'rgba(255,255,255,0.9)',
                      borderLeft: `4px solid ${option.color}`,
                    }}
                  >
                    <div className="flex items-start text-left">
                      <span className="text-3xl mr-4 animate-pulse">{option.emoji}</span>
                      <div className="flex-1">
                        <h3 className="text-lg font-medium text-gray-800 mb-1">
                          {option.greeting}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {option.description}
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
              
              {/* 陪伴信息 - 选择后淡入 */}
              {trend && (
                <div className="mt-6 p-4 bg-white/80 rounded-xl animate-fadeInUp animation-delay-300">
                  <p className="text-sm text-gray-700 italic">
                    <span className="font-medium">{trendOptions.find(t => t.value === trend)?.companion}</span> whispers: 
                    "{trendOptions.find(t => t.value === trend)?.message}"
                  </p>
                </div>
              )}
            </div>
          )}
          
          {/* Step 3: 微情绪选择 */}
          {currentStep === 'emotion' && trend && (
            <div className="w-full animate-fadeIn">
              <div className="text-center mb-6">
                <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-white/80 flex items-center justify-center">
                  <span className="text-xl">🎭</span>
                </div>
                <h2 className="text-xl font-light text-gray-800 mb-2">
                  Can you name the feeling more specifically?
                </h2>
                <p className="text-sm text-gray-500">
                  This helps me understand you better
                </p>
              </div>
              
              <div className="flex flex-wrap justify-center gap-3 max-w-md mx-auto">
                {microEmotionsByTrend[trend].map((emotion, index) => (
                  <button
                    key={emotion}
                    onClick={() => handleSelectMicroEmotion(emotion)}
                    className={`
                      px-5 py-2.5 rounded-full text-sm transition-all duration-300
                      ${microEmotion === emotion ? 'scale-110 shadow-md' : 'hover:scale-105'}
                      animate-fadeInUp
                    `}
                    style={{
                      animationDelay: `${index * 100}ms`,
                      backgroundColor: microEmotion === emotion 
                        ? `${trendOptions.find(t => t.value === trend)?.color}40`
                        : 'rgba(255,255,255,0.9)',
                      color: microEmotion === emotion ? '#333' : '#666',
                      border: microEmotion === emotion 
                        ? `2px solid ${trendOptions.find(t => t.value === trend)?.color}`
                        : '2px solid transparent'
                    }}
                  >
                    {emotion}
                  </button>
                ))}
              </div>
              
              <button
                onClick={() => setCurrentStep('reflection')}
                className="mt-8 mx-auto block text-sm text-gray-500 hover:text-gray-700 transition-colors"
              >
                Skip this step →
              </button>
            </div>
          )}
          
          {/* Step 4: 文字反思 */}
          {currentStep === 'reflection' && (
            <div className="w-full animate-fadeIn">
              <div className="text-center mb-6">
                <h2 className="text-xl font-light text-gray-800 mb-2">
                  Want to share what's on your mind?
                </h2>
                <p className="text-sm text-gray-500">
                  Your words help me attune to you
                </p>
              </div>
              
              <UserTextInput 
                standalone={false}
                customStyles={{
                  container: {
                    backgroundColor: 'rgba(255,255,255,0.95)',
                    padding: '24px',
                    borderRadius: '16px',
                    boxShadow: '0 8px 24px rgba(0,0,0,0.08)',
                    border: 'none',
                    borderLeft: `4px solid ${trend ? trendOptions.find(t => t.value === trend)?.color : '#ccc'}`,
                  },
                  textarea: {
                    placeholder: "Whatever feels true right now...",
                    rows: 4,
                    fontSize: '16px',
                    lineHeight: '1.6'
                  },
                  showResponse: false
                }}
                onSubmit={handleTextSubmit}
              />
              
              <button
                onClick={() => setCurrentStep('ready')}
                className="mt-4 mx-auto block text-sm text-gray-500 hover:text-gray-700 transition-colors"
              >
                I'll skip sharing today →
              </button>
            </div>
          )}
          
          {/* Step 5: 准备进入训练 */}
          {currentStep === 'ready' && (
            <div className="text-center animate-fadeIn">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-white/90 flex items-center justify-center shadow-lg animate-pulse-gentle">
                <span className="text-3xl">✨</span>
              </div>
              <h2 className="text-2xl font-light text-gray-800 mb-4">
                I see you, I hear you
              </h2>
              <p className="text-gray-600 mb-8 max-w-sm mx-auto">
                Let's work with your rhythm today, not against it.
              </p>
              
              <button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className={`
                  px-8 py-4 rounded-full text-white font-medium
                  shadow-lg hover:shadow-xl transition-all duration-300
                  transform hover:scale-105 active:scale-100
                  ${isSubmitting ? 'opacity-70' : ''}
                `}
                style={{
                  backgroundColor: trend ? trendOptions.find(t => t.value === trend)?.color : rhythmColors.accent,
                }}
              >
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <span className="animate-spin">⏳</span> Preparing your space...
                  </span>
                ) : (
                  'Enter Rhythm Training'
                )}
              </button>
              
              <button
                onClick={() => navigate('/goals')}
                className="mt-4 text-sm text-gray-600 hover:text-gray-800 transition-colors"
              >
                Review my goals first
              </button>
            </div>
          )}
          
        </div>
      </div>
    </div>
  );
};

export default RhythmCheckinPage;













