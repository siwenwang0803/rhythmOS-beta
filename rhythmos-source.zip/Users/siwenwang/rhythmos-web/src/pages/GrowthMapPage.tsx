// pages/GrowthMapPage.tsx

import React from 'react'
import RhythmTaskProgressChart from '../components/RhythmTaskProgressChart'
import CREStyleGrowthMap from '../components/CREStyleGrowthMap'
import BehaviorRadarChart from '../components/BehaviorRadarChart'
import { writeRhythmScore } from '../utils/rhythmscoreEngine'; // ⬅️ 一定要加这行


const handleComplete = (challenge: string) => {
  const log = JSON.parse(localStorage.getItem('challengeLog') || '[]');
  log.push({ persona: top, text: challenge, time: Date.now() });
  localStorage.setItem('challengeLog', JSON.stringify(log));

  // ✅ 正确调用写入节奏得分！
  writeRhythmScore(2, 'challenge_complete');

  setCompleted([...completed, challenge]);
};
const GrowthMapPage: React.FC = () => {
  return (
    <div className="min-h-screen px-6 py-10 max-w-4xl mx-auto text-left space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">🌱 Growth Map</h1>
      <p className="text-sm text-gray-500">
        This page visualizes your task rhythm progression and your CRE style evolution over time.
      </p>

      <section>
        <h2 className="text-md font-semibold mb-2 text-gray-700">📈 Rhythm Task Progression</h2>
        <RhythmTaskProgressChart />
      </section>

      <section>
        <h2 className="text-md font-semibold mb-2 text-gray-700">🎯 CRE Style Growth</h2>
        <CREStyleGrowthMap />
      </section>

      <section>
  <h2 className="text-md font-semibold mb-2 text-gray-700">🧭 Task Behavior Radar</h2>
  <p className="text-sm text-gray-500 mb-4">
    Visual breakdown of how you've completed, tried, or skipped tasks across all difficulty levels.
  </p>
  <BehaviorRadarChart />
</section>

    </div>
  )
}

export default GrowthMapPage
