import React, { useEffect, useState } from 'react';
import {
  getTodayDate,
  getLastFinalizedDate,
  isNewRhythmDay,
  hasTodayStarted
} from '../utils/rhythmDayEngine';

const RhythmStateDebug: React.FC = () => {
  const [state, setState] = useState({
    today: '',
    lastFinalizedDate: '',
    isNewDay: false,
    hasStarted: false
  });

  useEffect(() => {
    const today = getTodayDate();
    const lastFinalizedDate = getLastFinalizedDate();
    const isNewDay = isNewRhythmDay();
    const hasStarted = hasTodayStarted();

    setState({ today, lastFinalizedDate, isNewDay, hasStarted });
  }, []);

  return (
    <div className="max-w-xl mx-auto px-6 py-10">
      <h1 className="text-lg font-bold mb-4">🧠 Rhythm State Debug</h1>
      <ul className="text-sm text-gray-700 space-y-2">
        <li>📆 <strong>Today:</strong> {state.today}</li>
        <li>🔐 <strong>Last Finalized Date:</strong> {state.lastFinalizedDate}</li>
        <li>🆕 <strong>Is New Rhythm Day:</strong> {state.isNewDay ? '✅ YES' : '❌ NO'}</li>
        <li>🚦 <strong>Has Today Started:</strong> {state.hasStarted ? '✅ YES' : '❌ NO'}</li>
      </ul>
    </div>
  );
};

export default RhythmStateDebug;
