import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSignatureLogger } from "../hooks/useSignatureLogger";

// 波浪背景组件 - 动态版
const WaveBackground = () => (
  <div className="absolute top-0 left-0 w-full overflow-hidden z-0 opacity-30">
    <div className="wave wave1"></div>
    <div className="wave wave2"></div>
  </div>
);

// 情绪反馈气泡组件
const EmotionBubbles = ({ emotion }) => {
  // 不同情绪状态对应不同的气泡颜色和行为
  const emotionConfig = {
    collapsed: { colors: ['#fecaca', '#fca5a5', '#f87171'], count: 5, speed: 'slow' },
    wavy: { colors: ['#bfdbfe', '#93c5fd', '#60a5fa'], count: 8, speed: 'medium' },
    stable: { colors: ['#bbf7d0', '#86efac', '#4ade80'], count: 6, speed: 'medium' },
    rising: { colors: ['#e9d5ff', '#d8b4fe', '#c084fc'], count: 10, speed: 'fast' },
    default: { colors: ['#e5e7eb', '#d1d5db', '#9ca3af'], count: 4, speed: 'medium' }
  };
  
  const config = emotionConfig[emotion] || emotionConfig.default;
  const bubbles = Array.from({ length: config.count }, (_, i) => ({
    color: config.colors[Math.floor(Math.random() * config.colors.length)],
    size: 5 + Math.random() * 15,
    left: 5 + Math.random() * 90,
    delay: Math.random() * 5,
    duration: config.speed === 'slow' ? 15 + Math.random() * 10 : 
              config.speed === 'medium' ? 8 + Math.random() * 7 :
              5 + Math.random() * 5
  }));
  
  return (
    <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
      {emotion && bubbles.map((bubble, i) => (
        <div 
          key={i}
          className="absolute rounded-full animate-float"
          style={{
            width: `${bubble.size}px`,
            height: `${bubble.size}px`,
            backgroundColor: bubble.color,
            left: `${bubble.left}%`,
            bottom: '-20px',
            opacity: 0.7,
            animationDelay: `${bubble.delay}s`,
            animationDuration: `${bubble.duration}s`
          }}
        ></div>
      ))}
    </div>
  );
};

// 情绪特征主题组件
const EmotionTheme = ({ emotion }) => {
  const themeConfig = {
    collapsed: {
      bgGradient: 'from-red-50 to-orange-50',
      iconClass: 'spin-slow',
      iconStyle: { opacity: 0.2, filter: 'blur(2px)' }
    },
    wavy: {
      bgGradient: 'from-blue-50 to-indigo-50',
      iconClass: 'wave-animation',
      iconStyle: { opacity: 0.3 }
    },
    stable: {
      bgGradient: 'from-green-50 to-emerald-50',
      iconClass: 'pulse-gentle',
      iconStyle: { opacity: 0.3 }
    },
    rising: {
      bgGradient: 'from-purple-50 to-fuchsia-50',
      iconClass: 'float-fast',
      iconStyle: { opacity: 0.4 }
    },
    default: {
      bgGradient: '',
      iconClass: '',
      iconStyle: { opacity: 0 }
    }
  };
  
  const theme = themeConfig[emotion] || themeConfig.default;
  
  return (
    <>
      <div className={`absolute inset-0 bg-gradient-to-br ${theme.bgGradient} opacity-20 transition-opacity duration-1000 rounded-xl`}></div>
      <div className="absolute top-10 right-10">
        <div 
          className={`text-6xl ${theme.iconClass}`}
          style={theme.iconStyle}
        >
          {emotion === 'collapsed' && '😵'}
          {emotion === 'wavy' && '🌊'}
          {emotion === 'stable' && '😌'}
          {emotion === 'rising' && '🚀'}
        </div>
      </div>
    </>
  );
};

const options = [
  {
    text: "I often feel stuck and can't focus on anything.",
    emoji: "😵",
    trend: 'collapsed',
    score: -3,
    gradient: "from-red-100 to-orange-50",
    activeGradient: "from-red-200 to-orange-100",
    description: "You're feeling mentally blocked and finding it hard to concentrate.",
    moodColor: "bg-red-400",
    icon: "brain",
    stateDescription: "You're in a state of mental fog where concentration is difficult."
  },
  {
    text: "My energy changes a lot. Some days I try, some days I avoid.",
    emoji: "🌊",
    trend: 'wavy',
    score: 0,
    gradient: "from-blue-100 to-indigo-50",
    activeGradient: "from-blue-200 to-indigo-100",
    description: "Your motivation fluctuates between engagement and resistance.",
    moodColor: "bg-blue-400",
    icon: "wind",
    stateDescription: "Your energy ebbs and flows like waves, with varying intensity."
  },
  {
    text: "I'm in a fairly stable place and want to make steady progress.",
    emoji: "😌",
    trend: 'stable',
    score: 2,
    gradient: "from-green-100 to-emerald-50",
    activeGradient: "from-green-200 to-emerald-100",
    description: "You feel balanced and ready for consistent forward motion.",
    moodColor: "bg-green-400",
    icon: "heart",
    stateDescription: "You're experiencing stability, with a balanced emotional state."
  },
  {
    text: "I feel strong momentum lately and want to challenge myself.",
    emoji: "🚀",
    trend: 'rising',
    score: 4,
    gradient: "from-purple-100 to-fuchsia-50",
    activeGradient: "from-purple-200 to-fuchsia-100",
    description: "You're experiencing flow and seeking meaningful stretch goals.",
    moodColor: "bg-purple-400",
    icon: "trending-up",
    stateDescription: "You're in an upward trajectory with increasing energy and momentum."
  },
  {
    text: "I'm not sure. Let the system suggest for me.",
    emoji: "❓",
    trend: 'stable',
    score: 1,
    gradient: "from-gray-100 to-slate-50",
    activeGradient: "from-gray-200 to-slate-100",
    description: "You'd prefer guidance based on the system's assessment.",
    moodColor: "bg-gray-400",
    icon: "help-circle",
    stateDescription: "You're seeking external perspective to identify your current state."
  }
];

const OnboardingStep1: React.FC = () => {
  const navigate = useNavigate();
  const { logTrendEntry } = useSignatureLogger();
  const [selectedTrend, setSelectedTrend] = useState<'collapsed' | 'wavy' | 'stable' | 'rising' | null>(null);
  const [hoveredOption, setHoveredOption] = useState<number | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [showDetailsFor, setShowDetailsFor] = useState<number | null>(null);

  // 在组件挂载后触发加载动画
  useEffect(() => {
    setTimeout(() => {
      setLoaded(true);
    }, 100);
  }, []);

  const handleSelect = (trend: 'collapsed' | 'wavy' | 'stable' | 'rising', score: number, index: number) => {
    setSelectedTrend(trend);
    setShowDetailsFor(index);

    const log = [{
      source: 'onboarding',
      value: score,
      time: new Date().toISOString()
    }];
    localStorage.setItem('rhythmScoreLog', JSON.stringify(log));
    localStorage.setItem('lastTrend', trend);

    // ✅ SignatureMap log
    logTrendEntry({
      date: new Date().toISOString().slice(0, 10),
      trend: trend
    });

    // 添加短暂延迟，让用户体验选中状态的视觉反馈
    setTimeout(() => {
      navigate('/onboarding/step2');
    }, 1500);
  };

  // 自定义CSS样式，包含动画和过渡效果
  const customStyles = `
    .wave {
      position: absolute;
      width: 100%;
      height: 100px;
      background-size: 1600px 100px;
    }
    
    .wave1 {
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%23dcfce7' fill-opacity='0.6' d='M0,192L48,176C96,160,192,128,288,122.7C384,117,480,139,576,144C672,149,768,139,864,149.3C960,160,1056,192,1152,197.3C1248,203,1344,181,1392,170.7L1440,160L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z'%3E%3C/path%3E%3C/svg%3E");
      animation: wave 30s linear infinite;
    }
    
    .wave2 {
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%23dbeafe' fill-opacity='0.3' d='M0,256L48,261.3C96,267,192,277,288,266.7C384,256,480,224,576,213.3C672,203,768,213,864,224C960,235,1056,245,1152,240C1248,235,1344,213,1392,202.7L1440,192L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z'%3E%3C/path%3E%3C/svg%3E");
      animation: wave 20s linear reverse infinite;
      top: 30px;
    }
    
    @keyframes wave {
      0% {
        background-position-x: 0;
      }
      100% {
        background-position-x: 1600px;
      }
    }
    
    @keyframes float {
      0%, 100% {
        transform: translateY(0);
      }
      50% {
        transform: translateY(-100px);
      }
    }
    
    .animate-float {
      animation: float ease-in-out infinite;
    }
    
    .spin-slow {
      animation: spin 8s linear infinite;
    }
    
    @keyframes spin {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }
    
    .wave-animation {
      animation: wave-move 6s ease-in-out infinite;
    }
    
    @keyframes wave-move {
      0%, 100% {
        transform: translateX(0);
      }
      25% {
        transform: translateX(-10px) translateY(-5px);
      }
      75% {
        transform: translateX(10px) translateY(5px);
      }
    }
    
    .pulse-gentle {
      animation: pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
    
    @keyframes pulse {
      0%, 100% {
        opacity: 0.3;
        transform: scale(1);
      }
      50% {
        opacity: 0.5;
        transform: scale(1.05);
      }
    }
    
    .float-fast {
      animation: float-vertical 3s ease-in-out infinite;
    }
    
    @keyframes float-vertical {
      0%, 100% {
        transform: translateY(0);
      }
      50% {
        transform: translateY(-15px);
      }
    }
    
    .option-card {
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .option-card:hover {
      transform: translateY(-8px);
    }
    
    .option-card.selected {
      transform: scale(1.03);
    }
    
    .option-description {
      max-height: 0;
      overflow: hidden;
      transition: all 0.3s ease-out;
    }
    
    .option-description.visible {
      max-height: 100px;
    }
    
    .emotion-detail-panel {
      transform: translateY(20px);
      opacity: 0;
      transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .emotion-detail-panel.visible {
      transform: translateY(0);
      opacity: 1;
    }
    
    .progress-dot {
      transition: all 0.4s ease-out;
    }
    
    .progress-dot.active {
      transform: scale(1.2);
    }
  `;

  return (
    <div className="relative min-h-screen bg-gradient-to-b from-white to-gray-50 pt-12 pb-20 overflow-hidden">
      {/* 注入自定义动画样式 */}
      <style>{customStyles}</style>
      
      {/* 背景元素 */}
      <WaveBackground />
      <EmotionBubbles emotion={selectedTrend} />
      
      <div className="relative z-10 max-w-xl mx-auto px-6 pt-8 pb-12 space-y-8">
        {/* 标题区域 */}
        <div 
          className={`text-center mb-8 transition-all duration-1000 ease-out ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform -translate-y-10'}`}
        >
          <div className="inline-block p-3 mb-6 bg-green-50 bg-opacity-80 backdrop-blur-sm rounded-full shadow-md">
            <div className="w-20 h-20 flex items-center justify-center bg-gradient-to-br from-green-500 to-emerald-400 rounded-full shadow-lg">
              <span className="text-4xl transform transition-transform duration-700 ease-out hover:rotate-12">🌱</span>
            </div>
          </div>
          <h1 className="text-4xl font-serif font-bold text-gray-900 tracking-tight mb-3">
            Rhythm Check-In
          </h1>
          <p className="text-lg text-green-600 font-medium max-w-md mx-auto mt-3">
            <span className="bg-green-50 px-5 py-2 rounded-full shadow-sm backdrop-blur-sm">How are you feeling today?</span>
          </p>
        </div>

        {/* 选项区域 */}
        <div className="grid grid-cols-1 gap-5 mt-8">
          {options.map((opt, i) => (
            <button
              key={i}
              onClick={() => handleSelect(opt.trend as any, opt.score, i)}
              onMouseEnter={() => setHoveredOption(i)}
              onMouseLeave={() => setHoveredOption(null)}
              className={`relative option-card text-left bg-white backdrop-blur-sm bg-opacity-90 border border-gray-200 rounded-xl px-6 py-5 shadow-sm hover:shadow-md ${selectedTrend === opt.trend ? 'selected ring-2 ring-offset-1 shadow-md' : ''} ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
              style={{ 
                transitionDelay: `${300 + i * 150}ms`,
                borderLeft: `4px solid ${opt.moodColor?.replace('bg-', 'rgb(').replace('-400', '')}`,
                ...(selectedTrend === opt.trend ? { borderColor: opt.moodColor?.replace('bg-', 'rgb(').replace('-400', '') } : {})
              }}
            >
              {/* 情绪主题背景 - 仅在选中或悬停时显示 */}
              {(selectedTrend === opt.trend || hoveredOption === i) && (
                <EmotionTheme emotion={opt.trend} />
              )}
              
              <div className="flex items-start gap-4 relative z-10">
                <div className="flex-shrink-0 text-3xl">{opt.emoji}</div>
                <div className="flex-grow">
                  <p className="text-gray-800 font-medium text-base mb-1">{opt.text}</p>
                  <div 
                    className={`option-description ${hoveredOption === i || selectedTrend === opt.trend ? 'visible' : ''}`}
                  >
                    <p className="text-gray-600 text-sm mt-2">{opt.description}</p>
                  </div>
                </div>
              </div>
              
              {/* 情绪波形指示器 */}
              <div className="absolute bottom-0 left-0 right-0 h-1 overflow-hidden rounded-b-xl">
                {opt.trend === 'wavy' && (
                  <svg viewBox="0 0 120 6" preserveAspectRatio="none" className="w-full h-full">
                    <path d="M 0,3 C 10,0 20,6 30,3 C 40,0 50,6 60,3 C 70,0 80,6 90,3 C 100,0 110,6 120,3" stroke={opt.moodColor?.replace('bg-', 'var(--').replace('-400', '-400)')} strokeWidth="0.5" fill="none" />
                  </svg>
                )}
                {opt.trend === 'collapsed' && (
                  <svg viewBox="0 0 120 6" preserveAspectRatio="none" className="w-full h-full">
                    <path d="M 0,1 C 40,1 40,1 40,3 C 40,5 80,5 80,3 C 80,1 120,1 120,1" stroke={opt.moodColor?.replace('bg-', 'var(--').replace('-400', '-400)')} strokeWidth="0.5" fill="none" />
                  </svg>
                )}
                {opt.trend === 'rising' && (
                  <svg viewBox="0 0 120 6" preserveAspectRatio="none" className="w-full h-full">
                    <path d="M 0,5 C 40,5 40,3 40,3 C 40,3 80,1 120,1" stroke={opt.moodColor?.replace('bg-', 'var(--').replace('-400', '-400)')} strokeWidth="0.5" fill="none" />
                  </svg>
                )}
                {opt.trend === 'stable' && (
                  <svg viewBox="0 0 120 6" preserveAspectRatio="none" className="w-full h-full">
                    <path d="M 0,3 L 120,3" stroke={opt.moodColor?.replace('bg-', 'var(--').replace('-400', '-400)')} strokeWidth="0.5" fill="none" />
                  </svg>
                )}
              </div>
              
              {/* 选中标记 */}
              {selectedTrend === opt.trend && (
                <div className="absolute right-4 top-1/2 transform -translate-y-1/2 flex items-center justify-center w-8 h-8 bg-green-100 rounded-full">
                  <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                  </svg>
                </div>
              )}
            </button>
          ))}
        </div>
        
        {/* 选中状态详细信息 */}
        <div 
          className={`emotion-detail-panel bg-white bg-opacity-80 backdrop-blur-sm rounded-xl p-6 shadow-md border border-gray-200 ${showDetailsFor !== null ? 'visible' : ''}`}
          style={{
            borderColor: showDetailsFor !== null 
              ? options[showDetailsFor]?.moodColor?.replace('bg-', 'rgb(').replace('-400', '') 
              : 'transparent'
          }}
        >
          {showDetailsFor !== null && (
            <div className="text-center">
              <div className="text-4xl mb-3">{options[showDetailsFor].emoji}</div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">
                {options[showDetailsFor].stateDescription}
              </h3>
              <p className="text-gray-600 text-sm">
                RhythmOS will adapt to support your current emotional landscape.
                <br/>Taking you to the next step...
              </p>
            </div>
          )}
        </div>

        {/* 进度指示器 */}
        <div 
          className={`pt-6 flex justify-center space-x-3 transition-opacity duration-1000 delay-1000 ${loaded ? 'opacity-100' : 'opacity-0'}`}
        >
          {Array.from({ length: 3 }, (_, i) => (
            <div 
              key={i} 
              className={`progress-dot w-3 h-3 rounded-full ${i === 0 ? 'active bg-green-500' : 'bg-gray-200'}`}
            ></div>
          ))}
        </div>
        
        {/* 低调的返回按钮 */}
        <div className={`text-center transition-opacity duration-1000 ease-out delay-1200 ${loaded ? 'opacity-100' : 'opacity-0'}`}>
          <button 
            onClick={() => navigate(-1)}
            className="text-sm text-gray-500 hover:text-gray-700 transition-colors duration-300 flex items-center justify-center gap-1 mx-auto"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
            </svg>
            <span>Back to Welcome</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default OnboardingStep1;



