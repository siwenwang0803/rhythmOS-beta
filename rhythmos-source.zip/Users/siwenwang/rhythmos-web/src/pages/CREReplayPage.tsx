// src/pages/CREReplayPage.tsx (cleaned version: removed old cue replay, kept paragraph-level feedback)

import React from 'react'
import { getPersonaBiasSummary } from '../CREPersonaBiasMap'
import CREFeedbackTrendChart from '../components/CREFeedbackTrendChart'
import { writeCREGrowthLog } from '../creGrowthLog'
import CREGrowthView from '../components/CREGrowthView'
import PersonaTrendRadar from '../components/PersonaTrendRadar'
import { getNextCRECueSuggestion } from '../cueTrainer'
import { addFeedbackRecord } from '../feedbackRecord'
import RhythmStudioPanel from '../components/ui/RhythmStudioPanel'
import UserTextInput from '../components/UserTextInput'
import SpeakReplayView from '../components/SpeakReplayView'
import CREFeedbackSignatureMap from '../components/CREFeedbackSignatureMap'
import { getNextCREBlockSuggestion } from '../logic/getNextCREBlockSuggestion'



const CREReplayPage: React.FC = () => {
const { topPersona } = getPersonaBiasSummary()
const suggested = getNextCRECueSuggestion()
const suggestion = getNextCREBlockSuggestion()
  return (
    <div className="min-h-screen px-6 py-10 max-w-4xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">🧠 CRE Feedback Replay</h1>

      <RhythmStudioPanel
        title="📊 CRE Persona Insight"
        subtitle="Your dominant persona usage from feedback patterns"
        tone="gray"
      >
        <p className="text-base text-gray-700">🧠 Most Used Persona: <strong>{topPersona || '—'}</strong></p>
      </RhythmStudioPanel>

      <RhythmStudioPanel
        title="📈 CRE Feedback Trend"
        subtitle="Score trend over time"
        tone="default"
      >
        <CREFeedbackTrendChart />
        <CREGrowthView />
        <PersonaTrendRadar />
      </RhythmStudioPanel>

      <RhythmStudioPanel
        title="🌟 Next Suggested CRE"
        subtitle="System recommendation based on your past style bias"
        tone="blue"
      >
        {suggested && (
          <div className="border p-4 rounded bg-blue-50 space-y-3">
            <p className="text-base text-gray-700">“{suggested.text}”</p>
            <p className="text-sm text-gray-500">
              Suggested from underused persona: <strong>{suggested.persona}</strong>
            </p>
            <button
              className="text-sm px-3 py-1 rounded bg-green-600 text-white"
              onClick={() => {
                writeCREGrowthLog({
                  creText: suggested.text,
                  tone: suggested.tone,
                  variant: suggested.variant,
                  taskType: suggested.taskType,
                  persona: suggested.persona,
                  trend: 'wavy',
                  context: 'replay',
                  accepted: true,
                  score: undefined,
                  timestamp: Date.now()
                })
                addFeedbackRecord({
                  tone: suggested.tone,
                  variant: suggested.variant,
                  taskType: suggested.taskType,
                  score: 5,
                  persona: suggested.persona,
                  source: 'replay'
                })
                alert('✅ CRE accepted and recorded.')
              }}
            >
              ✅ Accept and record
            </button>
          </div>
        )}
      </RhythmStudioPanel>

      <RhythmStudioPanel
  title="🌟 You May Like This CRE"
  subtitle="Based on your past feedback on tone and persona"
  tone="blue"
>
  {suggestion ? (
    <div className="space-y-3 border bg-white p-4 rounded shadow-sm">
      <p className="text-base text-gray-800 font-medium">“{suggestion.cue}”</p>
      <p className="text-sm text-gray-600 whitespace-pre-wrap">{suggestion.paragraph}</p>
      <p className="text-sm text-gray-500">Persona: <strong>{suggestion.persona}</strong> · Tone: <strong>{suggestion.tone}</strong></p>
    </div>
  ) : (
    <p className="text-sm text-gray-500 italic">Not enough feedback yet to suggest a CRE.</p>
  )}
</RhythmStudioPanel>


      <RhythmStudioPanel
        title="🧠 Language Feedback Log"
        subtitle="How you responded to CRE paragraph messages"
        tone="default"
      >
        {(() => {
          const signatureLog = JSON.parse(localStorage.getItem('signatureFeedbackLog') || '[]')
          return signatureLog.length === 0 ? (
            <p className="text-sm text-gray-500">No paragraph-level feedback yet.</p>
          ) : (
            signatureLog.slice().reverse().map((entry: any, i: number) => (
              <div key={i} className="border rounded p-4 bg-white shadow-sm space-y-2">
                <p className="text-base font-medium text-gray-800">“{entry.cue}”</p>
                <p className="text-sm text-gray-600 whitespace-pre-wrap">{entry.paragraph}</p>
                <p className="text-sm text-gray-500">
                  Tone: <strong>{entry.tone}</strong> · Persona: <strong>{entry.persona}</strong>
                </p>
                <p className="text-sm text-gray-500">
                  Feedback: <strong>{entry.feedback}</strong> · {new Date(entry.timestamp).toLocaleString()}
                </p>
              </div>
            ))
          )
        })()}
      </RhythmStudioPanel>

      <RhythmStudioPanel
        title="🗣️ Language Reflections"
        subtitle="What you've said to the system and how it replied."
        tone="gray"
      >
        <SpeakReplayView />
        <div className="mt-6">
          <UserTextInput />
        </div>
      </RhythmStudioPanel>

      <RhythmStudioPanel
  title="🧬 CRE Feedback Map"
  subtitle="How your feedback shaped your rhythm language preferences"
  tone="default"
>
  <CREFeedbackSignatureMap />
</RhythmStudioPanel>

    </div>
  )
}

export default CREReplayPage