import React from 'react';
import { getTodayTotalScore } from '../utils/rhythmDayEngine';
import { scoreRules } from '../logic/scoreRules';
import { writeRhythmScore, getTodayGoalSubtaskScore } from '../utils/rhythmscoreEngine';


const RhythmScoreDebugPage: React.FC = () => {
  const log = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();

  const todayLog = log.filter((entry: any) => entry.time >= todayStart);
  const totalScore = getTodayTotalScore();
  const goalSubtaskScore = getTodayGoalSubtaskScore();

  return (
    <div className="max-w-2xl mx-auto px-6 py-10">
      <h1 className="text-xl font-bold mb-4">📊 Rhythm Score Debug Log</h1>
      <p className="text-sm text-gray-600 mb-4">
        This page shows all rhythm score events logged today.
      </p>

      <div className="mb-6 p-4 bg-gray-50 border rounded shadow space-y-2">
        <p className="text-sm text-gray-700">
          🎯 Total Score Today: <strong>{totalScore.toFixed(1)} / {scoreRules.maxDailyTotalScore}</strong>
        </p>
        <p className="text-sm text-gray-700">
          🧩 Goal + Subtask Score Today: <strong>{goalSubtaskScore.toFixed(1)} / {scoreRules.goalSubtaskCombinedMax}</strong>
        </p>
        <p className="text-xs text-gray-400">
          * Other actions (microtasks, challenges, trend diff) continue until total 6.0 cap.
        </p>
      </div>

      <div className="space-y-2">
        {todayLog.map((entry: any, i: number) => (
          <div
            key={i}
            className="border p-3 rounded bg-white text-sm flex justify-between"
          >
            <div>
              <p className="font-medium">{entry.source}</p>
              <p className="text-xs text-gray-400">{new Date(entry.time).toLocaleTimeString()}</p>
            </div>
            <div className="text-green-600 font-semibold">+{entry.value}</div>
          </div>
        ))}
        {todayLog.length === 0 && (
          <p className="text-sm text-gray-500 italic">No rhythm score activity yet today.</p>
        )}
      </div>
    </div>
  );
};

export default RhythmScoreDebugPage;
