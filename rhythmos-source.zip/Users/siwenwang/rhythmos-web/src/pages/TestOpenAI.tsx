// /src/pages/TestOpenAI.tsx
// 测试页面 - 验证 OpenAI 集成是否工作

import React, { useState } from 'react';
import { openaiComplete, generateCREWithOpenAI } from '../utils/openaiComplete';
import { CREVersionToggle } from '../components/CREVersionToggle';
const TestOpenAI: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [mockMode, setMockMode] = useState(false); // 改为默认关闭，以便测试真实 API

  // 模拟 CRE 生成
  const mockCREGeneration = () => {
    return {
      cue: "Take a deep breath and start small",
      paragraph: "When feeling overwhelmed, the most powerful action is often the simplest one. Begin with just one small task.",
      tone: "gentle",
      persona: "rhea"
    };
  };

  // 测试基础连接
  const testConnection = async () => {
    setLoading(true);
    setError(null);
    try {
      if (mockMode) {
        await new Promise(resolve => setTimeout(resolve, 500)); // 模拟延迟
        setResult({ type: 'connection', data: 'Hello RhythmOS (Mock Mode)' });
      } else {
        const response = await openaiComplete('Say "Hello RhythmOS" if you can hear me.');
        setResult({ type: 'connection', data: response });
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // 测试 CRE 生成
  const testCREGeneration = async () => {
    setLoading(true);
    setError(null);
    try {
      if (mockMode) {
        await new Promise(resolve => setTimeout(resolve, 800)); // 模拟延迟
        const mockCRE = mockCREGeneration();
        setResult({ type: 'cre', data: mockCRE });
      } else {
        const cre = await generateCREWithOpenAI({
          tone: 'gentle',
          trend: 'wavy',
          microEmotion: 'anxious',
          userContext: 'I feel overwhelmed with work'
        });
        setResult({ type: 'cre', data: cre });
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // 直接测试 API
  const testDirectAPI = async () => {
    setLoading(true);
    setError(null);
    setResult(null);
    
    const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    
    try {
      console.log('🔍 Testing with key:', apiKey?.slice(0, 20) + '...');
      
      // 最基础的 API 调用
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [
            {
              role: 'user',
              content: 'Reply with exactly: Hello RhythmOS'
            }
          ],
          max_tokens: 10,
          temperature: 0
        })
      });

      console.log('📡 Response status:', response.status);
      console.log('📡 Response headers:', Object.fromEntries(response.headers.entries()));

      if (!response.ok) {
        const errorData = await response.json();
        console.error('❌ Error response:', errorData);
        
        if (response.status === 429) {
          // 获取速率限制信息
          const headers = {
            'retry-after': response.headers.get('retry-after'),
            'x-ratelimit-limit-requests': response.headers.get('x-ratelimit-limit-requests'),
            'x-ratelimit-remaining-requests': response.headers.get('x-ratelimit-remaining-requests'),
            'x-ratelimit-reset-requests': response.headers.get('x-ratelimit-reset-requests'),
          };
          
          setError(`Rate Limited! Details:\n${JSON.stringify(headers, null, 2)}\n\nError: ${JSON.stringify(errorData, null, 2)}`);
        } else if (response.status === 401) {
          setError(`Authentication Error: Invalid API Key\n${JSON.stringify(errorData, null, 2)}`);
        } else {
          setError(`Error ${response.status}: ${JSON.stringify(errorData, null, 2)}`);
        }
        return;
      }

      const data = await response.json();
      console.log('✅ Success:', data);
      setResult({ type: 'direct', data });
      
    } catch (err: any) {
      console.error('💥 Request failed:', err);
      setError(`Network Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">OpenAI Integration Test</h1>
        
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">API Key Status</h2>
          <p className="text-sm text-gray-600">
            Key configured: {import.meta.env.VITE_OPENAI_API_KEY ? '✅ Yes' : '❌ No'}
          </p>
          {import.meta.env.VITE_OPENAI_API_KEY && (
            <p className="text-xs text-gray-500 mt-1">
              Key preview: {import.meta.env.VITE_OPENAI_API_KEY.slice(0, 20)}...
            </p>
          )}
          
          {/* 模拟模式切换 */}
          <div className="mt-4 flex items-center space-x-2">
            <input
              type="checkbox"
              id="mockMode"
              checked={mockMode}
              onChange={(e) => setMockMode(e.target.checked)}
              className="w-4 h-4"
            />
            <label htmlFor="mockMode" className="text-sm text-gray-700">
              Use Mock Mode (避免 API 调用)
            </label>
          </div>
        </div>
        <div className="mb-6">
  <CREVersionToggle />
</div>

        <div className="space-y-4">
          <button
            onClick={testDirectAPI}
            disabled={loading || !import.meta.env.VITE_OPENAI_API_KEY}
            className="w-full bg-purple-500 text-white px-4 py-2 rounded hover:bg-purple-600 disabled:opacity-50"
          >
            {loading ? 'Testing...' : '🚀 Test Direct API Call (最简单)'}
          </button>

          <button
            onClick={testConnection}
            disabled={loading}
            className="w-full bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 disabled:opacity-50"
          >
            {loading ? 'Testing...' : 'Test Basic Connection'}
          </button>

          <button
            onClick={testCREGeneration}
            disabled={loading}
            className="w-full bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 disabled:opacity-50"
          >
            {loading ? 'Generating...' : 'Test CRE Generation'}
          </button>
        </div>

        {error && (
          <div className="mt-6 bg-red-50 border border-red-200 rounded-lg p-4">
            <h3 className="text-red-800 font-semibold">Error:</h3>
            <pre className="text-red-600 text-sm mt-1 whitespace-pre-wrap font-mono">
              {error}
            </pre>
            {error.includes('Rate limit') && (
              <div className="mt-3 text-sm text-gray-700 bg-yellow-50 p-3 rounded">
                <p className="font-semibold">💡 解决方案：</p>
                <ul className="list-disc ml-5 mt-1">
                  <li>等待 retry-after 指定的时间</li>
                  <li>访问 <a href="https://platform.openai.com/account/billing" target="_blank" className="text-blue-500 underline">OpenAI Billing</a> 添加支付方式</li>
                  <li>新账户需要等待 48 小时激活</li>
                  <li>使用模拟模式继续开发</li>
                </ul>
              </div>
            )}
            {error.includes('Authentication Error') && (
              <div className="mt-3 text-sm text-gray-700 bg-yellow-50 p-3 rounded">
                <p className="font-semibold">🔑 API Key 问题：</p>
                <ul className="list-disc ml-5 mt-1">
                  <li>检查 .env.local 文件中的 VITE_OPENAI_API_KEY</li>
                  <li>确保密钥以 sk-proj- 开头</li>
                  <li>重启开发服务器: npm run dev</li>
                  <li>在 <a href="https://platform.openai.com/api-keys" target="_blank" className="text-blue-500 underline">OpenAI API Keys</a> 重新生成密钥</li>
                </ul>
              </div>
            )}
          </div>
        )}

        {result && (
          <div className="mt-6 bg-green-50 border border-green-200 rounded-lg p-4">
            <h3 className="text-green-800 font-semibold">
              {result.type === 'connection' ? 'Connection Test Result:' : 
               result.type === 'cre' ? 'Generated CRE:' : 
               'Direct API Test Result:'}
              {mockMode && ' (Mock Mode)'}
            </h3>
            <pre className="text-sm mt-2 overflow-auto bg-white p-3 rounded font-mono">
              {JSON.stringify(result.data, null, 2)}
            </pre>
          </div>
        )}

        <div className="mt-8 text-sm text-gray-500">
          <p className="font-semibold mb-2">💡 调试提示：</p>
          <ul className="list-disc ml-5 space-y-1">
            <li>打开浏览器控制台 (F12) 查看详细日志</li>
            <li>确保 VITE_OPENAI_API_KEY 在 .env.local 文件中</li>
            <li>重启开发服务器以加载新的环境变量</li>
            <li>检查 <a href="https://platform.openai.com/usage" target="_blank" className="text-blue-500 underline">OpenAI Usage</a> 页面</li>
            <li className="text-orange-600 font-semibold">如果是新账户，可能需要添加支付方式或等待激活</li>
          </ul>
          
          <div className="mt-4 p-3 bg-blue-50 rounded">
            <p className="font-semibold text-blue-800">🔧 快速测试命令：</p>
            <code className="block mt-2 p-2 bg-white rounded text-xs">
              curl -X POST https://api.openai.com/v1/chat/completions \<br/>
              -H "Authorization: Bearer YOUR_API_KEY" \<br/>
              -H "Content-Type: application/json" \<br/>
              -d '{`{"model":"gpt-3.5-turbo","messages":[{"role":"user","content":"Hi"}],"max_tokens":5}`}'
            </code>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestOpenAI;