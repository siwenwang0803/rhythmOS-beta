import React, { useState, useEffect } from 'react';
import { getRhythmGoals, updateGoalStatus } from '../rhythmGoal';
import { useNavigate } from 'react-router-dom';
import ConfidentialNotice from '../components/ConfidentialNotice';
import RhythmStudioPanel from '../components/ui/RhythmStudioPanel';
import RhythmButton from '../components/ui/RhythmButton';
import FooterNavigation from '../components/FooterNavigation';
import GlobalOnboardingHint from '../components/GlobalOnboardingHint';
import EndMyDayButton from '../components/EndMyDayButton';
import { handleCompleteGoal } from '../utils/handleRhythmCompletion';
import { useDailyRhythm } from '../hooks/useDailyRhythm';
import RhythmScoreSummaryCard from '../components/RhythmScoreSummaryCard';
import { TaskBehaviorRadarSummary } from '../components/TaskBehaviorRadarSummary';

/**
 * GoalOverviewPage - A visually appealing and psychologically comfortable interface 
 * for managing goals and tracking progress in RhythmOS.
 * 
 * Designed to encourage exploration and action through gradual engagement,
 * with attention to visual harmony and behavioral psychology principles.
 */
const GoalOverviewPage: React.FC = () => {
  useDailyRhythm();
  const navigate = useNavigate();
  const goals = getRhythmGoals();
  const activeGoals = goals.filter((goal) => goal.status === 'active');
  const completedGoals = goals.filter((goal) => goal.status === 'completed');
  
  // For animation and visual state management
  const [showCompletedGoals, setShowCompletedGoals] = useState(false);
  const [animateGoals, setAnimateGoals] = useState(false);
  const [isDaytime, setIsDaytime] = useState(true);
  
  // RhythmOS theme colors based on day/night mode
  const themeColors = {
    background: isDaytime ? '#F5E8C7' : '#2C2C2C',   // Sand base / Dark mode bg
    cardBg: isDaytime ? '#FFFFFF' : '#3A3A3A',       // White / Dark card bg
    cardAltBg: isDaytime ? '#F8F8F5' : '#454545',    // Slightly different card bg
    text: isDaytime ? '#333333' : '#E0E0E0',         // Dark text / Light text
    textMuted: isDaytime ? '#777777' : '#AAAAAA',    // Muted text colors
    border: isDaytime ? '#E6E6E6' : '#555555',       // Light/dark borders
    shadow: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(0, 0, 0, 0.2)',
    accent: '#F7DC6F',                               // Soft yellow accent
  };
  
  // Color mapping for goal card accents based on creation date (newer = more saturated)
  const getGoalAccentColor = (createdAt: string) => {
    const daysSinceCreation = Math.floor((Date.now() - new Date(createdAt).getTime()) / (1000 * 60 * 60 * 24));
    
    // Base colors from RhythmOS spec
    const colors = [
      '#FFB347', // Rising - activating orange-yellow (newest)
      '#C5D8A4', // Stable - grounded light green
      '#C3B1E1', // Wavy - transitional lavender
      '#AEC6CF', // Collapsed - gentle calming blue (oldest)
    ];
    
    if (daysSinceCreation < 1) return colors[0];
    if (daysSinceCreation < 3) return colors[1];
    if (daysSinceCreation < 7) return colors[2];
    return colors[3];
  };

  // Animate goals on initial load for a delightful entry
  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimateGoals(true);
    }, 300);
    
    return () => clearTimeout(timer);
  }, []);

  // Handle goal completion with visual feedback
  const handleComplete = (id: string) => {
    // Instead of an abrupt confirmation dialog, use a gentle visual state change
    updateGoalStatus(id, 'completed');
    handleCompleteGoal(id, []);
    
    // Provide visual feedback before reload
    setTimeout(() => {
      window.location.reload();
    }, 600);
  };

  // Display a welcoming message based on number of goals
  const getWelcomeMessage = () => {
    const completionRate = completedGoals.length / (completedGoals.length + activeGoals.length);
    
    if (activeGoals.length === 0 && completedGoals.length === 0) {
      return "Welcome to your goal space. Set your first goal to begin your journey.";
    }
    
    if (activeGoals.length === 0 && completedGoals.length > 0) {
      return "All goals completed! You're doing great. What would you like to focus on next?";
    }
    
    if (completionRate > 0.7) {
      return "You're making excellent progress! Keep up the great work.";
    }
    
    if (activeGoals.length > 3) {
      return "You have several goals in motion. Consider focusing on the most important ones.";
    }
    
    return "Your goals are ready for you. What would you like to advance today?";
  };

  // Custom confirmation dialog
  const showConfirmationDialog = () => {
    // Use a more gentle confirmation approach
    const confirmBox = document.createElement('div');
    confirmBox.style.position = 'fixed';
    confirmBox.style.top = '50%';
    confirmBox.style.left = '50%';
    confirmBox.style.transform = 'translate(-50%, -50%)';
    confirmBox.style.backgroundColor = themeColors.cardBg;
    confirmBox.style.borderRadius = '12px';
    confirmBox.style.padding = '24px';
    confirmBox.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.15)';
    confirmBox.style.zIndex = '1000';
    confirmBox.style.maxWidth = '320px';
    confirmBox.style.textAlign = 'center';
    
    confirmBox.innerHTML = `
      <h3 style="margin-bottom: 16px; font-weight: 600; color: ${themeColors.text};">
        Clear All Goals?
      </h3>
      <p style="margin-bottom: 24px; color: ${themeColors.textMuted}; font-size: 14px;">
        This will reset your goal space. This action cannot be undone.
      </p>
      <div style="display: flex; gap: 12px; justify-content: center;">
        <button id="cancel" style="padding: 8px 16px; border-radius: 8px; border: 1px solid ${themeColors.border}; background-color: transparent; color: ${themeColors.text};">
          Cancel
        </button>
        <button id="confirm" style="padding: 8px 16px; border-radius: 8px; background-color: #ef4444; color: white; border: none;">
          Clear All
        </button>
      </div>
    `;
    
    document.body.appendChild(confirmBox);
    
    document.getElementById('cancel')?.addEventListener('click', () => {
      document.body.removeChild(confirmBox);
    });
    
    document.getElementById('confirm')?.addEventListener('click', () => {
      localStorage.removeItem('rhythmGoals');
      localStorage.removeItem('rhythmSubtasks');
      document.body.removeChild(confirmBox);
      window.location.reload();
    });
  };

  return (
    <div 
      className="min-h-screen"
      style={{ 
        backgroundColor: isDaytime ? '#fbf9f5' : '#242424',
        color: themeColors.text,
        transition: 'background-color 0.5s ease'
      }}
    >
      <div className="px-6 py-12 max-w-4xl mx-auto space-y-10">
        <GlobalOnboardingHint />
        
        {/* Header with subtle animation - removed redundant statistics */}
        <div className="space-y-2">
          <div className="flex items-center">
            <h1 
              className="text-3xl font-bold"
              style={{ 
                color: themeColors.text,
                opacity: animateGoals ? 1 : 0.7,
                transform: animateGoals ? 'translateY(0)' : 'translateY(5px)',
                transition: 'opacity 0.5s ease, transform 0.5s ease',
                display: 'flex',
                alignItems: 'center',
                gap: '12px'
              }}
            >
              <span style={{ fontSize: '32px' }}>🎯</span>
              <span>Your Goals</span>
            </h1>
          </div>
          
          <p 
            style={{ 
              color: themeColors.textMuted,
              fontSize: '16px',
              opacity: animateGoals ? 1 : 0,
              transform: animateGoals ? 'translateY(0)' : 'translateY(10px)',
              transition: 'opacity 0.7s ease, transform 0.7s ease'
            }}
          >
            {getWelcomeMessage()}
          </p>
        </div>

        {/* Rhythm score summary with enhanced visual styling */}
        <div 
          style={{
            opacity: animateGoals ? 1 : 0,
            transform: animateGoals ? 'translateY(0)' : 'translateY(15px)',
            transition: 'opacity 0.8s ease, transform 0.8s ease',
            transitionDelay: '0.1s'
          }}
        >
          <RhythmScoreSummaryCard isDaytime={isDaytime} />
        </div>

        {/* Active Goals Section */}
        <div 
          style={{
            opacity: animateGoals ? 1 : 0,
            transform: animateGoals ? 'translateY(0)' : 'translateY(15px)',
            transition: 'opacity 0.8s ease, transform 0.8s ease',
            transitionDelay: '0.2s'
          }}
        >
          {activeGoals.length === 0 ? (
            <div
              style={{
                backgroundColor: themeColors.cardBg,
                borderRadius: '16px',
                padding: '32px',
                textAlign: 'center',
                boxShadow: `0 4px 16px ${themeColors.shadow}`,
                border: `1px solid ${themeColors.border}`
              }}
            >
              <div
                style={{
                  width: '80px',
                  height: '80px',
                  borderRadius: '50%',
                  backgroundColor: isDaytime ? 'rgba(245, 232, 199, 0.5)' : 'rgba(58, 58, 58, 0.8)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '32px',
                  margin: '0 auto 24px auto'
                }}
              >
                🚀
              </div>
              <h2
                style={{
                  fontSize: '20px',
                  fontWeight: 600,
                  color: themeColors.text,
                  marginBottom: '12px'
                }}
              >
                Begin Your Journey
              </h2>
              <p
                style={{
                  fontSize: '16px',
                  color: themeColors.textMuted,
                  marginBottom: '24px',
                  maxWidth: '400px',
                  margin: '0 auto 24px auto'
                }}
              >
                Set your first goal to start moving with intention. Goals help create direction for your daily rhythms.
              </p>
              <RhythmButton 
                onClick={() => navigate('/goal-input')} 
                variant="primary"
                isDaytime={isDaytime}
              >
                <span>+</span>
                <span>Add First Goal</span>
              </RhythmButton>
            </div>
          ) : (
            <div className="space-y-6">
              {activeGoals.map((goal, index) => (
                <div
                  key={goal.id}
                  style={{
                    backgroundColor: themeColors.cardBg,
                    borderRadius: '16px',
                    overflow: 'hidden',
                    boxShadow: `0 4px 12px ${themeColors.shadow}`,
                    border: `1px solid ${themeColors.border}`,
                    opacity: animateGoals ? 1 : 0,
                    transform: animateGoals ? 'translateY(0)' : 'translateY(20px)',
                    transition: 'opacity 0.5s ease, transform 0.5s ease',
                    transitionDelay: `${0.2 + index * 0.1}s`
                  }}
                >
                  {/* Color accent bar at top */}
                  <div
                    style={{
                      height: '6px',
                      backgroundColor: getGoalAccentColor(goal.createdAt)
                    }}
                  />
                  
                  <div style={{ padding: '20px' }}>
                    <div className="flex items-center justify-between">
                      <h3
                        style={{
                          fontSize: '18px',
                          fontWeight: 600,
                          color: themeColors.text,
                          display: 'flex',
                          alignItems: 'center',
                          gap: '8px'
                        }}
                      >
                        <span>🎯</span>
                        <span>{goal.title}</span>
                      </h3>
                      
                      <div
                        style={{
                          fontSize: '14px',
                          color: themeColors.textMuted
                        }}
                      >
                        Created on {new Date(goal.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                    
                    {/* Goal notes with subtle styling */}
                    {goal.notes && (
                      <div
                        style={{
                          padding: '12px',
                          backgroundColor: isDaytime ? 'rgba(245, 232, 199, 0.1)' : 'rgba(58, 58, 58, 0.4)',
                          borderRadius: '8px',
                          marginTop: '12px',
                          marginBottom: '16px',
                          fontSize: '14px',
                          color: themeColors.text,
                          lineHeight: 1.5
                        }}
                      >
                        {goal.notes}
                      </div>
                    )}

                    {/* Subtask progress indicator (if any) */}
                    {goal.subtasks && goal.subtasks.length > 0 && (
                      <div
                        style={{
                          marginTop: '12px',
                          marginBottom: '16px'
                        }}
                      >
                        <div
                          style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            marginBottom: '6px',
                            fontSize: '14px'
                          }}
                        >
                          <span style={{ color: themeColors.textMuted }}>
                            Progress: {goal.subtasks.filter(st => st.completed).length} of {goal.subtasks.length} subtasks
                          </span>
                          <span style={{ color: themeColors.text, fontWeight: 500 }}>
                            {Math.round((goal.subtasks.filter(st => st.completed).length / goal.subtasks.length) * 100)}%
                          </span>
                        </div>
                        
                        {/* Progress bar */}
                        <div
                          style={{
                            height: '6px',
                            backgroundColor: isDaytime ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.1)',
                            borderRadius: '3px',
                            overflow: 'hidden'
                          }}
                        >
                          <div
                            style={{
                              height: '100%',
                              width: `${(goal.subtasks.filter(st => st.completed).length / goal.subtasks.length) * 100}%`,
                              backgroundColor: getGoalAccentColor(goal.createdAt),
                              transition: 'width 0.5s ease'
                            }}
                          />
                        </div>
                      </div>
                    )}

                    <div className="flex gap-3 mt-4">
                      <RhythmButton 
                        onClick={() => navigate(`/goals/${goal.id}`)} 
                        variant="muted"
                        isDaytime={isDaytime}
                      >
                        <span>🔍</span>
                        <span>View Details</span>
                      </RhythmButton>
                      
                      <RhythmButton 
                        onClick={() => handleComplete(goal.id)} 
                        variant="secondary"
                        isDaytime={isDaytime}
                      >
                        <span>✓</span>
                        <span>Mark as Done</span>
                      </RhythmButton>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Task Behavior Summary - with enhanced styling */}
        <div 
          style={{
            backgroundColor: themeColors.cardBg,
            borderRadius: '16px',
            padding: '24px',
            boxShadow: `0 4px 12px ${themeColors.shadow}`,
            border: `1px solid ${themeColors.border}`,
            opacity: animateGoals ? 1 : 0,
            transform: animateGoals ? 'translateY(0)' : 'translateY(20px)',
            transition: 'opacity 0.5s ease, transform 0.5s ease',
            transitionDelay: '0.4s'
          }}
        >
          <h3 
            style={{ 
              fontSize: '16px', 
              fontWeight: 600, 
              marginBottom: '16px',
              color: themeColors.text,
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
          >
            <span role="img" aria-label="Chart">📊</span>
            <span>Task Behavior Summary</span>
          </h3>
          
          <TaskBehaviorRadarSummary isDaytime={isDaytime} />
          
          <p 
            style={{ 
              fontSize: '14px', 
              color: themeColors.textMuted,
              marginTop: '16px',
              textAlign: 'center'
            }}
          >
            This chart shows how many tasks you've completed in each difficulty category.
          </p>
        </div>

        {/* Completed Goals Toggle (only shown if there are completed goals) */}
        {completedGoals.length > 0 && (
          <div 
            style={{
              opacity: animateGoals ? 1 : 0,
              transition: 'opacity 0.8s ease',
              transitionDelay: '0.5s'
            }}
          >
            <button
              onClick={() => setShowCompletedGoals(!showCompletedGoals)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '8px 16px',
                backgroundColor: 'transparent',
                border: `1px solid ${themeColors.border}`,
                borderRadius: '8px',
                color: themeColors.textMuted,
                fontSize: '14px',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              <span style={{ 
                transform: showCompletedGoals ? 'rotate(90deg)' : 'rotate(0deg)',
                transition: 'transform 0.3s ease'
              }}>
                ▶
              </span>
              <span>
                {showCompletedGoals ? 'Hide' : 'Show'} Completed Goals ({completedGoals.length})
              </span>
            </button>
            
            {/* Completed Goals Section */}
            {showCompletedGoals && (
              <div 
                style={{ 
                  marginTop: '16px',
                  display: 'grid',
                  gap: '12px'
                }}
              >
                {completedGoals.map((goal, index) => (
                  <div
                    key={goal.id}
                    style={{
                      backgroundColor: themeColors.cardAltBg,
                      borderRadius: '12px',
                      padding: '16px',
                      border: `1px solid ${themeColors.border}`,
                      opacity: 0.8,
                      animation: 'fadeIn 0.5s ease forwards',
                      animationDelay: `${index * 0.05}s`
                    }}
                  >
                    <div className="flex justify-between items-center">
                      <div 
                        style={{ 
                          display: 'flex', 
                          alignItems: 'center',
                          gap: '8px'
                        }}
                      >
                        <span style={{ color: '#22c55e' }}>✓</span>
                        <h4 
                          style={{ 
                            fontSize: '16px',
                            color: themeColors.text,
                            textDecoration: 'line-through',
                            opacity: 0.9
                          }}
                        >
                          {goal.title}
                        </h4>
                      </div>
                      <span 
                        style={{ 
                          fontSize: '13px',
                          color: themeColors.textMuted
                        }}
                      >
                        Completed on {new Date(goal.completedAt || Date.now()).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Action Buttons with enhanced styling */}
        <div 
          className="pt-8 flex justify-center gap-3"
          style={{
            opacity: animateGoals ? 1 : 0,
            transform: animateGoals ? 'translateY(0)' : 'translateY(20px)',
            transition: 'opacity 0.5s ease, transform 0.5s ease',
            transitionDelay: '0.6s'
          }}
        >
          <RhythmButton 
            onClick={() => navigate('/goal-input')} 
            variant="primary"
            isDaytime={isDaytime}
            style={{ padding: '12px 24px', fontSize: '16px' }}
          >
            <span>+</span>
            <span>Add New Goal</span>
          </RhythmButton>
          
          <RhythmButton
            onClick={showConfirmationDialog}
            variant="danger"
            isDaytime={isDaytime}
            style={{ padding: '12px 20px', fontSize: '15px' }}
          >
            <span>🧹</span>
            <span>Clear All Goals</span>
          </RhythmButton>
        </div>

        <EndMyDayButton isDaytime={isDaytime} />
        <FooterNavigation isDaytime={isDaytime} />
        <ConfidentialNotice isDaytime={isDaytime} />
      </div>
      
      {/* Add animation keyframes */}
      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
};

export default GoalOverviewPage;



