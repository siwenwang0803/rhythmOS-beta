import React from "react";
import RhythmTooltip from "@/components/ui/RhythmTooltip";
import { Link } from "react-router-dom";

const glossaryTerms = [
  {
    term: "CRE",
    label: "Contextual Resonant Echo",
    example: "Even on low days, you’re still carrying strength.",
    link: "/identity/train",
    linkLabel: "Explore CRE Training →",
  },
  {
    term: "trend",
    label: "Self-Reported Rhythm Trend",
    example: "You selected 'rising' today — your cue will reflect it.",
    link: "/rhythm",
    linkLabel: "Check Today's Trend →",
  },
  {
    term: "dailyRhythm",
    label: "System Evaluated Daily Rhythm",
    example: "Today’s task performance: 7/10 → Daily Rhythm: Steady.",
    link: "/identity/insight",
    linkLabel: "View Daily Rhythm →",
  },
  {
    term: "tone",
    label: "Cue Tone Style",
    example: "gentle | directive | motivated | visionary | rational",
    link: "/identity/insight",
    linkLabel: "Adjust Your Cue Tone →",
  },
  {
    term: "persona",
    label: "Language Persona",
    example: "Rhea (gentle), Aurelia (rational), Niveus (directive)",
    link: "/identity/start",
    linkLabel: "Choose Your Persona →",
  },
  {
    term: "Signature",
    label: "Signature Growth Profile",
    example: "You most align with: directive tone × niveus persona.",
    link: "/identity/insight",
    linkLabel: "View Signature Map →",
  },
  {
    term: "rhythmScore",
    label: "Daily Rhythm Energy Score",
    example: "Today's score: 6.5/10 — maintaining steady momentum.",
    link: "/identity/insight",
    linkLabel: "View Score History →",
  },
  {
    term: "feedback",
    label: "Cue Response Feedback",
    example: "You rated today's cue as aligned with your intent.",
    link: "/identity/insight",
    linkLabel: "Review Feedback Log →",
  },
  {
    term: "subtaskSuggestion",
    label: "Action Suggestions from Cue",
    example: "Write 3 feelings without judgment after this cue.",
    link: "/goal-input",
    linkLabel: "View Suggested Tasks →",
  },
  {
    term: "goalIntent",
    label: "Training Direction Detected from Goal",
    example: "Goal: 'Present confidently' → detected intent: expression",
    link: "/goal-input",
    linkLabel: "Review Goal Intents →",
  },
];

const GlossaryPage: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      <h1 className="text-3xl font-bold text-gray-800 mb-8">📚 RhythmOS Glossary</h1>
      <ul className="space-y-8">
        {glossaryTerms.map((item) => (
          <li key={item.term} className="border-b pb-6">
            <h3 className="text-xl font-semibold text-blue-700 mb-1">
              <RhythmTooltip term={item.term} />
              <span className="ml-2 text-gray-500">({item.label})</span>
            </h3>
            <p className="text-sm text-gray-700 mt-1 italic">{item.example}</p>
            <div className="mt-2">
              <Link
                to={item.link}
                className="text-sm text-blue-600 underline hover:text-blue-800"
              >
                {item.linkLabel}
              </Link>
            </div>
          </li>
        ))}
      </ul>
      <div className="text-center pt-8">
  <a
    href="/"
    className="inline-block px-4 py-2 text-sm font-medium bg-gray-100 text-gray-800 rounded-md shadow hover:bg-gray-200 transition"
  >
    🔙 Return to Beta Welcome Page
  </a>
</div>
    </div>
  );
};

export default GlossaryPage;




