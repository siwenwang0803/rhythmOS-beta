// pages/FeedbackLogDebugPage.tsx (extended with rhythmScore log)

import React, { useState } from 'react'
import { getDominantPersonaTone } from '../logic/getDominantPersonaTone'

const FeedbackLogDebugPage: React.FC = () => {
  const log = JSON.parse(localStorage.getItem('signatureFeedbackLog') || '[]')
  const rhythmHistory = JSON.parse(localStorage.getItem('rhythmScoreHistory') || '[]')
  const dominant = getDominantPersonaTone()
  const [filter, setFilter] = useState('all')

  const filtered = filter === 'all'
    ? log
    : log.filter((entry: any) => entry.persona === filter || entry.tone === filter)

  const exportData = () => {
    const blob = new Blob([JSON.stringify(log, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'signatureFeedbackLog.json'
    link.click()
  }

  const countMap: Record<string, number> = {}
  log.forEach((entry: any) => {
    const key = `${entry.persona} × ${entry.tone}`
    countMap[key] = (countMap[key] || 0) + 1
  })

  return (
    <div className="max-w-4xl mx-auto px-6 py-12 space-y-8">
      <h1 className="text-2xl font-bold text-gray-800">🛠️ Feedback Debug Console</h1>

      <div className="space-y-2">
        <p className="text-sm text-gray-600">
          Total feedback entries: <strong>{log.length}</strong>
        </p>
        {dominant && (
          <p className="text-sm text-gray-600">
            Dominant Style: <strong>{dominant.persona}</strong> × <strong>{dominant.tone}</strong> — {dominant.aligned} aligned
          </p>
        )}
        <div className="flex flex-wrap gap-2 mt-2">
          {['all', 'rhea', 'caelum', 'lucis', 'aurelia', 'niveus', 'gentle', 'directive', 'visionary', 'motivated', 'rational'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1 rounded text-sm ${filter === f ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              {f}
            </button>
          ))}
        </div>
        <button
          className="mt-4 text-sm bg-blue-600 text-white px-4 py-2 rounded"
          onClick={exportData}
        >
          📥 Export Feedback JSON
        </button>
      </div>

      <div className="mt-6 space-y-4">
        <h2 className="text-md font-semibold text-gray-700">📊 Feedback Distribution</h2>
        {Object.entries(countMap).map(([label, count]) => (
          <div key={label} className="flex items-center text-sm text-gray-700">
            <span className="w-40 font-medium">{label}</span>
            <div className="flex-1 h-3 bg-blue-100 rounded overflow-hidden ml-2">
              <div className="h-full bg-blue-600" style={{ width: `${Math.min(count * 10, 100)}%` }}></div>
            </div>
            <span className="ml-2">{count}</span>
          </div>
        ))}
      </div>

      <div className="mt-8 space-y-4">
        <h2 className="text-md font-semibold text-gray-700">📝 Feedback Log ({filter})</h2>
        {filtered.length === 0 ? (
          <p className="text-sm text-gray-500 italic">No records match this filter.</p>
        ) : (
          filtered.slice().reverse().map((entry: any, i: number) => (
            <div key={i} className="bg-white border rounded p-4 shadow-sm space-y-1">
              <p className="text-sm text-gray-700"><strong>“{entry.cue}”</strong></p>
              <p className="text-xs text-gray-500">{entry.paragraph}</p>
              <p className="text-xs text-gray-500">
                {entry.persona} × {entry.tone} — <strong>{entry.feedback}</strong> ({new Date(entry.timestamp).toLocaleString()})
              </p>
            </div>
          ))
        )}
      </div>

      <div className="mt-12 space-y-4">
        <h2 className="text-md font-semibold text-gray-700">📈 Rhythm Score History</h2>
        {rhythmHistory.length === 0 ? (
          <p className="text-sm text-gray-500 italic">No rhythmScore data recorded.</p>
        ) : (
          rhythmHistory.map((entry: any, i: number) => (
            <div key={i} className="flex text-sm text-gray-700">
              <span className="w-32">{new Date(entry.timestamp).toLocaleDateString()}</span>
              <span className="flex-1">Score: {entry.score}</span>
              <span className="ml-4 text-xs text-gray-500">Trend: {entry.trend}</span>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

export default FeedbackLogDebugPage


