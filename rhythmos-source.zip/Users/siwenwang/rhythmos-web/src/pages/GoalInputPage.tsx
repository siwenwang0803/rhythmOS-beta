import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createGoal } from '../rhythmGoal';
import { generateInitialSubtasks, saveSubtasks } from '../rhythmSubtasks';
import RhythmStudioPanel from '../components/ui/RhythmStudioPanel';
import RhythmButton from '../components/ui/RhythmButton';
import FooterNavigation from '../components/FooterNavigation';

// Define rhythm state colors from the UI specs
const rhythmColors = {
  sand: '#F5E8C7',
  collapsed: '#AEC6CF',
  wavy: '#C3B1E1',
  stable: '#C5D8A4',
  rising: '#FFB347',
  accent: '#F7DC6F'
};

// Map RhythmOS colors to existing panel tones
const rhythmStateToTone = {
  collapsed: 'blue',     // Collapsed blue -> blue
  wavy: 'purple',        // Wavy lavender -> purple
  stable: 'green',       // Stable green -> green
  rising: 'yellow',      // Rising orange-yellow -> yellow
  default: 'default'     // Default state
};

const GoalInputPage: React.FC = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');
  const [focusedInput, setFocusedInput] = useState<string | null>(null);
  const [currentRhythm, setCurrentRhythm] = useState('default');
  
  // Simulate the rhythm state based on input progress
  useEffect(() => {
    if (title.length > 0 && notes.length > 0) {
      setCurrentRhythm('rising');
    } else if (title.length > 0) {
      setCurrentRhythm('stable');
    } else if (focusedInput) {
      setCurrentRhythm('wavy');
    } else {
      setCurrentRhythm('collapsed');
    }
  }, [title, notes, focusedInput]);

  const handleCreate = () => {
    if (!title.trim()) {
      // Instead of an alert, focus the input field
      const titleInput = document.getElementById('goal-title');
      titleInput?.focus();
      return;
    }

    // Small delay for better UX feel
    setTimeout(() => {
      const goal = createGoal(title, notes);
      const subtasks = generateInitialSubtasks(goal.id, goal.title);
      saveSubtasks(subtasks);
      navigate('/goals');
    }, 100);
  };

  // Calculate tone based on current rhythm state
  const getPanelTone = (step: number) => {
    if (step === 1) {
      // First panel
      return currentRhythm === 'stable' || currentRhythm === 'rising' 
        ? 'green'  // Success tone
        : rhythmStateToTone[currentRhythm as keyof typeof rhythmStateToTone] || 'gray';
    } else {
      // Second panel
      return currentRhythm === 'rising' 
        ? 'yellow'  // Success tone for the second step
        : 'gray';   // Default gray for incomplete
    }
  };

  // Custom styles for input focus states
  const getInputStyle = (inputType: string) => {
    const isFocused = focusedInput === inputType;
    return {
      transition: 'all 0.3s ease',
      borderColor: isFocused ? rhythmColors[currentRhythm as keyof typeof rhythmColors] : '',
      boxShadow: isFocused ? `0 0 0 2px rgba(${getRGBFromHex(rhythmColors[currentRhythm as keyof typeof rhythmColors])}, 0.25)` : '',
    };
  };

  return (
    <div 
      className="min-h-screen px-6 py-10 max-w-2xl mx-auto space-y-8"
      style={{ 
        backgroundImage: `linear-gradient(to bottom, ${rhythmColors.sand}20 0%, #FFFFFF 100%)`,
      }}
    >
      <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
        <span className="inline-block">🎯</span> Define Your New Goal
      </h1>

      <div className="space-y-6">
        <RhythmStudioPanel
          title="🌱 Step 1: What's your focus?"
          subtitle="Give your goal a clear, motivating name."
          tone={getPanelTone(1)}
        >
          <input
            id="goal-title"
            type="text"
            placeholder="e.g. Finish portfolio project"
            className="text-base w-full border border-gray-300 px-4 py-3 rounded-lg focus:outline-none transition-all duration-300"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onFocus={() => setFocusedInput('title')}
            onBlur={() => setFocusedInput(null)}
            style={getInputStyle('title')}
          />
        </RhythmStudioPanel>

        <RhythmStudioPanel
          title="🧠 Step 2: Any notes or blockers?"
          subtitle="Optional: Write any thoughts, concerns, or ideas you want to track."
          tone={getPanelTone(2)}
        >
          <textarea
            placeholder="e.g. I've been procrastinating because I don't know how to start."
            className="text-base w-full border border-gray-300 px-4 py-3 rounded-lg focus:outline-none transition-all duration-300"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            onFocus={() => setFocusedInput('notes')}
            onBlur={() => setFocusedInput(null)}
            rows={4}
            style={{
              ...getInputStyle('notes'),
              lineHeight: '1.5',
            }}
          />
        </RhythmStudioPanel>
      </div>

      <div className="flex justify-center gap-4 pt-4">
        <RhythmButton 
          onClick={handleCreate} 
          variant="primary"
          className="transition-all duration-300"
          style={{ 
            backgroundColor: title ? rhythmColors.rising : rhythmColors.stable,
            transform: `scale(${title ? '1.02' : '1'})`,
            boxShadow: title ? '0 4px 12px rgba(255, 179, 71, 0.2)' : 'none',
          }}
        >
          <span className="flex items-center gap-2">
            <span>✅</span>
            <span>Create Goal</span>
          </span>
        </RhythmButton>
        
        <RhythmButton 
          onClick={() => navigate('/goals')} 
          variant="muted"
        >
          <span className="flex items-center gap-2">
            <span>←</span>
            <span>Cancel</span>
          </span>
        </RhythmButton>
      </div>

      <div className="pt-4">
        <FooterNavigation />
      </div>
    </div>
  );
};

// Helper function to convert hex to RGB for rgba usage
function getRGBFromHex(hex: string): string {
  // Remove the # if present
  hex = hex.replace(/^#/, '');
  
  // Parse r, g, b values
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);
  
  return `${r}, ${g}, ${b}`;
}

export default GoalInputPage;








