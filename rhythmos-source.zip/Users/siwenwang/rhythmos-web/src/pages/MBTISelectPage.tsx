import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// 波浪背景组件 - 动态版
const WaveBackground = () => (
  <div className="absolute top-0 left-0 w-full overflow-hidden z-0 opacity-30">
    <div className="wave wave1"></div>
    <div className="wave wave2"></div>
  </div>
);

// 动态DNA装饰组件
const DNAHelix = () => (
  <div className="absolute right-10 top-32 opacity-20 z-0 hidden lg:block">
    <div className="dna-helix"></div>
  </div>
);

// 装饰形状组件
const DecorativeShapes = () => (
  <>
    <div className="absolute top-40 left-10 w-24 h-24 rounded-full bg-blue-100 opacity-20 z-0 blur-xl animate-pulse-slow"></div>
    <div className="absolute top-60 right-10 w-32 h-32 rounded-full bg-indigo-100 opacity-30 z-0 blur-xl animate-pulse-slow" style={{animationDelay: '2s'}}></div>
    <div className="absolute bottom-40 left-1/4 w-40 h-40 rounded-full bg-purple-100 opacity-20 z-0 blur-xl animate-pulse-slow" style={{animationDelay: '1s'}}></div>
    <div className="absolute top-1/3 right-1/4 w-16 h-16 rounded-full bg-blue-100 opacity-30 z-0 blur-md animate-pulse-slow" style={{animationDelay: '3s'}}></div>
  </>
);

// MBTI类型的更丰富数据
const mbtiOptions = [
  { 
    id: 'INTJ', 
    label: '🧠 INTJ', 
    description: 'Strategic, focused, independent thinker',
    color: 'indigo',
    gradient: 'from-indigo-50 to-purple-50',
    hoverGradient: 'from-indigo-100 to-purple-100',
    borderColor: 'border-indigo-200',
    traits: ['Analytical', 'Strategic', 'Independent'],
    category: 'analysts'
  },
  { 
    id: 'INTP', 
    label: '🧪 INTP', 
    description: 'Innovative, logical, concept-driven',
    color: 'blue',
    gradient: 'from-blue-50 to-indigo-50',
    hoverGradient: 'from-blue-100 to-indigo-100',
    borderColor: 'border-blue-200',
    traits: ['Logical', 'Creative', 'Curious'],
    category: 'analysts'
  },
  { 
    id: 'ENTJ', 
    label: '📊 ENTJ', 
    description: 'Bold, assertive, natural leader',
    color: 'purple',
    gradient: 'from-purple-50 to-indigo-50',
    hoverGradient: 'from-purple-100 to-indigo-100',
    borderColor: 'border-purple-200',
    traits: ['Decisive', 'Efficient', 'Structured'],
    category: 'analysts'
  },
  { 
    id: 'ENTP', 
    label: '🌀 ENTP', 
    description: 'Energetic, quick-witted, curious',
    color: 'cyan',
    gradient: 'from-cyan-50 to-blue-50',
    hoverGradient: 'from-cyan-100 to-blue-100',
    borderColor: 'border-cyan-200',
    traits: ['Innovative', 'Adaptable', 'Debater'],
    category: 'analysts'
  },
  { 
    id: 'INFJ', 
    label: '🪶 INFJ', 
    description: 'Insightful, idealistic, visionary',
    color: 'violet',
    gradient: 'from-violet-50 to-purple-50',
    hoverGradient: 'from-violet-100 to-purple-100',
    borderColor: 'border-violet-200',
    traits: ['Insightful', 'Visionary', 'Dedicated'],
    category: 'diplomats'
  },
  { 
    id: 'INFP', 
    label: '💖 INFP', 
    description: 'Empathetic, poetic, deeply loyal',
    color: 'rose',
    gradient: 'from-rose-50 to-pink-50',
    hoverGradient: 'from-rose-100 to-pink-100',
    borderColor: 'border-rose-200',
    traits: ['Idealistic', 'Compassionate', 'Creative'],
    category: 'diplomats'
  },
  { 
    id: 'ENFJ', 
    label: '🌟 ENFJ', 
    description: 'Inspiring, empathetic, natural teacher',
    color: 'fuchsia',
    gradient: 'from-fuchsia-50 to-pink-50',
    hoverGradient: 'from-fuchsia-100 to-pink-100',
    borderColor: 'border-fuchsia-200',
    traits: ['Charismatic', 'Empathetic', 'Supportive'],
    category: 'diplomats'
  },
  { 
    id: 'ENFP', 
    label: '🌈 ENFP', 
    description: 'Creative, expressive, enthusiastic explorer',
    color: 'pink',
    gradient: 'from-pink-50 to-rose-50',
    hoverGradient: 'from-pink-100 to-rose-100',
    borderColor: 'border-pink-200',
    traits: ['Enthusiastic', 'Creative', 'Inspirational'],
    category: 'diplomats'
  },
  { 
    id: 'ISTJ', 
    label: '📚 ISTJ', 
    description: 'Responsible, detail-focused, organized',
    color: 'slate',
    gradient: 'from-slate-50 to-gray-50',
    hoverGradient: 'from-slate-100 to-gray-100',
    borderColor: 'border-slate-200',
    traits: ['Responsible', 'Organized', 'Methodical'],
    category: 'sentinels'
  },
  { 
    id: 'ISFJ', 
    label: '🧺 ISFJ', 
    description: 'Caring, loyal, practical helper',
    color: 'emerald',
    gradient: 'from-emerald-50 to-green-50',
    hoverGradient: 'from-emerald-100 to-green-100',
    borderColor: 'border-emerald-200',
    traits: ['Protective', 'Loyal', 'Traditional'],
    category: 'sentinels'
  },
  { 
    id: 'ESTJ', 
    label: '📋 ESTJ', 
    description: 'Efficient, structured, take-charge',
    color: 'gray',
    gradient: 'from-gray-50 to-slate-50',
    hoverGradient: 'from-gray-100 to-slate-100',
    borderColor: 'border-gray-200',
    traits: ['Practical', 'Systematic', 'Organized'],
    category: 'sentinels'
  },
  { 
    id: 'ESFJ', 
    label: '🎉 ESFJ', 
    description: 'Sociable, nurturing, harmonious',
    color: 'green',
    gradient: 'from-green-50 to-emerald-50',
    hoverGradient: 'from-green-100 to-emerald-100',
    borderColor: 'border-green-200',
    traits: ['Supportive', 'Reliable', 'Cooperative'],
    category: 'sentinels'
  },
  { 
    id: 'ISTP', 
    label: '🛠️ ISTP', 
    description: 'Practical, analytical, self-reliant',
    color: 'sky',
    gradient: 'from-sky-50 to-blue-50',
    hoverGradient: 'from-sky-100 to-blue-100',
    borderColor: 'border-sky-200',
    traits: ['Adaptable', 'Technical', 'Practical'],
    category: 'explorers'
  },
  { 
    id: 'ISFP', 
    label: '🎨 ISFP', 
    description: 'Artistic, adaptable, gentle',
    color: 'amber',
    gradient: 'from-amber-50 to-yellow-50',
    hoverGradient: 'from-amber-100 to-yellow-100',
    borderColor: 'border-amber-200',
    traits: ['Artistic', 'Sensitive', 'Spontaneous'],
    category: 'explorers'
  },
  { 
    id: 'ESTP', 
    label: '🚀 ESTP', 
    description: 'Energetic, action-oriented, bold',
    color: 'blue',
    gradient: 'from-blue-50 to-sky-50',
    hoverGradient: 'from-blue-100 to-sky-100',
    borderColor: 'border-blue-200',
    traits: ['Energetic', 'Pragmatic', 'Spontaneous'],
    category: 'explorers'
  },
  { 
    id: 'ESFP', 
    label: '🎭 ESFP', 
    description: 'Playful, expressive, spontaneous',
    color: 'yellow',
    gradient: 'from-yellow-50 to-amber-50',
    hoverGradient: 'from-yellow-100 to-amber-100',
    borderColor: 'border-yellow-200',
    traits: ['Enthusiastic', 'Social', 'Flexible'],
    category: 'explorers'
  }
];

// 将MBTI选项按类别分组
const groupedOptions = {
  analysts: mbtiOptions.filter(opt => opt.category === 'analysts'),
  diplomats: mbtiOptions.filter(opt => opt.category === 'diplomats'),
  sentinels: mbtiOptions.filter(opt => opt.category === 'sentinels'),
  explorers: mbtiOptions.filter(opt => opt.category === 'explorers')
};

const MBTISelectPage: React.FC = () => {
  const navigate = useNavigate();
  const [loaded, setLoaded] = useState(false);
  const [hoveredType, setHoveredType] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [view, setView] = useState<'grid' | 'grouped'>('grid');

  // 在组件挂载后触发加载动画
  useEffect(() => {
    setTimeout(() => {
      setLoaded(true);
    }, 100);
  }, []);

  const handleSelect = (type: string) => {
    setSelectedType(type);
    setShowDetails(true);
    
    localStorage.setItem('mbtiType', type);
    
    // 添加短暂延迟，让用户体验选中状态的视觉反馈
    setTimeout(() => {
      navigate('/identity/start');
    }, 1200);
  };

  // 跳过选择
  const handleSkip = () => {
    navigate('/identity/start');
  };

  // 自定义CSS样式，包含动画和过渡效果
  const customStyles = `
    .wave {
      position: absolute;
      width: 100%;
      height: 100px;
      background-size: 1600px 100px;
    }
    
    .wave1 {
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%23dbeafe' fill-opacity='0.6' d='M0,192L48,176C96,160,192,128,288,122.7C384,117,480,139,576,144C672,149,768,139,864,149.3C960,160,1056,192,1152,197.3C1248,203,1344,181,1392,170.7L1440,160L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z'%3E%3C/path%3E%3C/svg%3E");
      animation: wave 30s linear infinite;
    }
    
    .wave2 {
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%23c7d2fe' fill-opacity='0.3' d='M0,256L48,261.3C96,267,192,277,288,266.7C384,256,480,224,576,213.3C672,203,768,213,864,224C960,235,1056,245,1152,240C1248,235,1344,213,1392,202.7L1440,192L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z'%3E%3C/path%3E%3C/svg%3E");
      animation: wave 20s linear reverse infinite;
      top: 30px;
    }
    
    @keyframes wave {
      0% {
        background-position-x: 0;
      }
      100% {
        background-position-x: 1600px;
      }
    }
    
    .dna-helix {
      width: 100px;
      height: 160px;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 160'%3E%3Cpath d='M50,0 C70,40 30,120 50,160 M50,0 C30,40 70,120 50,160' stroke='%236366f1' stroke-width='2' fill='none' stroke-linecap='round'/%3E%3C/svg%3E");
      animation: dna-spin 15s linear infinite;
    }
    
    @keyframes dna-spin {
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(360deg);
      }
    }
    
    .animate-pulse-slow {
      animation: pulse 6s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
    
    @keyframes pulse {
      0%, 100% {
        opacity: 0.2;
      }
      50% {
        opacity: 0.5;
      }
    }
    
    .mbti-card {
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .mbti-card:hover {
      transform: translateY(-5px);
    }
    
    .mbti-card.selected {
      transform: scale(1.05);
    }
    
    .type-traits {
      transition: all 0.3s ease-out;
    }
    
    .details-panel {
      transform: translateY(20px);
      opacity: 0;
      transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .details-panel.visible {
      transform: translateY(0);
      opacity: 1;
    }
    
    .progress-dot {
      transition: all 0.4s ease-out;
    }
    
    .progress-dot.active {
      transform: scale(1.2);
    }
    
    .category-header {
      position: relative;
      overflow: hidden;
    }
    
    .category-header::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 1px;
      background: linear-gradient(to right, transparent, currentColor, transparent);
      opacity: 0.3;
    }
    
    .view-toggle-button {
      transition: all 0.3s ease;
    }
    
    .view-toggle-button.active {
      background-color: rgba(99, 102, 241, 0.1);
      color: #4f46e5;
    }
  `;

  return (
    <div className="relative min-h-screen bg-gradient-to-b from-white to-gray-50 pt-12 pb-20 overflow-hidden">
      {/* 注入自定义动画样式 */}
      <style>{customStyles}</style>
      
      {/* 背景元素 */}
      <WaveBackground />
      <DecorativeShapes />
      <DNAHelix />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-12 space-y-8">
        {/* 标题区域 */}
        <div 
          className={`text-center mb-8 transition-all duration-1000 ease-out ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform -translate-y-10'}`}
        >
          <div className="inline-block p-3 mb-6 bg-indigo-50 bg-opacity-80 backdrop-blur-sm rounded-full shadow-md">
            <div className="w-20 h-20 flex items-center justify-center bg-gradient-to-br from-indigo-500 to-purple-400 rounded-full shadow-lg">
              <span className="text-4xl transform transition-transform duration-700 ease-out hover:rotate-12">🧬</span>
            </div>
          </div>
          <h1 className="text-4xl font-serif font-bold text-gray-900 tracking-tight mb-3">
            Choose Your MBTI Type
          </h1>
          <p className="text-lg text-indigo-600 font-medium max-w-2xl mx-auto mt-3">
            <span className="bg-indigo-50 px-5 py-2 rounded-full shadow-sm backdrop-blur-sm">
              Select the personality type that resonates with you
            </span>
          </p>
        </div>

        {/* 说明文本 */}
        <div 
          className={`bg-white bg-opacity-80 backdrop-blur-sm rounded-xl p-6 shadow-md border border-gray-100 max-w-3xl mx-auto transition-all duration-1000 ease-out delay-300 ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
        >
          <p className="text-gray-700 text-center leading-relaxed">
            Your personality type helps guide your rhythm path by adapting RhythmOS to your natural tendencies, 
            preferences, and growth areas. Choose the description that best matches how you see yourself.
          </p>
        </div>
        
        {/* 视图切换 */}
        <div className={`flex justify-center space-x-4 transition-all duration-1000 ease-out delay-400 ${loaded ? 'opacity-100' : 'opacity-0'}`}>
          <button 
            className={`px-4 py-2 rounded-lg text-sm font-medium view-toggle-button ${view === 'grid' ? 'active' : ''}`}
            onClick={() => setView('grid')}
          >
            <span className="flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
              </svg>
              Grid View
            </span>
          </button>
          <button 
            className={`px-4 py-2 rounded-lg text-sm font-medium view-toggle-button ${view === 'grouped' ? 'active' : ''}`}
            onClick={() => setView('grouped')}
          >
            <span className="flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
              Grouped View
            </span>
          </button>
        </div>

        {/* MBTI 类型选择区域 - 网格视图 */}
        {view === 'grid' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
            {mbtiOptions.map((type, i) => (
              <button
                key={type.id}
                onClick={() => handleSelect(type.id)}
                onMouseEnter={() => setHoveredType(type.id)}
                onMouseLeave={() => setHoveredType(null)}
                className={`relative mbti-card text-left bg-white backdrop-blur-sm bg-opacity-90 border ${type.borderColor} rounded-xl p-5 shadow-sm hover:shadow-md ${selectedType === type.id ? 'selected ring-2 ring-offset-1 ring-indigo-300 shadow-md' : ''} ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}
                style={{ 
                  transitionDelay: `${400 + (i % 8) * 50}ms`,
                }}
              >
                {/* 背景渐变 */}
                <div className={`absolute inset-0 bg-gradient-to-r ${type.gradient} rounded-xl opacity-40 transition-opacity duration-300 ${hoveredType === type.id || selectedType === type.id ? 'opacity-70' : ''}`}></div>
                
                <div className="relative z-10">
                  <div className="text-2xl mb-2">{type.label.split(' ')[0]}</div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-1">{type.id}</h3>
                  <p className="text-gray-600 text-sm mb-3">{type.description}</p>
                  
                  {/* 特质标签 */}
                  <div className={`flex flex-wrap gap-2 type-traits ${hoveredType === type.id || selectedType === type.id ? 'opacity-100' : 'opacity-70'}`}>
                    {type.traits.map((trait, j) => (
                      <span 
                        key={j} 
                        className={`inline-block px-2 py-1 rounded-full text-xs text-${type.color}-600 bg-${type.color}-50`}
                      >
                        {trait}
                      </span>
                    ))}
                  </div>
                  
                  {/* 开始按钮 */}
                  <div className={`mt-4 text-center transform transition-all duration-300 ${hoveredType === type.id ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}>
                    <span className="inline-flex items-center justify-center px-4 py-2 rounded-full bg-indigo-600 text-white text-sm font-medium shadow-sm">
                      <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      Start with {type.id}
                    </span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}

        {/* MBTI 类型选择区域 - 分组视图 */}
        {view === 'grouped' && (
          <div className="space-y-8 mt-6">
            {/* 分析家 */}
            <div className={`transition-all duration-1000 ease-out ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`} style={{transitionDelay: '400ms'}}>
              <h2 className="category-header text-xl font-semibold text-indigo-700 mb-4 pb-2">
                Analysts (NT) - Strategic Thinkers
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {groupedOptions.analysts.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => handleSelect(type.id)}
                    onMouseEnter={() => setHoveredType(type.id)}
                    onMouseLeave={() => setHoveredType(null)}
                    className={`relative mbti-card text-left bg-white backdrop-blur-sm bg-opacity-90 border ${type.borderColor} rounded-xl p-5 shadow-sm hover:shadow-md ${selectedType === type.id ? 'selected ring-2 ring-offset-1 ring-indigo-300 shadow-md' : ''}`}
                  >
                    <div className={`absolute inset-0 bg-gradient-to-r ${type.gradient} rounded-xl opacity-40 transition-opacity duration-300 ${hoveredType === type.id || selectedType === type.id ? 'opacity-70' : ''}`}></div>
                    
                    <div className="relative z-10">
                      <div className="text-2xl mb-2">{type.label.split(' ')[0]}</div>
                      <h3 className="text-xl font-semibold text-gray-800 mb-1">{type.id}</h3>
                      <p className="text-gray-600 text-sm mb-3">{type.description}</p>
                      
                      <div className={`flex flex-wrap gap-2 type-traits ${hoveredType === type.id || selectedType === type.id ? 'opacity-100' : 'opacity-70'}`}>
                        {type.traits.map((trait, j) => (
                          <span 
                            key={j} 
                            className={`inline-block px-2 py-1 rounded-full text-xs text-${type.color}-600 bg-${type.color}-50`}
                          >
                            {trait}
                          </span>
                        ))}
                      </div>
                      
                      <div className={`mt-4 text-center transform transition-all duration-300 ${hoveredType === type.id ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}>
                        <span className="inline-flex items-center justify-center px-4 py-2 rounded-full bg-indigo-600 text-white text-sm font-medium shadow-sm">
                          <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          Start with {type.id}
                        </span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* 外交家 */}
            <div className={`transition-all duration-1000 ease-out ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`} style={{transitionDelay: '600ms'}}>
              <h2 className="category-header text-xl font-semibold text-rose-700 mb-4 pb-2">
                Diplomats (NF) - Empathetic Idealists
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {groupedOptions.diplomats.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => handleSelect(type.id)}
                    onMouseEnter={() => setHoveredType(type.id)}
                    onMouseLeave={() => setHoveredType(null)}
                    className={`relative mbti-card text-left bg-white backdrop-blur-sm bg-opacity-90 border ${type.borderColor} rounded-xl p-5 shadow-sm hover:shadow-md ${selectedType === type.id ? 'selected ring-2 ring-offset-1 ring-indigo-300 shadow-md' : ''}`}
                  >
                    <div className={`absolute inset-0 bg-gradient-to-r ${type.gradient} rounded-xl opacity-40 transition-opacity duration-300 ${hoveredType === type.id || selectedType === type.id ? 'opacity-70' : ''}`}></div>
                    
                    <div className="relative z-10">
                      <div className="text-2xl mb-2">{type.label.split(' ')[0]}</div>
                      <h3 className="text-xl font-semibold text-gray-800 mb-1">{type.id}</h3>
                      <p className="text-gray-600 text-sm mb-3">{type.description}</p>
                      
                      <div className={`flex flex-wrap gap-2 type-traits ${hoveredType === type.id || selectedType === type.id ? 'opacity-100' : 'opacity-70'}`}>
                        {type.traits.map((trait, j) => (
                          <span 
                            key={j} 
                            className={`inline-block px-2 py-1 rounded-full text-xs text-${type.color}-600 bg-${type.color}-50`}
                          >
                            {trait}
                          </span>
                        ))}
                      </div>
                      
                      <div className={`mt-4 text-center transform transition-all duration-300 ${hoveredType === type.id ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}>
                        <span className="inline-flex items-center justify-center px-4 py-2 rounded-full bg-indigo-600 text-white text-sm font-medium shadow-sm">
                          <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          Start with {type.id}
                        </span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* 守卫者 */}
            <div className={`transition-all duration-1000 ease-out ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`} style={{transitionDelay: '800ms'}}>
              <h2 className="category-header text-xl font-semibold text-emerald-700 mb-4 pb-2">
                Sentinels (SJ) - Practical Organizers
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {groupedOptions.sentinels.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => handleSelect(type.id)}
                    onMouseEnter={() => setHoveredType(type.id)}
                    onMouseLeave={() => setHoveredType(null)}
                    className={`relative mbti-card text-left bg-white backdrop-blur-sm bg-opacity-90 border ${type.borderColor} rounded-xl p-5 shadow-sm hover:shadow-md ${selectedType === type.id ? 'selected ring-2 ring-offset-1 ring-indigo-300 shadow-md' : ''}`}
                  >
                    <div className={`absolute inset-0 bg-gradient-to-r ${type.gradient} rounded-xl opacity-40 transition-opacity duration-300 ${hoveredType === type.id || selectedType === type.id ? 'opacity-70' : ''}`}></div>
                    
                    <div className="relative z-10">
                      <div className="text-2xl mb-2">{type.label.split(' ')[0]}</div>
                      <h3 className="text-xl font-semibold text-gray-800 mb-1">{type.id}</h3>
                      <p className="text-gray-600 text-sm mb-3">{type.description}</p>
                      
                      <div className={`flex flex-wrap gap-2 type-traits ${hoveredType === type.id || selectedType === type.id ? 'opacity-100' : 'opacity-70'}`}>
                        {type.traits.map((trait, j) => (
                          <span 
                            key={j} 
                            className={`inline-block px-2 py-1 rounded-full text-xs text-${type.color}-600 bg-${type.color}-50`}
                          >
                            {trait}
                          </span>
                        ))}
                      </div>
                      
                      <div className={`mt-4 text-center transform transition-all duration-300 ${hoveredType === type.id ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}>
                        <span className="inline-flex items-center justify-center px-4 py-2 rounded-full bg-indigo-600 text-white text-sm font-medium shadow-sm">
                          <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          Start with {type.id}
                        </span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* 探险家 */}
            <div className={`transition-all duration-1000 ease-out ${loaded ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`} style={{transitionDelay: '1000ms'}}>
              <h2 className="category-header text-xl font-semibold text-amber-700 mb-4 pb-2">
                Explorers (SP) - Adaptable Adventurers
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {groupedOptions.explorers.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => handleSelect(type.id)}
                    onMouseEnter={() => setHoveredType(type.id)}
                    onMouseLeave={() => setHoveredType(null)}
                    className={`relative mbti-card text-left bg-white backdrop-blur-sm bg-opacity-90 border ${type.borderColor} rounded-xl p-5 shadow-sm hover:shadow-md ${selectedType === type.id ? 'selected ring-2 ring-offset-1 ring-indigo-300 shadow-md' : ''}`}
                  >
                    <div className={`absolute inset-0 bg-gradient-to-r ${type.gradient} rounded-xl opacity-40 transition-opacity duration-300 ${hoveredType === type.id || selectedType === type.id ? 'opacity-70' : ''}`}></div>
                    
                    <div className="relative z-10">
                      <div className="text-2xl mb-2">{type.label.split(' ')[0]}</div>
                      <h3 className="text-xl font-semibold text-gray-800 mb-1">{type.id}</h3>
                      <p className="text-gray-600 text-sm mb-3">{type.description}</p>
                      
                      <div className={`flex flex-wrap gap-2 type-traits ${hoveredType === type.id || selectedType === type.id ? 'opacity-100' : 'opacity-70'}`}>
                        {type.traits.map((trait, j) => (
                          <span 
                            key={j} 
                            className={`inline-block px-2 py-1 rounded-full text-xs text-${type.color}-600 bg-${type.color}-50`}
                          >
                            {trait}
                          </span>
                        ))}
                      </div>
                      
                      <div className={`mt-4 text-center transform transition-all duration-300 ${hoveredType === type.id ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}>
                        <span className="inline-flex items-center justify-center px-4 py-2 rounded-full bg-indigo-600 text-white text-sm font-medium shadow-sm">
                          <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          Start with {type.id}
                        </span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
        
        {/* 选中状态详细信息 */}
        <div 
          className={`details-panel bg-white bg-opacity-80 backdrop-blur-sm rounded-xl p-6 shadow-md border border-indigo-200 max-w-2xl mx-auto ${showDetails ? 'visible' : ''}`}
        >
          {selectedType !== null && (
            <div className="text-center">
              <div className="mb-4">
                {(() => {
                  const selectedOption = mbtiOptions.find(o => o.id === selectedType);
                  if (!selectedOption) return null;
                  
                  return (
                    <div className="flex items-center justify-center">
                      <span className="text-4xl">{selectedOption.label.split(' ')[0]}</span>
                    </div>
                  );
                })()}
              </div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">
                You've selected {selectedType} as your personality type
              </h3>
              <p className="text-gray-600 text-sm">
                {mbtiOptions.find(o => o.id === selectedType)?.description}
                <br/>Taking you to the next step...
              </p>
            </div>
          )}
        </div>

        {/* 进度指示器 */}
        <div 
          className={`pt-6 flex justify-center space-x-3 transition-opacity duration-1000 delay-1000 ${loaded ? 'opacity-100' : 'opacity-0'}`}
        >
          {Array.from({ length: 3 }, (_, i) => (
            <div 
              key={i} 
              className={`progress-dot w-3 h-3 rounded-full ${i === 2 ? 'active bg-indigo-500' : i < 2 ? 'bg-green-500' : 'bg-gray-200'}`}
            ></div>
          ))}
        </div>
        
        {/* 跳过选项 */}
        <div className={`text-center pt-6 transition-opacity duration-1000 ease-out delay-1200 ${loaded ? 'opacity-100' : 'opacity-0'}`}>
          <button 
            onClick={handleSkip}
            className="inline-block px-6 py-2 text-sm text-gray-500 hover:text-gray-700 transition-colors duration-300"
          >
            <span className="flex items-center gap-1">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              Skip MBTI Selection
            </span>
          </button>
          
          {/* 返回按钮 */}
          <button 
            onClick={() => navigate(-1)}
            className="block mx-auto mt-2 text-sm text-gray-400 hover:text-gray-600 transition-colors duration-300 flex items-center justify-center gap-1"
          >
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
            </svg>
            <span>Back to Previous Step</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default MBTISelectPage;
