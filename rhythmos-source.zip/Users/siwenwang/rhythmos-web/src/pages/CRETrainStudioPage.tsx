// /pages/CRETrainStudioPage.tsx

import React from 'react';
import CREMetaBlock from '../components/CREMetaBlock';
import RhythmStudioPanel from '../components/ui/RhythmStudioPanel';
import SignatureCueReplayList from '../components/SignatureCueReplayList';
import CREVariantTrainer from '../components/CREVariantTrainer';
import CREThemeTrainerView from '../components/CREThemeTrainerView';
import CREClusterMapView from '../components/CREClusterMapView';
import CRETemplateEditor from '../components/CRETemplateEditor';
import CRETemplateImporter from '../components/CRETemplateImporter';

const CRETrainStudioPage: React.FC = () => {
  return (
    <div className="min-h-screen px-6 py-10 max-w-5xl mx-auto space-y-12">
      <h1 className="text-2xl font-bold text-gray-800 mb-4">🧠 CRE Studio</h1>

      {/* Current CRE Cue Block */}
      <RhythmStudioPanel title="Current Identity Cue" subtitle="This is your most recently generated cue block." tone="default">
        <CREMetaBlock
          cue={localStorage.getItem('cre_cue') || 'Let us begin'}
          paragraph={localStorage.getItem('cre_paragraph') || 'This is a space to generate momentum.'}
          tone={localStorage.getItem('cre_tone') || 'gentle'}
          persona={localStorage.getItem('cre_persona') || 'rhea'}
          rhythm={localStorage.getItem('lastTrend') || 'wavy'}
        />
      </RhythmStudioPanel>

      {/* GPT Cue Replay Log */}
      <RhythmStudioPanel title="Signature Cue Replay" subtitle="Review your GPT-generated CRE history." tone="gray">
        <SignatureCueReplayList />
      </RhythmStudioPanel>

      {/* Tone Variant Trainer */}
      <RhythmStudioPanel title="Cue Variant Feedback Trainer" subtitle="Train your tone preferences by rating examples." tone="yellow">
        <CREVariantTrainer />
        <CREThemeTrainerView />
      </RhythmStudioPanel>

      {/* Cue Distribution Map */}
      <RhythmStudioPanel title="Cue Library Coverage" subtitle="Visualize your cue distribution across tone and stage." tone="purple">
        <CREClusterMapView />
      </RhythmStudioPanel>

      {/* Template Tools */}
      <RhythmStudioPanel title="Template Editor & Importer" subtitle="Manage and expand your CRE block templates." tone="blue">
        <CRETemplateEditor />
        <div className="mt-4">
          <CRETemplateImporter />
        </div>
      </RhythmStudioPanel>
    </div>
  );
};

export default CRETrainStudioPage;
