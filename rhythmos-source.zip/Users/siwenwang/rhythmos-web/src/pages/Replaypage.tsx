import React, { useState, useEffect } from 'react';
import { getSignatureCueReplayLog } from '../utils/SignatureCueReplayLog';

const ReplayPage: React.FC = () => {
  const [log, setLog] = useState<any[]>([]);

  useEffect(() => {
    const entries = getSignatureCueReplayLog();
    setLog(entries);
  }, []);

  return (
    <div className="max-w-3xl mx-auto px-6 py-10 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-800">🧠 Signature Replay</h1>
        <p className="text-sm text-gray-500 mt-2">
          These are the cues and responses that shaped your personalized growth path.
        </p>
      </div>

      <div className="space-y-6">
        {log.length === 0 ? (
          <div className="text-sm italic text-gray-400 text-center mt-20">
            No signature interactions recorded yet.
          </div>
        ) : (
          log.map((entry, i) => (
            <div key={i} className="p-4 rounded-xl border border-gray-200 bg-white shadow-sm">
              <p className="text-sm text-gray-500 mb-1">
                {new Date(entry.timestamp).toLocaleString()}
              </p>
              <p className="text-base text-gray-800 whitespace-pre-line">
                <span className="font-semibold">Cue:</span> {entry.cue}
              </p>
              <p className="text-base text-gray-700 whitespace-pre-line mt-3">
                <span className="font-semibold">Response:</span> {entry.response}
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ReplayPage;
