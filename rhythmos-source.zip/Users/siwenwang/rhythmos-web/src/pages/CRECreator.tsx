import React, { useState } from 'react';
import { getRecentRhythmLogs, getRhythmTrend } from '../rhythmLog';
import { getDefaultPersonaFromTrend } from '../utils/getDefaultPersonaFromTrend';
import { exportCRECorpus } from '../utils/exportCRECorpus';

const tones = ['gentle', 'directive', 'motivated', 'visionary'];
const variants = ['base', 'metaphorical', 'concise', 'expansive'];

export default function CRECreator() {
  const [selectedTone, setSelectedTone] = useState('gentle');
  const [creInputs, setCreInputs] = useState<Record<string, string>>({
    base: '',
    metaphorical: '',
    concise: '',
    expansive: ''
  });

  const [creCorpus, setCreCorpus] = useState<any[]>([]);

  // ✅ 所有 hooks 移入函数组件体内
  const recent = getRecentRhythmLogs(5);
  const detectedTrend = getRhythmTrend(recent);
  const userOverride = localStorage.getItem('crePersonaOverride');
  const initialPersona = userOverride || getDefaultPersonaFromTrend(detectedTrend);
  const [selectedPersona, setSelectedPersona] = useState(initialPersona);

  const handleInputChange = (variant: string, value: string) => {
    setCreInputs((prev) => ({
      ...prev,
      [variant]: value
    }));
  };

  const handleSave = () => {
    const creBlock = {
      tone: selectedTone,
      personaHint: selectedPersona,
      variants: { ...creInputs },
      dateCreated: new Date().toISOString()
    };

    setCreCorpus((prev) => [...prev, creBlock]);
    console.log('✅ Saved CRE block:', creBlock);
    alert('CRE saved with persona hint!');
  };

  return (
    <div className="max-w-3xl mx-auto mt-10 p-4 border rounded-lg shadow-sm bg-white">
      <h2 className="text-xl font-bold mb-4">🧠 Create a New CRE Expression</h2>

      {/* Tone Selector */}
      <label className="block text-sm font-medium mb-1">Tone</label>
      <select
        value={selectedTone}
        onChange={(e) => setSelectedTone(e.target.value)}
        className="mb-4 w-full border p-2 rounded"
      >
        {tones.map((tone) => (
          <option key={tone} value={tone}>
            {tone}
          </option>
        ))}
      </select>

      {/* Persona Selector */}
      <label className="block text-sm font-medium mb-1">Persona (style guide)</label>
      <select
        value={selectedPersona}
        onChange={(e) => {
          const chosen = e.target.value;
          setSelectedPersona(chosen);
          localStorage.setItem('crePersonaOverride', chosen);
        }}
        className="mb-4 w-full border p-2 rounded"
      >
        <option value="aurelia">🌸 Aurelia – emotional / symbolic / gentle</option>
        <option value="rhea">🌷 Rhea – warm / validating / conversational</option>
        <option value="niveus">❄️ Niveus – calm / precise / rational</option>
        <option value="lucis">🔥 Lucis – sharp / directive / motivating</option>
        <option value="caelum">🌌 Caelum – visionary / dignified / future-oriented</option>
      </select>

      {/* Variant Inputs */}
      {variants.map((variant) => (
        <div key={variant} className="mb-3">
          <label className="block text-sm font-semibold mb-1 capitalize">{variant}</label>
          <input
            type="text"
            value={creInputs[variant]}
            onChange={(e) => handleInputChange(variant, e.target.value)}
            className="w-full border px-3 py-2 rounded"
            placeholder={`Write the ${variant} variant...`}
          />
        </div>
      ))}

      {/* Save Button */}
      <button
        onClick={handleSave}
        className="mt-4 px-4 py-2 bg-black text-white rounded hover:bg-gray-800"
      >
        Save CRE
      </button>

      {/* Export Button */}
      <button
        onClick={() => exportCRECorpus(creCorpus)}
        className="mt-2 px-4 py-2 bg-gray-200 text-black rounded hover:bg-gray-300"
      >
        Export All CRE (JSON)
      </button>

      {/* Preview */}
      <div className="mt-8 border-t pt-4">
        <h3 className="text-lg font-semibold mb-2">🔍 Preview</h3>
        {variants.map((variant) => (
          <p key={variant} className="mb-2 text-sm">
            <strong>{variant}:</strong> {creInputs[variant] || '—'}
          </p>
        ))}
        <p className="mt-2 text-sm text-gray-600">
          <strong>Persona:</strong> {selectedPersona}
        </p>
        <p className="text-sm text-gray-600">
          <strong>Detected trend:</strong> {detectedTrend}
        </p>
      </div>
    </div>
  );
}


