export type GoalIntent =
  | 'write'
  | 'plan'
  | 'reflect'
  | 'clarify'
  | 'research'
  | 'review'
  | 'organize'
  | 'explore'
  | 'learn'
  | 'reading'  // 添加专门的 reading 意图类型
  | 'unknown'

export function classifyGoalIntent(goal: string): GoalIntent {
  const lower = goal.toLowerCase();
  console.log('Classifying goal intent for:', lower);

  // 阅读相关意图 - 专门处理 "read books" 类型的目标
  if (
    lower.includes('read book') ||
    lower.includes('reading book') ||
    lower.includes('read books') ||
    lower.includes('reading books') ||
    (lower.includes('read') && lower.includes('book'))
  ) {
    console.log('Intent matched: reading');
    return 'reading';
  }

  // 写作相关意图
  if (
    lower.includes('write') ||
    lower.includes('essay') ||
    lower.includes('article') ||
    lower.includes('post') ||
    lower.includes('journal')
  ) {
    console.log('Intent matched: write');
    return 'write';
  }

  // 计划相关意图
  if (
    lower.includes('plan') ||
    lower.includes('roadmap') ||
    lower.includes('strategy') ||
    lower.includes('timeline')
  ) {
    console.log('Intent matched: plan');
    return 'plan';
  }

  // 反思相关意图
  if (
    lower.includes('reflect') ||
    lower.includes('feel') ||
    lower.includes('emotion') ||
    lower.includes('review my day') ||
    lower.includes('introspect')
  ) {
    console.log('Intent matched: reflect');
    return 'reflect';
  }

  // 澄清相关意图
  if (
    lower.includes('clarify') ||
    lower.includes('confused') ||
    lower.includes('figure out') ||
    lower.includes('understand') ||
    lower.includes('sort out')
  ) {
    console.log('Intent matched: clarify');
    return 'clarify';
  }

  // 通用阅读相关意图 - 作为后备匹配
  if (
    lower.includes('read') ||
    lower.includes('reading') ||
    lower.includes('book') ||
    lower.includes('chapter')
  ) {
    console.log('Intent matched: review (reading fallback)');
    return 'review';
  }

  // 研究相关意图
  if (
    lower.includes('research') ||
    lower.includes('look into') ||
    lower.includes('read about') ||
    lower.includes('gather info')
  ) {
    console.log('Intent matched: research');
    return 'research';
  }

  // 复习相关意图
  if (
    lower.includes('review') ||
    lower.includes('revise') ||
    lower.includes('study') ||
    lower.includes('prepare for exam')
  ) {
    console.log('Intent matched: review');
    return 'review';
  }

  // 组织相关意图
  if (
    lower.includes('organize') ||
    lower.includes('clean up') ||
    lower.includes('restructure') ||
    lower.includes('reorganize') ||
    lower.includes('sort')
  ) {
    console.log('Intent matched: organize');
    return 'organize';
  }

  // 学习相关意图
  if (
    lower.includes('learn') ||
    lower.includes('practice') ||
    lower.includes('train') ||
    lower.includes('improve skill')
  ) {
    console.log('Intent matched: learn');
    return 'learn';
  }

  // 探索相关意图
  if (
    lower.includes('explore') ||
    lower.includes('think about') ||
    lower.includes('investigate') ||
    lower.includes('brainstorm')
  ) {
    console.log('Intent matched: explore');
    return 'explore';
  }

  console.log('No intent matched, returning: unknown');
  return 'unknown';
}