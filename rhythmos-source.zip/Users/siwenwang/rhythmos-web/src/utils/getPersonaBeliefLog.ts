export const getPersonaBeliefLog = (persona: string): { date: string, score: number }[] => {
    const raw = localStorage.getItem('growthBeliefLog');
    const log = raw ? JSON.parse(raw) : [];
  
    return log
      .filter((entry: any) => entry.persona?.toLowerCase() === persona.toLowerCase())
      .sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
      .map((entry: any) => ({
        date: new Date(entry.timestamp).toISOString().split('T')[0],
        score: entry.score
      }));
  };
  