import { getFeedbackScore, createUniqueKey } from './feedbackLogWriter';

/**
 * Creates and writes a tone log entry, handling deduplication
 */
export function writeToneLogEntry({
  cueId,
  cueText,
  tone,
  feedback,
  trend,
  persona,
  timestamp = new Date().toISOString(),
  score
}: {
  cueId: string;
  cueText: string
  tone: string;
  feedback: 'aligned' | 'okay' | 'notMe';
  trend: string;
  persona?: string;
  timestamp?: string;
  score?: number;
}) {
  // Calculate score if not provided
  const actualScore = typeof score === 'number' ? score : getFeedbackScore(feedback);
  
  // Create uniqueKey for consistent deduplication across the app
  const uniqueKey = createUniqueKey(cueId, tone, timestamp);

  // Create the entry
  const toneEntry = {
    cueId,
    cueText,
    tone,
    feedback, // Keep all feedback types, including 'notMe'
    score: actualScore,
    trendAtFeedback: trend,
    persona,
    timestamp,
    uniqueKey
  };

  try {
    // Read existing tone log
    const oldLogRaw = localStorage.getItem('toneLog');
    const oldLog = oldLogRaw ? JSON.parse(oldLogRaw) : [];
    
    // Filter out entries with the same uniqueKey
    const withoutDup = oldLog.filter((e: any) => e.uniqueKey !== uniqueKey);
    
    // Add the new entry
    const updatedLog = [...withoutDup, toneEntry];
    
    // Save to localStorage
    localStorage.setItem('toneLog', JSON.stringify(updatedLog));
    console.log('✅ toneLog written:', toneEntry);
  } catch (error) {
    console.error('❌ Failed to update toneLog:', error);
  }

  return toneEntry;
}

/**
 * Gets tone score map for visualization components
 * Includes ALL feedback types for accurate representation
 */
export function getToneScoreMapByDays(days: number): Record<string, number> {
  const raw = localStorage.getItem('toneLog');
  if (!raw) return {};

  let log: any[] = [];
  try {
    log = JSON.parse(raw);
    if (!Array.isArray(log)) return {};
  } catch {
    return {};
  }

  const now = new Date();
  const cutoff = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
  const map: Record<string, number> = {};
  const seenKeys = new Set<string>();

  for (const entry of log) {
    if (!entry?.tone || !entry?.timestamp) continue;

    const ts = new Date(entry.timestamp);
    if (ts < cutoff) continue;

    // Use the uniqueKey if available, or generate one
    const key = entry.uniqueKey || createUniqueKey(entry.cueId, entry.tone, entry.timestamp);
    
    if (seenKeys.has(key)) continue;
    seenKeys.add(key);

    // Include entries with feedback='notMe' but with a score of 0
    const score = typeof entry.score === 'number'
      ? entry.score
      : getFeedbackScore(entry.feedback);

    // Add the score to the map
    map[entry.tone] = (map[entry.tone] || 0) + score;
  }

  return map;
}