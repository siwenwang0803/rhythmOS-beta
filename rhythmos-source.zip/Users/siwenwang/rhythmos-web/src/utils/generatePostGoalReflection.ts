import { postGoalReflectionLibrary } from './reflectionLibrary';
import { classifyGoalIntent } from '../goalIntentClassifier';

export function generatePostGoalReflection(goalText: string) {
  const intent = classifyGoalIntent(goalText);
  const list = postGoalReflectionLibrary[intent] || postGoalReflectionLibrary['unknown'];
  return list[Math.floor(Math.random() * list.length)];
}
