// utils/rhythmTrend.ts

export type RhythmTrend = 'collapsed' | 'wavy' | 'stable' | 'rising';

// 节奏分数映射（你也可以用你自己的逻辑）
export function getCurrentTrend(): RhythmTrend {
  try {
    const raw = localStorage.getItem('rhythmScoreLog');
    if (!raw) return 'wavy';

    const list = JSON.parse(raw);
    if (!Array.isArray(list) || list.length === 0) return 'wavy';

    const today = new Date().toISOString().slice(0, 10);

    // 获取今天所有来源为用户行为的分数
    const todayScores = list.filter(
      (entry) => entry.date === today && typeof entry.score === 'number'
    );

    const total = todayScores.reduce((sum, e) => sum + e.score, 0);

    if (total >= 7) return 'rising';
    if (total >= 4) return 'stable';
    if (total >= 1) return 'wavy';
    return 'collapsed';
  } catch (e) {
    console.warn('[getCurrentTrend] fallback to wavy due to error:', e);
    return 'wavy';
  }
}
