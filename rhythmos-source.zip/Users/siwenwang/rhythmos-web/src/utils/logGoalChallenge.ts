// utils/logGoalChallenge.ts

import { GoalBasedChallenge } from './GoalToChallengeBridge';

export function logGoalChallenge(entry: GoalBasedChallenge) {
  const raw = localStorage.getItem('challengeLog');
  const existing = raw ? JSON.parse(raw) : [];

  const updated = [...existing, {
    ...entry,
    source: 'goal'
  }];

  localStorage.setItem('challengeLog', JSON.stringify(updated));
  console.log('📌 Goal-based challenge written to log:', entry);
}
