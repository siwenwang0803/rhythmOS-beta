// /utils/personaLogStats.ts

export function getRecentPersonaTrend(days = 3): string {
    const raw = localStorage.getItem('challengeLog');
    if (!raw) return 'rhea';
  
    const now = Date.now();
    const cutoff = now - days * 24 * 60 * 60 * 1000;
  
    let log: any[] = [];
    try {
      log = JSON.parse(raw);
    } catch {
      return 'rhea';
    }
  
    const recent = log.filter((e) => e.time >= cutoff);
    const personaMap: Record<string, number> = {};
  
    for (const entry of recent) {
      const p = entry.persona || 'rhea';
      personaMap[p] = (personaMap[p] || 0) + 1;
    }
  
    const sorted = Object.entries(personaMap).sort((a, b) => b[1] - a[1]);
    return sorted[0]?.[0] || 'rhea';
  }
  