// /utils/toneLogWriter.ts

import { getSignatureMap } from '../SignatureMap';

export function getFeedbackScore(feedback: string): number {
  switch (feedback) {
    case 'aligned': return 1;
    case 'okay': return 0.5;
    case 'notMe': return 0;
    default: return 0;
  }
}

export interface ToneFeedbackEntry {
  cueId: string;
  cueText: string;
  tone: string;
  persona: string;
  trend: string;
  feedback: 'aligned' | 'okay' | 'notMe';
  score?: number;
  timestamp?: string;
}

export function logToneFeedback(entry: ToneFeedbackEntry) {
  if (!entry || entry.cueText === 'You deserve to pause.') return;

  const signatureMap = getSignatureMap();
  const timestamp = entry.timestamp || new Date().toISOString();
  const score = entry.score !== undefined ? entry.score : getFeedbackScore(entry.feedback);
  const dateKey = timestamp.slice(0, 10); // YYYY-MM-DD

  const uniqueKey = `${entry.cueId}_${entry.tone}_${dateKey}`;

  const toneLogEntry = {
    cueId: entry.cueId,
    tone: entry.tone,
    persona: entry.persona,
    trendAtFeedback: entry.trend,
    feedback: entry.feedback,
    score,
    timestamp,
    uniqueKey,
  };

  if (!signatureMap.toneLog) signatureMap.toneLog = [];

  const existing = signatureMap.toneLog.findIndex(e => e.uniqueKey === uniqueKey);
  if (existing >= 0) {
    signatureMap.toneLog[existing] = toneLogEntry;
    console.log('🌀 Replaced toneLog entry for:', uniqueKey);
  } else {
    signatureMap.toneLog.push(toneLogEntry);
    console.log('➕ Added toneLog entry for:', uniqueKey);
  }

  try {
    localStorage.setItem('toneLog', JSON.stringify(signatureMap.toneLog));
  } catch (e) {
    console.warn('⚠️ Failed to save toneLog');
  }
}

  