// utils/personaToneMap.ts

export const personaToneMap: Record<string, string> = {
    rhea: 'gentle',
    niveus: 'directive',
    caelum: 'motivated',
    lucis: 'visionary',
    aurelia: 'rational'
  };
  
  export const tonePersonaMap: Record<string, string> = Object.fromEntries(
    Object.entries(personaToneMap).map(([persona, tone]) => [tone, persona])
  );
  
  export const getToneForPersona = (persona: string): string => {
    return personaToneMap[persona.toLowerCase()] || 'gentle';
  };
  
  export const getPersonaForTone = (tone: string): string => {
    return tonePersonaMap[tone.toLowerCase()] || 'rhea';
  };
  