// /src/utils/rateLimiter.ts
// 简单的速率限制器

class RateLimiter {
    private queue: Array<() => Promise<any>> = [];
    private processing = false;
    private lastRequestTime = 0;
    private minDelay = 1000; // 最小请求间隔（毫秒）
  
    async addRequest<T>(fn: () => Promise<T>): Promise<T> {
      return new Promise((resolve, reject) => {
        this.queue.push(async () => {
          try {
            const result = await fn();
            resolve(result);
          } catch (error) {
            reject(error);
          }
        });
        
        this.processQueue();
      });
    }
  
    private async processQueue() {
      if (this.processing || this.queue.length === 0) {
        return;
      }
  
      this.processing = true;
  
      while (this.queue.length > 0) {
        const now = Date.now();
        const timeSinceLastRequest = now - this.lastRequestTime;
        
        if (timeSinceLastRequest < this.minDelay) {
          await this.delay(this.minDelay - timeSinceLastRequest);
        }
  
        const request = this.queue.shift();
        if (request) {
          this.lastRequestTime = Date.now();
          await request();
        }
      }
  
      this.processing = false;
    }
  
    private delay(ms: number): Promise<void> {
      return new Promise(resolve => setTimeout(resolve, ms));
    }
  }
  
  // 创建全局实例
  export const openaiRateLimiter = new RateLimiter();
  
  // 包装后的 OpenAI 调用函数
  export async function rateLimitedOpenAICall<T>(
    fn: () => Promise<T>
  ): Promise<T> {
    return openaiRateLimiter.addRequest(fn);
  }