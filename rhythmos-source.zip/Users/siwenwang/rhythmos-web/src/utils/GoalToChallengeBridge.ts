// utils/GoalChallengeBridge.ts

import { classifyGoalIntent } from '../goalIntentClassifier';
import { getRecentPersonaTrend } from '../utils/personaLogStats';
import { getTopTone } from './toneLogStats';

export interface GoalBasedChallenge {
  cue: string;
  paragraph: string;
  action: string;
  persona: string;
  intent: string;
  trend?: string;
  timestamp: number;
  source: 'goal';
}

const fallbackChallengeCueMap: Record<string, Record<string, string[]>> = {
  write: {
    aurelia: [
      "Structure your next paragraph before you write.",
      "Simplify one messy section before expanding it."
    ],
    caelum: [
      "Don't revise — just write fast for 5 minutes.",
      "Move the draft forward, no matter how rough."
    ],
  },
  reflect: {
    rhea: [
      "Journal one sentence about how that goal felt.",
      "Close your eyes and relive your win, softly."
    ],
    lucis: [
      "Repeat what worked today — and notice how it felt.",
      "Anchor in the rhythm that made this goal possible."
    ]
  },
  // fallback default
  default: {
    rhea: ["Breathe in the end — and let it land."],
    aurelia: ["Capture your learnings before they fade."],
    caelum: ["Choose one more thing to finish today."],
    lucis: ["Repeat the small rhythm that worked."],
    niveus: ["Close the loop cleanly. No drag."]
  }
};

export function generatePostGoalReflection(goalText: string): GoalBasedChallenge {
  const persona = getRecentPersonaTrend();
  const trend = getTopTone();
  const intent = classifyGoalIntent(goalText);
  const timestamp = Date.now();

  const personaCues = fallbackChallengeCueMap[intent]?.[persona] 
    || fallbackChallengeCueMap.default[persona]
    || fallbackChallengeCueMap.default.rhea;

  const action = personaCues[Math.floor(Math.random() * personaCues.length)];

  return {
    cue: `[${persona}] says: Let's follow through.`,
    paragraph: "You’ve just taken real action — now seal it with momentum.",
    action,
    persona,
    trend,
    intent,
    timestamp,
    source: 'goal'
  };
}

