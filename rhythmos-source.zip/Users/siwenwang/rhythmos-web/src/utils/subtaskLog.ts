export function writeSubtaskIntentLog(taskId: string, taskType: string) {
    const raw = localStorage.getItem('subtaskIntentLog') || '[]';
    const existing = JSON.parse(raw);
  
    existing.push({
      id: taskId,
      type: taskType,
      timestamp: Date.now()
    });
  
    localStorage.setItem('subtaskIntentLog', JSON.stringify(existing));
  }
  