// utils/getFeedbackScore.ts

export function getFeedbackScore(feedback: 'aligned' | 'okay' | 'notMe'): number {
    if (feedback === 'aligned') return 1;
    if (feedback === 'okay') return 0.5;
    return 0; // notMe
  }
  