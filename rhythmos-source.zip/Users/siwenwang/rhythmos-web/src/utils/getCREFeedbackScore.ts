// utils/getCREFeedbackScore.ts

export function getCREFeedbackScore(feedback: 'aligned' | 'okay' | 'notMe'): number {
    switch (feedback) {
      case 'aligned': return 1;
      case 'okay': return 0.5;
      case 'notMe': return 0;
      default: return 0;
    }
  }
  