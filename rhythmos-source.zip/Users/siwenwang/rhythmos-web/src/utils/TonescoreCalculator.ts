import { getSignatureMap } from '../SignatureMap';

/**
 * 计算反馈得分
 */
export const getFeedbackScore = (feedback: string): number => {
  switch (feedback) {
    case 'aligned': return 1;
    case 'okay': return 0.5;
    case 'notMe': return 0;
    default: return 0;
  }
};

/**
 * 生成一个唯一的键，用于去重
 * 只使用关键的标识符，而不是完整的文本内容
 */
export const generateUniqueKey = (entry: any, dateStr: string): string => {
  // 使用 cueId 和 tone 作为唯一标识符的一部分
  // 如果 cueId 不可用，使用一个固定值
  const cueIdentifier = entry.cueId || 'unknown';
  
  // 返回格式: "cueId_tone_YYYY-MM-DD"
  return `${cueIdentifier}_${entry.tone}_${dateStr}`;
};

/**
 * 去重处理 toneLog 数据
 * 防止重复条目影响分数计算
 */
export const deduplicateToneLog = (): void => {
  const signatureMap = getSignatureMap();
  
  // 确保 toneLog 存在
  if (!signatureMap.toneLog || !Array.isArray(signatureMap.toneLog)) {
    signatureMap.toneLog = [];
    return;
  }
  
  const originalLength = signatureMap.toneLog.length;
  console.log(`Deduplicating toneLog with ${originalLength} entries...`);
  
  // 用于存储唯一条目的映射
  const uniqueEntries = new Map();
  
  // 按时间排序 (最新的优先)
  const sortedEntries = [...signatureMap.toneLog].sort((a, b) => 
    new Date(b.timestamp || '').getTime() - new Date(a.timestamp || '').getTime()
  );
  
  // 为每个条目创建唯一键并保留最新版本
  for (const entry of sortedEntries) {
    if (!entry || !entry.tone || !entry.timestamp) continue;
    
    const date = new Date(entry.timestamp);
    // 修正：使用正确的月份格式（JavaScript 中月份从 0 开始）
    const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    const uniqueKey = generateUniqueKey(entry, dateStr);
    
    if (!uniqueEntries.has(uniqueKey)) {
      uniqueEntries.set(uniqueKey, entry);
    }
  }
  
  // 更新 signatureMap
  signatureMap.toneLog = Array.from(uniqueEntries.values());
  
  // 保存到 localStorage
  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      localStorage.setItem('toneLog', JSON.stringify(signatureMap.toneLog));
    } catch (error) {
      console.error('Failed to save deduplicated toneLog to localStorage:', error);
    }
  }
  
  console.log(`Deduplication complete. Reduced from ${originalLength} to ${signatureMap.toneLog.length} entries.`);
};

/**
 * 获取过去 N 天内的 tone 评分图
 * 正确处理唯一性和分数计算
 */
export function getToneScoreMapByDays(days: number): Record<string, number> {
  const signatureMap = getSignatureMap();
  
  // 确保 toneLog 存在
  if (!signatureMap.toneLog) {
    signatureMap.toneLog = [];
    console.log('No toneLog available, initializing empty array');
    return {}; 
  }
  
  const log = signatureMap.toneLog;
  const now = new Date();
  const cutoff = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
  
  // 分数累计对象
  const scoreByTone: Record<string, number> = {};
  
  // 用于跟踪已处理条目的集合
  const processedKeys = new Set<string>();
  
  // 按时间倒序排序数据
  const sortedEntries = [...log].sort((a, b) => 
    new Date(b.timestamp || '').getTime() - new Date(a.timestamp || '').getTime()
  );
  
  console.log(`Processing ${sortedEntries.length} toneLog entries for the last ${days} days`);
  
  // 处理每个条目
  for (const entry of sortedEntries) {
    // 跳过无效数据
    if (!entry || !entry.tone || !entry.timestamp) {
      continue;
    }
    
    const { tone, feedback, timestamp } = entry;
    const entryDate = new Date(timestamp);
    
    // 跳过超出时间范围的数据
    if (entryDate < cutoff) {
      continue;
    }
    
    // 计算得分
    const score = typeof entry.score === 'number' ? 
      entry.score : getFeedbackScore(feedback);
    
    // 跳过零分数据 (notMe)
    if (score === 0) {
      continue;
    }
    
    // 修正：使用完整日期格式避免月份问题 YYYY-MM-DD
    const dateStr = `${entryDate.getFullYear()}-${String(entryDate.getMonth() + 1).padStart(2, '0')}-${String(entryDate.getDate()).padStart(2, '0')}`;
    
    // 修正：将 cueId 和 tone 都作为唯一键的一部分
    const uniqueKey = generateUniqueKey(entry, dateStr);
    
    // 防止重复计算
    if (processedKeys.has(uniqueKey)) {
      console.log(`Skipping duplicate entry:`, { 
        tone, 
        feedback, 
        uniqueKey 
      });
      continue;
    }
    
    // 标记为已处理
    processedKeys.add(uniqueKey);
    
    // 日志输出
    console.log(`Processing unique entry:`, { 
      tone, 
      feedback, 
      calculatedScore: score,
      timestamp,
      uniqueKey
    });
    
    // 累计分数 - 关键点：不同 tone 应该分别累计
    scoreByTone[tone] = (scoreByTone[tone] || 0) + score;
  }
  
  // 输出最终结果
  console.log(`Final tone score map:`, scoreByTone);
  
  return scoreByTone;
}