export function getTodayScoreBreakdown(): string {
    const raw = localStorage.getItem('rhythmScoreLog');
    if (!raw) return 'No score yet.';
  
    const log = JSON.parse(raw);
    const today = new Date().toISOString().slice(0, 10);
    const todayEntries = log.filter((e: any) => e.date === today);
  
    const summary: Record<string, number> = {
      goal: 0,
      subtask: 0,
      challenge: 0,
      microtask: 0
    };
  
    const resolveType = (entry: any): string => {
      const raw = entry.type || entry.actionType || '';
      if (raw.includes('goal')) return 'goal';
      if (raw.includes('subtask')) return 'subtask';
      if (raw.includes('challenge')) return 'challenge';
      if (raw.includes('microtask')) return 'microtask';
      return 'unknown';
    };
  
    for (const entry of todayEntries) {
      const type = resolveType(entry);
      if (summary[type] !== undefined) summary[type] += entry.value;
    }
  
    const parts = [];
    if (summary.goal > 0) parts.push(`🎯 ${summary.goal} from goals`);
    if (summary.subtask > 0) parts.push(`📋 ${summary.subtask} from subtasks`);
    if (summary.challenge > 0) parts.push(`⚡ ${summary.challenge} from challenges`);
    if (summary.microtask > 0) parts.push(`🧩 ${summary.microtask} from microtasks`);
  
    return parts.length > 0 ? parts.join(', ') : 'No activity yet today.';
  }
  
  
  