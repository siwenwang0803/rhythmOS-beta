// utils/updateCueSeenCount.ts

import { signatureMap } from '../SignatureMap';

/**
 * Increment the seen count of a cue by 1.
 * Falls back to using the cue string if no unique ID is available.
 * 
 * @param cueId - The unique ID of the cue, or the cue text as fallback.
 */
export function updateCueSeenCount(cueId: string) {
  if (!cueId) return;
  signatureMap.cueSeenCount = signatureMap.cueSeenCount || {};

  signatureMap.cueSeenCount[cueId] = 
    (signatureMap.cueSeenCount[cueId] || 0) + 1;
}
