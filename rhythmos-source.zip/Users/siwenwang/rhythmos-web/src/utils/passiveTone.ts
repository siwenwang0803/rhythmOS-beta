// src/utils/passiveTone.ts

export const passiveKeywords = [
    'feel stuck',
    'wish I could',
    'don’t know',
    'not sure',
    'can’t focus',
    'overwhelmed',
    'lost',
    'unsure',
    'avoid',
    'why bother'
  ];
  
  // 检测语句中是否包含被动词，返回评分值（默认 +0.5）
  export function detectPassiveTone(input: string): number {
    const lower = input.toLowerCase();
    const matched = passiveKeywords.find((kw) => lower.includes(kw));
    return matched ? 0.5 : 0;
  }
  
  // 写入日志结构（passiveToneLog）
  export function writePassiveToneLog(phrase: string, score: number) {
    const log = JSON.parse(localStorage.getItem('passiveToneLog') || '[]');
    log.push({
      phrase,
      score,
      time: new Date().toISOString()
    });
    localStorage.setItem('passiveToneLog', JSON.stringify(log));
  }
  