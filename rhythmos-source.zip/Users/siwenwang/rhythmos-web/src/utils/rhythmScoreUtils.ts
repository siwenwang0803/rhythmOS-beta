// /utils/rhythmScoreUtils.ts

import { getTodayDate } from './rhythmDayEngine';

/**
 * 计算今天的目标和子任务总得分
 */
export const getTodayGoalSubtaskScore = (): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) =>
      entry.date === today &&
      (entry.actionType === 'subtask_complete' || entry.actionType === 'goal_complete')
    )
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
};

/**
 * 获取今天完成的挑战数量
 */
export const getTodayChallengeCount = (): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) => 
      entry.date === today && 
      entry.actionType === 'challenge_complete'
    ).length;
};

/**
 * 获取今天挑战获得的分数
 */
export const getTodayChallengeScore = (): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) => 
      entry.date === today && 
      entry.actionType === 'challenge_complete'
    )
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
};

/**
 * 获取今天完成的微任务数量
 */
export const getTodayMicrotaskCount = (): number => {
  const today = getTodayDate();
  const tracker = JSON.parse(localStorage.getItem('xpTracker') || '{}');
  return tracker[today]?.microtaskCount || 0;
};

/**
 * 获取今天微任务获得的分数
 * (由于微任务目前只给XP不直接给节奏分，所以返回0)
 */
export const getTodayMicrotaskScore = (): number => {
  // 目前微任务不直接贡献节奏得分
  // 它们只提供XP奖励，所以这个函数返回0
  return 0;
};

/**
 * 获取特定动作类型今天的记录数量
 */
export const getTodayActionTypeCount = (actionType: string): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog.filter(
    (entry: any) => entry.date === today && entry.actionType === actionType
  ).length;
};

/**
 * 获取特定动作类型今天的得分总和
 */
export const getTodayActionTypeScore = (actionType: string): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) => entry.date === today && entry.actionType === actionType)
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
};

/**
 * 格式化得分为字符串，显示小数点后一位，如果是整数则不显示小数部分
 */
export const formatScore = (score: number): string => {
  return score % 1 === 0 ? score.toString() : score.toFixed(1);
};

/**
 * 获取根据分数的描述性文本
 */
export const getScoreDescription = (score: number): string => {
  if (score >= 9) return "You're having an exceptional day with strong momentum!";
  if (score >= 7) return "You're making great progress today.";
  if (score >= 5) return "You're maintaining a steady rhythm.";
  if (score >= 3) return "You're making steps forward today.";
  return "Today is a reset day. Every journey has moments of rest.";
};

// 常量
export const MAX_DAILY_SCORE = 10; 
export const MAX_GOAL_SUBTASK_COMBINED_SCORE = 4; 
export const MAX_CHALLENGE_COUNT = 2;
export const MAX_MICROTASK_COUNT = 3;

/**
 * 获取得分类别的最大限制
 */
export const getScoreLimits = () => {
  return {
    maxDaily: MAX_DAILY_SCORE,
    maxGoalSubtask: MAX_GOAL_SUBTASK_COMBINED_SCORE,
    maxChallengeCount: MAX_CHALLENGE_COUNT,
    maxMicrotaskCount: MAX_MICROTASK_COUNT
  };
};

/**
 * 获取建议的下一步行动
 */
export const getSuggestedNextAction = (challengeCount: number, goalSubtaskScore: number, microtaskCount: number): string => {
  if (challengeCount < MAX_CHALLENGE_COUNT) 
    return "Complete a daily challenge to boost your momentum.";
  
  if (goalSubtaskScore < MAX_GOAL_SUBTASK_COMBINED_SCORE) 
    return "Work on a goal or subtask to make progress on your priorities.";
  
  if (microtaskCount < MAX_MICROTASK_COUNT) 
    return "Quick win: complete a microtask to maintain your rhythm.";
  
  return "Amazing work! You've completed all your daily activities.";
};