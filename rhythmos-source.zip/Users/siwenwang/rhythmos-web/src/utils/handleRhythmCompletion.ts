// /utils/handleRhythmCompletion.ts - 修复版本

import { writeRhythmScore, getTodayGoalSubtaskScore } from './rhythmScoreEngine';
import { isTodayFinalized } from './rhythmDayEngine';

/**
 * 完成一个 subtask，加 0.5 分，受 Goal+Subtask 总得分上限保护（封顶 4.0）
 * 注意：subtask不给XP，只给节奏分
 */
export const handleCompleteSubtask = (subtaskId: string) => {
  if (isTodayFinalized()) {
    console.warn('⛔ Cannot complete subtask: day already finalized.');
    return;
  }

  const currentScore = getTodayGoalSubtaskScore(); // 当前 goal+subtask 总得分
  if (currentScore >= 4) {
    console.warn('⛔ Subtask+Goal total score already at maximum 4 points.');
    return;
  }

  // 检查剩余容量，最多给0.5分
  const remainingCapacity = Math.min(4 - currentScore, 0.5);

  if (remainingCapacity > 0) {
    const success = writeRhythmScore(remainingCapacity, 'subtask_complete');
    if (success) {
      console.log(`[✅ Subtask Completed] ID: ${subtaskId}, +${remainingCapacity} rhythm score`);
      // 触发分数更新事件
      window.dispatchEvent(new CustomEvent('rhythm-score-updated'));
    }
  } else {
    console.warn('⛔ No remaining capacity for subtask score.');
  }
};

/**
 * 完成一个 goal 的修复版本
 * 
 * 计分逻辑：
 * 1. 一个goal的总价值是2分
 * 2. 如果之前subtask已经给过分，goal完成时只补足到2分
 * 3. 如果没有subtask给过分，goal完成时给满2分
 * 4. goal下的subtask总分不能超过2分
 * 5. 每天所有goal+subtask的总分不能超过4分
 */
export const handleCompleteGoal = (goalId: string, subtaskIds: string[]) => {
  if (isTodayFinalized()) {
    console.warn('⛔ Cannot complete goal: day already finalized.');
    return;
  }

  // 获取这个goal下已完成的subtask数量
  const allSubtasks = JSON.parse(localStorage.getItem('rhythmSubtasks') || '[]');
  const goalSubtasks = allSubtasks.filter((s: any) => 
    (s.parentGoalId === goalId || s.goalId === goalId) && s.status === 'completed'
  );
  
  // 计算这个goal应该已经获得的subtask分数
  const completedSubtaskCount = goalSubtasks.length;
  const maxSubtaskScoreForThisGoal = Math.min(completedSubtaskCount * 0.5, 2.0);
  
  // 一个goal的总价值是2分
  const goalTotalValue = 2.0;
  
  // Goal完成时应该给的分数 = 总价值 - 已经通过subtask给的分数
  const scoreToGive = goalTotalValue - maxSubtaskScoreForThisGoal;
  
  console.log(`Goal completion calculation:`, {
    goalId,
    completedSubtaskCount,
    maxSubtaskScoreForThisGoal,
    goalTotalValue,
    scoreToGive
  });
  
  // 检查当前总分限制
  const currentTotalScore = getTodayGoalSubtaskScore();
  const maxScore = Math.min(scoreToGive, 4 - currentTotalScore);
  
  if (maxScore > 0) {
    const success = writeRhythmScore(maxScore, 'goal_complete');
    if (success) {
      console.log(`[✅ Goal Completed] ID: ${goalId}, +${maxScore} rhythm score (${completedSubtaskCount} subtasks already completed)`);
      // 触发分数更新事件
      window.dispatchEvent(new CustomEvent('rhythm-score-updated'));
    }
  } else {
    console.log(`[✅ Goal Completed] ID: ${goalId}, +0 rhythm score (full value already obtained from subtasks)`);
    // 即使不给分也要触发事件，让UI更新
    window.dispatchEvent(new CustomEvent('rhythm-score-updated'));
  }
};

/**
 * 完成一个 challenge，固定给 3 分
 */
export const handleCompleteChallenge = (challengeId: string) => {
  if (isTodayFinalized()) {
    console.warn('⛔ Cannot complete challenge: day already finalized.');
    return;
  }

  const success = writeRhythmScore(3, 'challenge_complete');
  if (success) {
    console.log(`[✅ Challenge Completed] ID: ${challengeId}, +3 rhythm score`);
    // 触发分数更新事件
    window.dispatchEvent(new CustomEvent('rhythm-score-updated'));
  }
};

/**
 * 完成一个 microtask
 * 注意：microtask不给节奏分，也不给XP，只是用于追踪完成数量
 */
export const handleCompleteMicrotask = (microtaskId: string) => {
  // microtask不给节奏分，只用于统计
  console.log(`[✅ Microtask Completed] ID: ${microtaskId}, +0 rhythm score (tracking only)`);
  
  // 触发microtask完成事件，让相关组件更新计数
  window.dispatchEvent(new CustomEvent('microtask-completed', { 
    detail: { microtaskId }
  }));
};
