// /utils/rhythmDayEngine.ts

/**
 * 获取今天的日期，格式为YYYY-MM-DD
 */
export const getTodayDate = (): string => {
  return new Date().toISOString().slice(0, 10);
};

/**
 * 检测当前节奏趋势
 */
export const detectCurrentTrend = (): 'collapsed' | 'wavy' | 'stable' | 'rising' => {
  const avgScore = getTodayTotalScore();

  if (avgScore <= 3) return 'collapsed';
  if (avgScore <= 5) return 'wavy';
  if (avgScore <= 7) return 'stable';
  return 'rising';
};

/**
 * 判断今天是否已完成（已终结）
 */
export const isTodayFinalized = (): boolean => {
  const today = getTodayDate();
  return localStorage.getItem('rhythmTodayFinalized') === today;
};

/**
 * 获取最后一次完成的日期
 */
export const getLastFinalizedDate = (): string | null => {
  return localStorage.getItem('lastFinalizedDate');
};

/**
 * 开始新的节奏日
 */
export const startNewRhythmDay = (): void => {
  const today = getTodayDate();
  if (localStorage.getItem('rhythmTodayStarted') !== today) {
    // ✅ 清空日缓存（不动总历史记录）
    localStorage.removeItem('dailyChallenge');
    localStorage.removeItem('rhythmTodayFinalized');
    localStorage.setItem('rhythmTodayStarted', today);
  }
};

/**
 * 强制自动结束昨天的节奏日
 */
export const forceAutoFinalizeYesterday = (): void => {
  const today = getTodayDate();
  const lastFinalized = getLastFinalizedDate();

  if (lastFinalized !== today) {
    const todayScore = getTodayTotalScore();
    finalizeToday(todayScore, 'auto');
  }
};

/**
 * 标记今天为已完成
 */
export const markTodayFinalized = () => {
  const today = getTodayDate();
  localStorage.setItem('rhythmTodayFinalized', today);
  localStorage.setItem('lastFinalizedDate', today);
};

/**
 * 完成今天并记录分数和趋势
 */
export const finalizeToday = (score: number, trend: string): void => {
  const today = getTodayDate();
  const summaryLog = JSON.parse(localStorage.getItem('dailySummaryLog') || '[]');
  const updated = summaryLog.filter((entry: any) => entry.date !== today);
  updated.push({ date: today, score, trend });
  localStorage.setItem('dailySummaryLog', JSON.stringify(updated));
  localStorage.setItem('lastFinalizedDate', today);
  localStorage.setItem('rhythmTodayFinalized', today);
};

/**
 * 判断是否新的节奏日
 */
export const isNewRhythmDay = (): boolean => {
  const today = getTodayDate();
  const started = localStorage.getItem('rhythmTodayStarted') === today;
  const finalized = localStorage.getItem('rhythmTodayFinalized') === today;
  return !(started || finalized);
};

/**
 * 获取今天的总分数
 */
export const getTodayTotalScore = (): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) => entry.date === today && typeof entry.value === 'number')
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
};

/**
 * 判断今天是否已开始
 */
export const hasTodayStarted = (): boolean => {
  const today = getTodayDate();
  return localStorage.getItem('rhythmTodayStarted') === today;
};

/**
 * 获取今天的完成摘要
 */
export const getFinalizedSummary = () => {
  const today = getTodayDate();
  const summaryLog = JSON.parse(localStorage.getItem('dailySummaryLog') || '[]');
  return summaryLog.find((entry: any) => entry.date === today) || null;
};
  
  
  