// utils/cuePromptBuilder.ts

export const useCueAsPrompt = (): string | null => {
    const raw = localStorage.getItem('signature_prompt_memory');
    if (!raw) return null;
  
    try {
      const memory = JSON.parse(raw);
      const fragments = memory.highScoreCueFragments || [];
  
      if (fragments.length === 0) return null;
  
      // 随机取一条，未来可按打分排序
      const base = fragments[Math.floor(Math.random() * fragments.length)];
  
      return `Write a similar identity cue in the tone of "${base.tone}" with a similar emotional feel to: "${base.cueText}"`;
    } catch {
      return null;
    }
  };
  