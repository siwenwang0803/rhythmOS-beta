//utils/getCurrentPersona.ts

export function getCurrentPersona(): string {
    const override = localStorage.getItem('creStyleOverride');
    if (override && override !== 'auto') return override;
  
    const init = localStorage.getItem('initPersona') || 'rhea';
    return init;
  }
  