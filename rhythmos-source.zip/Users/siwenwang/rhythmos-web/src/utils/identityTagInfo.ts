// /utils/identityTagInfo.ts

export const identityTagInfo: Record<string, { definition: string; reason?: string }> = {
    'Supportive Guardian': {
      definition: 'A steady, compassionate style combining structure and empathy.',
      reason: 'Derived from your frequent gentle (rhea) tone feedback and INFJ personality.'
    },
    'Decisive Strategist': {
      definition: 'Direct and forward-moving, goal-oriented leadership.',
      reason: 'Based on multiple directive-aligned responses and consistent challenge completions.'
    },
    'Logical Thinker': {
      definition: 'Processes situations with clarity, logic, and emotional neutrality.',
      reason: 'Generated from rational tone patterns and steady feedback trends.'
    },
    'Expressive Guide': {
      definition: 'Speaks with emotional clarity and supports others into action.',
      reason: 'Created from balanced/gentle tone usage and ENFJ personality.'
    },
    'Visionary Planner': {
      definition: 'Sees patterns in complexity and charts sustainable action.',
      reason: 'Triggered by visionary tone use and Lucis-style feedback consistency.'
    },
    'Execution-Oriented Leader': {
      definition: 'Moves plans forward with clear focus and accountability.',
      reason: 'Identified through directive tone streak and goal alignment success.'
    }
  };
  