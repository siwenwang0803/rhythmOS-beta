// utils/getMostResonantTone.ts

import { signatureMap } from '../SignatureMap';

export function getMostResonantTone(): string {
  const toneCounts: Record<string, number> = {};

  const countTone = (tone: string) => {
    if (!tone) return;
    toneCounts[tone] = (toneCounts[tone] || 0) + 1;
  };

  const cueLog = signatureMap.cueFeedbackLog || [];
  const speakLog = signatureMap.speakReplayLog || [];

  cueLog.forEach(entry => {
    if (entry.feedback === 'aligned') countTone(entry.tone);
  });

  speakLog.forEach(entry => {
    countTone(entry.tone);
  });

  const sorted = Object.entries(toneCounts).sort((a, b) => b[1] - a[1]);
  return sorted[0]?.[0] || 'gentle';
}
