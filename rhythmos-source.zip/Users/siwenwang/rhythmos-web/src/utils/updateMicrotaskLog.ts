// utils/updateMicrotaskLog.ts

import { signatureMap } from '../SignatureMap';

/**
 * Logs a microtask completion.
 * - Increments microtaskCount
 * - Appends log entry to microtaskLog[]
 */
export function updateMicrotaskLog(type: string = 'default') {
  console.log('[Microtask] Triggered update for:', type);

  signatureMap.microtaskCount = (signatureMap.microtaskCount || 0) + 1;
  signatureMap.microtaskLog = signatureMap.microtaskLog || [];

  signatureMap.microtaskLog.push({
    type,
    timestamp: new Date().toISOString(),
  });

  console.log('[Microtask] Count =', signatureMap.microtaskCount);
  console.log('[Microtask] Log =', signatureMap.microtaskLog);
  
  // 触发事件以通知组件更新
  const event = new CustomEvent('microtask-updated', { 
    detail: { count: signatureMap.microtaskCount } 
  });
  window.dispatchEvent(event);
}
