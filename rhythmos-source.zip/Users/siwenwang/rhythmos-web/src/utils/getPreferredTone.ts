// utils/getPreferredTone.ts

/**
 * Get the preferred tone for CRE cue generation
 * Priority order:
 * 1. crePreferredTone (from PersonaSelector override)
 * 2. preferredTone (from OnboardingStep2)
 * 3. Default to 'gentle'
 */
export function getPreferredTone(): string {
    // First check if user has selected a specific persona
    const overrideTone = localStorage.getItem('crePreferredTone');
    if (overrideTone) {
      console.log(`[getPreferredTone] Using persona override tone: ${overrideTone}`);
      return overrideTone;
    }
    
    // Then check initial preference from onboarding
    const preferredTone = localStorage.getItem('preferredTone');
    if (preferredTone) {
      console.log(`[getPreferredTone] Using initial onboarding preference: ${preferredTone}`);
      return preferredTone;
    }
    
    // Fallback to default
    console.log(`[getPreferredTone] No preferences found, using default: gentle`);
    return 'gentle';
  }