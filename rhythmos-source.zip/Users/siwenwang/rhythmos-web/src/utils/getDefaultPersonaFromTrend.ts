// utils/getDefaultPersonaFromTrend.ts

export function getDefaultPersonaFromTrend(trend: string): string {
    const map: Record<string, string> = {
      collapsed: 'aurelia',
      wavy: 'rhea',
      stable: 'niveus',
      rising: 'lucis',
      visionary: 'caelum'
    };
  
    return map[trend] || 'niveus'; // fallback 默认使用 Niveus
  }
  