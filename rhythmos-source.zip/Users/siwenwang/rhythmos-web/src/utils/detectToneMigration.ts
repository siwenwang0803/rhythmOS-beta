// detectToneMigration.ts

import { CREGrowthLogEntry } from '../creGrowthLog'

// ✅ tone → persona 映射规则（你可以扩展）
const toneToPersona: Record<string, string> = {
  gentle: 'rhea',
  supportive: 'rhea',
  balanced: 'aurelia',
  reflective: 'aurelia',
  directive: 'caelum',
}

export function detectToneMigration(): {
  suggested: string | null
  trigger: boolean
} {
  const raw = localStorage.getItem('creGrowthLog')
  const log: CREGrowthLogEntry[] = raw ? JSON.parse(raw) : []

  const recent = log.slice(-5)

  const toneScoreMap: Record<string, { total: number; count: number }> = {}

  recent.forEach((entry) => {
    if (!entry.tone || entry.score === undefined) return
    const tone = entry.tone
    if (!toneScoreMap[tone]) {
      toneScoreMap[tone] = { total: 0, count: 0 }
    }
    toneScoreMap[tone].total += entry.score
    toneScoreMap[tone].count += 1
  })

  // 计算平均得分
  const averages = Object.entries(toneScoreMap).map(([tone, { total, count }]) => ({
    tone,
    avg: total / count,
  }))

  if (averages.length < 2) return { suggested: null, trigger: false }

  averages.sort((a, b) => b.avg - a.avg)
  const [topTone, secondTone] = averages

  const gap = topTone.avg - secondTone.avg

  // ✅ 若当前 top tone 平均得分高于第二名 ≥ 1 分 → 建议切换风格
  if (gap >= 1 && toneToPersona[topTone.tone]) {
    return {
      suggested: toneToPersona[topTone.tone],
      trigger: true,
    }
  }

  return { suggested: null, trigger: false }
}
