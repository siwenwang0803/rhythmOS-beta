// utils/getTodayTrend.ts

import { signatureMap } from '../SignatureMap';
import { getTodayDate } from './rhythmDayEngine';

export function getTodayTrend(): 'collapsed' | 'wavy' | 'stable' | 'rising' | 'unknown' {
  const today = getTodayDate();
  const entry = (signatureMap.trendHistory || []).find(t => t.date === today);
  return entry?.trend || 'unknown';
}
