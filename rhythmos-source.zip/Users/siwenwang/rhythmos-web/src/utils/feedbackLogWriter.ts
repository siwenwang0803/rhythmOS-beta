import { getSignatureMap } from '../SignatureMap';

// 标准评分计算
export const getFeedbackScore = (feedback: 'aligned' | 'okay' | 'notMe'): number => {
  switch (feedback) {
    case 'aligned': return 1;
    case 'okay': return 0.5;
    case 'notMe': return 0;
    default: return 0;
  }
};

// 为去重创建唯一键
export const createUniqueKey = (
  cueId: string, 
  tone: string, 
  timestamp: string
): string => {
  const date = new Date(timestamp);
  const dayKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  return `${cueId}_${tone}_${dayKey}`;
};

/**
 * 添加反馈条目
 * 这个函数负责将反馈写入 localStorage['cueFeedbackLog']
 * 它确保:
 * 1. 所有反馈类型都被正确保存(aligned, okay, notMe)
 * 2. 相同的 cueId+tone+date 只保存最新的一条
 * 3. 每条记录都有唯一键，便于去重
 */
export const addFeedbackEntry = (entry: {
  cueId: string;
  cueText: string;
  tone: string;
  persona: string;
  trend: string;
  feedback: 'aligned' | 'okay' | 'notMe';
  score?: number;
  timestamp?: string;
}) => {
  // 使用当前时间戳，如果没有提供
  const timestamp = entry.timestamp || new Date().toISOString();
  
  // 计算分数
  const score = typeof entry.score === 'number' ? entry.score : getFeedbackScore(entry.feedback);
  
  // 创建唯一键，用于去重
  const uniqueKey = `${entry.cueId}_${entry.tone}_${timestamp.slice(0, 10)}`;
  
  // 创建要保存的条目
  const cueEntry = { 
    ...entry, 
    timestamp,
    score,
    uniqueKey
  };
  
  try {
    // 从 localStorage 读取现有的反馈日志
    const existingDataRaw = localStorage.getItem('cueFeedbackLog');
    let existingData = [];
    
    if (existingDataRaw) {
      try {
        existingData = JSON.parse(existingDataRaw);
        // 确保是数组
        if (!Array.isArray(existingData)) {
          existingData = [];
        }
      } catch (e) {
        console.error('Error parsing cueFeedbackLog:', e);
        existingData = [];
      }
    }
    
    // 过滤掉具有相同 uniqueKey 的条目
    const filteredData = existingData.filter((item: any) => 
      item && item.uniqueKey !== uniqueKey
    );
    
    // 添加新条目
    filteredData.push(cueEntry);
    
    // 将更新后的数据保存到 localStorage
    localStorage.setItem('cueFeedbackLog', JSON.stringify(filteredData));
    
    // 更新 signatureMap (用于实时引用)
    const signatureMap = getSignatureMap();
    if (!signatureMap.cueFeedbackLog) {
      signatureMap.cueFeedbackLog = [];
    }
    
    // 同步更新 signatureMap
    signatureMap.cueFeedbackLog = filteredData;
    
    // 触发更新事件
    window.dispatchEvent(new Event('cue-feedback-updated'));
    console.log('✅ cueFeedbackLog updated with uniqueKey:', uniqueKey, 'feedback:', entry.feedback);
  } catch (e) {
    console.error('❌ Failed to write cueFeedbackLog', e);
  }
  
  return cueEntry;
};
