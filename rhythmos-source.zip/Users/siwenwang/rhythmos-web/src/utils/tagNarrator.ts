export function getTagNarrative(tagId: string, persona: string, tone: string): string {
  const tagNarratives: Record<string, (p: string, t: string) => string> = {
    expressive_guide: (p, t) =>
      `You’ve expressed yourself as an Expressive Guide — combining a ${t} (${p}) tone with communicative clarity.`,
    calm_challenger: (p, t) =>
      `Your reflections show a steady resilience. As a Calm Challenger, you meet resistance with a ${t} (${p}) mindset.`,
    reflective_builder: (p, t) =>
      `As a Reflective Builder, you've cultivated thoughtful rhythm through a ${t} (${p}) practice.`,
  };

  const formatter = tagNarratives[tagId];
  if (!formatter) {
    // ✅ 修复点：用参数 tone 和 persona 替代未定义的 t 和 p
    return `You’re showing a unique growth pattern through your ${tone} (${persona}) rhythm.`;
  }

  return formatter(persona, tone);
}
