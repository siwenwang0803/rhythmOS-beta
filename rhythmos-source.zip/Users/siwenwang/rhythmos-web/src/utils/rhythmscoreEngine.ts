// /utils/rhythmScoreEngine.ts

import { getTodayDate, isTodayFinalized, getTodayTotalScore } from './rhythmDayEngine';

// Constants for score limitations
export const MAX_DAILY_SCORE = 10; 
export const MAX_GOAL_SUBTASK_COMBINED_SCORE = 4; 
export const MAX_CHALLENGE_COUNT = 2;
export const MAX_MICROTASK_COUNT = 3;

/**
 * 计算今天的目标和子任务总得分
 */
export const getTodayGoalSubtaskScore = (): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) =>
      entry.date === today &&
      (entry.actionType === 'subtask_complete' || entry.actionType === 'goal_complete')
    )
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
};

/**
 * 获取今天完成的挑战数量
 */
export const getTodayChallengeCount = (): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) => 
      entry.date === today && 
      entry.actionType === 'challenge_complete'
    ).length;
};

/**
 * 获取今天挑战获得的分数
 */
export const getTodayChallengeScore = (): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) => 
      entry.date === today && 
      entry.actionType === 'challenge_complete'
    )
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
};

/**
 * 获取今天完成的微任务数量
 */
export const getTodayMicrotaskCount = (): number => {
  const today = getTodayDate();
  const tracker = JSON.parse(localStorage.getItem('xpTracker') || '{}');
  return tracker[today]?.microtaskCount || 0;
};

/**
 * 获取今天微任务获得的分数
 * (由于微任务目前只给XP不直接给节奏分，所以返回0)
 */
export const getTodayMicrotaskScore = (): number => {
  // 目前微任务不直接贡献节奏得分
  // 它们只提供XP奖励，所以这个函数返回0
  return 0;
};

/**
 * 写入节奏得分，含各种验证
 */
export const writeRhythmScore = (value: number, actionType: string): boolean => {
  // 检查今天是否已完成
  if (isTodayFinalized()) {
    console.warn('⛔ Day finalized, cannot write score.');
    return false;
  }

  const today = getTodayDate();
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  
  // 获取当前总分
  const currentTotal = getTodayTotalScore();

  // 检查是否超过每日总分上限
  if (currentTotal + value > MAX_DAILY_SCORE) {
    console.warn('⛔ Total daily score exceeded.');
    return false;
  }

  // 挑战类型特殊检查
  if (actionType === 'challenge_complete') {
    const count = getTodayChallengeCount();
    if (count >= MAX_CHALLENGE_COUNT) {
      console.warn('⛔ Maximum daily challenges reached.');
      return false;
    }
  }

  // 目标和子任务类型特殊检查
  if (actionType === 'goal_complete' || actionType === 'subtask_complete') {
    const goalSubtaskTotal = getTodayGoalSubtaskScore();
    if (goalSubtaskTotal + value > MAX_GOAL_SUBTASK_COMBINED_SCORE) {
      console.warn('⛔ Goal+Subtask score exceeded.');
      return false;
    }
  }

  // 微任务类型特殊检查
  if (actionType === 'microtask_complete') {
    const count = getTodayMicrotaskCount();
    if (count >= MAX_MICROTASK_COUNT) {
      console.warn('⛔ Maximum daily microtasks reached.');
      return false;
    }
  }

  // 所有验证都通过，添加得分记录
  rhythmScoreLog.push({
    date: today,
    value,
    actionType,
    timestamp: new Date().toISOString(),
  });

  // 保存到本地存储
  localStorage.setItem('rhythmScoreLog', JSON.stringify(rhythmScoreLog));
  return true; // 表示成功写入得分
};

/**
 * 获取特定动作类型今天的记录数量
 */
export const getTodayActionTypeCount = (actionType: string): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog.filter(
    (entry: any) => entry.date === today && entry.actionType === actionType
  ).length;
};

/**
 * 获取特定动作类型今天的得分总和
 */
export const getTodayActionTypeScore = (actionType: string): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) => entry.date === today && entry.actionType === actionType)
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
};

/**
 * 获取得分类别的最大限制
 */
export const getScoreLimits = () => {
  return {
    maxDaily: MAX_DAILY_SCORE,
    maxGoalSubtask: MAX_GOAL_SUBTASK_COMBINED_SCORE,
    maxChallengeCount: MAX_CHALLENGE_COUNT,
    maxMicrotaskCount: MAX_MICROTASK_COUNT
  };
};

