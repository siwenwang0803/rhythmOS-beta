// /utils/xpDailyTracker.ts - Direct Fix

/**
 * XP Daily Tracker - Critical Fix
 * Focus on fixing the challenge XP accumulation issue
 */

import { addXp, forceRefreshAllXpData } from './xpEngine';

// Get today's date key (format: YYYY-MM-DD)
export const getTodayDateKey = () => new Date().toISOString().split('T')[0];

// Get XP tracker data
export const getXpTracker = (): any => {
  try {
    const raw = localStorage.getItem('xpDailyTracker');
    return raw ? JSON.parse(raw) : {};
  } catch (error) {
    console.error('Error getting XP tracker data:', error);
    return {};
  }
};

// Save XP tracker data and trigger update events
export const saveXpTracker = (data: any) => {
  try {
    // Save to localStorage
    localStorage.setItem('xpDailyTracker', JSON.stringify(data));
    
    // Trigger update events
    window.dispatchEvent(new Event('xp-updated'));
    window.dispatchEvent(new Event('rhythm-score-updated'));
    
    // Also dispatch microtask event for compatibility
    const today = getTodayDateKey();
    const event = new CustomEvent('microtask-completed', { 
      detail: { count: data[today]?.microtaskCount || 0, date: today } 
    });
    window.dispatchEvent(event);
  } catch (error) {
    console.error('Error saving XP tracker data:', error);
  }
};

// Check if challenge can be logged
export const canLogChallenge = (): boolean => {
  try {
    const tracker = getXpTracker();
    const today = getTodayDateKey();
    const count = tracker[today]?.challengeCount || 0;
    console.log(`Current challenge count: ${count}/2`);
    return count < 2; // Max 2 challenges per day
  } catch (error) {
    console.error('Error checking challenge limit:', error);
    return false;
  }
};

// CRITICAL FIX: logChallengeXp function
export const logChallengeXp = () => {
  try {
    console.log('=== LOGGING CHALLENGE XP ===');
    
    // Get current active persona
    const activePersona = localStorage.getItem('initPersona') || 'rhea';
    console.log(`Active persona: ${activePersona}`);
    
    // Get tracker data
    const tracker = getXpTracker();
    const today = getTodayDateKey();
    
    // Ensure today's record exists
    if (!tracker[today]) {
      tracker[today] = {
        challengeCount: 0,
        microtaskCount: 0,
        xpLogs: []
      };
    }
    
    // Record current count
    const oldCount = tracker[today].challengeCount || 0;
    console.log(`Current challenge count: ${oldCount}`);
    
    // Check if already at limit
    if (oldCount >= 2) {
      console.log('Challenge limit reached, not adding XP');
      return false;
    }
    
    // Update count
    tracker[today].challengeCount = oldCount + 1;
    console.log(`Updated challenge count: ${tracker[today].challengeCount}`);
    
    // Add XP log
    if (!tracker[today].xpLogs) tracker[today].xpLogs = [];
    
    // Log XP addition
    tracker[today].xpLogs.push({
      persona: activePersona,
      amount: 6, // 6 XP per challenge
      source: 'challenge_complete',
      timestamp: new Date().toISOString()
    });
    
    // Save updated tracker
    localStorage.setItem('xpDailyTracker', JSON.stringify(tracker));
    console.log('Saved updated tracker');
    
    // CRITICAL FIX: Direct XP addition with immediate verification
    console.log(`DIRECTLY adding 6 XP to ${activePersona}`);
    const newXp = addXp(activePersona, 6);
    console.log(`New XP value for ${activePersona}: ${newXp}`);
    
    // CRITICAL: Verify that the XP was actually added
    setTimeout(() => {
      try {
        // Read directly from localStorage
        const xpLogRaw = localStorage.getItem('personaXpLog');
        if (xpLogRaw) {
          const xpData = JSON.parse(xpLogRaw);
          console.log(`VERIFICATION - ${activePersona}'s XP value: ${xpData[activePersona]?.xp}`);
        }
      } catch (e) {
        console.error('Error verifying XP:', e);
      }
    }, 100);
    
    // Trigger update events
    window.dispatchEvent(new Event('xp-updated'));
    window.dispatchEvent(new Event('rhythm-score-updated'));
    
    // Force refresh after a delay to ensure everything is updated
    setTimeout(() => {
      forceRefreshAllXpData();
    }, 200);
    
    return true;
  } catch (error) {
    console.error('Error logging challenge XP:', error);
    console.trace(); // Print stack trace
    return false;
  }
};

// Other functions remain the same
export const canLogMicrotask = (): boolean => {
  try {
    const tracker = getXpTracker();
    const today = getTodayDateKey();
    const count = tracker[today]?.microtaskCount || 0;
    return count < 3; // Max 3 microtasks per day
  } catch (error) {
    console.error('Error checking microtask limit:', error);
    return false;
  }
};

export const getTodayMicrotaskCount = (): number => {
  try {
    const tracker = getXpTracker();
    const today = getTodayDateKey();
    return tracker[today]?.microtaskCount || 0;
  } catch (error) {
    console.error('Error getting microtask count:', error);
    return 0;
  }
};

export const getTodayChallengeCount = (): number => {
  try {
    const tracker = getXpTracker();
    const today = getTodayDateKey();
    return tracker[today]?.challengeCount || 0;
  } catch (error) {
    console.error('Error getting challenge count:', error);
    return 0;
  }
};

// Reset today's counters - for development testing
export const resetTodayCounters = () => {
  try {
    const tracker = getXpTracker();
    const today = getTodayDateKey();
    
    if (!tracker[today]) tracker[today] = {};
    
    const oldMicrotaskCount = tracker[today].microtaskCount || 0;
    const oldChallengeCount = tracker[today].challengeCount || 0;
    
    tracker[today].microtaskCount = 0;
    tracker[today].challengeCount = 0;
    
    saveXpTracker(tracker);
    console.log('Reset today\'s counters');
    
    return {
      oldMicrotaskCount,
      oldChallengeCount
    };
  } catch (error) {
    console.error('Error resetting counters:', error);
    return null;
  }
};

// Check and repair tracker data
export const checkAndRepairTracker = () => {
  try {
    console.log('Checking tracker data integrity...');
    const tracker = getXpTracker();
    const today = getTodayDateKey();
    
    if (!tracker[today]) {
      tracker[today] = {
        microtaskCount: 0,
        challengeCount: 0,
        xpLogs: []
      };
      console.log('Created today\'s tracker record');
    }
    
    let modified = false;
    
    if (typeof tracker[today].microtaskCount !== 'number') {
      tracker[today].microtaskCount = parseInt(tracker[today].microtaskCount?.toString() || '0', 10) || 0;
      modified = true;
      console.log(`Fixed microtask count: ${tracker[today].microtaskCount}`);
    }
    
    if (typeof tracker[today].challengeCount !== 'number') {
      tracker[today].challengeCount = parseInt(tracker[today].challengeCount?.toString() || '0', 10) || 0;
      modified = true;
      console.log(`Fixed challenge count: ${tracker[today].challengeCount}`);
    }
    
    if (!Array.isArray(tracker[today].xpLogs)) {
      tracker[today].xpLogs = [];
      modified = true;
      console.log('Created XP logs array');
    }
    
    if (modified) {
      saveXpTracker(tracker);
      console.log('Saved repaired tracker data');
    } else {
      console.log('Tracker data check complete, no issues found');
    }
    
    return tracker;
  } catch (error) {
    console.error('Error checking and repairing tracker data:', error);
    return null;
  }
};