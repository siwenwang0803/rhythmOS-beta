// utils/toneLogStats.ts
import { getToneScoreMapByDays } from '../utils/writeToneLog';

export function getTopTone(days = 3): string {
  const scoreMap = getToneScoreMapByDays(days);
  const sorted = Object.entries(scoreMap).sort((a, b) => b[1] - a[1]);
  return sorted[0]?.[0] || 'gentle';
}

// /utils/toneLogStats.ts

