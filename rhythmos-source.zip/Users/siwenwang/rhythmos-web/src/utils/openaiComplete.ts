// /src/utils/openaiComplete.ts
// 完整文件 - 直接替换整个文件内容

// 主要的 OpenAI 调用函数（兼容旧代码）
export async function openaiComplete(prompt: string, options: any = {}) {
  console.log('[openaiComplete] Legacy function called');
  
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  
  if (!apiKey) {
    throw new Error('OpenAI API key not found');
  }
  
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          { role: 'user', content: prompt }
        ],
        temperature: options.temperature || 0.7,
        max_tokens: options.max_tokens || 300,
        ...options
      })
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error?.message || 'OpenAI API error');
    }
    
    const data = await response.json();
    return data.choices[0].message.content;
    
  } catch (error) {
    console.error('[openaiComplete] Error:', error);
    throw error;
  }
}

// CRE 生成函数
export async function generateCREWithOpenAI(params: {
  tone: string;
  trend: string;
  microEmotion?: string;
  userContext?: string;
  signatureMemory?: string;
}) {
  const { tone, trend, microEmotion, userContext, signatureMemory } = params;
  
  console.log('[generateCREWithOpenAI] Starting generation...');
  
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  
  if (!apiKey) {
    throw new Error('OpenAI API key not found');
  }
  
  // 简洁的系统提示
  const systemMessage = `You are a compassionate AI companion in RhythmOS. 
Generate brief, thoughtful daily guidance that acknowledges the user's current emotional state.
Keep responses concise but meaningful.`;

  // 构建用户消息
  let userMessage = `User is feeling ${trend}`;
  
  if (microEmotion) {
    userMessage += ` and ${microEmotion}`;
  }
  
  if (userContext) {
    userMessage += `.\nThey shared: "${userContext}"`;
  }
  
  // 只包含最相关的签名记忆（如果有的话）
  if (signatureMemory) {
    // 只取前几行最重要的信息
    const memoryLines = signatureMemory.split('\n').slice(0, 3).join('\n');
    userMessage += `\n\nContext: ${memoryLines}`;
  }
  
  userMessage += `\n\nGenerate a ${tone} response in this exact JSON format:
{
  "cue": "brief empowering phrase (5-8 words)",
  "paragraph": "2-3 sentences only. First acknowledge their state, then offer one specific insight or gentle suggestion. Keep it concise and actionable.",
  "tone": "${tone}",
  "persona": "${getPersonaForTone(tone)}"
}`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: systemMessage },
          { role: 'user', content: userMessage }
        ],
        temperature: 0.8,
        max_tokens: 150
      })
    });
    
    if (!response.ok) {
      const error = await response.json();
      console.error('[generateCREWithOpenAI] API error:', error);
      throw new Error(error.error?.message || 'OpenAI API error');
    }
    
    const data = await response.json();
    const content = data.choices[0].message.content;
    
    console.log('[generateCREWithOpenAI] Success, tokens used:', data.usage);
    
    const parsed = JSON.parse(content.trim());
    
    return {
      cue: parsed.cue || "Begin where you are",
      paragraph: parsed.paragraph || "Every moment offers a chance to tune into your rhythm.",
      tone: parsed.tone || tone,
      persona: parsed.persona || getPersonaForTone(tone)
    };
    
  } catch (error) {
    console.error('[generateCREWithOpenAI] Error:', error);
    throw error;
  }
}

// 辅助函数：根据 tone 获取 persona
function getPersonaForTone(tone: string): string {
  const tonePersonaMap = {
    gentle: 'rhea',
    directive: 'niveus',
    rational: 'aurelia',
    visionary: 'lucis',
    motivated: 'caelum',
    balanced: 'lucis'
  };
  
  return tonePersonaMap[tone] || 'rhea';
}

// 简化的签名记忆函数 - 只获取最重要的信息
export function getDailySignatureContext(): string {
  try {
    let context = "";
    
    // 1. 最近的趋势模式（简短）
    const signatureMap = localStorage.getItem('signatureMap');
    if (signatureMap) {
      const map = JSON.parse(signatureMap);
      if (map.trendLog && map.trendLog.length > 0) {
        const recentTrends = map.trendLog.slice(-3).map(t => t.trend);
        context += `Recent pattern: ${recentTrends.join(' → ')}\n`;
      }
    }
    
    // 2. 今天的主要目标（如果有）
    const goals = localStorage.getItem('rhythmGoals');
    if (goals) {
      const goalList = JSON.parse(goals);
      const todayGoal = goalList.filter(g => !g.completed)[0];
      if (todayGoal) {
        context += `Focus: ${todayGoal.title}\n`;
      }
    }
    
    // 3. 微任务参与度
    const microtaskScore = localStorage.getItem('directScore');
    if (microtaskScore && parseInt(microtaskScore) > 0) {
      context += `Engagement level: ${microtaskScore}\n`;
    }
    
    return context || "Starting fresh today.";
    
  } catch (error) {
    console.error('[DailyContext] Error:', error);
    return "";
  }
}

// 测试函数
export async function testOpenAI() {
  console.log('[OpenAI] Testing API connection...');
  
  try {
    const result = await openaiComplete(
      'Say "API works" if you can read this.',
      { max_tokens: 10 }
    );
    
    console.log('[OpenAI] Test result:', result);
    return result;
  } catch (error) {
    console.error('[OpenAI] Test failed:', error);
    throw error;
  }
}