export const postGoalReflectionLibrary = {
    write: [
      {
        cue: "You translated thought into something tangible.",
        paragraph: "That took discipline. Let yourself feel what you created — even if it’s unfinished."
      },
      {
        cue: "Words have weight when you give them form.",
        paragraph: "You wrote something real today. It matters more than you think."
      }
    ],
    reflect: [
      {
        cue: "You paused — and that’s power.",
        paragraph: "Reflection isn’t a break from life. It’s how life becomes clearer."
      },
      {
        cue: "You showed up for yourself.",
        paragraph: "Even noticing how you feel is a kind of victory. Don’t rush past it."
      }
    ],
    organize: [
      {
        cue: "You cleared a corner of the chaos.",
        paragraph: "Space creates ease. Breathe in the order you made today."
      },
      {
        cue: "Structure is self-respect.",
        paragraph: "That small bit of organization gave you back a piece of clarity."
      }
    ],
    plan: [
      {
        cue: "You gave your future a shape.",
        paragraph: "Planning is an act of belief. You showed yourself what matters."
      },
      {
        cue: "Direction quiets doubt.",
        paragraph: "You sketched a path today. Trust the part of you that drew it."
      }
    ],
    review: [
      {
        cue: "You circled back — and that’s how progress sharpens.",
        paragraph: "Review isn’t repetition. It’s refinement."
      }
    ],
    clarify: [
      {
        cue: "You untangled something.",
        paragraph: "Clarity isn’t loud. It’s a calm you just earned."
      }
    ],
    explore: [
      {
        cue: "You stepped into uncertainty — and stayed.",
        paragraph: "Exploration takes courage, not answers. Let curiosity be enough today."
      }
    ],
    research: [
      {
        cue: "You gathered signal from noise.",
        paragraph: "That search wasn’t wasted. Something is taking shape beneath it."
      }
    ],
    learn: [
      {
        cue: "You stretched your edge today.",
        paragraph: "Learning isn’t always obvious — but you planted something."
      }
    ],
    unknown: [
      {
        cue: "You moved forward, even without full clarity.",
        paragraph: "Sometimes action comes first. Meaning catches up later."
      }
    ]
  };
  