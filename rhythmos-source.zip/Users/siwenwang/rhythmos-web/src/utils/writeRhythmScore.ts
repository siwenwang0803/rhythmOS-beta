// /utils/writeRhythmScore.ts

import { getTodayDate } from './rhythmDayEngine';

// 常量定义
export const MAX_DAILY_SCORE = 10; // 每日总分上限
export const MAX_GOAL_SUBTASK_COMBINED_SCORE = 4; // 目标和子任务总分上限
export const MAX_SINGLE_GOAL_SCORE = 2; // 单个目标最大分数
export const MAX_CHALLENGE_COUNT = 2; // 挑战最大数量
export const MAX_CHALLENGE_SCORE = 6; // 挑战总分上限(3分/个)
export const MAX_MICROTASK_COUNT = 3; // 微任务最大数量

/**
 * 写入节奏得分，含验证和上限处理
 * @param value 原始分数值
 * @param actionType 动作类型
 * @param goalId 可选的目标ID
 * @returns 实际记录的分数值
 */
export const writeRhythmScore = (
  value: number, 
  actionType: string, 
  goalId?: string
): number => {
  // 检查今天是否已完成
  const today = getTodayDate();
  if (localStorage.getItem('rhythmTodayFinalized') === today) {
    console.warn('⛔ Day finalized, cannot write score.');
    return 0;
  }

  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  
  // 获取当前总分
  const currentTotal = rhythmScoreLog
    .filter((entry: any) => entry.date === today && typeof entry.value === 'number')
    .reduce((acc: number, entry: any) => acc + entry.value, 0);

  // 调整分数以不超过每日总分上限
  let adjustedValue = value;
  if (currentTotal + value > MAX_DAILY_SCORE) {
    adjustedValue = Math.max(0, MAX_DAILY_SCORE - currentTotal);
    console.warn(`⚠️ Daily score cap reached. Adjusting score from ${value} to ${adjustedValue}`);
    
    if (adjustedValue <= 0) {
      console.warn('⛔ Maximum daily score reached.');
      return 0;
    }
  }

  // 挑战类型特殊检查
  if (actionType === 'challenge_complete') {
    // 获取今日挑战数量和分数
    const challengeEntries = rhythmScoreLog.filter(
      (entry: any) => entry.date === today && entry.actionType === 'challenge_complete'
    );
    const challengeCount = challengeEntries.length;
    const challengeScore = challengeEntries.reduce((sum: number, entry: any) => sum + entry.value, 0);
    
    // 检查挑战数量限制
    if (challengeCount >= MAX_CHALLENGE_COUNT) {
      console.warn('⛔ Maximum daily challenges reached.');
      return 0;
    }
    
    // 检查挑战分数限制
    if (challengeScore + adjustedValue > MAX_CHALLENGE_SCORE) {
      const newValue = Math.max(0, MAX_CHALLENGE_SCORE - challengeScore);
      console.warn(`⚠️ Challenge score cap reached. Adjusting from ${adjustedValue} to ${newValue}`);
      adjustedValue = newValue;
      
      if (adjustedValue <= 0) {
        console.warn('⛔ Maximum challenge score reached.');
        return 0;
      }
    }
  }

  // 目标和子任务类型特殊检查
  if (actionType === 'goal_complete' || actionType === 'subtask_complete') {
    if (!goalId) {
      console.warn('⛔ goalId is required for goal and subtask actions.');
      return 0;
    }
    
    // 获取目标+子任务总分和单个目标分数
    const goalSubtaskEntries = rhythmScoreLog.filter(
      (entry: any) => entry.date === today && 
      (entry.actionType === 'goal_complete' || entry.actionType === 'subtask_complete')
    );
    
    const goalSubtaskTotal = goalSubtaskEntries.reduce(
      (sum: number, entry: any) => sum + entry.value, 0
    );
    
    const singleGoalEntries = rhythmScoreLog.filter(
      (entry: any) => entry.date === today && 
      (entry.actionType === 'goal_complete' || entry.actionType === 'subtask_complete') &&
      entry.goalId === goalId
    );
    
    const singleGoalScore = singleGoalEntries.reduce(
      (sum: number, entry: any) => sum + entry.value, 0
    );
    
    // 调整分数以不超过单个目标限制
    if (singleGoalScore + adjustedValue > MAX_SINGLE_GOAL_SCORE) {
      const newValue = Math.max(0, MAX_SINGLE_GOAL_SCORE - singleGoalScore);
      console.warn(`⚠️ Single goal cap reached. Adjusting from ${adjustedValue} to ${newValue}`);
      adjustedValue = newValue;
      
      if (adjustedValue <= 0) {
        console.warn('⛔ Single goal score limit reached.');
        return 0;
      }
    }
    
    // 调整分数以不超过每日目标+子任务总分限制
    if (goalSubtaskTotal + adjustedValue > MAX_GOAL_SUBTASK_COMBINED_SCORE) {
      const newValue = Math.max(0, MAX_GOAL_SUBTASK_COMBINED_SCORE - goalSubtaskTotal);
      console.warn(`⚠️ Goal+Subtask cap reached. Adjusting from ${adjustedValue} to ${newValue}`);
      adjustedValue = newValue;
      
      if (adjustedValue <= 0) {
        console.warn('⛔ Goal+Subtask score limit reached.');
        return 0;
      }
    }
  }

  // 微任务类型特殊检查
  if (actionType === 'microtask_complete') {
    const microtaskCount = getMicrotaskCount();
    
    if (microtaskCount >= MAX_MICROTASK_COUNT) {
      console.warn('⛔ Maximum daily microtasks reached.');
      return 0;
    }
  }

  // 创建记录对象
  const entry: any = {
    date: today,
    value: adjustedValue, // 使用经过所有调整的值
    actionType,
    timestamp: new Date().toISOString(),
  };
  
  // 如果是goal或subtask，添加goalId
  if (goalId && (actionType === 'goal_complete' || actionType === 'subtask_complete')) {
    entry.goalId = goalId;
  }

  // 添加得分记录
  rhythmScoreLog.push(entry);

  // 保存到本地存储
  localStorage.setItem('rhythmScoreLog', JSON.stringify(rhythmScoreLog));
  
  // 返回实际记录的分数值
  return adjustedValue;
};

/**
 * 获取今日微任务数量
 */
function getMicrotaskCount(): number {
  try {
    const today = getTodayDate();
    // 微任务完成记录保存在xpTracker中
    const xpTracker = JSON.parse(localStorage.getItem('xpTracker') || '{}');
    return xpTracker[today]?.microtaskCount || 0;
  } catch (error) {
    console.error('Error getting microtask count:', error);
    return 0;
  }
}

/**
 * 获取今天的目标和子任务总分
 */
export const getTodayGoalSubtaskScore = (): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) =>
      entry.date === today &&
      (entry.actionType === 'subtask_complete' || entry.actionType === 'goal_complete')
    )
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
};

/**
 * 获取今天完成的挑战数量
 */
export const getTodayChallengeCount = (): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) => 
      entry.date === today && 
      entry.actionType === 'challenge_complete'
    ).length;
};

/**
 * 获取今天挑战获得的分数
 */
export const getTodayChallengeScore = (): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) => 
      entry.date === today && 
      entry.actionType === 'challenge_complete'
    )
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
};

/**
 * 获取特定动作类型今天的记录数量
 */
export const getTodayActionTypeCount = (actionType: string): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog.filter(
    (entry: any) => entry.date === today && entry.actionType === actionType
  ).length;
};

/**
 * 获取特定动作类型今天的得分总和
 */
export const getTodayActionTypeScore = (actionType: string): number => {
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const today = getTodayDate();
  return rhythmScoreLog
    .filter((entry: any) => entry.date === today && entry.actionType === actionType)
    .reduce((acc: number, entry: any) => acc + entry.value, 0);
};