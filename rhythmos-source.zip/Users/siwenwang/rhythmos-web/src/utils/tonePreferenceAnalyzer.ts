// /utils/tonePreferenceAnalyzer.ts - 改进版本

import { getToneScoreMapByDays } from './writeToneLog';
import { getSignatureMap } from '../SignatureMap';

// 定义语调常量，以便类型安全
export type ToneType = 'gentle' | 'supportive' | 'balanced' | 'motivated' | 'directive' | 'rational' | 'visionary';

// 定义分析结果类型
export interface TonePreference {
  dominant: ToneType;
  suggested: ToneType;
  dominantScore: number;
  suggestedScore: number;
  confidence: number; // 0-1之间的值，表示建议的可信度
  switchReason: 'fatigue' | 'strong_preference'; // 推荐原因
}

// 语调到Persona的映射
const TONE_TO_PERSONA: Record<string, string> = {
  gentle: 'rhea',
  supportive: 'rhea',
  balanced: 'aurelia',
  motivated: 'caelum',
  directive: 'caelum',
  rational: 'aurelia',
  visionary: 'aurelia'
};

// 以天为单位的缓存
const analysisCache: Record<number, {timestamp: number, result: TonePreference | null}> = {};

/**
 * 分析语调疲劳并提供切换建议 - 改进版本
 * @param days 分析的天数范围
 * @param forceRefresh 是否强制刷新缓存
 * @returns 语调建议结果或null
 */
export function analyzeTonePreference(days = 14, forceRefresh = false): TonePreference | null {
  // 使用缓存避免频繁分析
  const now = Date.now();
  if (!forceRefresh && analysisCache[days] && now - analysisCache[days].timestamp < 1000 * 60 * 30) { // 30分钟内
    return analysisCache[days].result;
  }
  
  // 🔥 新增：检查当前活跃 tone 和最近切换历史
  const currentTone = getActivePersonaTone();
  const recentSwitch = getLastToneSwitch();
  
  // 🔥 如果用户最近刚切换过（48小时内），不建议切换
  if (recentSwitch && isRecentSwitch(recentSwitch.timestamp, 48)) {
    console.log('[TONE_ANALYSIS] Recent switch detected, skipping suggestion');
    analysisCache[days] = { timestamp: now, result: null };
    return null;
  }
  
  // 调用现有函数获取语调得分
  const scoreMap = getToneScoreMapByDays(days);
  const entries = Object.entries(scoreMap);
  
  // 🔥 提高数据要求：需要至少5次反馈和3种不同语调
  if (entries.length < 3) {
    analysisCache[days] = { timestamp: now, result: null };
    return null;
  }
  
  const totalFeedbacks = entries.reduce((sum, [, score]) => sum + score, 0);
  if (totalFeedbacks < 5) {
    console.log('[TONE_ANALYSIS] Insufficient feedback data:', totalFeedbacks);
    analysisCache[days] = { timestamp: now, result: null };
    return null;
  }

  // 按分数排序
  const sorted = entries.sort((a, b) => b[1] - a[1]);
  const [dominantTone, dominantScore] = sorted[0];
  const [secondTone, secondScore] = sorted[1] || [null, 0];
  
  // 🔥 检查当前 tone 是否已经是最优的
  const currentToneScore = scoreMap[currentTone] || 0;
  const currentToneRank = sorted.findIndex(([tone]) => tone === currentTone);
  
  // 如果当前 tone 已经是前两名，不建议切换
  if (currentToneRank < 2 && currentToneScore > 0) {
    console.log('[TONE_ANALYSIS] Current tone performs well, no switch needed');
    analysisCache[days] = { timestamp: now, result: null };
    return null;
  }
  
  // 计算总分和比率
  const totalScore = sorted.reduce((sum, [, v]) => sum + v, 0);
  const dominantRatio = dominantScore / totalScore;
  
  // 🔥 动态调整阈值基于样本大小和差距
  const minSamples = 8; // 最少需要8次反馈
  const dynamicThreshold = totalFeedbacks < minSamples 
    ? 0.65 // 样本少时要求更高的阈值
    : Math.max(0.5, 0.7 - (totalFeedbacks - minSamples) * 0.02); // 样本多时可以降低阈值
  
  // 🔥 检查分数差距：主导 tone 必须明显优于其他 tone
  const scoreGap = dominantScore - secondScore;
  const minScoreGap = Math.max(2, totalFeedbacks * 0.2); // 动态最小差距
  
  // 判断是否需要建议切换
  let result: TonePreference | null = null;
  
  // 情况1: 语调疲劳 - 某个 tone 占主导地位
  if (dominantRatio >= dynamicThreshold && scoreGap >= minScoreGap) {
    // 确保建议的 tone 不是当前 tone
    if (dominantTone === currentTone) {
      console.log('[TONE_ANALYSIS] Dominant tone is current tone, no switch needed');
      analysisCache[days] = { timestamp: now, result: null };
      return null;
    }
    
    result = {
      dominant: currentTone,
      suggested: dominantTone as ToneType,
      dominantScore: currentToneScore,
      suggestedScore: dominantScore,
      confidence: calculateConfidence(dominantRatio, scoreGap, totalFeedbacks),
      switchReason: 'strong_preference'
    };
  }
  
  // 情况2: 当前 tone 表现不佳
  else if (currentToneScore < totalScore * 0.15 && dominantScore > currentToneScore * 2) {
    result = {
      dominant: currentTone,
      suggested: dominantTone as ToneType,
      dominantScore: currentToneScore,
      suggestedScore: dominantScore,
      confidence: calculateConfidence(dominantRatio, scoreGap, totalFeedbacks),
      switchReason: 'fatigue'
    };
  }
  
  // 🔥 最终验证：检查是否最近已经推荐过相同建议
  if (result && hasRecentlySuggestedSameTone(result.suggested, 7)) {
    console.log('[TONE_ANALYSIS] Same suggestion made recently, skipping');
    result = null;
  }
  
  // 更新缓存
  analysisCache[days] = { timestamp: now, result };
  return result;
}

/**
 * 计算推荐置信度
 */
function calculateConfidence(ratio: number, scoreGap: number, totalFeedbacks: number): number {
  // 基于比率的信心（0.5-1.0之间）
  const ratioConfidence = Math.min(1, (ratio - 0.5) * 2);
  
  // 基于分数差距的信心
  const gapConfidence = Math.min(1, scoreGap / 5);
  
  // 基于样本数量的信心
  const sampleConfidence = Math.min(1, totalFeedbacks / 15);
  
  // 综合置信度
  return (ratioConfidence * 0.4 + gapConfidence * 0.4 + sampleConfidence * 0.2);
}

/**
 * 检查是否是最近的切换
 */
function isRecentSwitch(timestamp: string, hoursThreshold: number): boolean {
  const switchTime = new Date(timestamp);
  const now = new Date();
  const hoursDiff = (now.getTime() - switchTime.getTime()) / (1000 * 60 * 60);
  return hoursDiff < hoursThreshold;
}

/**
 * 获取最后一次 tone 切换记录
 */
function getLastToneSwitch(): {from: ToneType; to: ToneType; timestamp: string} | null {
  try {
    const history = getToneSwitchHistory();
    return history.length > 0 ? history[history.length - 1] : null;
  } catch (error) {
    console.error('Error getting last tone switch:', error);
    return null;
  }
}

/**
 * 检查最近是否推荐过相同的 tone
 */
function hasRecentlySuggestedSameTone(suggestedTone: ToneType, days: number): boolean {
  try {
    const suggestions = JSON.parse(localStorage.getItem('toneSuggestionHistory') || '[]');
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    return suggestions.some((suggestion: any) => 
      suggestion.suggested === suggestedTone &&
      new Date(suggestion.timestamp) >= cutoffDate
    );
  } catch (error) {
    console.error('Error checking suggestion history:', error);
    return false;
  }
}

/**
 * 记录语调推荐历史
 */
export function recordToneSuggestion(suggested: ToneType): void {
  try {
    const suggestions = JSON.parse(localStorage.getItem('toneSuggestionHistory') || '[]');
    suggestions.push({
      suggested,
      timestamp: new Date().toISOString()
    });
    
    // 保持记录不超过20条
    const trimmedSuggestions = suggestions.slice(-20);
    localStorage.setItem('toneSuggestionHistory', JSON.stringify(trimmedSuggestions));
  } catch (error) {
    console.error('Error recording tone suggestion:', error);
  }
}

/**
 * 获取语调的互补或替代语调
 */
function getComplementaryTone(tone: ToneType): ToneType {
  const complements: Record<ToneType, ToneType> = {
    gentle: 'directive',
    supportive: 'motivated',
    balanced: 'visionary',
    motivated: 'supportive',
    directive: 'gentle',
    rational: 'gentle',
    visionary: 'balanced'
  };
  
  return complements[tone] || 'balanced';
}

/**
 * 获取当前活跃的语调
 */
export function getActivePersonaTone(): ToneType {
  const activePersona = localStorage.getItem('initPersona') || 'rhea';
  const personaTones: Record<string, ToneType> = {
    rhea: 'gentle',
    caelum: 'directive',
    aurelia: 'rational',
    lucis: 'visionary', // 🔥 新增
    niveus: 'balanced'  // 🔥 新增
  };
  
  return personaTones[activePersona] || 'balanced';
}

/**
 * 设置活跃的语调
 */
export function setActivePersonaTone(tone: ToneType): void {
  // 获取对应的persona
  const persona = TONE_TO_PERSONA[tone] || 'rhea';
  
  // 记录之前的语调
  const prevTone = getActivePersonaTone();
  
  // 设置新的persona
  localStorage.setItem('initPersona', persona);
  
  // 记录语调切换
  if (prevTone !== tone) {
    recordToneSwitch(prevTone, tone);
  }
  
  // 触发事件通知其他组件
  window.dispatchEvent(new Event('persona-tone-changed'));
}

/**
 * 记录语调切换到历史
 */
export function recordToneSwitch(from: ToneType, to: ToneType): void {
  try {
    const history = getToneSwitchHistory();
    const timestamp = new Date().toISOString();
    
    history.push({ from, to, timestamp });
    
    // 保持记录不超过50条
    const trimmedHistory = history.slice(-50);
    localStorage.setItem('toneSwitchLog', JSON.stringify(trimmedHistory));
    
    console.log(`[TONE_SWITCH] ${from} → ${to}`);
  } catch (error) {
    console.error('Error recording tone switch:', error);
  }
}

/**
 * 获取语调切换历史
 */
export function getToneSwitchHistory(): Array<{
  from: ToneType;
  to: ToneType;
  timestamp: string;
}> {
  try {
    const raw = localStorage.getItem('toneSwitchLog');
    return raw ? JSON.parse(raw) : [];
  } catch (error) {
    console.error('Error reading tone switch history:', error);
    return [];
  }
}

/**
 * 检查最近是否已经提示过相同的建议
 */
export function hasRecentlySuggestedTone(dominant: ToneType, suggested: ToneType, days = 7): boolean {
  const history = getToneSwitchHistory();
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);
  
  return history.some(entry => 
    entry.from === dominant && 
    entry.to === suggested &&
    new Date(entry.timestamp) >= cutoffDate
  );
}

/**
 * 获取指定时间段内的顶级语调
 */
export function getTopTone(days = 3): ToneType {
  const scoreMap = getToneScoreMapByDays(days);
  const sorted = Object.entries(scoreMap).sort((a, b) => b[1] - a[1]);
  return (sorted[0]?.[0] || 'gentle') as ToneType;
}