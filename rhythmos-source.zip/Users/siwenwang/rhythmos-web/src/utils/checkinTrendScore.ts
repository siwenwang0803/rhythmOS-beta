import { writeRhythmScore } from './rhythmscoreEngine';
import { getTodayDate } from './rhythmDayEngine';

export const getTrendScoreChange = (yesterday: number, today: number): number => {
  const diff = today - yesterday;
  if (diff >= 2) return 3;
  if (diff === 1) return 1.5;
  if (diff === 0) return 0;
  if (diff === -1) return -1.5;
  if (diff <= -2) return -3;
  return 0;
};

export const handleTrendCheckin = (todayTrend: number): void => {
  const today = getTodayDate();
  const rhythmScoreLog = JSON.parse(localStorage.getItem('rhythmScoreLog') || '[]');
  const alreadyCheckedIn = rhythmScoreLog.some(
    (entry: any) => entry.date === today && entry.actionType === 'daily_checkin'
  );
  if (alreadyCheckedIn) {
    console.warn('⛔ Already checked in today.');
    return;
  }

  const lastTrend = parseInt(localStorage.getItem('lastTrend') || '0', 10);
  const delta = getTrendScoreChange(lastTrend, todayTrend);

  writeRhythmScore(delta, 'daily_checkin');
  localStorage.setItem('lastTrend', String(todayTrend));
};

