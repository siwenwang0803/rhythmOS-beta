// mbtiToPersonaMap.ts

/**
 * 将 MBTI 性格类型映射到对应的 Persona
 * 
 * 映射关系:
 * - NF (理想主义者/外交家): 适合 rhea (温和支持型) 和 lucis (愿景稳定型)
 * - NT (理性主义者/分析家): 适合 aurelia (理性清晰型) 和 niveus (精确逻辑型)
 * - SJ (守卫者/保护者): 适合 niveus (精确逻辑型) 
 * - SP (探索者/艺术家): 适合 caelum (大胆决断型) 和 lucis (愿景稳定型)
 */

export const mbtiToPersonaMap: Record<string, string> = {
  // 理想主义者/外交家 (NF)
  infp: 'rhea',    // 调和者需要温和支持
  enfp: 'lucis',   // 活跃想象力但需要稳定基础
  infj: 'rhea',    // 需要温和支持的理想主义者
  enfj: 'rhea',    // 具有温暖魅力的人格
  
  // 理性主义者/分析家 (NT)
  intp: 'aurelia', // 理性思考者
  entp: 'aurelia', // 创新者需要清晰思考
  intj: 'niveus',  // 系统规划者需要精确逻辑
  entj: 'caelum',  // 指挥官型需要大胆决断
  
  // 守卫者/保护者 (SJ)
  istj: 'niveus',  // 逻辑细致的检查者
  estj: 'niveus',  // 井然有序的管理者
  isfj: 'rhea',    // 温暖体贴的保护者
  esfj: 'rhea',    // 关怀细致的供给者
  
  // 探索者/艺术家 (SP)
  istp: 'caelum',  // 实用主义的决策者
  estp: 'caelum',  // 大胆的冒险家
  isfp: 'lucis',   // 艺术家需要稳定愿景
  esfp: 'lucis'    // 表演者需要稳定愿景
};

/**
 * Personas 对应的说明:
 * 
 * rhea   - "Gentle & Supportive" (温和支持型) - 适合情感丰富的理想主义者和关怀者
 * aurelia - "Clear & Rational" (理性清晰型) - 适合逻辑分析和创新思考的人
 * niveus - "Precise & Logical" (精确逻辑型) - 适合系统规划和精确操作的人
 * lucis  - "Steady & Grounded" (愿景稳定型) - 适合需要稳定基础但有创意的人
 * caelum - "Bold & Decisive" (大胆决断型) - 适合行动导向和冒险精神的人
 */

// 根据不同 MBTI 维度可能的偏好映射
export const mbtiDimensionToPersona = {
  // 能量来源
  extraversion: ['caelum', 'rhea'],     // 外向型更倾向于活力和支持
  introversion: ['niveus', 'aurelia'],  // 内向型更倾向于精确和理性
  
  // 信息获取
  sensing: ['niveus', 'lucis'],         // 实感型更倾向于精确和稳定
  intuition: ['aurelia', 'caelum'],     // 直觉型更倾向于理性和大胆
  
  // 决策方式
  thinking: ['niveus', 'aurelia'],      // 思考型更倾向于精确和理性
  feeling: ['rhea', 'lucis'],           // 情感型更倾向于温和和稳定
  
  // 生活方式
  judging: ['niveus', 'caelum'],        // 判断型更倾向于精确和决断
  perceiving: ['lucis', 'aurelia']      // 感知型更倾向于稳定和理性
};
