// /utils/xpEngine.ts - Direct Fix

/**
 * XP Engine - Critical Fix
 * Focus on the addXp function which appears to be the root cause
 */

// Get XP data with basic error handling
export const getXpData = (): any => {
    try {
      const raw = localStorage.getItem('personaXpLog');
      return raw ? JSON.parse(raw) : {};
    } catch (error) {
      console.error('Error getting XP data:', error);
      return {};
    }
  };
  
  // Save XP data and trigger update events
  export const saveXpData = (data: any) => {
    // Save to localStorage
    localStorage.setItem('personaXpLog', JSON.stringify(data));
    
    // Trigger custom event to notify components
    window.dispatchEvent(new Event('xp-updated'));
    window.dispatchEvent(new Event('rhythm-score-updated'));
  };
  
  // Initialize XP if needed
  export const initXpIfNeeded = () => {
    const xp = getXpData();
    const base = {
      rhea: { xp: 0, history: [] },
      caelum: { xp: 0, history: [] },
      aurelia: { xp: 0, history: [] },
      lucis: { xp: 0, history: [] },
      niveus: { xp: 0, history: [] },
    };
    const merged = { ...base, ...xp };
    saveXpData(merged);
  };
  
  // CRITICAL FIX: Complete rewrite of addXp function
  export const addXp = (persona: string, amount: number) => {
    if (!persona) {
      console.error('Invalid persona name');
      return 0;
    }
    
    console.log(`ADDING ${amount} XP to ${persona}`);
    
    // CRITICAL: Use direct localStorage read instead of getXpData()
    // This ensures we're working with the most current data
    let data;
    try {
      const raw = localStorage.getItem('personaXpLog');
      data = raw ? JSON.parse(raw) : {};
    } catch (e) {
      console.error('Error parsing personaXpLog:', e);
      data = {};
    }
    
    // Ensure persona exists in data
    if (!data[persona]) {
      data[persona] = { xp: 0, history: [] };
    }
    
    // Get current XP value
    const currentXp = typeof data[persona].xp === 'number' ? data[persona].xp : 0;
    console.log(`Current XP for ${persona}: ${currentXp}`);
    
    // Add XP - Ensure numeric addition
    const newXp = currentXp + amount;
    data[persona].xp = newXp;
    
    // Add to history
    const now = new Date().toISOString();
    data[persona].history.push({
      amount: amount,
      timestamp: now,
      newValue: newXp
    });
    
    // CRITICAL: Direct localStorage write
    const jsonData = JSON.stringify(data);
    localStorage.setItem('personaXpLog', JSON.stringify(data));
    
    // Verify the write was successful
    try {
      const verification = localStorage.getItem('personaXpLog');
      const verifiedData = verification ? JSON.parse(verification) : null;
      if (verifiedData && verifiedData[persona]) {
        console.log(`VERIFIED: ${persona} now has ${verifiedData[persona].xp} XP`);
      } else {
        console.error('XP verification failed');
      }
    } catch (e) {
      console.error('Error during XP verification:', e);
    }
    
    // Trigger events to update UI
    window.dispatchEvent(new Event('xp-updated'));
    
    // Return the new XP value
    return newXp;
  };
  
  export const xpMilestones = [0, 30, 80, 150];
  
  export const titleMap: Record<string, string[]> = {
    rhea: ["Gentle Initiate", "Supportive Guide", "Emotional Mentor"],
    caelum: ["Decisive Novice", "Strategic Mover", "Clarity Coach"],
    aurelia: ["Rational Observer", "Analytical Thinker", "Insight Architect"],
    lucis: ["Calm Seed", "Grounded Doer", "Organic Synthesist"],
    niveus: ["Pattern Starter", "Feedback Weaver", "Metric Strategist"]
  };
  
  // Get current persona title
  export const getCurrentTitle = (persona: string, xp: number): string => {
    // Get titles list, use default if not found
    const titles = titleMap[persona] || ["Explorer"];
    
    // Find appropriate title based on XP
    for (let i = xpMilestones.length - 1; i >= 0; i--) {
      if (xp >= xpMilestones[i]) {
        return titles[i] || titles[0];
      }
    }
    
    // Default to first title
    return titles[0];
  };
  
  // Force refresh XP data
  export const forceRefreshAllXpData = () => {
    const data = getXpData();
    saveXpData(data); // Save again to trigger update event
  };
  
  // Add the missing setPersonaXp function
  export const setPersonaXp = (persona: string, amount: number) => {
    if (!persona) {
      console.error('Invalid persona name');
      return;
    }
    
    console.log(`SETTING ${persona}'s XP to ${amount}`);
    
    // Direct localStorage access
    let data;
    try {
      const raw = localStorage.getItem('personaXpLog');
      data = raw ? JSON.parse(raw) : {};
    } catch (e) {
      console.error('Error parsing personaXpLog:', e);
      data = {};
    }
    
    // Ensure persona exists
    if (!data[persona]) {
      data[persona] = { xp: 0, history: [] };
    }
    
    // Record current time
    const now = new Date().toISOString();
    
    // Set the new XP value
    const oldValue = data[persona].xp || 0;
    data[persona].xp = amount;
    
    // Add a history record
    data[persona].history.push({
      amount: amount - oldValue,
      timestamp: now,
      oldValue: oldValue,
      newValue: amount,
      note: 'Manual adjustment'
    });
    
    // Save to localStorage
    localStorage.setItem('personaXpLog', JSON.stringify(data));
    
    // Verify the write
    try {
      const verification = localStorage.getItem('personaXpLog');
      const verifiedData = verification ? JSON.parse(verification) : null;
      if (verifiedData && verifiedData[persona]) {
        console.log(`VERIFIED: ${persona}'s XP set to ${verifiedData[persona].xp}`);
      }
    } catch (e) {
      console.error('Error during XP verification:', e);
    }
    
    // Trigger update events
    window.dispatchEvent(new Event('xp-updated'));
  };
