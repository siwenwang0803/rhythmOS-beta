export function isValidTrend(value: string | null): value is RhythmTrend {
    return ['collapsed', 'wavy', 'stable', 'rising'].includes(value ?? '');
  }
  
  export function isValidPersona(value: string | null): value is PersonaKey {
    return ['rhea', 'aurelia', 'lucis', 'niveus', 'caelum'].includes(value ?? '');
  }
  
  export function isValidTone(value: string | null): value is ToneStyle {
    return ['gentle', 'directive', 'rational', 'visionary', 'motivated'].includes(value ?? '');
  }
  