// /utils/getDriftHistory.ts

import { getSignatureMap } from '../SignatureMap'; // 确保路径对 SignatureMap.ts 正确

export const getDriftHistory = (days: number): string[] => {
  const feedbacks = getSignatureMap().cueFeedbackLog || [];
  const now = Date.now();
  const cutoff = now - days * 24 * 60 * 60 * 1000;

  return feedbacks
    .filter(f => {
      const time = new Date(f.timestamp).getTime();
      return f.persona && time >= cutoff;
    })
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    .map(f => f.persona); // ['rhea', 'aurelia', 'caelum', ...]
};
