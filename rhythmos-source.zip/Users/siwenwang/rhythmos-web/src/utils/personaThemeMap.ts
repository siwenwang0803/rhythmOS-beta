// /utils/personaThemeMap.ts

export type PersonaKey = 'rhea' | 'caelum' | 'aurelia' | 'lucis' | 'niveus';

export const personaThemeMap: Record<PersonaKey, {
  label: string;
  emoji: string;
  baseColor: string;
  gradient: string;
  tone: string;
  fontFamily: string;
  textColor: string;
  styleTagline: string;
}> = {
  rhea: {
    label: 'Rhea',
    emoji: '💗',
    baseColor: '#F5CFCF',
    gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
    tone: 'gentle',
    fontFamily: `'Nunito', sans-serif`,
    textColor: '#6B4B4B',
    styleTagline: 'gentle × empathic × nurturing'  // 更符合 gentle tone
  },
  caelum: {
    label: 'Caelum',
    emoji: '💠',
    baseColor: '#4B6587',
    gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
    tone: 'motivated',
    fontFamily: `'Inter', sans-serif`,
    textColor: '#FFFFFF',
    styleTagline: 'driven × energetic × action-oriented'  // 符合 motivated tone
  },
  aurelia: {
    label: 'Aurelia',
    emoji: '🧠',
    baseColor: '#D8A7CA',
    gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
    tone: 'rational',
    fontFamily: `'Inter', sans-serif`,
    textColor: '#502A4B',
    styleTagline: 'logical × analytical × systematic'  // 更符合 rational tone
  },
  lucis: {
    label: 'Lucis',
    emoji: '🌱',
    baseColor: '#A4D8C5',
    gradient: 'linear-gradient(135deg, #E8F5C7, #A4D8C5)',
    tone: 'visionary',
    fontFamily: `'Nunito', sans-serif`,
    textColor: '#205040',
    styleTagline: 'forward-thinking × creative × inspiring'  // 符合 visionary tone
  },
  niveus: {
    label: 'Niveus',
    emoji: '📊',
    baseColor: '#C7C7C7',
    gradient: 'linear-gradient(135deg, #E8E8E8, #C7C7C7)',
    tone: 'directive',
    fontFamily: `'Inter', sans-serif`,
    textColor: '#333333',
    styleTagline: 'decisive × authoritative × results-focused'  // 符合 directive tone
  }
};
