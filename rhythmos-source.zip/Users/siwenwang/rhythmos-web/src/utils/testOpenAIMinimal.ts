// /src/utils/testOpenAIMinimal.ts
// 最小化的 OpenAI 测试

export async function testOpenAIMinimal() {
    const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    
    if (!apiKey) {
      throw new Error('No API key found');
    }
  
    console.log('Testing with key:', apiKey.slice(0, 20) + '...');
  
    // 最简单的请求
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'user',
            content: 'Say "Hi"'
          }
        ],
        max_tokens: 5, // 极少的 token
        temperature: 0
      })
    });
  
    if (!response.ok) {
      const error = await response.json();
      console.error('Error details:', error);
      
      // 详细的错误信息
      if (response.status === 429) {
        const retryAfter = response.headers.get('retry-after');
        const rateLimitRemaining = response.headers.get('x-ratelimit-remaining-requests');
        const rateLimitReset = response.headers.get('x-ratelimit-reset-requests');
        
        console.error('Rate limit info:', {
          retryAfter,
          remaining: rateLimitRemaining,
          resetAt: rateLimitReset
        });
      }
      
      throw new Error(`API Error ${response.status}: ${JSON.stringify(error)}`);
    }
  
    const data = await response.json();
    return data;
  }
  
  // 在浏览器控制台测试
  export function runMinimalTest() {
    testOpenAIMinimal()
      .then(result => {
        console.log('✅ Success!', result);
      })
      .catch(error => {
        console.error('❌ Failed:', error);
      });
  }