// /src/utils/exportCRECorpus.ts

export function exportCRECorpus(corpus: any[]) {
    const blob = new Blob([JSON.stringify(corpus, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'cre-corpus.json';
    a.click();
    URL.revokeObjectURL(url);
  }
  