// outputRouter.ts (corrected to use updated generateCRE logic)

import { RhythmSignatureMap } from './rhythmSignature';
import { generateCRE } from './creGenerator';
import { getCREStylePreference } from './creStylePreference';

export function generateCREOutput({
  trend,
  stage,
  taskType,
  signature
}: {
  trend: string;
  stage: string;
  taskType: 'minimal' | 'light' | 'normal' | 'challenge';
  signature: RhythmSignatureMap;
}): { cre: string; tone: string; variant: string; source: 'preset' } {
  const override = localStorage.getItem('creStyleOverride');
  const tone = override && override !== 'skip' ? override : getCREStylePreference(signature).tone;

  const cue = generateCRE({ trend, stage, taskType, signature, override: tone });

  return {
    cre: cue,
    tone,
    variant: 'base',
    source: 'preset'
  };
}



