// speak-interface/CRECueResponder.ts

export const generateCREStyleReply = (
    input: string,
    tone: string = 'gentle',
    persona: string = 'lucis'
  ): string => {
    const lower = input.toLowerCase()
    const base = lower.includes('stuck') ? 'Even small steps move you forward.' :
                 lower.includes('lost') ? 'Clarity returns when you pause and reframe.' :
                 lower.includes('tired') ? 'Rest is not failure — it’s recovery.' :
                 lower.includes('hope') ? 'Hope can be your rhythm’s restart point.' :
                 'Let rhythm help you shift gently from thought to motion.'
  
    if (tone === 'gentle') {
      return `💙 ${base}`
    } else if (tone === 'directive') {
      return `🔥 Decide your next move. ${base}`
    } else if (tone === 'balanced') {
      return `🧭 Breathe. Then align. ${base}`
    } else if (tone === 'supportive') {
      return `🌱 You don’t have to carry this alone. ${base}`
    } else if (tone === 'visionary') {
      return `🌠 Imagine a path beyond this. ${base}`
    }
  
    return base
  }
  