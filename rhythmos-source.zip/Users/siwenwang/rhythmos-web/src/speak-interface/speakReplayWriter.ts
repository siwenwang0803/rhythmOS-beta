// speak-interface/speakReplayWriter.ts

interface SpeakReplayEntry {
    userInput: string
    systemResponse: string
    emotion: string
    tone: string
    persona: string
    timestamp: number
  }
  
  export const writeSpeakReplayLog = (entry: SpeakReplayEntry) => {
    const key = 'speakReplayLog'
    const existing = JSON.parse(localStorage.getItem(key) || '[]')
    const updated = [...existing, entry]
    localStorage.setItem(key, JSON.stringify(updated))
  }
  