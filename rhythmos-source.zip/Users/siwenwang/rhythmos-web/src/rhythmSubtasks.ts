import { classifyGoalIntent } from './goalIntentClassifier';

export interface RhythmSubtask {
  id: string;
  goalId: string;
  parentGoalId?: string; // 添加这个字段以兼容新的代码
  text?: string; // 添加这个字段以存储子任务文本
  title: string;
  createdAt: string;
  status: 'pending' | 'completed' | 'skipped';
  difficulty: 'minimal' | 'light' | 'normal' | 'challenge';
  notes?: string;
  cue?: string; // 激励提示
  tone?: string; // 语气
  taskType?: string; // 任务类型
}

export function generateInitialSubtasks(goalId: string, title: string): RhythmSubtask[] {
  console.log('Generating initial subtasks for goal:', title);
  
  // 检测目标意图
  const intent = classifyGoalIntent(title);
  console.log('Goal intent classified as:', intent);
  
  // 为阅读相关的目标创建特定的子任务
  if (intent === 'reading' || intent === 'review' || 
      title.toLowerCase().includes('read') || 
      title.toLowerCase().includes('book')) {
    console.log('Creating reading-specific subtasks');
    
    const readingSubtasks: RhythmSubtask[] = [
      {
        id: crypto.randomUUID(),
        goalId,
        parentGoalId: goalId,
        title: `Choose which book to read first`,
        text: `Choose which book to read first`,
        createdAt: new Date().toISOString(),
        status: 'pending',
        difficulty: 'minimal',
        cue: 'Small choices lead to big journeys.'
      },
      {
        id: crypto.randomUUID(),
        goalId,
        parentGoalId: goalId,
        title: `Schedule dedicated reading time in your calendar`,
        text: `Schedule dedicated reading time in your calendar`,
        createdAt: new Date().toISOString(),
        status: 'pending',
        difficulty: 'light',
        cue: 'Protected time creates meaningful space.'
      },
      {
        id: crypto.randomUUID(),
        goalId,
        parentGoalId: goalId,
        title: `Read the first chapter and take notes`,
        text: `Read the first chapter and take notes`,
        createdAt: new Date().toISOString(),
        status: 'pending',
        difficulty: 'normal',
        cue: 'The first step is often the most important.'
      }
    ];
    
    return readingSubtasks;
  }
  
  // 通用子任务（非阅读目标的默认子任务）
  const genericSubtasks: RhythmSubtask[] = [
    {
      id: crypto.randomUUID(),
      goalId,
      parentGoalId: goalId,
      title: `Clarify the scope of: ${title}`,
      text: `Clarify the scope of: ${title}`,
      createdAt: new Date().toISOString(),
      status: 'pending',
      difficulty: 'minimal',
      cue: 'Clarity creates confidence.'
    },
    {
      id: crypto.randomUUID(),
      goalId,
      parentGoalId: goalId,
      title: `Break down "${title}" into 3 milestones`,
      text: `Break down "${title}" into 3 milestones`,
      createdAt: new Date().toISOString(),
      status: 'pending',
      difficulty: 'light',
      cue: 'Small steps make big goals achievable.'
    },
    {
      id: crypto.randomUUID(),
      goalId,
      parentGoalId: goalId,
      title: `Start the first action step toward: ${title}`,
      text: `Start the first action step toward: ${title}`,
      createdAt: new Date().toISOString(),
      status: 'pending',
      difficulty: 'normal',
      cue: 'Beginning is half the journey.'
    }
  ];

  return genericSubtasks;
}

export function saveSubtasks(subtasks: RhythmSubtask[]) {
  console.log('Saving subtasks:', subtasks);
  
  try {
    const raw = localStorage.getItem('rhythmSubtasks');
    const existing: RhythmSubtask[] = raw ? JSON.parse(raw) : [];
    
    // 确保每个子任务都有 text 字段
    const processedSubtasks = subtasks.map(subtask => ({
      ...subtask,
      text: subtask.text || subtask.title // 如果没有 text 字段，使用 title
    }));
    
    const updated = [...existing, ...processedSubtasks];
    localStorage.setItem('rhythmSubtasks', JSON.stringify(updated));
    console.log('Successfully saved subtasks to localStorage');
  } catch (error) {
    console.error('Error saving subtasks:', error);
  }
}

export function getSubtasksForGoal(goalId: string): RhythmSubtask[] {
  try {
    const raw = localStorage.getItem('rhythmSubtasks');
    if (!raw) return [];
    
    const all: RhythmSubtask[] = JSON.parse(raw);
    
    // 首先尝试使用 parentGoalId 匹配
    let matches = all.filter(task => task.parentGoalId === goalId);
    
    // 如果没有找到，尝试使用 goalId 匹配
    if (matches.length === 0) {
      matches = all.filter(task => task.goalId === goalId);
    }
    
    console.log(`Found ${matches.length} subtasks for goal ${goalId}`);
    return matches;
  } catch (error) {
    console.error('Error getting subtasks for goal:', error);
    return [];
  }
}

export function updateSubtaskStatus(id: string, newStatus: 'pending' | 'completed' | 'skipped') {
  try {
    const raw = localStorage.getItem('rhythmSubtasks') || '[]';
    const subtasks = JSON.parse(raw);
    const updated = subtasks.map((task: any) => {
      if (task.id === id) {
        return {
          ...task,
          status: newStatus,
          completedAt: newStatus === 'completed' ? new Date().toISOString() : null
        };
      }
      return task;
    });

    localStorage.setItem('rhythmSubtasks', JSON.stringify(updated));
    console.log(`Updated subtask ${id} status to ${newStatus}`);
  } catch (error) {
    console.error('Error updating subtask status:', error);
  }
}









