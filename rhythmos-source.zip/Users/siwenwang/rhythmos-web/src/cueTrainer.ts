// cueTrainer.ts

import { getPersonaBiasSummary } from './CREPersonaBiasMap'
import { creTemplates, CRETemplate } from './creTemplateRegistry'

export function getNextCRECueSuggestion(): CRETemplate | null {
  const { personaUsage } = getPersonaBiasSummary()

  const allPersonas = ['aurelia', 'lucis', 'caelum', 'rhea', 'niveus']
  const usageSorted = allPersonas.map((p) => ({
    persona: p,
    count: personaUsage[p] || 0
  })).sort((a, b) => a.count - b.count)

  const leastUsed = usageSorted[0]?.persona
  const suggestion = creTemplates.find(t => t.persona === leastUsed)

  return suggestion || null
}