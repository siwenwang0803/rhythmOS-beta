// src/constants/uiTheme.js

export const RHYTHM_COLORS = {
    collapsed: '#AEC6CF', // 平静的蓝色
    wavy: '#C3B1E1',      // 过渡的薰衣草色
    stable: '#C5D8A4',    // 稳定的绿色
    rising: '#FFB347'     // 激活的橙黄色
  };
  
  export const PERSONA_GRADIENTS = {
    rhea: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',     // 温和、共情
    caelum: 'linear-gradient(135deg, #F5E8C7, #4B6587)',   // 指导性、自信
    aurelia: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)'   // 理性、直觉
  };
  
  export const PERSONAS = {
    rhea: {
      name: 'Rhea',
      description: '温和、共情',
      fontStyle: 'Nunito, sans-serif',
      gradient: 'linear-gradient(135deg, #F5E8C7, #F5CFCF)',
      color: '#F5CFCF',
      weight: 400
    },
    caelum: {
      name: 'Caelum',
      description: '指导性、自信',
      fontStyle: 'Inter, sans-serif',
      gradient: 'linear-gradient(135deg, #F5E8C7, #4B6587)',
      color: '#4B6587',
      weight: 700
    },
    aurelia: {
      name: 'Aurelia',
      description: '理性、直觉',
      fontStyle: 'Inter, sans-serif',
      gradient: 'linear-gradient(135deg, #F5E8C7, #D8A7CA)',
      color: '#D8A7CA',
      weight: 500
    }
  };
  
  // 动画配置
  export const ANIMATION_CONFIGS = {
    microtaskCompleted: {
      duration: '0.3s',
      glowColor: '#F7DC6F',
      timingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)'
    },
    toneChange: {
      duration: '0.5s',
      timingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)'
    },
    creInteraction: {
      duration: '0.2s',
      scale: '1.1',
      timingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)'
    },
    pageTransition: {
      duration: '0.2s',
      timingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)'
    }
  };
  
  // 按角色的对话气泡样式
  export const CHAT_STYLES = {
    rhea: {
      bubbleStyle: {
        borderRadius: '12px',
        boxShadow: '0 3px 10px rgba(0, 0, 0, 0.06)',
        animation: 'float-in-wobble 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }
    },
    caelum: {
      bubbleStyle: {
        borderRadius: '8px',
        boxShadow: '0 2px 6px rgba(0, 0, 0, 0.08)',
        animation: 'pop-in 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }
    },
    aurelia: {
      bubbleStyle: {
        borderRadius: '10px',
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.07)',
        animation: 'fade-slide 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }
    }
  };