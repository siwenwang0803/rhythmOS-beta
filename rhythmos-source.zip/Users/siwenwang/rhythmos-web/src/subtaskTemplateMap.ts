// subtaskTemplateMap_EN_General.ts

export interface SubtaskTemplate {
  intent: string
  steps: string[]
}

export const subtaskTemplateMap: SubtaskTemplate[] = [
  {
    intent: 'write',
    steps: [
      'Define what you want to express',
      'Decide the structure: intro, body, conclusion',
      'Draft your first paragraph',
      'Write a supporting example or story',
      'Review and refine your writing'
    ]
  },
  {
    intent: 'plan',
    steps: [
      'Clarify the outcome you want',
      'Break it down into smaller milestones',
      'Assign a timeline to each part',
      'Identify what you need to get started',
      'Summarize your plan in one paragraph'
    ]
  },
  {
    intent: 'reflect',
    steps: [
      'Describe a recent experience or emotion',
      'Identify what it triggered inside you',
      'Ask yourself: why did this matter?',
      'Write one insight you realized',
      'Think of one small shift you want to try'
    ]
  },
  {
    intent: 'clarify',
    steps: [
      'Write down what feels unclear or stuck',
      'Rephrase it as a question',
      'Break the question into sub-parts',
      'Answer what you can, leave what you can’t',
      'Capture any helpful insight or perspective'
    ]
  },
  {
    intent: 'research',
    steps: [
      'Write the topic you want to explore',
      'Search for at least 3 relevant sources',
      'Summarize one key point from each',
      'Compare what you learned',
      'Write a synthesis or takeaway'
    ]
  },
  {
    intent: 'review',
    steps: [
      'List what you want to review',
      'Pick one and summarize key ideas',
      'Test yourself briefly',
      'Write a quick memory trigger',
      'Decide if you need to go deeper'
    ]
  },
  {
    intent: 'organize',
    steps: [
      'Decide what area or topic you want to clean up',
      'List what’s currently in that area',
      'Group or label them clearly',
      'Remove or archive things that don’t fit',
      'Rebuild the structure with simplicity in mind'
    ]
  },
  {
    intent: 'learn',
    steps: [
      'Identify the concept or skill you want to learn',
      'Find a simple explanation or source',
      'Write down the 3 most important ideas',
      'Try using or explaining it in your own words',
      'Decide your next learning step'
    ]
  },

  {
    intent: 'habit_daily',
    steps: [
      'Write down one habit you want to repeat',
      'Shrink it to a 1-minute starter version',
      'Decide exactly when you’ll do it today',
      'Do it once — no pressure to continue',
      'Reflect briefly on how it felt'
    ]
  },
  {
    intent: 'unblock',
    steps: [
      'Identify one thing you’re avoiding',
      'Ask: what’s the tiniest action you can take?',
      'Do it poorly on purpose, just to break the wall',
      'Set a 5-minute timer — go without thinking',
      'Acknowledge the effort, not the outcome'
    ]
  },
  {
    intent: 'reset',
    steps: [
      'Stand up and move to a different space',
      'Close all tabs — leave only what you need',
      'Do a 30-second breath reset',
      'Delete or discard one thing from your list',
      'Write down just ONE thing you’ll do next'
    ]
  },
  {
    intent: 'connection',
    steps: [
      'Think of one person you care about',
      'Write them a quick message, even if it’s just “thinking of you”',
      'Express one thing you appreciate about them',
      'Ask a small question that invites response',
      'Send it — no overthinking'
    ]
  },
  {
    intent: 'focus_block',
    steps: [
      'Choose one task you want to make progress on',
      'Set a 25-minute timer (Pomodoro style)',
      'Remove distractions — silence phone, close tabs',
      'Start the timer and begin — even if not perfectly',
      'At the end, write one sentence reflecting how it went'
    ]
  },
  
  {
    intent: 'explore',
    steps: [
      'Write down the topic or question that interests you',
      'List any related things you already know',
      'Brainstorm possible directions or ideas',
      'Follow one thread deeper',
      'Reflect on what excites you about it'
    ]
  },
  {
    intent: 'unknown', // 添加通用模板作为后备
    steps: [
      'Define what success looks like for this goal',
      'Identify the first small step to take',
      'Schedule time on your calendar to work on this',
      'Find resources or people who can help you',
      'Create a way to track your progress'
    ]
    }
]