// personaPathMap.ts

export interface PersonaPath {
  persona: string
  description: string
  recommendedTone: string
  taskFocus: string[]
  cueExamples: string[]
}

export const personaPathMap: PersonaPath[] = [
  {
    persona: 'caelum',
    description: 'Visionary, confident, calm under pressure',
    recommendedTone: 'directive',
    taskFocus: ['reflect', 'plan', 'write'],
    cueExamples: [
      'You are not here to repeat. You are here to reshape.',
      'Start with clarity. Move with force.',
      'Decide now. Align everything else later.'
    ]
  },
  {
    persona: 'lucis',
    description: 'Disciplined, action-oriented, momentum driven',
    recommendedTone: 'motivated',
    taskFocus: ['plan', 'write', 'execute'],
    cueExamples: [
      'Push the block. No delay.',
      'Begin now. Energy follows movement.',
      'You don’t wait for readiness. You become it.'
    ]
  },
  {
    persona: 'niveus',
    description: 'Logical, focused, composed',
    recommendedTone: 'neutral',
    taskFocus: ['clarify', 'organize', 'reflect'],
    cueExamples: [
      'List the facts. Let logic lead.',
      'Sort first. Decide after.',
      'Clarity begins with order.'
    ]
  },
  {
    persona: 'aurelia',
    description: 'Gentle, emotional, symbolic thinker',
    recommendedTone: 'gentle',
    taskFocus: ['reflect', 'write', 'calm'],
    cueExamples: [
      'Begin with softness, not strength.',
      'Let the moment meet you.',
      'This pause is sacred.'
    ]
  },
  {
    persona: 'rhea',
    description: 'Relational, empathetic, present with others',
    recommendedTone: 'warm',
    taskFocus: ['reflect', 'connect', 'support'],
    cueExamples: [
      'You don’t need to carry this alone.',
      'Kindness is also progress.',
      'Presence is your power today.'
    ]
  }
]