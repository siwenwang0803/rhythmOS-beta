// creGPTSuggest.ts (placeholder for GPT integration)

export interface GPTCueVariant {
  text: string
  tone: string
  style: 'minimal' | 'motivation' | 'directive' | 'metaphor' | 'calm'
}

export function getMockGPTSuggestions(base: string): GPTCueVariant[] {
  // Pretend we asked GPT for stylistic variants of the base
  return [
    {
      text: 'Let this breath begin your rhythm.',
      tone: 'gentle',
      style: 'calm'
    },
    {
      text: 'Go. Don’t hesitate.',
      tone: 'directive',
      style: 'directive'
    },
    {
      text: 'Your rhythm doesn’t start perfect. It starts moving.',
      tone: 'motivated',
      style: 'motivation'
    },
    {
      text: 'Breathe like the first leaf opening to the sun.',
      tone: 'visionary',
      style: 'metaphor'
    }
  ]
}