// rhythmGPTCueLibrary.ts

export const rhythmGPTCueLibrary: Record<string, string[]> = {
  caelum: [
    'Decide now. Align everything else later.',
    'You are not here to repeat. You are here to reshape.',
    'Clarity creates leadership.'
  ],
  lucis: [
    'Begin. Now.',
    'Push the block. No delay.',
    'Momentum begins with you.'
  ],
  aurelia: [
    'This pause is sacred.',
    'Let the moment meet you.',
    'Write without armor.'
  ],
  niveus: [
    'List first. Decide after.',
    'You don’t need clarity. You need order.',
    'Structure is how you breathe.'
  ],
  rhea: [
    'Kindness is also progress.',
    'You don’t have to carry this alone.',
    'Presence is your power today.'
  ]
}