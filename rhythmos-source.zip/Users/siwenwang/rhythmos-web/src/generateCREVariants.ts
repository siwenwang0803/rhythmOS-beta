// generateCREVariants.ts

import { creTemplates, CRETemplate } from './creTemplateRegistry'

export function generateCREVariants({
  tone,
  taskType,
  persona
}: {
  tone: string
  taskType: string
  persona?: string
}): CRETemplate[] {
  return creTemplates.filter(
    (t) =>
      t.tone === tone &&
      t.taskType === taskType &&
      (!persona || t.persona === persona)
  )
}