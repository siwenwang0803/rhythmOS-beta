// getCueByGoalIntent.ts

export function getCueByGoalIntent(
    intent: string,
    trend: 'collapsed' | 'wavy' | 'stable' | 'rising'
  ): { cue: string; tone: string } {
    const cueTemplateMap: Record<string, Record<string, { cue: string; tone: string }>> = {
      habit_daily: {
        collapsed: { cue: 'Start with one tiny action.', tone: 'gentle' },
        wavy: { cue: 'Rhythm begins with intention. Take one real step.', tone: 'motivated' },
        stable: { cue: 'Consistency grows from rhythm.', tone: 'balanced' },
        rising: { cue: 'You’re ready. Move with purpose.', tone: 'directive' }
      },
      emotional_reset: {
        collapsed: { cue: 'Slow down. You can begin again.', tone: 'gentle' },
        wavy: { cue: 'It’s okay to feel wavy. Let rhythm hold you.', tone: 'gentle' },
        stable: { cue: 'Even calm has direction. Choose one.', tone: 'rational' },
        rising: { cue: 'You’re not behind — you’re already shifting.', tone: 'motivated' }
      },
      milestone_project: {
        collapsed: { cue: 'Break it down. One block is enough.', tone: 'gentle' },
        wavy: { cue: 'Refocus. The next step is your anchor.', tone: 'motivated' },
        stable: { cue: 'You know what matters. Begin there.', tone: 'directive' },
        rising: { cue: 'Execute without hesitation.', tone: 'directive' }
      }
    };
  
    const intentMap = cueTemplateMap[intent];
    if (!intentMap) {
      return { cue: 'Let rhythm begin here.', tone: 'gentle' };
    }
  
    return intentMap[trend] || intentMap['stable'] || { cue: 'Begin where you are.', tone: 'gentle' };
  }
  