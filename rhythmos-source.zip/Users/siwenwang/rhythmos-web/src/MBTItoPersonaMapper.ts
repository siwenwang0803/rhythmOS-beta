// MBTItoPersonaMapper.ts

export type MBTIType =
  | 'INTJ' | 'INFJ' | 'ISTJ' | 'ISFJ'
  | 'ENTJ' | 'ENFJ' | 'ESTJ' | 'ESFJ'
  | 'INTP' | 'INFP' | 'ISTP' | 'ISFP'
  | 'ENTP' | 'ENFP' | 'ESTP' | 'ESFP'

export type PersonaId = 'caelum' | 'lucis' | 'niveus' | 'aurelia' | 'rhea'

const mbtiMap: Record<MBTIType, PersonaId> = {
  INTJ: 'caelum',
  INFJ: 'aurelia',
  ISTJ: 'niveus',
  ISFJ: 'rhea',
  ENTJ: 'caelum',
  ENFJ: 'lucis',
  ESTJ: 'lucis',
  ESFJ: 'rhea',
  INTP: 'niveus',
  INFP: 'aurelia',
  ISTP: 'niveus',
  ISFP: 'aurelia',
  ENTP: 'lucis',
  ENFP: 'rhea',
  ESTP: 'lucis',
  ESFP: 'rhea'
}

export function mapMBTItoPersona(mbti: MBTIType): PersonaId {
  return mbtiMap[mbti]
}