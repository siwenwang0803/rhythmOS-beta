export type RhythmTrend = 'collapsed' | 'wavy' | 'stable' | 'rising';
export type PersonaKey = 'rhea' | 'aurelia' | 'lucis' | 'niveus' | 'caelum';
export type ToneStyle = 'gentle' | 'directive' | 'rational' | 'visionary' | 'motivated';
