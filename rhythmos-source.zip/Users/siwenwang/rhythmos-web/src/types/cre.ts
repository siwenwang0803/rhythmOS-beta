// types/cre.ts
export interface GeneratedCRE {
  cue: string;
  paragraph: string;
  tone: string;
  persona: string;
  rhythm: string; // ✅ 新增
}

  