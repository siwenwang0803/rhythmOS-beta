// /src/types/creTypes.ts

export type CueStage = 'initial' | 'middle' | 'final';
export type CRETone = 'gentle' | 'directive' | 'rational' | 'motivated' | 'visionary' | 'balanced';
export type CREPersona = 'rhea' | 'caelum' | 'aurelia' | 'lucis' | 'niveus';
export type RhythmTrend = 'collapsed' | 'wavy' | 'stable' | 'rising';
export type CRESource = 'static' | 'gpt' | 'exploratory';

export interface CRECue {
  id?: string;
  cue: string;
  paragraph: string;
  persona: CREPersona;
  tone: CRETone;
  stage: CueStage;
  rhythm?: RhythmTrend;
  taskType?: string;
  voiceStyle?: string;
  source?: CRESource;
}
